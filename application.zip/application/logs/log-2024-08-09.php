<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-08-09 18:31:22 --> init client assets
ERROR - 2024-08-09 18:31:26 --> init client assets
ERROR - 2024-08-09 18:31:28 --> Could not find the language line "Prospect Details"
ERROR - 2024-08-09 18:31:28 --> Could not find the language line "First Name"
ERROR - 2024-08-09 18:31:28 --> Could not find the language line "Last Name"
ERROR - 2024-08-09 18:31:28 --> Could not find the language line "Phone"
ERROR - 2024-08-09 18:31:28 --> Could not find the language line "Email"
ERROR - 2024-08-09 18:31:28 --> Could not find the language line "Edit"
ERROR - 2024-08-09 18:31:28 --> Could not find the language line "Back to List"
