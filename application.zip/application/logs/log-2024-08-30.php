<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-08-30 11:47:20 --> Severity: Warning --> include_once(C:\xampp\htdocs\perfex_crm\application\hooks./../libraries/App_modules.php): Failed to open stream: Permission denied C:\xampp\htdocs\perfex_crm\application\hooks\InitModules.php 12
ERROR - 2024-08-30 11:47:20 --> Severity: Warning --> include_once(): Failed opening 'C:\xampp\htdocs\perfex_crm\application\hooks./../libraries/App_modules.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\perfex_crm\application\hooks\InitModules.php 12
ERROR - 2024-08-30 11:47:20 --> Severity: Warning --> include_once(C:\xampp\htdocs\perfex_crm\application\hooks./../../system/helpers/directory_helper.php): Failed to open stream: Permission denied C:\xampp\htdocs\perfex_crm\application\hooks\InitModules.php 14
ERROR - 2024-08-30 11:47:20 --> Severity: Warning --> include_once(): Failed opening 'C:\xampp\htdocs\perfex_crm\application\hooks./../../system/helpers/directory_helper.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\perfex_crm\application\hooks\InitModules.php 14
ERROR - 2024-08-30 11:47:20 --> Severity: error --> Exception: Class "App_modules" not found C:\xampp\htdocs\perfex_crm\application\hooks\InitModules.php 16
ERROR - 2024-08-30 14:48:00 --> client
ERROR - 2024-08-30 14:48:00 --> 12
ERROR - 2024-08-30 14:48:00 --> client
ERROR - 2024-08-30 14:49:21 --> Could not find the language line "total_campaigns"
ERROR - 2024-08-30 14:49:21 --> Could not find the language line "total_prospects"
ERROR - 2024-08-30 14:49:21 --> Could not find the language line "prospects_average_cost"
ERROR - 2024-08-30 14:49:21 --> Could not find the language line "reported_prospects"
ERROR - 2024-08-30 14:49:21 --> client
ERROR - 2024-08-30 14:49:21 --> 12
ERROR - 2024-08-30 14:49:21 --> client
ERROR - 2024-08-30 14:49:24 --> client
ERROR - 2024-08-30 14:49:24 --> 12
ERROR - 2024-08-30 14:49:24 --> client
ERROR - 2024-08-30 14:49:31 --> client
ERROR - 2024-08-30 14:49:31 --> 12
ERROR - 2024-08-30 14:49:31 --> client
ERROR - 2024-08-30 14:49:33 --> client
ERROR - 2024-08-30 14:49:33 --> 12
ERROR - 2024-08-30 14:49:33 --> client
ERROR - 2024-08-30 14:49:38 --> Could not find the language line "total_campaigns"
ERROR - 2024-08-30 14:49:38 --> Could not find the language line "total_prospects"
ERROR - 2024-08-30 14:49:38 --> Could not find the language line "prospects_average_cost"
ERROR - 2024-08-30 14:49:38 --> Could not find the language line "reported_prospects"
ERROR - 2024-08-30 14:49:38 --> client
ERROR - 2024-08-30 14:49:38 --> 12
ERROR - 2024-08-30 14:49:38 --> client
ERROR - 2024-08-30 14:49:44 --> Could not find the language line "total_campaigns"
ERROR - 2024-08-30 14:49:44 --> Could not find the language line "total_prospects"
ERROR - 2024-08-30 14:49:44 --> Could not find the language line "prospects_average_cost"
ERROR - 2024-08-30 14:49:44 --> Could not find the language line "reported_prospects"
ERROR - 2024-08-30 14:49:44 --> client
ERROR - 2024-08-30 14:49:44 --> 12
ERROR - 2024-08-30 14:49:44 --> client
ERROR - 2024-08-30 14:49:48 --> Could not find the language line "Onboarding"
ERROR - 2024-08-30 14:49:48 --> Could not find the language line "Onboarding"
ERROR - 2024-08-30 14:49:48 --> Could not find the language line "Invite Friend"
ERROR - 2024-08-30 14:49:48 --> Could not find the language line "Join our private Facebook group"
ERROR - 2024-08-30 14:49:48 --> Could not find the language line "group dedicated specifically for ambassadors. In the group, you'll get access to other successful ambassadors, learn the latest marketing strategies, get help from our support team, and stay informed on all the latest product updates."
ERROR - 2024-08-30 14:49:48 --> Could not find the language line "Sign Up for Alerts"
ERROR - 2024-08-30 14:49:48 --> Could not find the language line "Sign up for our email alerts to stay informed about the latest updates, opportunities, and important information."
ERROR - 2024-08-30 14:49:48 --> Could not find the language line "Complete and Continue"
ERROR - 2024-08-30 14:49:48 --> Could not find the language line "Continue"
ERROR - 2024-08-30 14:49:48 --> Could not find the language line "Onboarding Progress"
ERROR - 2024-08-30 14:49:48 --> Could not find the language line "Watch welcome message"
ERROR - 2024-08-30 14:49:48 --> Could not find the language line "Join Facebook group"
ERROR - 2024-08-30 14:49:48 --> Could not find the language line "Sign up for email alerts"
ERROR - 2024-08-30 14:49:48 --> Could not find the language line "Watch portal walkthrough"
ERROR - 2024-08-30 14:49:48 --> Could not find the language line "Understand the opportunity"
ERROR - 2024-08-30 14:49:48 --> Could not find the language line "Review available products"
ERROR - 2024-08-30 14:49:48 --> Could not find the language line "Who do you want to invite?"
ERROR - 2024-08-30 14:49:48 --> Could not find the language line "Send Invitation"
ERROR - 2024-08-30 14:49:48 --> Could not find the language line "Sign Up for Alerts"
ERROR - 2024-08-30 14:49:48 --> Could not find the language line "<i class="fa fa-exclamation-circle tw-mr-1"></i> We'll never send marketing emails through these alerts. These email alerts are strictly to inform you about Ambassador Program latest updates."
ERROR - 2024-08-30 14:49:48 --> Could not find the language line "Sign Up and Continue"
ERROR - 2024-08-30 14:49:48 --> Could not find the language line "Invitation sent!"
ERROR - 2024-08-30 14:49:48 --> client
ERROR - 2024-08-30 14:49:48 --> 12
ERROR - 2024-08-30 14:49:48 --> client
ERROR - 2024-08-30 14:49:53 --> Could not find the language line "New Prospect"
ERROR - 2024-08-30 14:49:53 --> Could not find the language line "Search Prospects"
ERROR - 2024-08-30 14:49:53 --> Could not find the language line "Filter By"
ERROR - 2024-08-30 14:49:53 --> Could not find the language line "Active Prospects"
ERROR - 2024-08-30 14:49:53 --> Could not find the language line "Inactive Prospects"
ERROR - 2024-08-30 14:49:53 --> Could not find the language line "No prospects found."
ERROR - 2024-08-30 14:49:53 --> client
ERROR - 2024-08-30 14:49:53 --> 12
ERROR - 2024-08-30 14:49:53 --> client
ERROR - 2024-08-30 14:49:54 --> step1
ERROR - 2024-08-30 14:49:54 --> step2
ERROR - 2024-08-30 14:49:54 --> step3
ERROR - 2024-08-30 14:49:54 --> Could not find the language line "Search Prospect Alerts"
ERROR - 2024-08-30 14:49:54 --> Could not find the language line "Filter By"
ERROR - 2024-08-30 14:49:54 --> Could not find the language line "All"
ERROR - 2024-08-30 14:49:54 --> Could not find the language line "Active"
ERROR - 2024-08-30 14:49:54 --> Could not find the language line "Inactive"
ERROR - 2024-08-30 14:49:54 --> Could not find the language line "New Prospect Alert"
ERROR - 2024-08-30 14:49:54 --> Could not find the language line "Active"
ERROR - 2024-08-30 14:49:54 --> Could not find the language line "Active"
ERROR - 2024-08-30 14:49:54 --> Could not find the language line "Active"
ERROR - 2024-08-30 14:49:54 --> client
ERROR - 2024-08-30 14:49:54 --> 12
ERROR - 2024-08-30 14:49:54 --> client
ERROR - 2024-08-30 14:49:56 --> Could not find the language line "clients_list_value"
ERROR - 2024-08-30 14:49:56 --> Could not find the language line "clients_list_tags"
ERROR - 2024-08-30 14:49:56 --> Could not find the language line "clients_list_status"
ERROR - 2024-08-30 14:49:56 --> Could not find the language line "clients_list_source"
ERROR - 2024-08-30 14:49:56 --> Could not find the language line "Stars"
ERROR - 2024-08-30 14:49:56 --> Could not find the language line "Reasons"
ERROR - 2024-08-30 14:49:56 --> Could not find the language line "Select Reason"
ERROR - 2024-08-30 14:49:56 --> Could not find the language line "Select Reason"
ERROR - 2024-08-30 14:49:56 --> Could not find the language line "Details"
ERROR - 2024-08-30 14:49:56 --> Could not find the language line "Name"
ERROR - 2024-08-30 14:49:56 --> Could not find the language line "Status"
ERROR - 2024-08-30 14:49:56 --> Could not find the language line "Type"
ERROR - 2024-08-30 14:49:56 --> Could not find the language line "Category"
ERROR - 2024-08-30 14:49:56 --> Could not find the language line "Acquisition Channels"
ERROR - 2024-08-30 14:49:56 --> Could not find the language line "Desired Amount"
ERROR - 2024-08-30 14:49:56 --> Could not find the language line "Industry"
ERROR - 2024-08-30 14:49:56 --> Could not find the language line "Upload Evidence (MP3)"
ERROR - 2024-08-30 14:49:56 --> Could not find the language line "Target CRM"
ERROR - 2024-08-30 14:49:56 --> Could not find the language line "Target CRM"
ERROR - 2024-08-30 14:49:56 --> client
ERROR - 2024-08-30 14:49:56 --> 12
ERROR - 2024-08-30 14:49:56 --> client
ERROR - 2024-08-30 14:49:57 --> Could not find the language line "Search Reported Prospects"
ERROR - 2024-08-30 14:49:57 --> Could not find the language line "Filter By"
ERROR - 2024-08-30 14:49:57 --> Could not find the language line "Active Reported Prospects"
ERROR - 2024-08-30 14:49:57 --> Could not find the language line "Inactive Reported Prospects"
ERROR - 2024-08-30 14:49:57 --> Could not find the language line "Prospect"
ERROR - 2024-08-30 14:49:57 --> Could not find the language line "Reason"
ERROR - 2024-08-30 14:49:57 --> Could not find the language line "Created At"
ERROR - 2024-08-30 14:49:57 --> Could not find the language line "Evidence"
ERROR - 2024-08-30 14:49:57 --> Could not find the language line "Actions"
ERROR - 2024-08-30 14:49:57 --> client
ERROR - 2024-08-30 14:49:57 --> 12
ERROR - 2024-08-30 14:49:57 --> client
ERROR - 2024-08-30 14:49:58 --> Could not find the language line "New Campaign"
ERROR - 2024-08-30 14:49:58 --> Could not find the language line "description"
ERROR - 2024-08-30 14:49:58 --> Could not find the language line "status"
ERROR - 2024-08-30 14:49:58 --> Could not find the language line "budget"
ERROR - 2024-08-30 14:49:58 --> Could not find the language line "deal"
ERROR - 2024-08-30 14:49:58 --> Could not find the language line "Start Date"
ERROR - 2024-08-30 14:49:58 --> Could not find the language line "End Date"
ERROR - 2024-08-30 14:49:58 --> Could not find the language line "Industry"
ERROR - 2024-08-30 14:49:58 --> Could not find the language line "Select Industry"
ERROR - 2024-08-30 14:49:58 --> Could not find the language line "Select Industry"
ERROR - 2024-08-30 14:49:58 --> Could not find the language line "countries"
ERROR - 2024-08-30 14:49:58 --> Could not find the language line "Select Country"
ERROR - 2024-08-30 14:49:58 --> Could not find the language line "Select Country"
ERROR - 2024-08-30 14:49:58 --> client
ERROR - 2024-08-30 14:49:58 --> 12
ERROR - 2024-08-30 14:49:58 --> client
ERROR - 2024-08-30 14:50:01 --> client
ERROR - 2024-08-30 14:50:01 --> 12
ERROR - 2024-08-30 14:50:01 --> client
ERROR - 2024-08-30 14:50:06 --> client
ERROR - 2024-08-30 14:50:06 --> 12
ERROR - 2024-08-30 14:50:06 --> client
ERROR - 2024-08-30 14:50:08 --> client
ERROR - 2024-08-30 14:50:08 --> 12
ERROR - 2024-08-30 14:50:08 --> client
ERROR - 2024-08-30 14:53:02 --> client
ERROR - 2024-08-30 14:53:02 --> 12
ERROR - 2024-08-30 14:53:02 --> client
ERROR - 2024-08-30 14:53:12 --> Could not find the language line "Onboarding"
ERROR - 2024-08-30 14:53:12 --> Could not find the language line "Onboarding"
ERROR - 2024-08-30 14:53:12 --> Could not find the language line "Invite Friend"
ERROR - 2024-08-30 14:53:12 --> Could not find the language line "Join our private Facebook group"
ERROR - 2024-08-30 14:53:12 --> Could not find the language line "group dedicated specifically for ambassadors. In the group, you'll get access to other successful ambassadors, learn the latest marketing strategies, get help from our support team, and stay informed on all the latest product updates."
ERROR - 2024-08-30 14:53:12 --> Could not find the language line "Sign Up for Alerts"
ERROR - 2024-08-30 14:53:12 --> Could not find the language line "Sign up for our email alerts to stay informed about the latest updates, opportunities, and important information."
ERROR - 2024-08-30 14:53:12 --> Could not find the language line "Complete and Continue"
ERROR - 2024-08-30 14:53:12 --> Could not find the language line "Continue"
ERROR - 2024-08-30 14:53:12 --> Could not find the language line "Onboarding Progress"
ERROR - 2024-08-30 14:53:12 --> Could not find the language line "Watch welcome message"
ERROR - 2024-08-30 14:53:12 --> Could not find the language line "Join Facebook group"
ERROR - 2024-08-30 14:53:12 --> Could not find the language line "Sign up for email alerts"
ERROR - 2024-08-30 14:53:12 --> Could not find the language line "Watch portal walkthrough"
ERROR - 2024-08-30 14:53:12 --> Could not find the language line "Understand the opportunity"
ERROR - 2024-08-30 14:53:12 --> Could not find the language line "Review available products"
ERROR - 2024-08-30 14:53:12 --> Could not find the language line "Who do you want to invite?"
ERROR - 2024-08-30 14:53:12 --> Could not find the language line "Send Invitation"
ERROR - 2024-08-30 14:53:12 --> Could not find the language line "Sign Up for Alerts"
ERROR - 2024-08-30 14:53:12 --> Could not find the language line "<i class="fa fa-exclamation-circle tw-mr-1"></i> We'll never send marketing emails through these alerts. These email alerts are strictly to inform you about Ambassador Program latest updates."
ERROR - 2024-08-30 14:53:12 --> Could not find the language line "Sign Up and Continue"
ERROR - 2024-08-30 14:53:12 --> Could not find the language line "Invitation sent!"
ERROR - 2024-08-30 14:53:12 --> client
ERROR - 2024-08-30 14:53:12 --> 12
ERROR - 2024-08-30 14:53:12 --> client
ERROR - 2024-08-30 14:53:16 --> client
ERROR - 2024-08-30 14:53:16 --> 12
ERROR - 2024-08-30 14:53:16 --> client
ERROR - 2024-08-30 14:53:29 --> client
ERROR - 2024-08-30 14:53:29 --> 12
ERROR - 2024-08-30 14:53:29 --> client
ERROR - 2024-08-30 14:53:32 --> client
ERROR - 2024-08-30 14:53:32 --> 12
ERROR - 2024-08-30 14:53:32 --> client
ERROR - 2024-08-30 14:53:34 --> client
ERROR - 2024-08-30 14:53:34 --> 12
ERROR - 2024-08-30 14:53:34 --> client
ERROR - 2024-08-30 14:56:53 --> client
ERROR - 2024-08-30 14:56:53 --> 12
ERROR - 2024-08-30 14:56:53 --> client
ERROR - 2024-08-30 15:03:16 --> client
ERROR - 2024-08-30 15:03:16 --> 12
ERROR - 2024-08-30 15:03:16 --> client
ERROR - 2024-08-30 15:03:18 --> client
ERROR - 2024-08-30 15:03:18 --> 12
ERROR - 2024-08-30 15:03:18 --> client
ERROR - 2024-08-30 15:03:20 --> client
ERROR - 2024-08-30 15:03:20 --> 12
ERROR - 2024-08-30 15:03:20 --> client
ERROR - 2024-08-30 15:03:22 --> client
ERROR - 2024-08-30 15:03:22 --> 12
ERROR - 2024-08-30 15:03:22 --> client
ERROR - 2024-08-30 15:03:29 --> client
ERROR - 2024-08-30 15:03:29 --> 12
ERROR - 2024-08-30 15:03:29 --> client
ERROR - 2024-08-30 15:13:47 --> Could not find the language line "New Prospect"
ERROR - 2024-08-30 15:13:47 --> Could not find the language line "Search Prospects"
ERROR - 2024-08-30 15:13:47 --> Could not find the language line "Filter By"
ERROR - 2024-08-30 15:13:47 --> Could not find the language line "Active Prospects"
ERROR - 2024-08-30 15:13:47 --> Could not find the language line "Inactive Prospects"
ERROR - 2024-08-30 15:13:47 --> Could not find the language line "No prospects found."
ERROR - 2024-08-30 15:13:47 --> client
ERROR - 2024-08-30 15:13:47 --> 12
ERROR - 2024-08-30 15:13:47 --> client
ERROR - 2024-08-30 15:14:17 --> client
ERROR - 2024-08-30 15:14:17 --> 12
ERROR - 2024-08-30 15:14:17 --> client
ERROR - 2024-08-30 15:14:19 --> client
ERROR - 2024-08-30 15:14:19 --> 12
ERROR - 2024-08-30 15:14:19 --> client
ERROR - 2024-08-30 15:16:00 --> client
ERROR - 2024-08-30 15:16:00 --> 12
ERROR - 2024-08-30 15:16:00 --> client
ERROR - 2024-08-30 15:16:22 --> client
ERROR - 2024-08-30 15:16:22 --> 12
ERROR - 2024-08-30 15:16:22 --> client
ERROR - 2024-08-30 15:16:24 --> client
ERROR - 2024-08-30 15:16:24 --> 12
ERROR - 2024-08-30 15:16:24 --> client
ERROR - 2024-08-30 15:16:28 --> client
ERROR - 2024-08-30 15:16:28 --> 12
ERROR - 2024-08-30 15:16:28 --> client
ERROR - 2024-08-30 15:16:30 --> step1
ERROR - 2024-08-30 15:16:30 --> step2
ERROR - 2024-08-30 15:16:30 --> step3
ERROR - 2024-08-30 15:16:30 --> Could not find the language line "Search Prospect Alerts"
ERROR - 2024-08-30 15:16:30 --> Could not find the language line "Filter By"
ERROR - 2024-08-30 15:16:30 --> Could not find the language line "All"
ERROR - 2024-08-30 15:16:30 --> Could not find the language line "Active"
ERROR - 2024-08-30 15:16:30 --> Could not find the language line "Inactive"
ERROR - 2024-08-30 15:16:30 --> Could not find the language line "New Prospect Alert"
ERROR - 2024-08-30 15:16:30 --> Could not find the language line "Active"
ERROR - 2024-08-30 15:16:30 --> Could not find the language line "Active"
ERROR - 2024-08-30 15:16:30 --> Could not find the language line "Active"
ERROR - 2024-08-30 15:16:30 --> client
ERROR - 2024-08-30 15:16:30 --> 12
ERROR - 2024-08-30 15:16:30 --> client
ERROR - 2024-08-30 15:16:49 --> client
ERROR - 2024-08-30 15:16:49 --> 12
ERROR - 2024-08-30 15:16:49 --> client
ERROR - 2024-08-30 15:17:13 --> client
ERROR - 2024-08-30 15:17:13 --> 12
ERROR - 2024-08-30 15:17:13 --> client
ERROR - 2024-08-30 15:17:15 --> client
ERROR - 2024-08-30 15:17:15 --> 12
ERROR - 2024-08-30 15:17:15 --> client
ERROR - 2024-08-30 15:17:17 --> client
ERROR - 2024-08-30 15:17:17 --> 12
ERROR - 2024-08-30 15:17:17 --> client
ERROR - 2024-08-30 15:17:19 --> client
ERROR - 2024-08-30 15:17:19 --> 12
ERROR - 2024-08-30 15:17:19 --> client
ERROR - 2024-08-30 15:17:36 --> client
ERROR - 2024-08-30 15:17:36 --> 12
ERROR - 2024-08-30 15:17:36 --> client
ERROR - 2024-08-30 15:17:59 --> client
ERROR - 2024-08-30 15:17:59 --> 12
ERROR - 2024-08-30 15:17:59 --> client
ERROR - 2024-08-30 15:18:01 --> client
ERROR - 2024-08-30 15:18:01 --> 12
ERROR - 2024-08-30 15:18:01 --> client
ERROR - 2024-08-30 15:18:02 --> client
ERROR - 2024-08-30 15:18:02 --> 12
ERROR - 2024-08-30 15:18:02 --> client
ERROR - 2024-08-30 15:18:03 --> Could not find the language line "Statistics"
ERROR - 2024-08-30 15:18:03 --> client
ERROR - 2024-08-30 15:18:03 --> 12
ERROR - 2024-08-30 15:18:03 --> client
ERROR - 2024-08-30 15:18:24 --> client
ERROR - 2024-08-30 15:18:24 --> 12
ERROR - 2024-08-30 15:18:24 --> client
ERROR - 2024-08-30 15:18:30 --> external-form
ERROR - 2024-08-30 15:18:30 --> 8
ERROR - 2024-08-30 15:18:30 --> external-form
ERROR - 2024-08-30 15:18:32 --> client
ERROR - 2024-08-30 15:18:32 --> 12
ERROR - 2024-08-30 15:18:32 --> client
ERROR - 2024-08-30 15:18:35 --> client
ERROR - 2024-08-30 15:18:35 --> 12
ERROR - 2024-08-30 15:18:35 --> client
ERROR - 2024-08-30 15:18:38 --> client
ERROR - 2024-08-30 15:18:38 --> 12
ERROR - 2024-08-30 15:18:38 --> client
ERROR - 2024-08-30 15:18:42 --> client
ERROR - 2024-08-30 15:18:42 --> 12
ERROR - 2024-08-30 15:18:42 --> client
ERROR - 2024-08-30 15:18:45 --> client
ERROR - 2024-08-30 15:18:45 --> 12
ERROR - 2024-08-30 15:18:45 --> client
