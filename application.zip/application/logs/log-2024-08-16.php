<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-08-16 11:39:58 --> Could not find the language line "Information Points"
ERROR - 2024-08-16 11:39:58 --> Could not find the language line "billings"
ERROR - 2024-08-16 11:39:58 --> Could not find the language line "appointment_you_have_new_appointment"
ERROR - 2024-08-16 11:39:58 --> Could not find the language line "appointment_you_have_new_appointment"
ERROR - 2024-08-16 11:39:58 --> Could not find the language line "appointment_you_have_new_appointment"
ERROR - 2024-08-16 11:39:58 --> admin
ERROR - 2024-08-16 11:39:58 --> 12
ERROR - 2024-08-16 11:39:58 --> admin
ERROR - 2024-08-16 11:39:59 --> Could not find the language line "Information Points"
ERROR - 2024-08-16 11:39:59 --> Could not find the language line "billings"
ERROR - 2024-08-16 11:40:57 --> Severity: error --> Exception: Too few arguments to function Invoices_model::get_max_invoice_number(), 0 passed in /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/controllers/Cart.php on line 48 and exactly 1 expected /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/models/Invoices_model.php 1904
ERROR - 2024-08-16 11:41:17 --> Severity: Warning --> Undefined array key "name" /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/controllers/Cart.php 87
ERROR - 2024-08-16 11:41:17 --> Severity: Warning --> Undefined array key "description" /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/controllers/Cart.php 88
ERROR - 2024-08-16 11:41:17 --> Severity: Warning --> Undefined array key "price" /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/controllers/Cart.php 89
ERROR - 2024-08-16 11:41:17 --> Severity: Warning --> Undefined array key "name" /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/controllers/Cart.php 87
ERROR - 2024-08-16 11:41:17 --> Severity: Warning --> Undefined array key "description" /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/controllers/Cart.php 88
ERROR - 2024-08-16 11:41:17 --> Severity: Warning --> Undefined array key "price" /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/controllers/Cart.php 89
ERROR - 2024-08-16 11:41:17 --> Severity: Warning --> Undefined array key "name" /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/controllers/Cart.php 87
ERROR - 2024-08-16 11:41:17 --> Severity: Warning --> Undefined array key "description" /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/controllers/Cart.php 88
ERROR - 2024-08-16 11:41:17 --> Severity: Warning --> Undefined array key "price" /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/controllers/Cart.php 89
ERROR - 2024-08-16 11:41:17 --> Severity: Warning --> Undefined array key "number" /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/controllers/Cart.php 99
ERROR - 2024-08-16 11:41:17 --> Severity: 8192 --> ltrim(): Passing null to parameter #1 ($string) of type string is deprecated /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/controllers/Cart.php 99
ERROR - 2024-08-16 11:41:17 --> Severity: error --> Exception: Unknown column 'invoice_number' in 'field list' /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/system/database/drivers/mysqli/mysqli_driver.php 307
ERROR - 2024-08-16 11:41:17 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/system/core/Exceptions.php:271) /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/system/core/Common.php 574
ERROR - 2024-08-16 11:42:05 --> Severity: Warning --> Undefined array key "phone" /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/controllers/Cart.php 88
ERROR - 2024-08-16 11:42:05 --> Severity: Warning --> Undefined array key "desired_price" /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/controllers/Cart.php 89
ERROR - 2024-08-16 11:42:05 --> Severity: Warning --> Undefined array key "phone" /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/controllers/Cart.php 88
ERROR - 2024-08-16 11:42:05 --> Severity: Warning --> Undefined array key "desired_price" /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/controllers/Cart.php 89
ERROR - 2024-08-16 11:42:05 --> Severity: Warning --> Undefined array key "phone" /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/controllers/Cart.php 88
ERROR - 2024-08-16 11:42:05 --> Severity: Warning --> Undefined array key "desired_price" /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/controllers/Cart.php 89
ERROR - 2024-08-16 11:42:05 --> Severity: Warning --> Undefined array key "number" /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/controllers/Cart.php 99
ERROR - 2024-08-16 11:42:05 --> Severity: 8192 --> ltrim(): Passing null to parameter #1 ($string) of type string is deprecated /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/controllers/Cart.php 99
ERROR - 2024-08-16 11:42:05 --> Severity: error --> Exception: Unknown column 'invoice_number' in 'field list' /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/system/database/drivers/mysqli/mysqli_driver.php 307
ERROR - 2024-08-16 11:42:05 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/system/core/Exceptions.php:271) /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/system/core/Common.php 574
ERROR - 2024-08-16 11:42:22 --> Severity: Warning --> Undefined array key "phone" /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/controllers/Cart.php 88
ERROR - 2024-08-16 11:42:22 --> Severity: Warning --> Undefined array key "desired_price" /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/controllers/Cart.php 89
ERROR - 2024-08-16 11:42:22 --> Severity: Warning --> Undefined array key "phone" /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/controllers/Cart.php 88
ERROR - 2024-08-16 11:42:22 --> Severity: Warning --> Undefined array key "desired_price" /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/controllers/Cart.php 89
ERROR - 2024-08-16 11:42:22 --> Severity: Warning --> Undefined array key "phone" /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/controllers/Cart.php 88
ERROR - 2024-08-16 11:42:22 --> Severity: Warning --> Undefined array key "desired_price" /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/controllers/Cart.php 89
ERROR - 2024-08-16 11:42:22 --> Severity: Warning --> Undefined array key "number" /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/controllers/Cart.php 99
ERROR - 2024-08-16 11:42:22 --> Severity: 8192 --> ltrim(): Passing null to parameter #1 ($string) of type string is deprecated /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/controllers/Cart.php 99
ERROR - 2024-08-16 11:42:22 --> Severity: error --> Exception: Unknown column 'invoice_number' in 'field list' /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/system/database/drivers/mysqli/mysqli_driver.php 307
ERROR - 2024-08-16 11:42:22 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/system/core/Exceptions.php:271) /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/system/core/Common.php 574
ERROR - 2024-08-16 11:44:25 --> Severity: Warning --> Undefined array key "id" /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/controllers/Cart.php 84
ERROR - 2024-08-16 11:44:25 --> Severity: Warning --> Undefined array key "last_name" /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/controllers/Cart.php 87
ERROR - 2024-08-16 11:44:25 --> Severity: Warning --> Undefined array key "id" /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/controllers/Cart.php 88
ERROR - 2024-08-16 11:44:25 --> Severity: Warning --> Trying to access array offset on value of type null /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/controllers/Cart.php 88
ERROR - 2024-08-16 11:44:25 --> Severity: Warning --> Trying to access array offset on value of type null /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/controllers/Cart.php 89
ERROR - 2024-08-16 11:44:25 --> Severity: Warning --> Undefined array key "id" /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/controllers/Cart.php 84
ERROR - 2024-08-16 11:44:25 --> Severity: Warning --> Undefined array key "last_name" /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/controllers/Cart.php 87
ERROR - 2024-08-16 11:44:25 --> Severity: Warning --> Undefined array key "id" /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/controllers/Cart.php 88
ERROR - 2024-08-16 11:44:25 --> Severity: Warning --> Trying to access array offset on value of type null /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/controllers/Cart.php 88
ERROR - 2024-08-16 11:44:25 --> Severity: Warning --> Trying to access array offset on value of type null /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/controllers/Cart.php 89
ERROR - 2024-08-16 11:44:25 --> Severity: Warning --> Undefined array key "id" /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/controllers/Cart.php 84
ERROR - 2024-08-16 11:44:25 --> Severity: Warning --> Undefined array key "last_name" /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/controllers/Cart.php 87
ERROR - 2024-08-16 11:44:25 --> Severity: Warning --> Undefined array key "id" /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/controllers/Cart.php 88
ERROR - 2024-08-16 11:44:25 --> Severity: Warning --> Trying to access array offset on value of type null /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/controllers/Cart.php 88
ERROR - 2024-08-16 11:44:25 --> Severity: Warning --> Trying to access array offset on value of type null /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/controllers/Cart.php 89
ERROR - 2024-08-16 11:44:25 --> Severity: Warning --> Undefined array key "number" /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/controllers/Cart.php 99
ERROR - 2024-08-16 11:44:25 --> Severity: 8192 --> ltrim(): Passing null to parameter #1 ($string) of type string is deprecated /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/controllers/Cart.php 99
ERROR - 2024-08-16 11:44:25 --> Severity: error --> Exception: Unknown column 'invoice_number' in 'field list' /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/system/database/drivers/mysqli/mysqli_driver.php 307
ERROR - 2024-08-16 11:44:25 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/system/core/Exceptions.php:271) /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/system/core/Common.php 574
ERROR - 2024-08-16 11:44:48 --> Severity: Warning --> Undefined array key "last_name" /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/controllers/Cart.php 87
ERROR - 2024-08-16 11:44:48 --> Severity: Warning --> Undefined array key "desired_price" /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/controllers/Cart.php 89
ERROR - 2024-08-16 11:44:48 --> Severity: Warning --> Undefined array key "last_name" /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/controllers/Cart.php 87
ERROR - 2024-08-16 11:44:48 --> Severity: Warning --> Undefined array key "desired_price" /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/controllers/Cart.php 89
ERROR - 2024-08-16 11:44:48 --> Severity: Warning --> Undefined array key "last_name" /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/controllers/Cart.php 87
ERROR - 2024-08-16 11:44:48 --> Severity: Warning --> Undefined array key "desired_price" /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/controllers/Cart.php 89
ERROR - 2024-08-16 11:44:48 --> Severity: Warning --> Undefined array key "number" /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/controllers/Cart.php 99
ERROR - 2024-08-16 11:44:48 --> Severity: 8192 --> ltrim(): Passing null to parameter #1 ($string) of type string is deprecated /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/controllers/Cart.php 99
ERROR - 2024-08-16 11:44:48 --> Severity: error --> Exception: Unknown column 'invoice_number' in 'field list' /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/system/database/drivers/mysqli/mysqli_driver.php 307
ERROR - 2024-08-16 11:44:48 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/system/core/Exceptions.php:271) /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/system/core/Common.php 574
ERROR - 2024-08-16 11:45:11 --> Severity: Warning --> Undefined array key "desired_price" /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/controllers/Cart.php 89
ERROR - 2024-08-16 11:45:11 --> Severity: Warning --> Undefined array key "desired_price" /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/controllers/Cart.php 89
ERROR - 2024-08-16 11:45:11 --> Severity: Warning --> Undefined array key "desired_price" /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/controllers/Cart.php 89
ERROR - 2024-08-16 11:45:11 --> Severity: Warning --> Undefined array key "number" /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/controllers/Cart.php 99
ERROR - 2024-08-16 11:45:11 --> Severity: 8192 --> ltrim(): Passing null to parameter #1 ($string) of type string is deprecated /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/controllers/Cart.php 99
ERROR - 2024-08-16 11:45:11 --> Severity: error --> Exception: Unknown column 'invoice_number' in 'field list' /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/system/database/drivers/mysqli/mysqli_driver.php 307
ERROR - 2024-08-16 11:45:41 --> Severity: Warning --> Undefined array key "number" /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/controllers/Cart.php 99
ERROR - 2024-08-16 11:45:41 --> Severity: 8192 --> ltrim(): Passing null to parameter #1 ($string) of type string is deprecated /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/controllers/Cart.php 99
ERROR - 2024-08-16 11:45:41 --> Severity: error --> Exception: Unknown column 'invoice_number' in 'field list' /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/system/database/drivers/mysqli/mysqli_driver.php 307
ERROR - 2024-08-16 11:47:01 --> Severity: Warning --> Attempt to read property "firstname" on array /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/helpers/staff_helper.php 298
ERROR - 2024-08-16 11:47:01 --> Severity: Warning --> Attempt to read property "lastname" on array /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/helpers/staff_helper.php 298
ERROR - 2024-08-16 11:47:01 --> Severity: 8192 --> number_format(): Passing null to parameter #1 ($num) of type float is deprecated /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/helpers/sales_helper.php 684
ERROR - 2024-08-16 11:47:01 --> Severity: Warning --> Undefined array key "order" /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/helpers/sales_helper.php 687
ERROR - 2024-08-16 11:47:01 --> Severity: Warning --> Undefined array key "unit" /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/helpers/sales_helper.php 688
ERROR - 2024-08-16 11:47:01 --> Severity: 8192 --> number_format(): Passing null to parameter #1 ($num) of type float is deprecated /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/helpers/sales_helper.php 684
ERROR - 2024-08-16 11:47:01 --> Severity: Warning --> Undefined array key "order" /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/helpers/sales_helper.php 687
ERROR - 2024-08-16 11:47:01 --> Severity: Warning --> Undefined array key "unit" /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/helpers/sales_helper.php 688
ERROR - 2024-08-16 11:47:01 --> Severity: 8192 --> number_format(): Passing null to parameter #1 ($num) of type float is deprecated /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/helpers/sales_helper.php 684
ERROR - 2024-08-16 11:47:01 --> Severity: Warning --> Undefined array key "order" /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/helpers/sales_helper.php 687
ERROR - 2024-08-16 11:47:01 --> Severity: Warning --> Undefined array key "unit" /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/helpers/sales_helper.php 688
ERROR - 2024-08-16 11:47:01 --> Severity: Warning --> Attempt to read property "firstname" on array /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/helpers/staff_helper.php 298
ERROR - 2024-08-16 11:47:01 --> Severity: Warning --> Attempt to read property "lastname" on array /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/helpers/staff_helper.php 298
ERROR - 2024-08-16 11:51:51 --> Severity: Warning --> Attempt to read property "firstname" on array /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/helpers/staff_helper.php 298
ERROR - 2024-08-16 11:51:51 --> Severity: Warning --> Attempt to read property "lastname" on array /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/helpers/staff_helper.php 298
ERROR - 2024-08-16 11:51:51 --> Severity: 8192 --> number_format(): Passing null to parameter #1 ($num) of type float is deprecated /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/helpers/sales_helper.php 684
ERROR - 2024-08-16 11:51:51 --> Severity: Warning --> Undefined array key "order" /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/helpers/sales_helper.php 687
ERROR - 2024-08-16 11:51:51 --> Severity: Warning --> Undefined array key "unit" /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/helpers/sales_helper.php 688
ERROR - 2024-08-16 11:51:51 --> Severity: 8192 --> number_format(): Passing null to parameter #1 ($num) of type float is deprecated /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/helpers/sales_helper.php 684
ERROR - 2024-08-16 11:51:51 --> Severity: Warning --> Undefined array key "order" /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/helpers/sales_helper.php 687
ERROR - 2024-08-16 11:51:51 --> Severity: Warning --> Undefined array key "unit" /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/helpers/sales_helper.php 688
ERROR - 2024-08-16 11:51:51 --> Severity: 8192 --> number_format(): Passing null to parameter #1 ($num) of type float is deprecated /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/helpers/sales_helper.php 684
ERROR - 2024-08-16 11:51:51 --> Severity: Warning --> Undefined array key "order" /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/helpers/sales_helper.php 687
ERROR - 2024-08-16 11:51:51 --> Severity: Warning --> Undefined array key "unit" /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/helpers/sales_helper.php 688
ERROR - 2024-08-16 11:51:51 --> Severity: Warning --> Attempt to read property "firstname" on array /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/helpers/staff_helper.php 298
ERROR - 2024-08-16 11:51:51 --> Severity: Warning --> Attempt to read property "lastname" on array /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/helpers/staff_helper.php 298
ERROR - 2024-08-16 11:53:51 --> Severity: 8192 --> number_format(): Passing null to parameter #1 ($num) of type float is deprecated /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/helpers/sales_helper.php 684
ERROR - 2024-08-16 11:53:51 --> Severity: Warning --> Undefined array key "order" /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/helpers/sales_helper.php 687
ERROR - 2024-08-16 11:53:51 --> Severity: Warning --> Undefined array key "unit" /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/helpers/sales_helper.php 688
ERROR - 2024-08-16 11:53:51 --> Severity: 8192 --> number_format(): Passing null to parameter #1 ($num) of type float is deprecated /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/helpers/sales_helper.php 684
ERROR - 2024-08-16 11:53:51 --> Severity: Warning --> Undefined array key "order" /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/helpers/sales_helper.php 687
ERROR - 2024-08-16 11:53:51 --> Severity: Warning --> Undefined array key "unit" /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/helpers/sales_helper.php 688
ERROR - 2024-08-16 11:53:51 --> Severity: 8192 --> number_format(): Passing null to parameter #1 ($num) of type float is deprecated /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/helpers/sales_helper.php 684
ERROR - 2024-08-16 11:53:51 --> Severity: Warning --> Undefined array key "order" /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/helpers/sales_helper.php 687
ERROR - 2024-08-16 11:53:51 --> Severity: Warning --> Undefined array key "unit" /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/helpers/sales_helper.php 688
ERROR - 2024-08-16 11:54:44 --> Severity: 8192 --> number_format(): Passing null to parameter #1 ($num) of type float is deprecated /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/helpers/sales_helper.php 684
ERROR - 2024-08-16 11:54:44 --> Severity: Warning --> Undefined array key "order" /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/helpers/sales_helper.php 687
ERROR - 2024-08-16 11:54:44 --> Severity: Warning --> Undefined array key "unit" /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/helpers/sales_helper.php 688
ERROR - 2024-08-16 11:54:44 --> Severity: 8192 --> number_format(): Passing null to parameter #1 ($num) of type float is deprecated /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/helpers/sales_helper.php 684
ERROR - 2024-08-16 11:54:44 --> Severity: Warning --> Undefined array key "order" /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/helpers/sales_helper.php 687
ERROR - 2024-08-16 11:54:44 --> Severity: Warning --> Undefined array key "unit" /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/helpers/sales_helper.php 688
ERROR - 2024-08-16 11:54:44 --> Severity: 8192 --> number_format(): Passing null to parameter #1 ($num) of type float is deprecated /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/helpers/sales_helper.php 684
ERROR - 2024-08-16 11:54:44 --> Severity: Warning --> Undefined array key "order" /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/helpers/sales_helper.php 687
ERROR - 2024-08-16 11:54:44 --> Severity: Warning --> Undefined array key "unit" /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/helpers/sales_helper.php 688
ERROR - 2024-08-16 11:55:49 --> Severity: Warning --> Undefined array key "order" /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/helpers/sales_helper.php 687
ERROR - 2024-08-16 11:55:49 --> Severity: Warning --> Undefined array key "unit" /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/helpers/sales_helper.php 688
ERROR - 2024-08-16 11:55:49 --> Severity: Warning --> Undefined array key "order" /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/helpers/sales_helper.php 687
ERROR - 2024-08-16 11:55:49 --> Severity: Warning --> Undefined array key "unit" /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/helpers/sales_helper.php 688
ERROR - 2024-08-16 11:55:49 --> Severity: Warning --> Undefined array key "order" /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/helpers/sales_helper.php 687
ERROR - 2024-08-16 11:55:49 --> Severity: Warning --> Undefined array key "unit" /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/helpers/sales_helper.php 688
ERROR - 2024-08-16 11:57:52 --> Could not find the language line "Information Points"
ERROR - 2024-08-16 11:57:52 --> Could not find the language line "billings"
ERROR - 2024-08-16 11:57:52 --> Could not find the language line "appointment_you_have_new_appointment"
ERROR - 2024-08-16 11:57:52 --> Could not find the language line "appointment_you_have_new_appointment"
ERROR - 2024-08-16 11:57:52 --> Could not find the language line "appointment_you_have_new_appointment"
ERROR - 2024-08-16 11:57:52 --> admin
ERROR - 2024-08-16 11:57:52 --> 12
ERROR - 2024-08-16 11:57:52 --> admin
ERROR - 2024-08-16 08:57:53 --> 404 Page Not Found: /index
ERROR - 2024-08-16 11:57:53 --> Could not find the language line "Information Points"
ERROR - 2024-08-16 11:57:53 --> Could not find the language line "billings"
ERROR - 2024-08-16 11:57:57 --> Could not find the language line "Information Points"
ERROR - 2024-08-16 11:57:57 --> Could not find the language line "billings"
ERROR - 2024-08-16 11:57:57 --> Could not find the language line "appointment_you_have_new_appointment"
ERROR - 2024-08-16 11:57:57 --> Could not find the language line "appointment_you_have_new_appointment"
ERROR - 2024-08-16 11:57:57 --> Could not find the language line "appointment_you_have_new_appointment"
ERROR - 2024-08-16 11:57:57 --> admin
ERROR - 2024-08-16 11:57:57 --> 12
ERROR - 2024-08-16 11:57:57 --> admin
ERROR - 2024-08-16 11:57:58 --> Could not find the language line "Information Points"
ERROR - 2024-08-16 11:57:58 --> Could not find the language line "billings"
ERROR - 2024-08-16 11:57:58 --> Could not find the language line "Information Points"
ERROR - 2024-08-16 11:57:58 --> Could not find the language line "billings"
ERROR - 2024-08-16 11:57:58 --> Could not find the language line "appointment_you_have_new_appointment"
ERROR - 2024-08-16 11:57:58 --> Could not find the language line "appointment_you_have_new_appointment"
ERROR - 2024-08-16 11:57:58 --> Could not find the language line "appointment_you_have_new_appointment"
ERROR - 2024-08-16 11:57:58 --> admin
ERROR - 2024-08-16 11:57:58 --> 12
ERROR - 2024-08-16 11:57:58 --> admin
ERROR - 2024-08-16 11:57:59 --> Could not find the language line "Information Points"
ERROR - 2024-08-16 11:57:59 --> Could not find the language line "billings"
ERROR - 2024-08-16 16:05:16 --> Could not find the language line "New Campaign"
ERROR - 2024-08-16 16:05:16 --> Could not find the language line "description"
ERROR - 2024-08-16 16:05:16 --> Could not find the language line "status"
ERROR - 2024-08-16 16:05:16 --> Could not find the language line "budget"
ERROR - 2024-08-16 16:05:16 --> Could not find the language line "deal"
ERROR - 2024-08-16 16:05:16 --> Could not find the language line "Start Date"
ERROR - 2024-08-16 16:05:16 --> Could not find the language line "End Date"
ERROR - 2024-08-16 16:05:16 --> Could not find the language line "Industry"
ERROR - 2024-08-16 16:05:16 --> Could not find the language line "Select Industry"
ERROR - 2024-08-16 16:05:16 --> Could not find the language line "Select Industry"
ERROR - 2024-08-16 16:05:16 --> Could not find the language line "countries"
ERROR - 2024-08-16 16:05:16 --> Could not find the language line "Select Country"
ERROR - 2024-08-16 16:05:16 --> Could not find the language line "Select Country"
ERROR - 2024-08-16 16:05:16 --> client
ERROR - 2024-08-16 16:05:16 --> 12
ERROR - 2024-08-16 16:05:16 --> client
ERROR - 2024-08-16 16:05:41 --> Could not find the language line "New Campaign"
ERROR - 2024-08-16 16:05:41 --> Could not find the language line "description"
ERROR - 2024-08-16 16:05:41 --> Could not find the language line "status"
ERROR - 2024-08-16 16:05:41 --> Could not find the language line "budget"
ERROR - 2024-08-16 16:05:41 --> Could not find the language line "deal"
ERROR - 2024-08-16 16:05:41 --> Could not find the language line "Start Date"
ERROR - 2024-08-16 16:05:41 --> Could not find the language line "End Date"
ERROR - 2024-08-16 16:05:41 --> Could not find the language line "Industry"
ERROR - 2024-08-16 16:05:41 --> Could not find the language line "Select Industry"
ERROR - 2024-08-16 16:05:41 --> Could not find the language line "Select Industry"
ERROR - 2024-08-16 16:05:41 --> Could not find the language line "countries"
ERROR - 2024-08-16 16:05:41 --> Could not find the language line "Select Country"
ERROR - 2024-08-16 16:05:41 --> Could not find the language line "Select Country"
ERROR - 2024-08-16 16:05:41 --> client
ERROR - 2024-08-16 16:05:41 --> 12
ERROR - 2024-08-16 16:05:41 --> client
ERROR - 2024-08-16 16:06:09 --> ---->End date cannot be before the start date..
ERROR - 2024-08-16 16:10:40 --> ---->End date cannot be before the start date..
ERROR - 2024-08-16 16:10:58 --> ---->End date cannot be before the start date..
ERROR - 2024-08-16 16:11:04 --> Could not find the language line "New Campaign"
ERROR - 2024-08-16 16:11:04 --> Could not find the language line "description"
ERROR - 2024-08-16 16:11:04 --> Could not find the language line "status"
ERROR - 2024-08-16 16:11:04 --> Could not find the language line "budget"
ERROR - 2024-08-16 16:11:04 --> Could not find the language line "deal"
ERROR - 2024-08-16 16:11:04 --> Could not find the language line "Start Date"
ERROR - 2024-08-16 16:11:04 --> Could not find the language line "End Date"
ERROR - 2024-08-16 16:11:04 --> Could not find the language line "Industry"
ERROR - 2024-08-16 16:11:04 --> Could not find the language line "Select Industry"
ERROR - 2024-08-16 16:11:04 --> Could not find the language line "Select Industry"
ERROR - 2024-08-16 16:11:04 --> Could not find the language line "countries"
ERROR - 2024-08-16 16:11:04 --> Could not find the language line "Select Country"
ERROR - 2024-08-16 16:11:04 --> Could not find the language line "Select Country"
ERROR - 2024-08-16 16:11:04 --> client
ERROR - 2024-08-16 16:11:04 --> 12
ERROR - 2024-08-16 16:11:04 --> client
ERROR - 2024-08-16 16:11:46 -->  creating invoice
ERROR - 2024-08-16 16:11:46 -->  created invoice
ERROR - 2024-08-16 16:11:46 --> Severity: error --> Exception: Table 'perfex_crm.tblcampaigns' doesn't exist C:\xampp\htdocs\perfex_crm\system\database\drivers\mysqli\mysqli_driver.php 307
ERROR - 2024-08-16 16:12:21 -->  creating invoice
ERROR - 2024-08-16 16:12:21 -->  created invoice
ERROR - 2024-08-16 16:12:21 --> Severity: error --> Exception: Call to undefined method Client_invoices_model::get_invoice() C:\xampp\htdocs\perfex_crm\application\controllers\Campaigns.php 114
ERROR - 2024-08-16 16:16:03 -->  creating invoice
ERROR - 2024-08-16 16:16:03 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\perfex_crm\application\controllers\Campaigns.php 112
ERROR - 2024-08-16 16:16:03 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\perfex_crm\application\controllers\Campaigns.php 114
ERROR - 2024-08-16 16:16:45 -->  creating invoice
ERROR - 2024-08-16 16:17:02 --> 404 Page Not Found: 
ERROR - 2024-08-16 16:17:15 --> client
ERROR - 2024-08-16 16:17:15 --> 12
ERROR - 2024-08-16 16:17:15 --> client
ERROR - 2024-08-16 16:17:27 --> Severity: error --> Exception: Table 'perfex_crm.tblviews_tracking' doesn't exist C:\xampp\htdocs\perfex_crm\system\database\drivers\mysqli\mysqli_driver.php 307
ERROR - 2024-08-16 16:17:43 --> client
ERROR - 2024-08-16 16:17:43 --> 12
ERROR - 2024-08-16 16:17:43 --> client
ERROR - 2024-08-16 16:24:36 --> client
ERROR - 2024-08-16 16:24:36 --> 12
ERROR - 2024-08-16 16:24:36 --> client
ERROR - 2024-08-16 16:24:41 --> Could not find the language line "New Campaign"
ERROR - 2024-08-16 16:24:41 --> Could not find the language line "description"
ERROR - 2024-08-16 16:24:41 --> Could not find the language line "status"
ERROR - 2024-08-16 16:24:41 --> Could not find the language line "budget"
ERROR - 2024-08-16 16:24:41 --> Could not find the language line "deal"
ERROR - 2024-08-16 16:24:41 --> Could not find the language line "Start Date"
ERROR - 2024-08-16 16:24:41 --> Could not find the language line "End Date"
ERROR - 2024-08-16 16:24:41 --> Could not find the language line "Industry"
ERROR - 2024-08-16 16:24:41 --> Could not find the language line "Select Industry"
ERROR - 2024-08-16 16:24:41 --> Could not find the language line "Select Industry"
ERROR - 2024-08-16 16:24:41 --> Could not find the language line "countries"
ERROR - 2024-08-16 16:24:41 --> Could not find the language line "Select Country"
ERROR - 2024-08-16 16:24:41 --> Could not find the language line "Select Country"
ERROR - 2024-08-16 16:24:41 --> client
ERROR - 2024-08-16 16:24:41 --> 12
ERROR - 2024-08-16 16:24:41 --> client
ERROR - 2024-08-16 16:25:59 --> Could not find the language line "New Campaign"
ERROR - 2024-08-16 16:25:59 --> Could not find the language line "description"
ERROR - 2024-08-16 16:25:59 --> Could not find the language line "status"
ERROR - 2024-08-16 16:25:59 --> Could not find the language line "budget"
ERROR - 2024-08-16 16:25:59 --> Could not find the language line "deal"
ERROR - 2024-08-16 16:25:59 --> Could not find the language line "Start Date"
ERROR - 2024-08-16 16:25:59 --> Could not find the language line "End Date"
ERROR - 2024-08-16 16:25:59 --> Could not find the language line "Industry"
ERROR - 2024-08-16 16:25:59 --> Could not find the language line "Select Industry"
ERROR - 2024-08-16 16:25:59 --> Could not find the language line "Select Industry"
ERROR - 2024-08-16 16:25:59 --> Could not find the language line "countries"
ERROR - 2024-08-16 16:25:59 --> Could not find the language line "Select Country"
ERROR - 2024-08-16 16:25:59 --> Could not find the language line "Select Country"
ERROR - 2024-08-16 16:25:59 --> client
ERROR - 2024-08-16 16:25:59 --> 12
ERROR - 2024-08-16 16:25:59 --> client
ERROR - 2024-08-16 16:27:23 --> client
ERROR - 2024-08-16 16:27:23 --> 12
ERROR - 2024-08-16 16:27:23 --> client
ERROR - 2024-08-16 16:27:29 --> client
ERROR - 2024-08-16 16:27:29 --> 12
ERROR - 2024-08-16 16:27:29 --> client
ERROR - 2024-08-16 16:27:33 --> Could not find the language line "New Prospect"
ERROR - 2024-08-16 16:27:33 --> Could not find the language line "Search Prospects"
ERROR - 2024-08-16 16:27:33 --> Could not find the language line "Filter By"
ERROR - 2024-08-16 16:27:33 --> Could not find the language line "Active Prospects"
ERROR - 2024-08-16 16:27:33 --> Could not find the language line "Inactive Prospects"
ERROR - 2024-08-16 16:27:33 --> Could not find the language line "Name"
ERROR - 2024-08-16 16:27:33 --> Could not find the language line "Status"
ERROR - 2024-08-16 16:27:33 --> Could not find the language line "Type"
ERROR - 2024-08-16 16:27:33 --> Could not find the language line "Category"
ERROR - 2024-08-16 16:27:33 --> Could not find the language line "Acquisition Channels"
ERROR - 2024-08-16 16:27:33 --> Could not find the language line "Desired Amount"
ERROR - 2024-08-16 16:27:33 --> Could not find the language line "Industry"
ERROR - 2024-08-16 16:27:33 --> client
ERROR - 2024-08-16 16:27:33 --> 12
ERROR - 2024-08-16 16:27:33 --> client
ERROR - 2024-08-16 16:27:59 --> client
ERROR - 2024-08-16 16:27:59 --> 12
ERROR - 2024-08-16 16:27:59 --> client
ERROR - 2024-08-16 16:28:03 --> Could not find the language line "total_campaigns"
ERROR - 2024-08-16 16:28:03 --> Could not find the language line "total_prospects"
ERROR - 2024-08-16 16:28:03 --> Could not find the language line "prospects_average_cost"
ERROR - 2024-08-16 16:28:03 --> Could not find the language line "reported_prospects"
ERROR - 2024-08-16 16:28:03 --> client
ERROR - 2024-08-16 16:28:03 --> 12
ERROR - 2024-08-16 16:28:03 --> client
ERROR - 2024-08-16 16:31:15 --> Could not find the language line "total_campaigns"
ERROR - 2024-08-16 16:31:15 --> Could not find the language line "total_prospects"
ERROR - 2024-08-16 16:31:15 --> Could not find the language line "prospects_average_cost"
ERROR - 2024-08-16 16:31:15 --> Could not find the language line "reported_prospects"
ERROR - 2024-08-16 16:31:15 --> client
ERROR - 2024-08-16 16:31:15 --> 12
ERROR - 2024-08-16 16:31:15 --> client
ERROR - 2024-08-16 16:31:17 --> Could not find the language line "New Campaign"
ERROR - 2024-08-16 16:31:17 --> Could not find the language line "description"
ERROR - 2024-08-16 16:31:17 --> Could not find the language line "status"
ERROR - 2024-08-16 16:31:17 --> Could not find the language line "budget"
ERROR - 2024-08-16 16:31:17 --> Could not find the language line "deal"
ERROR - 2024-08-16 16:31:17 --> Could not find the language line "Start Date"
ERROR - 2024-08-16 16:31:17 --> Could not find the language line "End Date"
ERROR - 2024-08-16 16:31:17 --> Could not find the language line "Industry"
ERROR - 2024-08-16 16:31:17 --> Could not find the language line "Select Industry"
ERROR - 2024-08-16 16:31:17 --> Could not find the language line "Select Industry"
ERROR - 2024-08-16 16:31:17 --> Could not find the language line "countries"
ERROR - 2024-08-16 16:31:17 --> Could not find the language line "Select Country"
ERROR - 2024-08-16 16:31:17 --> Could not find the language line "Select Country"
ERROR - 2024-08-16 16:31:17 --> client
ERROR - 2024-08-16 16:31:17 --> 12
ERROR - 2024-08-16 16:31:17 --> client
ERROR - 2024-08-16 16:31:50 --> Could not find the language line "New Campaign"
ERROR - 2024-08-16 16:31:50 --> Could not find the language line "description"
ERROR - 2024-08-16 16:31:50 --> Could not find the language line "status"
ERROR - 2024-08-16 16:31:50 --> Could not find the language line "budget"
ERROR - 2024-08-16 16:31:50 --> Could not find the language line "deal"
ERROR - 2024-08-16 16:31:50 --> Could not find the language line "Start Date"
ERROR - 2024-08-16 16:31:50 --> Could not find the language line "End Date"
ERROR - 2024-08-16 16:31:50 --> Could not find the language line "Industry"
ERROR - 2024-08-16 16:31:50 --> Could not find the language line "Select Industry"
ERROR - 2024-08-16 16:31:50 --> Could not find the language line "Select Industry"
ERROR - 2024-08-16 16:31:50 --> Could not find the language line "countries"
ERROR - 2024-08-16 16:31:50 --> Could not find the language line "Select Country"
ERROR - 2024-08-16 16:31:50 --> Could not find the language line "Select Country"
ERROR - 2024-08-16 16:31:50 --> client
ERROR - 2024-08-16 16:31:50 --> 12
ERROR - 2024-08-16 16:31:50 --> client
ERROR - 2024-08-16 16:47:56 --> Could not find the language line "New Campaign"
ERROR - 2024-08-16 16:47:56 --> Could not find the language line "description"
ERROR - 2024-08-16 16:47:56 --> Could not find the language line "status"
ERROR - 2024-08-16 16:47:56 --> Could not find the language line "budget"
ERROR - 2024-08-16 16:47:56 --> Could not find the language line "deal"
ERROR - 2024-08-16 16:47:56 --> Could not find the language line "Start Date"
ERROR - 2024-08-16 16:47:56 --> Could not find the language line "End Date"
ERROR - 2024-08-16 16:47:56 --> Could not find the language line "Industry"
ERROR - 2024-08-16 16:47:56 --> Could not find the language line "Select Industry"
ERROR - 2024-08-16 16:47:56 --> Could not find the language line "Select Industry"
ERROR - 2024-08-16 16:47:56 --> Could not find the language line "countries"
ERROR - 2024-08-16 16:47:56 --> Could not find the language line "Select Country"
ERROR - 2024-08-16 16:47:56 --> Could not find the language line "Select Country"
ERROR - 2024-08-16 16:47:56 --> client
ERROR - 2024-08-16 16:47:56 --> 12
ERROR - 2024-08-16 16:47:56 --> client
ERROR - 2024-08-16 16:48:28 --> Could not find the language line "New Campaign"
ERROR - 2024-08-16 16:48:28 --> Could not find the language line "description"
ERROR - 2024-08-16 16:48:28 --> Could not find the language line "status"
ERROR - 2024-08-16 16:48:28 --> Could not find the language line "budget"
ERROR - 2024-08-16 16:48:28 --> Could not find the language line "deal"
ERROR - 2024-08-16 16:48:28 --> Could not find the language line "Start Date"
ERROR - 2024-08-16 16:48:28 --> Could not find the language line "End Date"
ERROR - 2024-08-16 16:48:28 --> Could not find the language line "Industry"
ERROR - 2024-08-16 16:48:28 --> Could not find the language line "Select Industry"
ERROR - 2024-08-16 16:48:28 --> Could not find the language line "Select Industry"
ERROR - 2024-08-16 16:48:28 --> Could not find the language line "countries"
ERROR - 2024-08-16 16:48:28 --> Could not find the language line "Select Country"
ERROR - 2024-08-16 16:48:28 --> Could not find the language line "Select Country"
ERROR - 2024-08-16 16:48:28 --> client
ERROR - 2024-08-16 16:48:28 --> 12
ERROR - 2024-08-16 16:48:28 --> client
ERROR - 2024-08-16 16:49:29 -->  creating invoice
ERROR - 2024-08-16 16:52:32 -->  creating invoice
ERROR - 2024-08-16 16:52:39 -->  creating invoice
ERROR - 2024-08-16 16:52:42 -->  creating invoice
ERROR - 2024-08-16 16:56:05 --> Could not find the language line "New Campaign"
ERROR - 2024-08-16 16:56:05 --> Could not find the language line "description"
ERROR - 2024-08-16 16:56:05 --> Could not find the language line "status"
ERROR - 2024-08-16 16:56:05 --> Could not find the language line "budget"
ERROR - 2024-08-16 16:56:05 --> Could not find the language line "deal"
ERROR - 2024-08-16 16:56:05 --> Could not find the language line "Start Date"
ERROR - 2024-08-16 16:56:05 --> Could not find the language line "End Date"
ERROR - 2024-08-16 16:56:05 --> Could not find the language line "Industry"
ERROR - 2024-08-16 16:56:05 --> Could not find the language line "Select Industry"
ERROR - 2024-08-16 16:56:05 --> Could not find the language line "Select Industry"
ERROR - 2024-08-16 16:56:05 --> Could not find the language line "countries"
ERROR - 2024-08-16 16:56:05 --> Could not find the language line "Select Country"
ERROR - 2024-08-16 16:56:05 --> Could not find the language line "Select Country"
ERROR - 2024-08-16 16:56:05 --> client
ERROR - 2024-08-16 16:56:05 --> 12
ERROR - 2024-08-16 16:56:05 --> client
ERROR - 2024-08-16 16:56:48 --> Could not find the language line "New Campaign"
ERROR - 2024-08-16 16:56:48 --> Could not find the language line "No campaigns found."
ERROR - 2024-08-16 16:56:48 --> Could not find the language line "Industry"
ERROR - 2024-08-16 16:56:48 --> Could not find the language line "Select Industry"
ERROR - 2024-08-16 16:56:48 --> Could not find the language line "Select Industry"
ERROR - 2024-08-16 16:56:48 --> Could not find the language line "countries"
ERROR - 2024-08-16 16:56:48 --> Could not find the language line "Select Country"
ERROR - 2024-08-16 16:56:48 --> Could not find the language line "Select Country"
ERROR - 2024-08-16 16:56:48 --> client
ERROR - 2024-08-16 16:56:48 --> 12
ERROR - 2024-08-16 16:56:48 --> client
ERROR - 2024-08-16 16:57:24 -->  creating invoice
ERROR - 2024-08-16 16:58:55 --> Could not find the language line "New Campaign"
ERROR - 2024-08-16 16:58:55 --> Could not find the language line "description"
ERROR - 2024-08-16 16:58:55 --> Could not find the language line "status"
ERROR - 2024-08-16 16:58:55 --> Could not find the language line "budget"
ERROR - 2024-08-16 16:58:55 --> Could not find the language line "deal"
ERROR - 2024-08-16 16:58:55 --> Could not find the language line "Start Date"
ERROR - 2024-08-16 16:58:55 --> Could not find the language line "End Date"
ERROR - 2024-08-16 16:58:55 --> Could not find the language line "Industry"
ERROR - 2024-08-16 16:58:55 --> Could not find the language line "Select Industry"
ERROR - 2024-08-16 16:58:55 --> Could not find the language line "Select Industry"
ERROR - 2024-08-16 16:58:55 --> Could not find the language line "countries"
ERROR - 2024-08-16 16:58:55 --> Could not find the language line "Select Country"
ERROR - 2024-08-16 16:58:55 --> Could not find the language line "Select Country"
ERROR - 2024-08-16 16:58:55 --> client
ERROR - 2024-08-16 16:58:55 --> 12
ERROR - 2024-08-16 16:58:55 --> client
ERROR - 2024-08-16 16:59:20 --> Could not find the language line "New Campaign"
ERROR - 2024-08-16 16:59:20 --> Could not find the language line "No campaigns found."
ERROR - 2024-08-16 16:59:20 --> Could not find the language line "Industry"
ERROR - 2024-08-16 16:59:20 --> Could not find the language line "Select Industry"
ERROR - 2024-08-16 16:59:20 --> Could not find the language line "Select Industry"
ERROR - 2024-08-16 16:59:20 --> Could not find the language line "countries"
ERROR - 2024-08-16 16:59:20 --> Could not find the language line "Select Country"
ERROR - 2024-08-16 16:59:20 --> Could not find the language line "Select Country"
ERROR - 2024-08-16 16:59:20 --> client
ERROR - 2024-08-16 16:59:20 --> 12
ERROR - 2024-08-16 16:59:20 --> client
ERROR - 2024-08-16 16:59:47 -->  creating invoice
ERROR - 2024-08-16 17:00:53 -->  creating invoice
ERROR - 2024-08-16 17:01:28 -->  creating invoice
ERROR - 2024-08-16 17:03:41 -->  creating invoice
ERROR - 2024-08-16 17:03:51 --> Could not find the language line "New Campaign"
ERROR - 2024-08-16 17:03:51 --> Could not find the language line "description"
ERROR - 2024-08-16 17:03:51 --> Could not find the language line "status"
ERROR - 2024-08-16 17:03:51 --> Could not find the language line "budget"
ERROR - 2024-08-16 17:03:51 --> Could not find the language line "deal"
ERROR - 2024-08-16 17:03:51 --> Could not find the language line "Start Date"
ERROR - 2024-08-16 17:03:51 --> Could not find the language line "End Date"
ERROR - 2024-08-16 17:03:51 --> Could not find the language line "Industry"
ERROR - 2024-08-16 17:03:51 --> Could not find the language line "Select Industry"
ERROR - 2024-08-16 17:03:51 --> Could not find the language line "Select Industry"
ERROR - 2024-08-16 17:03:51 --> Could not find the language line "countries"
ERROR - 2024-08-16 17:03:51 --> Could not find the language line "Select Country"
ERROR - 2024-08-16 17:03:51 --> Could not find the language line "Select Country"
ERROR - 2024-08-16 17:03:51 --> client
ERROR - 2024-08-16 17:03:51 --> 12
ERROR - 2024-08-16 17:03:51 --> client
ERROR - 2024-08-16 17:03:51 --> Could not find the language line "New Campaign"
ERROR - 2024-08-16 17:03:51 --> Could not find the language line "description"
ERROR - 2024-08-16 17:03:51 --> Could not find the language line "status"
ERROR - 2024-08-16 17:03:51 --> Could not find the language line "budget"
ERROR - 2024-08-16 17:03:51 --> Could not find the language line "deal"
ERROR - 2024-08-16 17:03:51 --> Could not find the language line "Start Date"
ERROR - 2024-08-16 17:03:51 --> Could not find the language line "End Date"
ERROR - 2024-08-16 17:03:51 --> Could not find the language line "Industry"
ERROR - 2024-08-16 17:03:51 --> Could not find the language line "Select Industry"
ERROR - 2024-08-16 17:03:51 --> Could not find the language line "Select Industry"
ERROR - 2024-08-16 17:03:51 --> Could not find the language line "countries"
ERROR - 2024-08-16 17:03:51 --> Could not find the language line "Select Country"
ERROR - 2024-08-16 17:03:51 --> Could not find the language line "Select Country"
ERROR - 2024-08-16 17:03:51 --> client
ERROR - 2024-08-16 17:03:51 --> 12
ERROR - 2024-08-16 17:03:51 --> client
ERROR - 2024-08-16 17:03:51 --> Could not find the language line "New Campaign"
ERROR - 2024-08-16 17:03:51 --> Could not find the language line "description"
ERROR - 2024-08-16 17:03:51 --> Could not find the language line "status"
ERROR - 2024-08-16 17:03:51 --> Could not find the language line "budget"
ERROR - 2024-08-16 17:03:51 --> Could not find the language line "deal"
ERROR - 2024-08-16 17:03:51 --> Could not find the language line "Start Date"
ERROR - 2024-08-16 17:03:51 --> Could not find the language line "End Date"
ERROR - 2024-08-16 17:03:51 --> Could not find the language line "Industry"
ERROR - 2024-08-16 17:03:51 --> Could not find the language line "Select Industry"
ERROR - 2024-08-16 17:03:51 --> Could not find the language line "Select Industry"
ERROR - 2024-08-16 17:03:51 --> Could not find the language line "countries"
ERROR - 2024-08-16 17:03:51 --> Could not find the language line "Select Country"
ERROR - 2024-08-16 17:03:51 --> Could not find the language line "Select Country"
ERROR - 2024-08-16 17:03:51 --> client
ERROR - 2024-08-16 17:03:51 --> 12
ERROR - 2024-08-16 17:03:51 --> client
ERROR - 2024-08-16 17:03:51 --> Could not find the language line "New Campaign"
ERROR - 2024-08-16 17:03:51 --> Could not find the language line "description"
ERROR - 2024-08-16 17:03:51 --> Could not find the language line "status"
ERROR - 2024-08-16 17:03:51 --> Could not find the language line "budget"
ERROR - 2024-08-16 17:03:51 --> Could not find the language line "deal"
ERROR - 2024-08-16 17:03:51 --> Could not find the language line "Start Date"
ERROR - 2024-08-16 17:03:51 --> Could not find the language line "End Date"
ERROR - 2024-08-16 17:03:51 --> Could not find the language line "Industry"
ERROR - 2024-08-16 17:03:51 --> Could not find the language line "Select Industry"
ERROR - 2024-08-16 17:03:51 --> Could not find the language line "Select Industry"
ERROR - 2024-08-16 17:03:51 --> Could not find the language line "countries"
ERROR - 2024-08-16 17:03:51 --> Could not find the language line "Select Country"
ERROR - 2024-08-16 17:03:51 --> Could not find the language line "Select Country"
ERROR - 2024-08-16 17:03:51 --> client
ERROR - 2024-08-16 17:03:51 --> 12
ERROR - 2024-08-16 17:03:51 --> client
ERROR - 2024-08-16 17:04:41 --> Could not find the language line "New Campaign"
ERROR - 2024-08-16 17:04:41 --> Could not find the language line "No campaigns found."
ERROR - 2024-08-16 17:04:41 --> Could not find the language line "Industry"
ERROR - 2024-08-16 17:04:41 --> Could not find the language line "Select Industry"
ERROR - 2024-08-16 17:04:41 --> Could not find the language line "Select Industry"
ERROR - 2024-08-16 17:04:41 --> Could not find the language line "countries"
ERROR - 2024-08-16 17:04:41 --> Could not find the language line "Select Country"
ERROR - 2024-08-16 17:04:41 --> Could not find the language line "Select Country"
ERROR - 2024-08-16 17:04:41 --> client
ERROR - 2024-08-16 17:04:41 --> 12
ERROR - 2024-08-16 17:04:41 --> client
ERROR - 2024-08-16 17:05:02 --> ---->End date cannot be before the start date..
ERROR - 2024-08-16 17:06:25 --> Could not find the language line "New Campaign"
ERROR - 2024-08-16 17:06:25 --> Could not find the language line "No campaigns found."
ERROR - 2024-08-16 17:06:25 --> Could not find the language line "Industry"
ERROR - 2024-08-16 17:06:25 --> Could not find the language line "Select Industry"
ERROR - 2024-08-16 17:06:25 --> Could not find the language line "Select Industry"
ERROR - 2024-08-16 17:06:25 --> Could not find the language line "countries"
ERROR - 2024-08-16 17:06:25 --> Could not find the language line "Select Country"
ERROR - 2024-08-16 17:06:25 --> Could not find the language line "Select Country"
ERROR - 2024-08-16 17:06:25 --> client
ERROR - 2024-08-16 17:06:25 --> 12
ERROR - 2024-08-16 17:06:25 --> client
ERROR - 2024-08-16 17:06:50 --> ---->End date cannot be before the start date..
ERROR - 2024-08-16 17:07:28 --> Could not find the language line "New Campaign"
ERROR - 2024-08-16 17:07:28 --> Could not find the language line "No campaigns found."
ERROR - 2024-08-16 17:07:28 --> Could not find the language line "Industry"
ERROR - 2024-08-16 17:07:28 --> Could not find the language line "Select Industry"
ERROR - 2024-08-16 17:07:28 --> Could not find the language line "Select Industry"
ERROR - 2024-08-16 17:07:28 --> Could not find the language line "countries"
ERROR - 2024-08-16 17:07:28 --> Could not find the language line "Select Country"
ERROR - 2024-08-16 17:07:28 --> Could not find the language line "Select Country"
ERROR - 2024-08-16 17:07:28 --> client
ERROR - 2024-08-16 17:07:28 --> 12
ERROR - 2024-08-16 17:07:28 --> client
ERROR - 2024-08-16 17:07:51 --> ---->End date cannot be before the start date..
ERROR - 2024-08-16 17:08:09 --> Could not find the language line "New Campaign"
ERROR - 2024-08-16 17:08:09 --> Could not find the language line "No campaigns found."
ERROR - 2024-08-16 17:08:09 --> Could not find the language line "Industry"
ERROR - 2024-08-16 17:08:09 --> Could not find the language line "Select Industry"
ERROR - 2024-08-16 17:08:09 --> Could not find the language line "Select Industry"
ERROR - 2024-08-16 17:08:09 --> Could not find the language line "countries"
ERROR - 2024-08-16 17:08:09 --> Could not find the language line "Select Country"
ERROR - 2024-08-16 17:08:09 --> Could not find the language line "Select Country"
ERROR - 2024-08-16 17:08:09 --> client
ERROR - 2024-08-16 17:08:09 --> 12
ERROR - 2024-08-16 17:08:09 --> client
ERROR - 2024-08-16 17:08:34 -->  creating invoice
ERROR - 2024-08-16 17:09:13 -->  creating invoice
ERROR - 2024-08-16 17:09:19 --> Could not find the language line "New Campaign"
ERROR - 2024-08-16 17:09:19 --> Could not find the language line "description"
ERROR - 2024-08-16 17:09:19 --> Could not find the language line "status"
ERROR - 2024-08-16 17:09:19 --> Could not find the language line "budget"
ERROR - 2024-08-16 17:09:19 --> Could not find the language line "deal"
ERROR - 2024-08-16 17:09:19 --> Could not find the language line "Start Date"
ERROR - 2024-08-16 17:09:19 --> Could not find the language line "End Date"
ERROR - 2024-08-16 17:09:19 --> Could not find the language line "Industry"
ERROR - 2024-08-16 17:09:19 --> Could not find the language line "Select Industry"
ERROR - 2024-08-16 17:09:19 --> Could not find the language line "Select Industry"
ERROR - 2024-08-16 17:09:19 --> Could not find the language line "countries"
ERROR - 2024-08-16 17:09:19 --> Could not find the language line "Select Country"
ERROR - 2024-08-16 17:09:19 --> Could not find the language line "Select Country"
ERROR - 2024-08-16 17:09:19 --> client
ERROR - 2024-08-16 17:09:19 --> 12
ERROR - 2024-08-16 17:09:19 --> client
ERROR - 2024-08-16 17:19:38 --> Could not find the language line "New Campaign"
ERROR - 2024-08-16 17:19:38 --> Could not find the language line "No campaigns found."
ERROR - 2024-08-16 17:19:38 --> Could not find the language line "Industry"
ERROR - 2024-08-16 17:19:38 --> Could not find the language line "Select Industry"
ERROR - 2024-08-16 17:19:38 --> Could not find the language line "Select Industry"
ERROR - 2024-08-16 17:19:38 --> Could not find the language line "countries"
ERROR - 2024-08-16 17:19:38 --> Could not find the language line "Select Country"
ERROR - 2024-08-16 17:19:38 --> Could not find the language line "Select Country"
ERROR - 2024-08-16 17:19:38 --> client
ERROR - 2024-08-16 17:19:38 --> 12
ERROR - 2024-08-16 17:19:38 --> client
ERROR - 2024-08-16 17:19:59 -->  creating invoice
ERROR - 2024-08-16 17:20:00 --> Could not find the language line "New Campaign"
ERROR - 2024-08-16 17:20:00 --> Could not find the language line "description"
ERROR - 2024-08-16 17:20:00 --> Could not find the language line "status"
ERROR - 2024-08-16 17:20:00 --> Could not find the language line "budget"
ERROR - 2024-08-16 17:20:00 --> Could not find the language line "deal"
ERROR - 2024-08-16 17:20:00 --> Could not find the language line "Start Date"
ERROR - 2024-08-16 17:20:00 --> Could not find the language line "End Date"
ERROR - 2024-08-16 17:20:00 --> Could not find the language line "Industry"
ERROR - 2024-08-16 17:20:00 --> Could not find the language line "Select Industry"
ERROR - 2024-08-16 17:20:00 --> Could not find the language line "Select Industry"
ERROR - 2024-08-16 17:20:00 --> Could not find the language line "countries"
ERROR - 2024-08-16 17:20:00 --> Could not find the language line "Select Country"
ERROR - 2024-08-16 17:20:00 --> Could not find the language line "Select Country"
ERROR - 2024-08-16 17:20:00 --> client
ERROR - 2024-08-16 17:20:00 --> 12
ERROR - 2024-08-16 17:20:00 --> client
ERROR - 2024-08-16 17:20:51 --> Could not find the language line "New Campaign"
ERROR - 2024-08-16 17:20:51 --> Could not find the language line "description"
ERROR - 2024-08-16 17:20:51 --> Could not find the language line "status"
ERROR - 2024-08-16 17:20:51 --> Could not find the language line "budget"
ERROR - 2024-08-16 17:20:51 --> Could not find the language line "deal"
ERROR - 2024-08-16 17:20:51 --> Could not find the language line "Start Date"
ERROR - 2024-08-16 17:20:51 --> Could not find the language line "End Date"
ERROR - 2024-08-16 17:20:51 --> Could not find the language line "Industry"
ERROR - 2024-08-16 17:20:51 --> Could not find the language line "Select Industry"
ERROR - 2024-08-16 17:20:51 --> Could not find the language line "Select Industry"
ERROR - 2024-08-16 17:20:51 --> Could not find the language line "countries"
ERROR - 2024-08-16 17:20:51 --> Could not find the language line "Select Country"
ERROR - 2024-08-16 17:20:51 --> Could not find the language line "Select Country"
ERROR - 2024-08-16 17:20:51 --> client
ERROR - 2024-08-16 17:20:51 --> 12
ERROR - 2024-08-16 17:20:51 --> client
ERROR - 2024-08-16 17:21:21 --> Could not find the language line "New Campaign"
ERROR - 2024-08-16 17:21:21 --> Could not find the language line "No campaigns found."
ERROR - 2024-08-16 17:21:21 --> Could not find the language line "Industry"
ERROR - 2024-08-16 17:21:21 --> Could not find the language line "Select Industry"
ERROR - 2024-08-16 17:21:21 --> Could not find the language line "Select Industry"
ERROR - 2024-08-16 17:21:21 --> Could not find the language line "countries"
ERROR - 2024-08-16 17:21:21 --> Could not find the language line "Select Country"
ERROR - 2024-08-16 17:21:21 --> Could not find the language line "Select Country"
ERROR - 2024-08-16 17:21:21 --> client
ERROR - 2024-08-16 17:21:21 --> 12
ERROR - 2024-08-16 17:21:21 --> client
ERROR - 2024-08-16 17:21:44 -->  creating invoice
ERROR - 2024-08-16 17:21:44 --> Could not find the language line "New Campaign"
ERROR - 2024-08-16 17:21:44 --> Could not find the language line "description"
ERROR - 2024-08-16 17:21:44 --> Could not find the language line "status"
ERROR - 2024-08-16 17:21:44 --> Could not find the language line "budget"
ERROR - 2024-08-16 17:21:44 --> Could not find the language line "deal"
ERROR - 2024-08-16 17:21:44 --> Could not find the language line "Start Date"
ERROR - 2024-08-16 17:21:44 --> Could not find the language line "End Date"
ERROR - 2024-08-16 17:21:44 --> Could not find the language line "Industry"
ERROR - 2024-08-16 17:21:44 --> Could not find the language line "Select Industry"
ERROR - 2024-08-16 17:21:44 --> Could not find the language line "Select Industry"
ERROR - 2024-08-16 17:21:44 --> Could not find the language line "countries"
ERROR - 2024-08-16 17:21:44 --> Could not find the language line "Select Country"
ERROR - 2024-08-16 17:21:44 --> Could not find the language line "Select Country"
ERROR - 2024-08-16 17:21:44 --> client
ERROR - 2024-08-16 17:21:44 --> 12
ERROR - 2024-08-16 17:21:44 --> client
ERROR - 2024-08-16 17:22:27 --> Could not find the language line "Campaign Details"
ERROR - 2024-08-16 17:22:27 --> Could not find the language line "Name"
ERROR - 2024-08-16 17:22:27 --> Could not find the language line "Description"
ERROR - 2024-08-16 17:22:27 --> Could not find the language line "Start Date"
ERROR - 2024-08-16 17:22:27 --> Could not find the language line "End Date"
ERROR - 2024-08-16 17:22:27 --> Could not find the language line "Status"
ERROR - 2024-08-16 17:22:27 --> Could not find the language line "Budget"
ERROR - 2024-08-16 17:22:27 --> Could not find the language line "Edit"
ERROR - 2024-08-16 17:22:27 --> Could not find the language line "Back"
ERROR - 2024-08-16 17:22:27 --> client
ERROR - 2024-08-16 17:22:27 --> 12
ERROR - 2024-08-16 17:22:27 --> client
ERROR - 2024-08-16 17:22:30 --> Could not find the language line "New Campaign"
ERROR - 2024-08-16 17:22:30 --> Could not find the language line "description"
ERROR - 2024-08-16 17:22:30 --> Could not find the language line "status"
ERROR - 2024-08-16 17:22:30 --> Could not find the language line "budget"
ERROR - 2024-08-16 17:22:30 --> Could not find the language line "deal"
ERROR - 2024-08-16 17:22:30 --> Could not find the language line "Start Date"
ERROR - 2024-08-16 17:22:30 --> Could not find the language line "End Date"
ERROR - 2024-08-16 17:22:30 --> Could not find the language line "Industry"
ERROR - 2024-08-16 17:22:30 --> Could not find the language line "Select Industry"
ERROR - 2024-08-16 17:22:30 --> Could not find the language line "Select Industry"
ERROR - 2024-08-16 17:22:30 --> Could not find the language line "countries"
ERROR - 2024-08-16 17:22:30 --> Could not find the language line "Select Country"
ERROR - 2024-08-16 17:22:30 --> Could not find the language line "Select Country"
ERROR - 2024-08-16 17:22:30 --> client
ERROR - 2024-08-16 17:22:30 --> 12
ERROR - 2024-08-16 17:22:30 --> client
