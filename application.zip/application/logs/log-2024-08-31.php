<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-08-31 09:51:25 --> 404 Page Not Found: Migration/index
ERROR - 2024-08-31 10:35:27 --> Severity: error --> Exception: Access denied for user 'leadevo'@'%' to database 'perfex_crm' C:\laragon\www\perfex_crm\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2024-08-31 10:36:26 --> Severity: error --> Exception: Unknown database 'perfex_crm' C:\laragon\www\perfex_crm\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2024-08-31 15:36:41 --> client
ERROR - 2024-08-31 15:36:41 --> 12
ERROR - 2024-08-31 15:36:41 --> client
ERROR - 2024-08-31 10:38:40 --> 404 Page Not Found: admin/Login/index
ERROR - 2024-08-31 15:38:44 --> client
ERROR - 2024-08-31 15:38:44 --> 12
ERROR - 2024-08-31 15:38:44 --> client
ERROR - 2024-08-31 15:48:47 --> client
ERROR - 2024-08-31 15:48:47 --> 12
ERROR - 2024-08-31 15:48:47 --> client
ERROR - 2024-08-31 15:51:08 --> client
ERROR - 2024-08-31 15:51:08 --> 12
ERROR - 2024-08-31 15:51:08 --> client
ERROR - 2024-08-31 15:51:14 --> client
ERROR - 2024-08-31 15:51:14 --> 12
ERROR - 2024-08-31 15:51:14 --> client
ERROR - 2024-08-31 15:51:27 --> client
ERROR - 2024-08-31 15:51:27 --> 12
ERROR - 2024-08-31 15:51:27 --> client
ERROR - 2024-08-31 15:51:50 --> client
ERROR - 2024-08-31 15:51:50 --> 12
ERROR - 2024-08-31 15:51:50 --> client
ERROR - 2024-08-31 10:52:12 --> 404 Page Not Found: admin/Login/index
ERROR - 2024-08-31 15:52:15 --> client
ERROR - 2024-08-31 15:52:15 --> 12
ERROR - 2024-08-31 15:52:15 --> client
ERROR - 2024-08-31 15:52:34 --> client
ERROR - 2024-08-31 15:52:34 --> 12
ERROR - 2024-08-31 15:52:34 --> client
ERROR - 2024-08-31 15:53:22 --> client
ERROR - 2024-08-31 15:53:22 --> 12
ERROR - 2024-08-31 15:53:22 --> client
ERROR - 2024-08-31 15:55:16 --> client
ERROR - 2024-08-31 15:55:16 --> 12
ERROR - 2024-08-31 15:55:16 --> client
ERROR - 2024-08-31 15:55:31 --> client
ERROR - 2024-08-31 15:55:31 --> 12
ERROR - 2024-08-31 15:55:31 --> client
ERROR - 2024-08-31 15:59:46 --> client
ERROR - 2024-08-31 15:59:46 --> 12
ERROR - 2024-08-31 15:59:46 --> client
ERROR - 2024-08-31 16:00:07 --> client
ERROR - 2024-08-31 16:00:07 --> 12
ERROR - 2024-08-31 16:00:07 --> client
ERROR - 2024-08-31 11:00:50 --> 404 Page Not Found: /index
ERROR - 2024-08-31 16:00:54 --> client
ERROR - 2024-08-31 16:00:54 --> 12
ERROR - 2024-08-31 16:00:54 --> client
ERROR - 2024-08-31 16:03:26 --> client
ERROR - 2024-08-31 16:03:26 --> 12
ERROR - 2024-08-31 16:03:26 --> client
ERROR - 2024-08-31 16:03:54 --> client
ERROR - 2024-08-31 16:03:54 --> 12
ERROR - 2024-08-31 16:03:54 --> client
ERROR - 2024-08-31 16:04:05 --> client
ERROR - 2024-08-31 16:04:05 --> 12
ERROR - 2024-08-31 16:04:05 --> client
ERROR - 2024-08-31 16:04:39 --> client
ERROR - 2024-08-31 16:04:39 --> 12
ERROR - 2024-08-31 16:04:39 --> client
ERROR - 2024-08-31 16:06:53 --> client
ERROR - 2024-08-31 16:06:53 --> 12
ERROR - 2024-08-31 16:06:53 --> client
ERROR - 2024-08-31 16:07:02 --> client
ERROR - 2024-08-31 16:07:02 --> 12
ERROR - 2024-08-31 16:07:02 --> client
ERROR - 2024-08-31 16:08:00 --> client
ERROR - 2024-08-31 16:08:00 --> 12
ERROR - 2024-08-31 16:08:00 --> client
ERROR - 2024-08-31 16:09:27 --> client
ERROR - 2024-08-31 16:09:27 --> 12
ERROR - 2024-08-31 16:09:27 --> client
ERROR - 2024-08-31 16:09:37 --> client
ERROR - 2024-08-31 16:09:37 --> 12
ERROR - 2024-08-31 16:09:37 --> client
ERROR - 2024-08-31 16:10:17 --> client
ERROR - 2024-08-31 16:10:17 --> 12
ERROR - 2024-08-31 16:10:17 --> client
ERROR - 2024-08-31 16:16:04 --> client
ERROR - 2024-08-31 16:16:04 --> 12
ERROR - 2024-08-31 16:16:04 --> client
ERROR - 2024-08-31 16:16:11 --> client
ERROR - 2024-08-31 16:16:11 --> 12
ERROR - 2024-08-31 16:16:11 --> client
ERROR - 2024-08-31 16:16:36 --> client
ERROR - 2024-08-31 16:16:36 --> 12
ERROR - 2024-08-31 16:16:36 --> client
ERROR - 2024-08-31 16:17:39 --> client
ERROR - 2024-08-31 16:17:39 --> 12
ERROR - 2024-08-31 16:17:39 --> client
ERROR - 2024-08-31 16:17:56 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 16:17:56 --> Could not find the language line "billings"
ERROR - 2024-08-31 16:18:05 --> admin
ERROR - 2024-08-31 16:18:05 --> 13
ERROR - 2024-08-31 16:18:05 --> admin
ERROR - 2024-08-31 11:18:06 --> 404 Page Not Found: /index
ERROR - 2024-08-31 16:18:07 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 16:18:07 --> Could not find the language line "billings"
ERROR - 2024-08-31 16:18:08 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 16:18:08 --> Could not find the language line "billings"
ERROR - 2024-08-31 16:19:29 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 16:19:29 --> Could not find the language line "billings"
ERROR - 2024-08-31 16:19:29 --> Could not find the language line "No campaigns found."
ERROR - 2024-08-31 16:19:29 --> admin
ERROR - 2024-08-31 16:19:29 --> 12
ERROR - 2024-08-31 16:19:29 --> admin
ERROR - 2024-08-31 11:19:29 --> 404 Page Not Found: /index
ERROR - 2024-08-31 16:19:31 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 16:19:31 --> Could not find the language line "billings"
ERROR - 2024-08-31 16:19:31 --> Could not find the language line "Add Affiliate Training Video"
ERROR - 2024-08-31 16:19:31 --> Could not find the language line "Id"
ERROR - 2024-08-31 16:19:31 --> Could not find the language line "Name"
ERROR - 2024-08-31 16:19:31 --> Could not find the language line "URL"
ERROR - 2024-08-31 16:19:31 --> Could not find the language line "Description"
ERROR - 2024-08-31 16:19:31 --> Could not find the language line "Order"
ERROR - 2024-08-31 16:19:31 --> Could not find the language line "Actions"
ERROR - 2024-08-31 16:19:31 --> Could not find the language line "Watch Video"
ERROR - 2024-08-31 16:19:31 --> admin
ERROR - 2024-08-31 16:19:31 --> 12
ERROR - 2024-08-31 16:19:31 --> admin
ERROR - 2024-08-31 11:19:31 --> 404 Page Not Found: /index
ERROR - 2024-08-31 16:19:33 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 16:19:33 --> Could not find the language line "billings"
ERROR - 2024-08-31 16:19:33 --> Could not find the language line "Create New Affiliate Training Video"
ERROR - 2024-08-31 16:19:33 --> Could not find the language line "Name"
ERROR - 2024-08-31 16:19:33 --> Could not find the language line "Description"
ERROR - 2024-08-31 16:19:33 --> Could not find the language line "Video URL"
ERROR - 2024-08-31 16:19:33 --> Could not find the language line "video_order"
ERROR - 2024-08-31 16:19:33 --> Could not find the language line "Save"
ERROR - 2024-08-31 16:19:33 --> admin
ERROR - 2024-08-31 16:19:33 --> 12
ERROR - 2024-08-31 16:19:33 --> admin
ERROR - 2024-08-31 11:19:33 --> 404 Page Not Found: /index
ERROR - 2024-08-31 16:19:49 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 16:19:49 --> Could not find the language line "billings"
ERROR - 2024-08-31 16:19:49 --> Could not find the language line "Add Affiliate Training Video"
ERROR - 2024-08-31 16:19:49 --> Could not find the language line "Id"
ERROR - 2024-08-31 16:19:49 --> Could not find the language line "Name"
ERROR - 2024-08-31 16:19:49 --> Could not find the language line "URL"
ERROR - 2024-08-31 16:19:49 --> Could not find the language line "Description"
ERROR - 2024-08-31 16:19:49 --> Could not find the language line "Order"
ERROR - 2024-08-31 16:19:49 --> Could not find the language line "Actions"
ERROR - 2024-08-31 16:19:49 --> Could not find the language line "Watch Video"
ERROR - 2024-08-31 16:19:49 --> admin
ERROR - 2024-08-31 16:19:49 --> 12
ERROR - 2024-08-31 16:19:49 --> admin
ERROR - 2024-08-31 11:19:49 --> 404 Page Not Found: /index
ERROR - 2024-08-31 16:19:51 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 16:19:51 --> Could not find the language line "billings"
ERROR - 2024-08-31 16:19:51 --> Could not find the language line "Create New Affiliate Training Video"
ERROR - 2024-08-31 16:19:51 --> Could not find the language line "Name"
ERROR - 2024-08-31 16:19:51 --> Could not find the language line "Description"
ERROR - 2024-08-31 16:19:51 --> Could not find the language line "Video URL"
ERROR - 2024-08-31 16:19:51 --> Could not find the language line "video_order"
ERROR - 2024-08-31 16:19:51 --> Could not find the language line "Save"
ERROR - 2024-08-31 16:19:51 --> admin
ERROR - 2024-08-31 16:19:51 --> 12
ERROR - 2024-08-31 16:19:51 --> admin
ERROR - 2024-08-31 11:19:52 --> 404 Page Not Found: /index
ERROR - 2024-08-31 16:20:02 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 16:20:02 --> Could not find the language line "billings"
ERROR - 2024-08-31 16:20:02 --> Could not find the language line "No prospects found."
ERROR - 2024-08-31 16:20:02 --> Could not find the language line "deal"
ERROR - 2024-08-31 16:20:02 --> Could not find the language line "Desired Amount"
ERROR - 2024-08-31 16:20:02 --> Could not find the language line "Minimum Amount"
ERROR - 2024-08-31 16:20:02 --> admin
ERROR - 2024-08-31 16:20:02 --> 12
ERROR - 2024-08-31 16:20:02 --> admin
ERROR - 2024-08-31 11:20:03 --> 404 Page Not Found: /index
ERROR - 2024-08-31 16:20:26 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 16:20:26 --> Could not find the language line "billings"
ERROR - 2024-08-31 16:20:28 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 16:20:28 --> Could not find the language line "billings"
ERROR - 2024-08-31 16:20:38 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 16:20:38 --> Could not find the language line "billings"
ERROR - 2024-08-31 16:20:38 --> Could not find the language line "New Prospect Status"
ERROR - 2024-08-31 16:20:38 --> Could not find the language line "No prospect statuses found."
ERROR - 2024-08-31 16:20:38 --> admin
ERROR - 2024-08-31 16:20:38 --> 12
ERROR - 2024-08-31 16:20:38 --> admin
ERROR - 2024-08-31 11:20:38 --> 404 Page Not Found: /index
ERROR - 2024-08-31 16:20:39 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 16:20:39 --> Could not find the language line "billings"
ERROR - 2024-08-31 16:20:40 --> Could not find the language line "Create Prospect Status"
ERROR - 2024-08-31 16:20:40 --> Could not find the language line "Name"
ERROR - 2024-08-31 16:20:40 --> Could not find the language line "Description"
ERROR - 2024-08-31 16:20:40 --> Could not find the language line "Create"
ERROR - 2024-08-31 16:20:40 --> admin
ERROR - 2024-08-31 16:20:40 --> 12
ERROR - 2024-08-31 16:20:40 --> admin
ERROR - 2024-08-31 11:20:40 --> 404 Page Not Found: /index
ERROR - 2024-08-31 16:20:51 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 16:20:51 --> Could not find the language line "billings"
ERROR - 2024-08-31 16:20:51 --> Could not find the language line "New Prospect Type"
ERROR - 2024-08-31 16:20:51 --> Could not find the language line "No prospect types found."
ERROR - 2024-08-31 16:20:51 --> admin
ERROR - 2024-08-31 16:20:51 --> 12
ERROR - 2024-08-31 16:20:51 --> admin
ERROR - 2024-08-31 11:20:51 --> 404 Page Not Found: /index
ERROR - 2024-08-31 16:20:53 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 16:20:53 --> Could not find the language line "billings"
ERROR - 2024-08-31 16:20:53 --> Could not find the language line "Create Prospect Type"
ERROR - 2024-08-31 16:20:53 --> Could not find the language line "Name"
ERROR - 2024-08-31 16:20:53 --> Could not find the language line "Description"
ERROR - 2024-08-31 16:20:53 --> Could not find the language line "Create"
ERROR - 2024-08-31 16:20:53 --> admin
ERROR - 2024-08-31 16:20:53 --> 12
ERROR - 2024-08-31 16:20:53 --> admin
ERROR - 2024-08-31 11:20:53 --> 404 Page Not Found: /index
ERROR - 2024-08-31 16:21:03 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 16:21:03 --> Could not find the language line "billings"
ERROR - 2024-08-31 16:21:03 --> admin
ERROR - 2024-08-31 16:21:03 --> 12
ERROR - 2024-08-31 16:21:03 --> admin
ERROR - 2024-08-31 11:21:03 --> 404 Page Not Found: /index
ERROR - 2024-08-31 16:21:09 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 16:21:09 --> Could not find the language line "billings"
ERROR - 2024-08-31 16:21:10 --> admin
ERROR - 2024-08-31 16:21:10 --> 12
ERROR - 2024-08-31 16:21:10 --> admin
ERROR - 2024-08-31 11:21:10 --> 404 Page Not Found: /index
ERROR - 2024-08-31 16:21:26 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 16:21:26 --> Could not find the language line "billings"
ERROR - 2024-08-31 16:22:00 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 16:22:00 --> Could not find the language line "billings"
ERROR - 2024-08-31 16:22:09 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 16:22:09 --> Could not find the language line "billings"
ERROR - 2024-08-31 16:22:09 --> Could not find the language line "New Prospect Status"
ERROR - 2024-08-31 16:22:09 --> Could not find the language line "No prospect statuses found."
ERROR - 2024-08-31 16:22:09 --> admin
ERROR - 2024-08-31 16:22:09 --> 12
ERROR - 2024-08-31 16:22:09 --> admin
ERROR - 2024-08-31 11:22:10 --> 404 Page Not Found: /index
ERROR - 2024-08-31 16:22:13 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 16:22:13 --> Could not find the language line "billings"
ERROR - 2024-08-31 16:22:13 --> Could not find the language line "New Prospect category"
ERROR - 2024-08-31 16:22:13 --> Could not find the language line "No prospect categories found."
ERROR - 2024-08-31 16:22:13 --> admin
ERROR - 2024-08-31 16:22:13 --> 12
ERROR - 2024-08-31 16:22:13 --> admin
ERROR - 2024-08-31 11:22:13 --> 404 Page Not Found: /index
ERROR - 2024-08-31 16:22:14 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 16:22:14 --> Could not find the language line "billings"
ERROR - 2024-08-31 16:22:15 --> Could not find the language line "Create Prospect Category"
ERROR - 2024-08-31 16:22:15 --> Could not find the language line "Name"
ERROR - 2024-08-31 16:22:15 --> Could not find the language line "Description"
ERROR - 2024-08-31 16:22:15 --> Could not find the language line "Create"
ERROR - 2024-08-31 16:22:15 --> admin
ERROR - 2024-08-31 16:22:15 --> 12
ERROR - 2024-08-31 16:22:15 --> admin
ERROR - 2024-08-31 11:22:15 --> 404 Page Not Found: /index
ERROR - 2024-08-31 16:24:11 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 16:24:11 --> Could not find the language line "billings"
ERROR - 2024-08-31 16:24:11 --> Could not find the language line "New Prospect Status"
ERROR - 2024-08-31 16:24:11 --> Could not find the language line "No prospect statuses found."
ERROR - 2024-08-31 16:24:11 --> admin
ERROR - 2024-08-31 16:24:11 --> 12
ERROR - 2024-08-31 16:24:11 --> admin
ERROR - 2024-08-31 11:24:11 --> 404 Page Not Found: /index
ERROR - 2024-08-31 16:24:16 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 16:24:16 --> Could not find the language line "billings"
ERROR - 2024-08-31 16:24:16 --> Could not find the language line "Create Prospect Status"
ERROR - 2024-08-31 16:24:16 --> Could not find the language line "Name"
ERROR - 2024-08-31 16:24:16 --> Could not find the language line "Description"
ERROR - 2024-08-31 16:24:16 --> Could not find the language line "Create"
ERROR - 2024-08-31 16:24:16 --> admin
ERROR - 2024-08-31 16:24:16 --> 12
ERROR - 2024-08-31 16:24:16 --> admin
ERROR - 2024-08-31 11:24:17 --> 404 Page Not Found: /index
ERROR - 2024-08-31 16:30:49 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 16:30:49 --> Could not find the language line "billings"
ERROR - 2024-08-31 16:30:49 --> admin
ERROR - 2024-08-31 16:30:49 --> 13
ERROR - 2024-08-31 16:30:49 --> admin
ERROR - 2024-08-31 11:30:50 --> 404 Page Not Found: /index
ERROR - 2024-08-31 16:30:51 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 16:30:51 --> Could not find the language line "billings"
ERROR - 2024-08-31 16:30:52 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 16:30:52 --> Could not find the language line "billings"
ERROR - 2024-08-31 16:30:54 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 16:30:54 --> Could not find the language line "billings"
ERROR - 2024-08-31 16:31:01 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 16:31:01 --> Could not find the language line "billings"
ERROR - 2024-08-31 16:31:01 --> Could not find the language line "New Prospect Status"
ERROR - 2024-08-31 16:31:01 --> Could not find the language line "No prospect statuses found."
ERROR - 2024-08-31 16:31:01 --> admin
ERROR - 2024-08-31 16:31:01 --> 12
ERROR - 2024-08-31 16:31:01 --> admin
ERROR - 2024-08-31 11:31:02 --> 404 Page Not Found: /index
ERROR - 2024-08-31 16:31:03 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 16:31:03 --> Could not find the language line "billings"
ERROR - 2024-08-31 16:31:03 --> Could not find the language line "Create Prospect Status"
ERROR - 2024-08-31 16:31:03 --> Could not find the language line "Name"
ERROR - 2024-08-31 16:31:03 --> Could not find the language line "Description"
ERROR - 2024-08-31 16:31:03 --> Could not find the language line "Create"
ERROR - 2024-08-31 16:31:03 --> admin
ERROR - 2024-08-31 16:31:03 --> 12
ERROR - 2024-08-31 16:31:03 --> admin
ERROR - 2024-08-31 11:31:04 --> 404 Page Not Found: /index
ERROR - 2024-08-31 16:32:58 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 16:32:58 --> Could not find the language line "billings"
ERROR - 2024-08-31 16:32:58 --> Could not find the language line "description"
ERROR - 2024-08-31 16:32:58 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\laragon\www\perfex_crm\system\libraries\Form_validation.php 1059
ERROR - 2024-08-31 16:32:58 --> Could not find the language line "Create Prospect Status"
ERROR - 2024-08-31 16:32:58 --> Could not find the language line "Name"
ERROR - 2024-08-31 16:32:58 --> Could not find the language line "Description"
ERROR - 2024-08-31 16:32:58 --> Could not find the language line "Create"
ERROR - 2024-08-31 16:32:58 --> admin
ERROR - 2024-08-31 16:32:58 --> 12
ERROR - 2024-08-31 16:32:58 --> admin
ERROR - 2024-08-31 11:32:58 --> 404 Page Not Found: /index
ERROR - 2024-08-31 11:36:04 --> Severity: error --> Exception: syntax error, unexpected token "public" C:\laragon\www\perfex_crm\application\controllers\admin\leadevo\Prospect_status.php 37
ERROR - 2024-08-31 11:36:06 --> Severity: error --> Exception: syntax error, unexpected token "public" C:\laragon\www\perfex_crm\application\controllers\admin\leadevo\Prospect_status.php 37
ERROR - 2024-08-31 16:37:01 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 16:37:01 --> Could not find the language line "billings"
ERROR - 2024-08-31 16:37:01 --> Could not find the language line "Create Prospect Status"
ERROR - 2024-08-31 16:37:01 --> Could not find the language line "Name"
ERROR - 2024-08-31 16:37:01 --> Could not find the language line "Description"
ERROR - 2024-08-31 16:37:01 --> Could not find the language line "Create"
ERROR - 2024-08-31 16:37:01 --> admin
ERROR - 2024-08-31 16:37:01 --> 12
ERROR - 2024-08-31 16:37:01 --> admin
ERROR - 2024-08-31 11:37:02 --> 404 Page Not Found: /index
ERROR - 2024-08-31 16:37:23 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 16:37:23 --> Could not find the language line "billings"
ERROR - 2024-08-31 16:37:24 --> Could not find the language line "Create Prospect Status"
ERROR - 2024-08-31 16:37:24 --> Could not find the language line "Name"
ERROR - 2024-08-31 16:37:24 --> Could not find the language line "Description"
ERROR - 2024-08-31 16:37:24 --> Could not find the language line "Create"
ERROR - 2024-08-31 16:37:24 --> admin
ERROR - 2024-08-31 16:37:24 --> 12
ERROR - 2024-08-31 16:37:24 --> admin
ERROR - 2024-08-31 11:37:24 --> 404 Page Not Found: /index
ERROR - 2024-08-31 16:44:33 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 16:44:33 --> Could not find the language line "billings"
ERROR - 2024-08-31 16:44:33 --> Could not find the language line "Create Prospect Status"
ERROR - 2024-08-31 16:44:33 --> Could not find the language line "Name"
ERROR - 2024-08-31 16:44:33 --> Could not find the language line "Description"
ERROR - 2024-08-31 16:44:33 --> Could not find the language line "Create"
ERROR - 2024-08-31 16:44:33 --> admin
ERROR - 2024-08-31 16:44:33 --> 12
ERROR - 2024-08-31 16:44:33 --> admin
ERROR - 2024-08-31 11:44:33 --> 404 Page Not Found: /index
ERROR - 2024-08-31 16:44:44 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 16:44:44 --> Could not find the language line "billings"
ERROR - 2024-08-31 16:44:44 --> Could not find the language line "Create Prospect Status"
ERROR - 2024-08-31 16:44:44 --> Could not find the language line "Name"
ERROR - 2024-08-31 16:44:44 --> Could not find the language line "Description"
ERROR - 2024-08-31 16:44:44 --> Could not find the language line "Create"
ERROR - 2024-08-31 16:44:44 --> admin
ERROR - 2024-08-31 16:44:44 --> 12
ERROR - 2024-08-31 16:44:44 --> admin
ERROR - 2024-08-31 11:44:45 --> 404 Page Not Found: /index
ERROR - 2024-08-31 16:44:59 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 16:44:59 --> Could not find the language line "billings"
ERROR - 2024-08-31 16:44:59 --> Could not find the language line "Create Prospect Status"
ERROR - 2024-08-31 16:44:59 --> Could not find the language line "Name"
ERROR - 2024-08-31 16:44:59 --> Could not find the language line "Description"
ERROR - 2024-08-31 16:44:59 --> Could not find the language line "Create"
ERROR - 2024-08-31 16:44:59 --> admin
ERROR - 2024-08-31 16:44:59 --> 12
ERROR - 2024-08-31 16:44:59 --> admin
ERROR - 2024-08-31 11:44:59 --> 404 Page Not Found: /index
ERROR - 2024-08-31 16:46:44 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 16:46:44 --> Could not find the language line "billings"
ERROR - 2024-08-31 16:46:44 --> Could not find the language line "Create Prospect Status"
ERROR - 2024-08-31 16:46:44 --> Could not find the language line "Name"
ERROR - 2024-08-31 16:46:44 --> Could not find the language line "Description"
ERROR - 2024-08-31 16:46:44 --> Could not find the language line "Create"
ERROR - 2024-08-31 16:46:44 --> admin
ERROR - 2024-08-31 16:46:44 --> 12
ERROR - 2024-08-31 16:46:44 --> admin
ERROR - 2024-08-31 11:46:44 --> 404 Page Not Found: /index
ERROR - 2024-08-31 16:50:12 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 16:50:12 --> Could not find the language line "billings"
ERROR - 2024-08-31 16:50:12 --> Could not find the language line "Create Prospect Status"
ERROR - 2024-08-31 16:50:12 --> Could not find the language line "Name"
ERROR - 2024-08-31 16:50:12 --> Could not find the language line "Description"
ERROR - 2024-08-31 16:50:12 --> Could not find the language line "Create"
ERROR - 2024-08-31 16:50:12 --> admin
ERROR - 2024-08-31 16:50:12 --> 12
ERROR - 2024-08-31 16:50:12 --> admin
ERROR - 2024-08-31 11:50:12 --> 404 Page Not Found: /index
ERROR - 2024-08-31 16:50:16 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 16:50:16 --> Could not find the language line "billings"
ERROR - 2024-08-31 16:50:16 --> Could not find the language line "Create Prospect Status"
ERROR - 2024-08-31 16:50:16 --> Could not find the language line "Name"
ERROR - 2024-08-31 16:50:16 --> Could not find the language line "Description"
ERROR - 2024-08-31 16:50:16 --> Could not find the language line "Create"
ERROR - 2024-08-31 16:50:16 --> admin
ERROR - 2024-08-31 16:50:16 --> 12
ERROR - 2024-08-31 16:50:16 --> admin
ERROR - 2024-08-31 11:50:17 --> 404 Page Not Found: /index
ERROR - 2024-08-31 16:50:18 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 16:50:18 --> Could not find the language line "billings"
ERROR - 2024-08-31 16:50:19 --> Could not find the language line "Create Prospect Status"
ERROR - 2024-08-31 16:50:19 --> Could not find the language line "Name"
ERROR - 2024-08-31 16:50:19 --> Could not find the language line "Description"
ERROR - 2024-08-31 16:50:19 --> Could not find the language line "Create"
ERROR - 2024-08-31 16:50:19 --> admin
ERROR - 2024-08-31 16:50:19 --> 12
ERROR - 2024-08-31 16:50:19 --> admin
ERROR - 2024-08-31 11:50:19 --> 404 Page Not Found: /index
ERROR - 2024-08-31 16:50:26 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 16:50:26 --> Could not find the language line "billings"
ERROR - 2024-08-31 16:50:27 --> Could not find the language line "Create Prospect Status"
ERROR - 2024-08-31 16:50:27 --> Could not find the language line "Name"
ERROR - 2024-08-31 16:50:27 --> Could not find the language line "Description"
ERROR - 2024-08-31 16:50:27 --> Could not find the language line "Create"
ERROR - 2024-08-31 16:50:27 --> admin
ERROR - 2024-08-31 16:50:27 --> 12
ERROR - 2024-08-31 16:50:27 --> admin
ERROR - 2024-08-31 11:50:27 --> 404 Page Not Found: /index
ERROR - 2024-08-31 16:50:27 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 16:50:27 --> Could not find the language line "billings"
ERROR - 2024-08-31 16:50:28 --> Could not find the language line "Create Prospect Status"
ERROR - 2024-08-31 16:50:28 --> Could not find the language line "Name"
ERROR - 2024-08-31 16:50:28 --> Could not find the language line "Description"
ERROR - 2024-08-31 16:50:28 --> Could not find the language line "Create"
ERROR - 2024-08-31 16:50:28 --> admin
ERROR - 2024-08-31 16:50:28 --> 12
ERROR - 2024-08-31 16:50:28 --> admin
ERROR - 2024-08-31 11:50:28 --> 404 Page Not Found: /index
ERROR - 2024-08-31 16:50:32 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 16:50:32 --> Could not find the language line "billings"
ERROR - 2024-08-31 16:50:32 --> Could not find the language line "Create Prospect Status"
ERROR - 2024-08-31 16:50:32 --> Could not find the language line "Name"
ERROR - 2024-08-31 16:50:32 --> Could not find the language line "Description"
ERROR - 2024-08-31 16:50:32 --> Could not find the language line "Create"
ERROR - 2024-08-31 16:50:32 --> admin
ERROR - 2024-08-31 16:50:32 --> 12
ERROR - 2024-08-31 16:50:32 --> admin
ERROR - 2024-08-31 11:50:32 --> 404 Page Not Found: /index
ERROR - 2024-08-31 16:50:44 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 16:50:44 --> Could not find the language line "billings"
ERROR - 2024-08-31 16:50:44 --> Could not find the language line "Create Prospect Status"
ERROR - 2024-08-31 16:50:44 --> Could not find the language line "Name"
ERROR - 2024-08-31 16:50:44 --> Could not find the language line "Description"
ERROR - 2024-08-31 16:50:44 --> Could not find the language line "Create"
ERROR - 2024-08-31 16:50:44 --> admin
ERROR - 2024-08-31 16:50:44 --> 12
ERROR - 2024-08-31 16:50:44 --> admin
ERROR - 2024-08-31 11:50:44 --> 404 Page Not Found: /index
ERROR - 2024-08-31 16:50:47 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 16:50:47 --> Could not find the language line "billings"
ERROR - 2024-08-31 16:50:47 --> Could not find the language line "Create Prospect Status"
ERROR - 2024-08-31 16:50:47 --> Could not find the language line "Name"
ERROR - 2024-08-31 16:50:47 --> Could not find the language line "Description"
ERROR - 2024-08-31 16:50:47 --> Could not find the language line "Create"
ERROR - 2024-08-31 16:50:47 --> admin
ERROR - 2024-08-31 16:50:47 --> 12
ERROR - 2024-08-31 16:50:47 --> admin
ERROR - 2024-08-31 11:50:48 --> 404 Page Not Found: /index
ERROR - 2024-08-31 16:51:46 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 16:51:46 --> Could not find the language line "billings"
ERROR - 2024-08-31 16:52:07 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 16:52:07 --> Could not find the language line "billings"
ERROR - 2024-08-31 16:52:37 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 16:52:37 --> Could not find the language line "billings"
ERROR - 2024-08-31 16:52:37 --> Could not find the language line "New Prospect Type"
ERROR - 2024-08-31 16:52:37 --> Could not find the language line "No prospect types found."
ERROR - 2024-08-31 16:52:37 --> admin
ERROR - 2024-08-31 16:52:37 --> 12
ERROR - 2024-08-31 16:52:37 --> admin
ERROR - 2024-08-31 11:52:37 --> 404 Page Not Found: /index
ERROR - 2024-08-31 16:52:40 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 16:52:40 --> Could not find the language line "billings"
ERROR - 2024-08-31 16:52:40 --> Could not find the language line "Create Prospect Type"
ERROR - 2024-08-31 16:52:40 --> Could not find the language line "Name"
ERROR - 2024-08-31 16:52:40 --> Could not find the language line "Description"
ERROR - 2024-08-31 16:52:40 --> Could not find the language line "Create"
ERROR - 2024-08-31 16:52:40 --> admin
ERROR - 2024-08-31 16:52:40 --> 12
ERROR - 2024-08-31 16:52:40 --> admin
ERROR - 2024-08-31 11:52:40 --> 404 Page Not Found: /index
ERROR - 2024-08-31 16:54:46 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 16:54:46 --> Could not find the language line "billings"
ERROR - 2024-08-31 16:54:54 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 16:54:54 --> Could not find the language line "billings"
ERROR - 2024-08-31 16:54:57 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 16:54:57 --> Could not find the language line "billings"
ERROR - 2024-08-31 16:54:59 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 16:54:59 --> Could not find the language line "billings"
ERROR - 2024-08-31 16:54:59 --> Could not find the language line "No prospects found."
ERROR - 2024-08-31 16:54:59 --> Could not find the language line "deal"
ERROR - 2024-08-31 16:54:59 --> Could not find the language line "Desired Amount"
ERROR - 2024-08-31 16:54:59 --> Could not find the language line "Minimum Amount"
ERROR - 2024-08-31 16:54:59 --> admin
ERROR - 2024-08-31 16:54:59 --> 12
ERROR - 2024-08-31 16:54:59 --> admin
ERROR - 2024-08-31 11:55:00 --> 404 Page Not Found: /index
ERROR - 2024-08-31 16:55:04 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 16:55:04 --> Could not find the language line "billings"
ERROR - 2024-08-31 16:55:04 --> admin
ERROR - 2024-08-31 16:55:04 --> 13
ERROR - 2024-08-31 16:55:04 --> admin
ERROR - 2024-08-31 11:55:05 --> 404 Page Not Found: /index
ERROR - 2024-08-31 16:55:06 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 16:55:06 --> Could not find the language line "billings"
ERROR - 2024-08-31 16:55:06 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 16:55:06 --> Could not find the language line "billings"
ERROR - 2024-08-31 16:55:08 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 16:55:08 --> Could not find the language line "billings"
ERROR - 2024-08-31 16:55:09 --> Could not find the language line "Meet Industry's Most Advanced Real Estate Lead Marketplace"
ERROR - 2024-08-31 16:55:09 --> Could not find the language line "Buy Lead"
ERROR - 2024-08-31 16:55:09 --> Could not find the language line "Learn More"
ERROR - 2024-08-31 16:55:09 --> Could not find the language line "Zip Codes"
ERROR - 2024-08-31 16:55:09 --> Could not find the language line "Price Range start"
ERROR - 2024-08-31 16:55:09 --> Could not find the language line "Price Range end"
ERROR - 2024-08-31 16:55:09 --> Could not find the language line "From"
ERROR - 2024-08-31 16:55:09 --> Could not find the language line "To"
ERROR - 2024-08-31 16:55:09 --> Could not find the language line "deal"
ERROR - 2024-08-31 16:55:09 --> Could not find the language line "quality"
ERROR - 2024-08-31 16:55:09 --> Could not find the language line "Prospect ID"
ERROR - 2024-08-31 16:55:09 --> Could not find the language line "Generated date"
ERROR - 2024-08-31 16:55:09 --> Could not find the language line "Industry"
ERROR - 2024-08-31 16:55:09 --> Could not find the language line "Zip code"
ERROR - 2024-08-31 16:55:09 --> Could not find the language line "Source"
ERROR - 2024-08-31 16:55:09 --> Could not find the language line "Deal"
ERROR - 2024-08-31 16:55:09 --> Could not find the language line "Quality"
ERROR - 2024-08-31 16:55:09 --> Could not find the language line "Quality"
ERROR - 2024-08-31 16:55:09 --> admin
ERROR - 2024-08-31 16:55:09 --> 12
ERROR - 2024-08-31 16:55:09 --> admin
ERROR - 2024-08-31 11:55:09 --> 404 Page Not Found: /index
ERROR - 2024-08-31 16:55:57 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 16:55:57 --> Could not find the language line "billings"
ERROR - 2024-08-31 16:55:58 --> Could not find the language line "No prospects found."
ERROR - 2024-08-31 16:55:58 --> admin
ERROR - 2024-08-31 16:55:58 --> 12
ERROR - 2024-08-31 16:55:58 --> admin
ERROR - 2024-08-31 11:55:58 --> 404 Page Not Found: /index
ERROR - 2024-08-31 16:56:01 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 16:56:01 --> Could not find the language line "billings"
ERROR - 2024-08-31 16:56:01 --> Could not find the language line "Search Reported Prospects"
ERROR - 2024-08-31 16:56:01 --> Could not find the language line "Filter By"
ERROR - 2024-08-31 16:56:01 --> Could not find the language line "Active Reported Prospects"
ERROR - 2024-08-31 16:56:01 --> Could not find the language line "Inactive Reported Prospects"
ERROR - 2024-08-31 16:56:01 --> Could not find the language line "No reported prospects found."
ERROR - 2024-08-31 16:56:01 --> admin
ERROR - 2024-08-31 16:56:01 --> 12
ERROR - 2024-08-31 16:56:01 --> admin
ERROR - 2024-08-31 11:56:01 --> 404 Page Not Found: /index
ERROR - 2024-08-31 16:56:04 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 16:56:04 --> Could not find the language line "billings"
ERROR - 2024-08-31 16:56:04 --> Could not find the language line "No prospects found."
ERROR - 2024-08-31 16:56:04 --> admin
ERROR - 2024-08-31 16:56:04 --> 12
ERROR - 2024-08-31 16:56:04 --> admin
ERROR - 2024-08-31 11:56:05 --> 404 Page Not Found: /index
ERROR - 2024-08-31 16:56:08 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 16:56:08 --> Could not find the language line "billings"
ERROR - 2024-08-31 16:56:08 --> Could not find the language line "Search Reported Prospects"
ERROR - 2024-08-31 16:56:08 --> Could not find the language line "Filter By"
ERROR - 2024-08-31 16:56:08 --> Could not find the language line "Active Reported Prospects"
ERROR - 2024-08-31 16:56:08 --> Could not find the language line "Inactive Reported Prospects"
ERROR - 2024-08-31 16:56:08 --> Could not find the language line "No reported prospects found."
ERROR - 2024-08-31 16:56:08 --> admin
ERROR - 2024-08-31 16:56:08 --> 12
ERROR - 2024-08-31 16:56:08 --> admin
ERROR - 2024-08-31 11:56:08 --> 404 Page Not Found: /index
ERROR - 2024-08-31 16:56:13 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 16:56:13 --> Could not find the language line "billings"
ERROR - 2024-08-31 16:56:13 --> Could not find the language line "No prospects found."
ERROR - 2024-08-31 16:56:13 --> admin
ERROR - 2024-08-31 16:56:13 --> 12
ERROR - 2024-08-31 16:56:13 --> admin
ERROR - 2024-08-31 11:56:13 --> 404 Page Not Found: /index
ERROR - 2024-08-31 16:56:17 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 16:56:17 --> Could not find the language line "billings"
ERROR - 2024-08-31 16:56:17 --> Could not find the language line "No prospects found."
ERROR - 2024-08-31 16:56:17 --> Could not find the language line "deal"
ERROR - 2024-08-31 16:56:17 --> Could not find the language line "Desired Amount"
ERROR - 2024-08-31 16:56:17 --> Could not find the language line "Minimum Amount"
ERROR - 2024-08-31 16:56:17 --> admin
ERROR - 2024-08-31 16:56:17 --> 12
ERROR - 2024-08-31 16:56:17 --> admin
ERROR - 2024-08-31 11:56:17 --> 404 Page Not Found: /index
ERROR - 2024-08-31 16:56:20 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 16:56:20 --> Could not find the language line "billings"
ERROR - 2024-08-31 16:56:21 --> admin
ERROR - 2024-08-31 16:56:21 --> 12
ERROR - 2024-08-31 16:56:21 --> admin
ERROR - 2024-08-31 11:56:21 --> 404 Page Not Found: /index
ERROR - 2024-08-31 16:56:22 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 16:56:22 --> Could not find the language line "billings"
ERROR - 2024-08-31 16:56:25 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 16:56:25 --> Could not find the language line "billings"
ERROR - 2024-08-31 16:56:26 --> admin
ERROR - 2024-08-31 16:56:26 --> 12
ERROR - 2024-08-31 16:56:26 --> admin
ERROR - 2024-08-31 11:56:26 --> 404 Page Not Found: /index
ERROR - 2024-08-31 17:01:45 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 17:01:45 --> Could not find the language line "billings"
ERROR - 2024-08-31 17:01:50 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 17:01:50 --> Could not find the language line "billings"
ERROR - 2024-08-31 17:01:50 --> Could not find the language line "New Prospect Status"
ERROR - 2024-08-31 17:01:50 --> Could not find the language line "No prospect statuses found."
ERROR - 2024-08-31 17:01:50 --> admin
ERROR - 2024-08-31 17:01:50 --> 12
ERROR - 2024-08-31 17:01:50 --> admin
ERROR - 2024-08-31 12:01:50 --> 404 Page Not Found: /index
ERROR - 2024-08-31 17:01:52 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 17:01:52 --> Could not find the language line "billings"
ERROR - 2024-08-31 17:01:52 --> Could not find the language line "Create Prospect Status"
ERROR - 2024-08-31 17:01:52 --> Could not find the language line "Name"
ERROR - 2024-08-31 17:01:52 --> Could not find the language line "Description"
ERROR - 2024-08-31 17:01:52 --> Could not find the language line "Create"
ERROR - 2024-08-31 17:01:52 --> admin
ERROR - 2024-08-31 17:01:52 --> 12
ERROR - 2024-08-31 17:01:52 --> admin
ERROR - 2024-08-31 12:01:53 --> 404 Page Not Found: /index
ERROR - 2024-08-31 17:02:01 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 17:02:01 --> Could not find the language line "billings"
ERROR - 2024-08-31 17:02:01 --> Could not find the language line "Create Prospect Status"
ERROR - 2024-08-31 17:02:01 --> Could not find the language line "Name"
ERROR - 2024-08-31 17:02:01 --> Could not find the language line "Description"
ERROR - 2024-08-31 17:02:01 --> Could not find the language line "Create"
ERROR - 2024-08-31 17:02:01 --> admin
ERROR - 2024-08-31 17:02:01 --> 12
ERROR - 2024-08-31 17:02:01 --> admin
ERROR - 2024-08-31 12:02:02 --> 404 Page Not Found: /index
ERROR - 2024-08-31 17:03:48 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 17:03:48 --> Could not find the language line "billings"
ERROR - 2024-08-31 17:03:48 --> Could not find the language line "New Prospect Type"
ERROR - 2024-08-31 17:03:48 --> Could not find the language line "No prospect types found."
ERROR - 2024-08-31 17:03:48 --> admin
ERROR - 2024-08-31 17:03:48 --> 12
ERROR - 2024-08-31 17:03:48 --> admin
ERROR - 2024-08-31 12:03:48 --> 404 Page Not Found: /index
ERROR - 2024-08-31 17:08:38 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 17:08:38 --> Could not find the language line "billings"
ERROR - 2024-08-31 17:08:38 --> Could not find the language line "New Prospect Type"
ERROR - 2024-08-31 17:08:38 --> Could not find the language line "No prospect types found."
ERROR - 2024-08-31 17:08:38 --> admin
ERROR - 2024-08-31 17:08:38 --> 12
ERROR - 2024-08-31 17:08:38 --> admin
ERROR - 2024-08-31 12:08:38 --> 404 Page Not Found: /index
ERROR - 2024-08-31 17:08:40 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 17:08:40 --> Could not find the language line "billings"
ERROR - 2024-08-31 17:08:41 --> Could not find the language line "Create Prospect Type"
ERROR - 2024-08-31 17:08:41 --> Could not find the language line "Name"
ERROR - 2024-08-31 17:08:41 --> Could not find the language line "Description"
ERROR - 2024-08-31 17:08:41 --> Could not find the language line "Create"
ERROR - 2024-08-31 17:08:41 --> admin
ERROR - 2024-08-31 17:08:41 --> 12
ERROR - 2024-08-31 17:08:41 --> admin
ERROR - 2024-08-31 12:08:41 --> 404 Page Not Found: /index
ERROR - 2024-08-31 17:08:46 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 17:08:46 --> Could not find the language line "billings"
ERROR - 2024-08-31 17:08:46 --> Could not find the language line "Create Prospect Type"
ERROR - 2024-08-31 17:08:46 --> Could not find the language line "Name"
ERROR - 2024-08-31 17:08:46 --> Could not find the language line "Description"
ERROR - 2024-08-31 17:08:46 --> Could not find the language line "Create"
ERROR - 2024-08-31 17:08:46 --> admin
ERROR - 2024-08-31 17:08:46 --> 12
ERROR - 2024-08-31 17:08:46 --> admin
ERROR - 2024-08-31 12:08:46 --> 404 Page Not Found: /index
ERROR - 2024-08-31 17:08:54 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 17:08:54 --> Could not find the language line "billings"
ERROR - 2024-08-31 17:08:55 --> Could not find the language line "New Prospect Type"
ERROR - 2024-08-31 17:08:55 --> Could not find the language line "No prospect types found."
ERROR - 2024-08-31 17:08:55 --> admin
ERROR - 2024-08-31 17:08:55 --> 12
ERROR - 2024-08-31 17:08:55 --> admin
ERROR - 2024-08-31 12:08:55 --> 404 Page Not Found: /index
ERROR - 2024-08-31 17:08:56 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 17:08:56 --> Could not find the language line "billings"
ERROR - 2024-08-31 17:08:57 --> Could not find the language line "Create Prospect Type"
ERROR - 2024-08-31 17:08:57 --> Could not find the language line "Name"
ERROR - 2024-08-31 17:08:57 --> Could not find the language line "Description"
ERROR - 2024-08-31 17:08:57 --> Could not find the language line "Create"
ERROR - 2024-08-31 17:08:57 --> admin
ERROR - 2024-08-31 17:08:57 --> 12
ERROR - 2024-08-31 17:08:57 --> admin
ERROR - 2024-08-31 12:08:57 --> 404 Page Not Found: /index
ERROR - 2024-08-31 17:09:02 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 17:09:02 --> Could not find the language line "billings"
ERROR - 2024-08-31 17:09:02 --> Could not find the language line "New Prospect category"
ERROR - 2024-08-31 17:09:02 --> Could not find the language line "No prospect categories found."
ERROR - 2024-08-31 17:09:02 --> admin
ERROR - 2024-08-31 17:09:02 --> 12
ERROR - 2024-08-31 17:09:02 --> admin
ERROR - 2024-08-31 12:09:02 --> 404 Page Not Found: /index
ERROR - 2024-08-31 17:10:05 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 17:10:05 --> Could not find the language line "billings"
ERROR - 2024-08-31 17:10:05 --> Could not find the language line "Create Prospect Category"
ERROR - 2024-08-31 17:10:05 --> Could not find the language line "Name"
ERROR - 2024-08-31 17:10:05 --> Could not find the language line "Description"
ERROR - 2024-08-31 17:10:05 --> Could not find the language line "Create"
ERROR - 2024-08-31 17:10:05 --> admin
ERROR - 2024-08-31 17:10:05 --> 12
ERROR - 2024-08-31 17:10:05 --> admin
ERROR - 2024-08-31 12:10:06 --> 404 Page Not Found: /index
ERROR - 2024-08-31 17:13:10 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 17:13:10 --> Could not find the language line "billings"
ERROR - 2024-08-31 17:13:11 --> Could not find the language line "Create Prospect Category"
ERROR - 2024-08-31 17:13:11 --> Could not find the language line "Name"
ERROR - 2024-08-31 17:13:11 --> Could not find the language line "Description"
ERROR - 2024-08-31 17:13:11 --> Could not find the language line "Create"
ERROR - 2024-08-31 17:13:11 --> admin
ERROR - 2024-08-31 17:13:11 --> 12
ERROR - 2024-08-31 17:13:11 --> admin
ERROR - 2024-08-31 12:13:11 --> 404 Page Not Found: /index
ERROR - 2024-08-31 17:13:15 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 17:13:15 --> Could not find the language line "billings"
ERROR - 2024-08-31 17:13:15 --> Could not find the language line "Create Prospect Category"
ERROR - 2024-08-31 17:13:15 --> Could not find the language line "Name"
ERROR - 2024-08-31 17:13:15 --> Could not find the language line "Description"
ERROR - 2024-08-31 17:13:15 --> Could not find the language line "Create"
ERROR - 2024-08-31 17:13:15 --> admin
ERROR - 2024-08-31 17:13:15 --> 12
ERROR - 2024-08-31 17:13:15 --> admin
ERROR - 2024-08-31 12:13:15 --> 404 Page Not Found: /index
ERROR - 2024-08-31 17:14:52 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 17:14:52 --> Could not find the language line "billings"
ERROR - 2024-08-31 17:14:52 --> Could not find the language line "New Industry"
ERROR - 2024-08-31 17:14:52 --> Could not find the language line "No industries found."
ERROR - 2024-08-31 17:14:52 --> admin
ERROR - 2024-08-31 17:14:52 --> 12
ERROR - 2024-08-31 17:14:52 --> admin
ERROR - 2024-08-31 12:14:52 --> 404 Page Not Found: /index
ERROR - 2024-08-31 17:14:54 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 17:14:54 --> Could not find the language line "billings"
ERROR - 2024-08-31 17:14:55 --> Could not find the language line "Create New Industry"
ERROR - 2024-08-31 17:14:55 --> Could not find the language line "Name"
ERROR - 2024-08-31 17:14:55 --> Could not find the language line "Description"
ERROR - 2024-08-31 17:14:55 --> Could not find the language line "Category"
ERROR - 2024-08-31 17:14:55 --> Could not find the language line "Save"
ERROR - 2024-08-31 17:14:55 --> admin
ERROR - 2024-08-31 17:14:55 --> 12
ERROR - 2024-08-31 17:14:55 --> admin
ERROR - 2024-08-31 12:14:55 --> 404 Page Not Found: /index
ERROR - 2024-08-31 17:16:00 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 17:16:00 --> Could not find the language line "billings"
ERROR - 2024-08-31 17:16:00 --> Could not find the language line "New Industry"
ERROR - 2024-08-31 17:16:00 --> Could not find the language line "No industries found."
ERROR - 2024-08-31 17:16:00 --> admin
ERROR - 2024-08-31 17:16:00 --> 12
ERROR - 2024-08-31 17:16:00 --> admin
ERROR - 2024-08-31 12:16:00 --> 404 Page Not Found: /index
ERROR - 2024-08-31 17:16:03 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 17:16:03 --> Could not find the language line "billings"
ERROR - 2024-08-31 17:16:03 --> Could not find the language line "Create New Industry"
ERROR - 2024-08-31 17:16:03 --> Could not find the language line "Name"
ERROR - 2024-08-31 17:16:03 --> Could not find the language line "Description"
ERROR - 2024-08-31 17:16:03 --> Could not find the language line "Category"
ERROR - 2024-08-31 17:16:03 --> Could not find the language line "Save"
ERROR - 2024-08-31 17:16:03 --> admin
ERROR - 2024-08-31 17:16:03 --> 12
ERROR - 2024-08-31 17:16:03 --> admin
ERROR - 2024-08-31 12:16:03 --> 404 Page Not Found: /index
ERROR - 2024-08-31 17:21:34 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 17:21:34 --> Could not find the language line "billings"
ERROR - 2024-08-31 17:21:34 --> Could not find the language line "Create New Industry"
ERROR - 2024-08-31 17:21:34 --> Could not find the language line "Name"
ERROR - 2024-08-31 17:21:34 --> Could not find the language line "Description"
ERROR - 2024-08-31 17:21:34 --> Could not find the language line "Category"
ERROR - 2024-08-31 17:21:34 --> Could not find the language line "Save"
ERROR - 2024-08-31 17:21:34 --> admin
ERROR - 2024-08-31 17:21:34 --> 12
ERROR - 2024-08-31 17:21:34 --> admin
ERROR - 2024-08-31 12:21:35 --> 404 Page Not Found: /index
ERROR - 2024-08-31 17:22:02 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 17:22:02 --> Could not find the language line "billings"
ERROR - 2024-08-31 17:22:02 --> Could not find the language line "New Industry Category"
ERROR - 2024-08-31 17:22:02 --> Could not find the language line "No industry categories found."
ERROR - 2024-08-31 17:22:02 --> admin
ERROR - 2024-08-31 17:22:02 --> 12
ERROR - 2024-08-31 17:22:02 --> admin
ERROR - 2024-08-31 12:22:02 --> 404 Page Not Found: /index
ERROR - 2024-08-31 17:22:05 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 17:22:05 --> Could not find the language line "billings"
ERROR - 2024-08-31 17:22:05 --> Could not find the language line "New Industry Category"
ERROR - 2024-08-31 17:22:05 --> Could not find the language line "Name"
ERROR - 2024-08-31 17:22:05 --> Could not find the language line "Description"
ERROR - 2024-08-31 17:22:05 --> Could not find the language line "Save"
ERROR - 2024-08-31 17:22:05 --> admin
ERROR - 2024-08-31 17:22:05 --> 12
ERROR - 2024-08-31 17:22:05 --> admin
ERROR - 2024-08-31 12:22:05 --> 404 Page Not Found: /index
ERROR - 2024-08-31 17:26:57 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 17:26:57 --> Could not find the language line "billings"
ERROR - 2024-08-31 17:26:57 --> Could not find the language line "New Acquisition Channel"
ERROR - 2024-08-31 17:26:57 --> Could not find the language line "No acquisition channels found."
ERROR - 2024-08-31 17:26:57 --> admin
ERROR - 2024-08-31 17:26:57 --> 12
ERROR - 2024-08-31 17:26:57 --> admin
ERROR - 2024-08-31 12:26:57 --> 404 Page Not Found: /index
ERROR - 2024-08-31 17:26:59 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 17:26:59 --> Could not find the language line "billings"
ERROR - 2024-08-31 17:27:00 --> Could not find the language line "Create New Acquisition Channel"
ERROR - 2024-08-31 17:27:00 --> Could not find the language line "Name"
ERROR - 2024-08-31 17:27:00 --> Could not find the language line "Description"
ERROR - 2024-08-31 17:27:00 --> Could not find the language line "Save"
ERROR - 2024-08-31 17:27:00 --> admin
ERROR - 2024-08-31 17:27:00 --> 12
ERROR - 2024-08-31 17:27:00 --> admin
ERROR - 2024-08-31 12:27:00 --> 404 Page Not Found: /index
ERROR - 2024-08-31 17:30:53 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 17:30:53 --> Could not find the language line "billings"
ERROR - 2024-08-31 17:30:54 --> Could not find the language line "Create New Acquisition Channel"
ERROR - 2024-08-31 17:30:54 --> Could not find the language line "Name"
ERROR - 2024-08-31 17:30:54 --> Could not find the language line "Description"
ERROR - 2024-08-31 17:30:54 --> Could not find the language line "Save"
ERROR - 2024-08-31 17:30:54 --> admin
ERROR - 2024-08-31 17:30:54 --> 12
ERROR - 2024-08-31 17:30:54 --> admin
ERROR - 2024-08-31 12:30:54 --> 404 Page Not Found: /index
ERROR - 2024-08-31 17:31:00 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 17:31:00 --> Could not find the language line "billings"
ERROR - 2024-08-31 17:31:01 --> Could not find the language line "New Campaign Status"
ERROR - 2024-08-31 17:31:01 --> Could not find the language line "No campaign statuses found."
ERROR - 2024-08-31 17:31:01 --> admin
ERROR - 2024-08-31 17:31:01 --> 12
ERROR - 2024-08-31 17:31:01 --> admin
ERROR - 2024-08-31 12:31:01 --> 404 Page Not Found: /index
ERROR - 2024-08-31 17:31:03 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 17:31:03 --> Could not find the language line "billings"
ERROR - 2024-08-31 17:31:03 --> Could not find the language line "Create New Campaign Status"
ERROR - 2024-08-31 17:31:03 --> Could not find the language line "Name"
ERROR - 2024-08-31 17:31:03 --> Could not find the language line "Description"
ERROR - 2024-08-31 17:31:03 --> Could not find the language line "Save"
ERROR - 2024-08-31 17:31:03 --> admin
ERROR - 2024-08-31 17:31:03 --> 12
ERROR - 2024-08-31 17:31:03 --> admin
ERROR - 2024-08-31 12:31:03 --> 404 Page Not Found: /index
ERROR - 2024-08-31 17:33:08 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 17:33:08 --> Could not find the language line "billings"
ERROR - 2024-08-31 17:33:08 --> Could not find the language line "No lead reasons found."
ERROR - 2024-08-31 17:33:08 --> admin
ERROR - 2024-08-31 17:33:08 --> 12
ERROR - 2024-08-31 17:33:08 --> admin
ERROR - 2024-08-31 12:33:08 --> 404 Page Not Found: /index
ERROR - 2024-08-31 17:33:10 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 17:33:10 --> Could not find the language line "billings"
ERROR - 2024-08-31 17:33:11 --> Could not find the language line "Create New Lead Reason"
ERROR - 2024-08-31 17:33:11 --> Could not find the language line "Name"
ERROR - 2024-08-31 17:33:11 --> Could not find the language line "Description"
ERROR - 2024-08-31 17:33:11 --> Could not find the language line "Save"
ERROR - 2024-08-31 17:33:11 --> admin
ERROR - 2024-08-31 17:33:11 --> 12
ERROR - 2024-08-31 17:33:11 --> admin
ERROR - 2024-08-31 12:33:11 --> 404 Page Not Found: /index
ERROR - 2024-08-31 17:33:13 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 17:33:13 --> Could not find the language line "billings"
ERROR - 2024-08-31 17:33:13 --> Could not find the language line "No lead reasons found."
ERROR - 2024-08-31 17:33:13 --> admin
ERROR - 2024-08-31 17:33:13 --> 12
ERROR - 2024-08-31 17:33:13 --> admin
ERROR - 2024-08-31 17:33:15 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 17:33:15 --> Could not find the language line "billings"
ERROR - 2024-08-31 17:33:19 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 17:33:19 --> Could not find the language line "billings"
ERROR - 2024-08-31 17:33:19 --> Could not find the language line "Create New Lead Reason"
ERROR - 2024-08-31 17:33:19 --> Could not find the language line "Name"
ERROR - 2024-08-31 17:33:19 --> Could not find the language line "Description"
ERROR - 2024-08-31 17:33:19 --> Could not find the language line "Save"
ERROR - 2024-08-31 17:33:19 --> admin
ERROR - 2024-08-31 17:33:19 --> 12
ERROR - 2024-08-31 17:33:19 --> admin
ERROR - 2024-08-31 12:33:19 --> 404 Page Not Found: /index
ERROR - 2024-08-31 17:36:43 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 17:36:43 --> Could not find the language line "billings"
ERROR - 2024-08-31 17:36:43 --> Could not find the language line "Create New Lead Reason"
ERROR - 2024-08-31 17:36:43 --> Could not find the language line "Name"
ERROR - 2024-08-31 17:36:43 --> Could not find the language line "Description"
ERROR - 2024-08-31 17:36:43 --> Could not find the language line "Save"
ERROR - 2024-08-31 17:36:43 --> admin
ERROR - 2024-08-31 17:36:43 --> 12
ERROR - 2024-08-31 17:36:43 --> admin
ERROR - 2024-08-31 12:36:43 --> 404 Page Not Found: /index
ERROR - 2024-08-31 17:37:17 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 17:37:17 --> Could not find the language line "billings"
ERROR - 2024-08-31 17:37:17 --> Could not find the language line "No lead reasons found."
ERROR - 2024-08-31 17:37:17 --> admin
ERROR - 2024-08-31 17:37:17 --> 12
ERROR - 2024-08-31 17:37:17 --> admin
ERROR - 2024-08-31 12:37:17 --> 404 Page Not Found: /index
ERROR - 2024-08-31 17:37:20 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 17:37:20 --> Could not find the language line "billings"
ERROR - 2024-08-31 17:37:21 --> Could not find the language line "New Lead Status"
ERROR - 2024-08-31 17:37:21 --> Could not find the language line "No lead statuses found."
ERROR - 2024-08-31 17:37:21 --> admin
ERROR - 2024-08-31 17:37:21 --> 12
ERROR - 2024-08-31 17:37:21 --> admin
ERROR - 2024-08-31 12:37:21 --> 404 Page Not Found: /index
ERROR - 2024-08-31 17:37:23 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 17:37:23 --> Could not find the language line "billings"
ERROR - 2024-08-31 17:37:23 --> Could not find the language line "Create New Lead Status"
ERROR - 2024-08-31 17:37:23 --> Could not find the language line "Name"
ERROR - 2024-08-31 17:37:23 --> Could not find the language line "Description"
ERROR - 2024-08-31 17:37:23 --> Could not find the language line "Save"
ERROR - 2024-08-31 17:37:23 --> admin
ERROR - 2024-08-31 17:37:23 --> 12
ERROR - 2024-08-31 17:37:23 --> admin
ERROR - 2024-08-31 12:37:23 --> 404 Page Not Found: /index
ERROR - 2024-08-31 17:39:06 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 17:39:06 --> Could not find the language line "billings"
ERROR - 2024-08-31 17:39:07 --> Could not find the language line "Create New Lead Status"
ERROR - 2024-08-31 17:39:07 --> Could not find the language line "Name"
ERROR - 2024-08-31 17:39:07 --> Could not find the language line "Description"
ERROR - 2024-08-31 17:39:07 --> Could not find the language line "Save"
ERROR - 2024-08-31 17:39:07 --> admin
ERROR - 2024-08-31 17:39:07 --> 12
ERROR - 2024-08-31 17:39:07 --> admin
ERROR - 2024-08-31 12:39:07 --> 404 Page Not Found: /index
ERROR - 2024-08-31 17:39:14 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 17:39:14 --> Could not find the language line "billings"
ERROR - 2024-08-31 17:39:14 --> Could not find the language line "Create New Lead Status"
ERROR - 2024-08-31 17:39:14 --> Could not find the language line "Name"
ERROR - 2024-08-31 17:39:14 --> Could not find the language line "Description"
ERROR - 2024-08-31 17:39:14 --> Could not find the language line "Save"
ERROR - 2024-08-31 17:39:14 --> admin
ERROR - 2024-08-31 17:39:14 --> 12
ERROR - 2024-08-31 17:39:14 --> admin
ERROR - 2024-08-31 12:39:15 --> 404 Page Not Found: /index
ERROR - 2024-08-31 17:43:03 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 17:43:03 --> Could not find the language line "billings"
ERROR - 2024-08-31 17:43:03 --> Could not find the language line "New Prospect Status"
ERROR - 2024-08-31 17:43:03 --> Could not find the language line "No prospect statuses found."
ERROR - 2024-08-31 17:43:03 --> admin
ERROR - 2024-08-31 17:43:03 --> 12
ERROR - 2024-08-31 17:43:03 --> admin
ERROR - 2024-08-31 12:43:03 --> 404 Page Not Found: /index
ERROR - 2024-08-31 17:43:05 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 17:43:05 --> Could not find the language line "billings"
ERROR - 2024-08-31 17:43:06 --> Could not find the language line "Create Prospect Status"
ERROR - 2024-08-31 17:43:06 --> Could not find the language line "Name"
ERROR - 2024-08-31 17:43:06 --> Could not find the language line "Description"
ERROR - 2024-08-31 17:43:06 --> Could not find the language line "Create"
ERROR - 2024-08-31 17:43:06 --> admin
ERROR - 2024-08-31 17:43:06 --> 12
ERROR - 2024-08-31 17:43:06 --> admin
ERROR - 2024-08-31 12:43:06 --> 404 Page Not Found: /index
ERROR - 2024-08-31 17:43:09 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 17:43:09 --> Could not find the language line "billings"
ERROR - 2024-08-31 17:43:09 --> Could not find the language line "Create Prospect Status"
ERROR - 2024-08-31 17:43:09 --> Could not find the language line "Name"
ERROR - 2024-08-31 17:43:09 --> Could not find the language line "Description"
ERROR - 2024-08-31 17:43:09 --> Could not find the language line "Create"
ERROR - 2024-08-31 17:43:09 --> admin
ERROR - 2024-08-31 17:43:09 --> 12
ERROR - 2024-08-31 17:43:09 --> admin
ERROR - 2024-08-31 12:43:09 --> 404 Page Not Found: /index
ERROR - 2024-08-31 17:43:34 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 17:43:34 --> Could not find the language line "billings"
ERROR - 2024-08-31 17:43:34 --> admin
ERROR - 2024-08-31 17:43:34 --> 12
ERROR - 2024-08-31 17:43:34 --> admin
ERROR - 2024-08-31 12:43:35 --> 404 Page Not Found: /index
ERROR - 2024-08-31 12:43:35 --> 404 Page Not Found: /index
ERROR - 2024-08-31 17:43:52 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 17:43:52 --> Could not find the language line "billings"
ERROR - 2024-08-31 17:43:52 --> Could not find the language line "New Prospect Status"
ERROR - 2024-08-31 17:43:52 --> Could not find the language line "No prospect statuses found."
ERROR - 2024-08-31 17:43:52 --> admin
ERROR - 2024-08-31 17:43:52 --> 12
ERROR - 2024-08-31 17:43:52 --> admin
ERROR - 2024-08-31 12:43:52 --> 404 Page Not Found: /index
ERROR - 2024-08-31 17:44:46 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 17:44:46 --> Could not find the language line "billings"
ERROR - 2024-08-31 17:44:46 --> Could not find the language line "New Prospect Type"
ERROR - 2024-08-31 17:44:46 --> Could not find the language line "No prospect types found."
ERROR - 2024-08-31 17:44:46 --> admin
ERROR - 2024-08-31 17:44:46 --> 12
ERROR - 2024-08-31 17:44:46 --> admin
ERROR - 2024-08-31 12:44:47 --> 404 Page Not Found: /index
ERROR - 2024-08-31 17:44:48 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 17:44:48 --> Could not find the language line "billings"
ERROR - 2024-08-31 17:44:49 --> Could not find the language line "Create Prospect Type"
ERROR - 2024-08-31 17:44:49 --> Could not find the language line "Name"
ERROR - 2024-08-31 17:44:49 --> Could not find the language line "Description"
ERROR - 2024-08-31 17:44:49 --> Could not find the language line "Create"
ERROR - 2024-08-31 17:44:49 --> admin
ERROR - 2024-08-31 17:44:49 --> 12
ERROR - 2024-08-31 17:44:49 --> admin
ERROR - 2024-08-31 12:44:49 --> 404 Page Not Found: /index
ERROR - 2024-08-31 17:44:53 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 17:44:53 --> Could not find the language line "billings"
ERROR - 2024-08-31 17:44:53 --> Could not find the language line "New Prospect category"
ERROR - 2024-08-31 17:44:53 --> Could not find the language line "No prospect categories found."
ERROR - 2024-08-31 17:44:53 --> admin
ERROR - 2024-08-31 17:44:53 --> 12
ERROR - 2024-08-31 17:44:53 --> admin
ERROR - 2024-08-31 12:44:54 --> 404 Page Not Found: /index
ERROR - 2024-08-31 17:44:58 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 17:44:58 --> Could not find the language line "billings"
ERROR - 2024-08-31 17:44:58 --> Could not find the language line "New Industry"
ERROR - 2024-08-31 17:44:58 --> Could not find the language line "No industries found."
ERROR - 2024-08-31 17:44:58 --> admin
ERROR - 2024-08-31 17:44:58 --> 12
ERROR - 2024-08-31 17:44:58 --> admin
ERROR - 2024-08-31 12:44:58 --> 404 Page Not Found: /index
ERROR - 2024-08-31 17:45:00 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 17:45:00 --> Could not find the language line "billings"
ERROR - 2024-08-31 17:45:00 --> Could not find the language line "Create New Industry"
ERROR - 2024-08-31 17:45:00 --> Could not find the language line "Name"
ERROR - 2024-08-31 17:45:00 --> Could not find the language line "Description"
ERROR - 2024-08-31 17:45:00 --> Could not find the language line "Category"
ERROR - 2024-08-31 17:45:00 --> Could not find the language line "Save"
ERROR - 2024-08-31 17:45:00 --> admin
ERROR - 2024-08-31 17:45:00 --> 12
ERROR - 2024-08-31 17:45:00 --> admin
ERROR - 2024-08-31 12:45:01 --> 404 Page Not Found: /index
ERROR - 2024-08-31 18:02:21 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:02:21 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:02:22 --> Could not find the language line "New Prospect Status"
ERROR - 2024-08-31 18:02:22 --> Could not find the language line "No prospect statuses found."
ERROR - 2024-08-31 18:02:22 --> admin
ERROR - 2024-08-31 18:02:22 --> 12
ERROR - 2024-08-31 18:02:22 --> admin
ERROR - 2024-08-31 13:02:22 --> 404 Page Not Found: /index
ERROR - 2024-08-31 18:02:24 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:02:24 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:02:24 --> Could not find the language line "Create Prospect Status"
ERROR - 2024-08-31 18:02:24 --> Could not find the language line "Name"
ERROR - 2024-08-31 18:02:24 --> Could not find the language line "Description"
ERROR - 2024-08-31 18:02:24 --> Could not find the language line "Create"
ERROR - 2024-08-31 18:02:24 --> admin
ERROR - 2024-08-31 18:02:24 --> 12
ERROR - 2024-08-31 18:02:24 --> admin
ERROR - 2024-08-31 13:02:24 --> 404 Page Not Found: /index
ERROR - 2024-08-31 18:04:17 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:04:17 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:04:17 --> Could not find the language line "Create Prospect Status"
ERROR - 2024-08-31 18:04:17 --> Could not find the language line "Name"
ERROR - 2024-08-31 18:04:17 --> Could not find the language line "Description"
ERROR - 2024-08-31 18:04:17 --> Could not find the language line "Status"
ERROR - 2024-08-31 18:04:17 --> Could not find the language line "Create"
ERROR - 2024-08-31 18:04:17 --> admin
ERROR - 2024-08-31 18:04:17 --> 12
ERROR - 2024-08-31 18:04:17 --> admin
ERROR - 2024-08-31 13:04:18 --> 404 Page Not Found: /index
ERROR - 2024-08-31 18:05:16 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:05:16 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:05:16 --> admin
ERROR - 2024-08-31 18:05:16 --> 12
ERROR - 2024-08-31 18:05:16 --> admin
ERROR - 2024-08-31 13:05:16 --> 404 Page Not Found: /index
ERROR - 2024-08-31 18:05:18 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:05:18 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:05:19 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:05:19 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:05:20 --> admin
ERROR - 2024-08-31 18:05:20 --> 12
ERROR - 2024-08-31 18:05:20 --> admin
ERROR - 2024-08-31 13:05:20 --> 404 Page Not Found: /index
ERROR - 2024-08-31 18:05:46 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:05:46 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:05:55 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:05:55 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:05:55 --> admin
ERROR - 2024-08-31 18:05:55 --> 12
ERROR - 2024-08-31 18:05:55 --> admin
ERROR - 2024-08-31 13:05:55 --> 404 Page Not Found: /index
ERROR - 2024-08-31 18:05:56 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:05:56 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:05:57 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:05:57 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:05:58 --> admin
ERROR - 2024-08-31 18:05:58 --> 12
ERROR - 2024-08-31 18:05:58 --> admin
ERROR - 2024-08-31 13:05:58 --> 404 Page Not Found: /index
ERROR - 2024-08-31 18:06:27 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:06:27 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:06:29 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:06:29 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:06:29 --> admin
ERROR - 2024-08-31 18:06:29 --> 12
ERROR - 2024-08-31 18:06:29 --> admin
ERROR - 2024-08-31 13:06:29 --> 404 Page Not Found: /index
ERROR - 2024-08-31 18:06:40 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:06:40 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:06:40 --> admin
ERROR - 2024-08-31 18:06:40 --> 12
ERROR - 2024-08-31 18:06:40 --> admin
ERROR - 2024-08-31 13:06:40 --> 404 Page Not Found: /index
ERROR - 2024-08-31 18:06:44 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:06:44 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:06:44 --> admin
ERROR - 2024-08-31 18:06:44 --> 12
ERROR - 2024-08-31 18:06:44 --> admin
ERROR - 2024-08-31 13:06:44 --> 404 Page Not Found: /index
ERROR - 2024-08-31 18:06:49 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:06:49 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:06:49 --> admin
ERROR - 2024-08-31 18:06:49 --> 12
ERROR - 2024-08-31 18:06:49 --> admin
ERROR - 2024-08-31 13:06:50 --> 404 Page Not Found: /index
ERROR - 2024-08-31 18:06:56 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:06:56 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:06:57 --> admin
ERROR - 2024-08-31 18:06:57 --> 12
ERROR - 2024-08-31 18:06:57 --> admin
ERROR - 2024-08-31 13:06:57 --> 404 Page Not Found: /index
ERROR - 2024-08-31 18:07:03 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:07:03 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:07:03 --> admin
ERROR - 2024-08-31 18:07:03 --> 12
ERROR - 2024-08-31 18:07:03 --> admin
ERROR - 2024-08-31 13:07:04 --> 404 Page Not Found: /index
ERROR - 2024-08-31 18:07:07 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:07:07 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:07:11 --> admin
ERROR - 2024-08-31 18:07:11 --> 12
ERROR - 2024-08-31 18:07:11 --> admin
ERROR - 2024-08-31 13:07:12 --> 404 Page Not Found: /index
ERROR - 2024-08-31 18:07:14 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:07:14 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:07:14 --> admin
ERROR - 2024-08-31 18:07:14 --> 12
ERROR - 2024-08-31 18:07:14 --> admin
ERROR - 2024-08-31 13:07:14 --> 404 Page Not Found: /index
ERROR - 2024-08-31 18:07:17 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:07:17 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:07:18 --> admin
ERROR - 2024-08-31 18:07:18 --> 12
ERROR - 2024-08-31 18:07:18 --> admin
ERROR - 2024-08-31 13:07:18 --> 404 Page Not Found: /index
ERROR - 2024-08-31 18:07:19 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:07:19 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:07:22 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:07:22 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:07:23 --> Could not find the language line "general"
ERROR - 2024-08-31 18:07:23 --> Could not find the language line "form"
ERROR - 2024-08-31 18:07:23 --> admin
ERROR - 2024-08-31 18:07:23 --> 12
ERROR - 2024-08-31 18:07:23 --> admin
ERROR - 2024-08-31 13:07:23 --> 404 Page Not Found: /index
ERROR - 2024-08-31 18:07:31 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:07:31 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:07:32 --> admin
ERROR - 2024-08-31 18:07:32 --> 12
ERROR - 2024-08-31 18:07:32 --> admin
ERROR - 2024-08-31 13:07:32 --> 404 Page Not Found: /index
ERROR - 2024-08-31 18:07:39 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:07:39 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:07:39 --> admin
ERROR - 2024-08-31 18:07:39 --> 12
ERROR - 2024-08-31 18:07:39 --> admin
ERROR - 2024-08-31 13:07:39 --> 404 Page Not Found: /index
ERROR - 2024-08-31 18:07:44 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:07:44 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:07:45 --> admin
ERROR - 2024-08-31 18:07:45 --> 12
ERROR - 2024-08-31 18:07:45 --> admin
ERROR - 2024-08-31 13:07:45 --> 404 Page Not Found: /index
ERROR - 2024-08-31 18:07:52 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:07:52 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:07:52 --> admin
ERROR - 2024-08-31 18:07:52 --> 12
ERROR - 2024-08-31 18:07:52 --> admin
ERROR - 2024-08-31 13:07:52 --> 404 Page Not Found: /index
ERROR - 2024-08-31 18:07:57 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:07:57 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:07:58 --> admin
ERROR - 2024-08-31 18:07:58 --> 12
ERROR - 2024-08-31 18:07:58 --> admin
ERROR - 2024-08-31 13:07:58 --> 404 Page Not Found: /index
ERROR - 2024-08-31 18:08:02 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:08:02 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:08:03 --> admin
ERROR - 2024-08-31 18:08:03 --> 12
ERROR - 2024-08-31 18:08:03 --> admin
ERROR - 2024-08-31 13:08:03 --> 404 Page Not Found: /index
ERROR - 2024-08-31 18:08:19 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:08:19 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:08:20 --> admin
ERROR - 2024-08-31 18:08:20 --> 12
ERROR - 2024-08-31 18:08:20 --> admin
ERROR - 2024-08-31 13:08:20 --> 404 Page Not Found: /index
ERROR - 2024-08-31 18:08:24 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:08:24 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:08:24 --> admin
ERROR - 2024-08-31 18:08:24 --> 12
ERROR - 2024-08-31 18:08:24 --> admin
ERROR - 2024-08-31 13:08:25 --> 404 Page Not Found: /index
ERROR - 2024-08-31 18:08:27 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:08:27 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:08:28 --> admin
ERROR - 2024-08-31 18:08:28 --> 12
ERROR - 2024-08-31 18:08:28 --> admin
ERROR - 2024-08-31 13:08:28 --> 404 Page Not Found: /index
ERROR - 2024-08-31 18:08:41 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:08:41 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:08:41 --> admin
ERROR - 2024-08-31 18:08:41 --> 12
ERROR - 2024-08-31 18:08:41 --> admin
ERROR - 2024-08-31 13:08:41 --> 404 Page Not Found: /index
ERROR - 2024-08-31 18:08:44 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:08:44 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:08:44 --> admin
ERROR - 2024-08-31 18:08:44 --> 12
ERROR - 2024-08-31 18:08:44 --> admin
ERROR - 2024-08-31 13:08:45 --> 404 Page Not Found: /index
ERROR - 2024-08-31 18:08:51 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:08:51 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:08:51 --> admin
ERROR - 2024-08-31 18:08:51 --> 12
ERROR - 2024-08-31 18:08:51 --> admin
ERROR - 2024-08-31 13:08:52 --> 404 Page Not Found: /index
ERROR - 2024-08-31 18:08:55 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:08:55 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:08:56 --> admin
ERROR - 2024-08-31 18:08:56 --> 12
ERROR - 2024-08-31 18:08:56 --> admin
ERROR - 2024-08-31 13:08:56 --> 404 Page Not Found: /index
ERROR - 2024-08-31 18:09:20 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:09:20 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:09:20 --> admin
ERROR - 2024-08-31 18:09:20 --> 12
ERROR - 2024-08-31 18:09:20 --> admin
ERROR - 2024-08-31 13:09:21 --> 404 Page Not Found: /index
ERROR - 2024-08-31 18:13:56 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:13:56 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:14:00 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:14:00 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:14:03 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:14:03 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:14:03 --> admin
ERROR - 2024-08-31 18:14:03 --> 12
ERROR - 2024-08-31 18:14:03 --> admin
ERROR - 2024-08-31 13:14:03 --> 404 Page Not Found: /index
ERROR - 2024-08-31 18:23:12 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:23:12 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:23:12 --> Could not find the language line "New Prospect Status"
ERROR - 2024-08-31 18:23:12 --> Could not find the language line "No prospect statuses found."
ERROR - 2024-08-31 18:23:12 --> admin
ERROR - 2024-08-31 18:23:12 --> 12
ERROR - 2024-08-31 18:23:12 --> admin
ERROR - 2024-08-31 13:23:13 --> 404 Page Not Found: /index
ERROR - 2024-08-31 18:23:14 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:23:14 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:23:15 --> Could not find the language line "Create Prospect Status"
ERROR - 2024-08-31 18:23:15 --> Could not find the language line "Name"
ERROR - 2024-08-31 18:23:15 --> Could not find the language line "Description"
ERROR - 2024-08-31 18:23:15 --> Could not find the language line "Create"
ERROR - 2024-08-31 18:23:15 --> admin
ERROR - 2024-08-31 18:23:15 --> 12
ERROR - 2024-08-31 18:23:15 --> admin
ERROR - 2024-08-31 13:23:15 --> 404 Page Not Found: /index
ERROR - 2024-08-31 18:25:54 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:25:54 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:25:54 --> admin
ERROR - 2024-08-31 18:25:54 --> 12
ERROR - 2024-08-31 18:25:54 --> admin
ERROR - 2024-08-31 13:25:54 --> 404 Page Not Found: /index
ERROR - 2024-08-31 18:28:23 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:28:23 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:28:23 --> Could not find the language line "Create Prospect Status"
ERROR - 2024-08-31 18:28:23 --> Could not find the language line "Name"
ERROR - 2024-08-31 18:28:23 --> Could not find the language line "Description"
ERROR - 2024-08-31 18:28:23 --> Could not find the language line "Status"
ERROR - 2024-08-31 18:28:23 --> Could not find the language line "Create"
ERROR - 2024-08-31 18:28:23 --> admin
ERROR - 2024-08-31 18:28:23 --> 12
ERROR - 2024-08-31 18:28:23 --> admin
ERROR - 2024-08-31 13:28:23 --> 404 Page Not Found: /index
ERROR - 2024-08-31 18:28:49 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:28:49 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:28:50 --> admin
ERROR - 2024-08-31 18:28:50 --> 12
ERROR - 2024-08-31 18:28:50 --> admin
ERROR - 2024-08-31 13:28:50 --> 404 Page Not Found: /index
ERROR - 2024-08-31 13:28:50 --> 404 Page Not Found: /index
ERROR - 2024-08-31 18:28:51 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:28:51 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:28:51 --> Could not find the language line "Create Prospect Status"
ERROR - 2024-08-31 18:28:51 --> Could not find the language line "Name"
ERROR - 2024-08-31 18:28:51 --> Could not find the language line "Description"
ERROR - 2024-08-31 18:28:51 --> Could not find the language line "Status"
ERROR - 2024-08-31 18:28:51 --> Could not find the language line "Create"
ERROR - 2024-08-31 18:28:51 --> admin
ERROR - 2024-08-31 18:28:51 --> 12
ERROR - 2024-08-31 18:28:51 --> admin
ERROR - 2024-08-31 13:28:52 --> 404 Page Not Found: /index
ERROR - 2024-08-31 18:30:09 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:30:09 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:30:09 --> Could not find the language line "Create Prospect Status"
ERROR - 2024-08-31 18:30:09 --> Could not find the language line "Name"
ERROR - 2024-08-31 18:30:09 --> Could not find the language line "Description"
ERROR - 2024-08-31 18:30:09 --> Could not find the language line "Status"
ERROR - 2024-08-31 18:30:09 --> Could not find the language line "Create"
ERROR - 2024-08-31 18:30:09 --> admin
ERROR - 2024-08-31 18:30:09 --> 12
ERROR - 2024-08-31 18:30:09 --> admin
ERROR - 2024-08-31 13:30:09 --> 404 Page Not Found: /index
ERROR - 2024-08-31 18:30:12 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:30:12 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:30:12 --> Could not find the language line "Create Prospect Status"
ERROR - 2024-08-31 18:30:12 --> Could not find the language line "Name"
ERROR - 2024-08-31 18:30:12 --> Could not find the language line "Description"
ERROR - 2024-08-31 18:30:12 --> Could not find the language line "Status"
ERROR - 2024-08-31 18:30:12 --> Could not find the language line "Create"
ERROR - 2024-08-31 18:30:12 --> admin
ERROR - 2024-08-31 18:30:12 --> 12
ERROR - 2024-08-31 18:30:12 --> admin
ERROR - 2024-08-31 13:30:12 --> 404 Page Not Found: /index
ERROR - 2024-08-31 18:30:17 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:30:17 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:30:17 --> Could not find the language line "Create Prospect Status"
ERROR - 2024-08-31 18:30:17 --> Could not find the language line "Name"
ERROR - 2024-08-31 18:30:17 --> Could not find the language line "Description"
ERROR - 2024-08-31 18:30:17 --> Could not find the language line "Status"
ERROR - 2024-08-31 18:30:17 --> Could not find the language line "Create"
ERROR - 2024-08-31 18:30:17 --> admin
ERROR - 2024-08-31 18:30:17 --> 12
ERROR - 2024-08-31 18:30:17 --> admin
ERROR - 2024-08-31 13:30:17 --> 404 Page Not Found: /index
ERROR - 2024-08-31 18:30:25 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:30:25 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:30:26 --> Could not find the language line "Create Prospect Status"
ERROR - 2024-08-31 18:30:26 --> Could not find the language line "Name"
ERROR - 2024-08-31 18:30:26 --> Could not find the language line "Description"
ERROR - 2024-08-31 18:30:26 --> Could not find the language line "Status"
ERROR - 2024-08-31 18:30:26 --> Could not find the language line "Create"
ERROR - 2024-08-31 18:30:26 --> admin
ERROR - 2024-08-31 18:30:26 --> 12
ERROR - 2024-08-31 18:30:26 --> admin
ERROR - 2024-08-31 13:30:26 --> 404 Page Not Found: /index
ERROR - 2024-08-31 18:31:05 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:31:05 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:31:05 --> Could not find the language line "Create Prospect Status"
ERROR - 2024-08-31 18:31:05 --> Could not find the language line "Name"
ERROR - 2024-08-31 18:31:05 --> Could not find the language line "Description"
ERROR - 2024-08-31 18:31:05 --> Could not find the language line "Status"
ERROR - 2024-08-31 18:31:05 --> Could not find the language line "Create"
ERROR - 2024-08-31 18:31:05 --> admin
ERROR - 2024-08-31 18:31:05 --> 12
ERROR - 2024-08-31 18:31:05 --> admin
ERROR - 2024-08-31 13:31:05 --> 404 Page Not Found: /index
ERROR - 2024-08-31 18:31:20 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:31:20 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:31:21 --> Could not find the language line "Create Prospect Status"
ERROR - 2024-08-31 18:31:21 --> Could not find the language line "Name"
ERROR - 2024-08-31 18:31:21 --> Could not find the language line "Description"
ERROR - 2024-08-31 18:31:21 --> Could not find the language line "Status"
ERROR - 2024-08-31 18:31:21 --> Could not find the language line "Create"
ERROR - 2024-08-31 18:31:21 --> admin
ERROR - 2024-08-31 18:31:21 --> 12
ERROR - 2024-08-31 18:31:21 --> admin
ERROR - 2024-08-31 13:31:21 --> 404 Page Not Found: /index
ERROR - 2024-08-31 18:31:45 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:31:45 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:31:45 --> Could not find the language line "Create Prospect Status"
ERROR - 2024-08-31 18:31:45 --> Could not find the language line "Name"
ERROR - 2024-08-31 18:31:45 --> Could not find the language line "Description"
ERROR - 2024-08-31 18:31:45 --> Could not find the language line "Status"
ERROR - 2024-08-31 18:31:45 --> Could not find the language line "Create"
ERROR - 2024-08-31 18:31:45 --> admin
ERROR - 2024-08-31 18:31:45 --> 12
ERROR - 2024-08-31 18:31:45 --> admin
ERROR - 2024-08-31 13:31:45 --> 404 Page Not Found: /index
ERROR - 2024-08-31 18:31:56 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:31:56 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:31:56 --> Could not find the language line "Create Prospect Status"
ERROR - 2024-08-31 18:31:56 --> Could not find the language line "Name"
ERROR - 2024-08-31 18:31:56 --> Could not find the language line "Description"
ERROR - 2024-08-31 18:31:56 --> Could not find the language line "Status"
ERROR - 2024-08-31 18:31:56 --> Could not find the language line "Create"
ERROR - 2024-08-31 18:31:56 --> admin
ERROR - 2024-08-31 18:31:56 --> 12
ERROR - 2024-08-31 18:31:56 --> admin
ERROR - 2024-08-31 13:31:56 --> 404 Page Not Found: /index
ERROR - 2024-08-31 18:32:21 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:32:21 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:32:21 --> Could not find the language line "Create Prospect Status"
ERROR - 2024-08-31 18:32:21 --> Could not find the language line "Name"
ERROR - 2024-08-31 18:32:21 --> Could not find the language line "Description"
ERROR - 2024-08-31 18:32:21 --> Could not find the language line "Status"
ERROR - 2024-08-31 18:32:21 --> Could not find the language line "Create"
ERROR - 2024-08-31 18:32:21 --> admin
ERROR - 2024-08-31 18:32:21 --> 12
ERROR - 2024-08-31 18:32:21 --> admin
ERROR - 2024-08-31 13:32:21 --> 404 Page Not Found: /index
ERROR - 2024-08-31 18:32:32 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:32:32 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:32:36 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:32:36 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:32:36 --> Could not find the language line "Create Prospect Status"
ERROR - 2024-08-31 18:32:36 --> Could not find the language line "Name"
ERROR - 2024-08-31 18:32:36 --> Could not find the language line "Description"
ERROR - 2024-08-31 18:32:36 --> Could not find the language line "Status"
ERROR - 2024-08-31 18:32:36 --> Could not find the language line "Create"
ERROR - 2024-08-31 18:32:36 --> admin
ERROR - 2024-08-31 18:32:36 --> 12
ERROR - 2024-08-31 18:32:36 --> admin
ERROR - 2024-08-31 18:32:40 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:32:40 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:32:42 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:32:42 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:32:43 --> Could not find the language line "Create Prospect Status"
ERROR - 2024-08-31 18:32:43 --> Could not find the language line "Name"
ERROR - 2024-08-31 18:32:43 --> Could not find the language line "Description"
ERROR - 2024-08-31 18:32:43 --> Could not find the language line "Status"
ERROR - 2024-08-31 18:32:43 --> Could not find the language line "Create"
ERROR - 2024-08-31 18:32:43 --> admin
ERROR - 2024-08-31 18:32:43 --> 12
ERROR - 2024-08-31 18:32:43 --> admin
ERROR - 2024-08-31 18:32:51 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:32:51 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:32:51 --> Could not find the language line "Create Prospect Status"
ERROR - 2024-08-31 18:32:51 --> Could not find the language line "Name"
ERROR - 2024-08-31 18:32:51 --> Could not find the language line "Description"
ERROR - 2024-08-31 18:32:51 --> Could not find the language line "Status"
ERROR - 2024-08-31 18:32:51 --> Could not find the language line "Create"
ERROR - 2024-08-31 18:32:51 --> admin
ERROR - 2024-08-31 18:32:51 --> 12
ERROR - 2024-08-31 18:32:51 --> admin
ERROR - 2024-08-31 13:32:52 --> 404 Page Not Found: /index
ERROR - 2024-08-31 18:32:56 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:32:56 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:32:57 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:32:57 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:32:57 --> Could not find the language line "New Prospect Status"
ERROR - 2024-08-31 18:32:57 --> Could not find the language line "Name"
ERROR - 2024-08-31 18:32:57 --> Could not find the language line "Description"
ERROR - 2024-08-31 18:32:57 --> Could not find the language line "Actions"
ERROR - 2024-08-31 18:32:57 --> admin
ERROR - 2024-08-31 18:32:57 --> 12
ERROR - 2024-08-31 18:32:57 --> admin
ERROR - 2024-08-31 13:32:57 --> 404 Page Not Found: /index
ERROR - 2024-08-31 18:33:00 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:33:00 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:33:01 --> Could not find the language line "Edit Prospect Status"
ERROR - 2024-08-31 18:33:01 --> Could not find the language line "Name"
ERROR - 2024-08-31 18:33:01 --> Could not find the language line "Description"
ERROR - 2024-08-31 18:33:01 --> Could not find the language line "Save Changes"
ERROR - 2024-08-31 18:33:01 --> admin
ERROR - 2024-08-31 18:33:01 --> 12
ERROR - 2024-08-31 18:33:01 --> admin
ERROR - 2024-08-31 13:33:01 --> 404 Page Not Found: /index
ERROR - 2024-08-31 18:34:34 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:34:34 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:34:34 --> Could not find the language line "Edit Prospect Status"
ERROR - 2024-08-31 18:34:34 --> Could not find the language line "Name"
ERROR - 2024-08-31 18:34:34 --> Could not find the language line "Description"
ERROR - 2024-08-31 18:34:34 --> Could not find the language line "Status"
ERROR - 2024-08-31 18:34:34 --> Could not find the language line "Save Changes"
ERROR - 2024-08-31 18:34:34 --> admin
ERROR - 2024-08-31 18:34:34 --> 12
ERROR - 2024-08-31 18:34:34 --> admin
ERROR - 2024-08-31 13:34:35 --> 404 Page Not Found: /index
ERROR - 2024-08-31 18:34:39 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:34:39 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:34:39 --> Could not find the language line "Edit Prospect Status"
ERROR - 2024-08-31 18:34:39 --> Could not find the language line "Name"
ERROR - 2024-08-31 18:34:39 --> Could not find the language line "Description"
ERROR - 2024-08-31 18:34:39 --> Could not find the language line "Status"
ERROR - 2024-08-31 18:34:39 --> Could not find the language line "Save Changes"
ERROR - 2024-08-31 18:34:39 --> admin
ERROR - 2024-08-31 18:34:39 --> 12
ERROR - 2024-08-31 18:34:39 --> admin
ERROR - 2024-08-31 13:34:39 --> 404 Page Not Found: /index
ERROR - 2024-08-31 18:34:52 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:34:52 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:34:52 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:34:52 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:34:52 --> Could not find the language line "New Prospect Status"
ERROR - 2024-08-31 18:34:52 --> Could not find the language line "Name"
ERROR - 2024-08-31 18:34:52 --> Could not find the language line "Description"
ERROR - 2024-08-31 18:34:52 --> Could not find the language line "Actions"
ERROR - 2024-08-31 18:34:52 --> admin
ERROR - 2024-08-31 18:34:52 --> 12
ERROR - 2024-08-31 18:34:52 --> admin
ERROR - 2024-08-31 13:34:53 --> 404 Page Not Found: /index
ERROR - 2024-08-31 18:34:56 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:34:56 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:34:56 --> Could not find the language line "Edit Prospect Status"
ERROR - 2024-08-31 18:34:56 --> Could not find the language line "Name"
ERROR - 2024-08-31 18:34:56 --> Could not find the language line "Description"
ERROR - 2024-08-31 18:34:56 --> Could not find the language line "Status"
ERROR - 2024-08-31 18:34:56 --> Could not find the language line "Save Changes"
ERROR - 2024-08-31 18:34:56 --> admin
ERROR - 2024-08-31 18:34:56 --> 12
ERROR - 2024-08-31 18:34:56 --> admin
ERROR - 2024-08-31 13:34:56 --> 404 Page Not Found: /index
ERROR - 2024-08-31 18:34:59 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:34:59 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:35:00 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:35:00 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:35:00 --> Could not find the language line "New Prospect Status"
ERROR - 2024-08-31 18:35:00 --> Could not find the language line "Name"
ERROR - 2024-08-31 18:35:00 --> Could not find the language line "Description"
ERROR - 2024-08-31 18:35:00 --> Could not find the language line "Actions"
ERROR - 2024-08-31 18:35:00 --> admin
ERROR - 2024-08-31 18:35:00 --> 12
ERROR - 2024-08-31 18:35:00 --> admin
ERROR - 2024-08-31 13:35:00 --> 404 Page Not Found: /index
ERROR - 2024-08-31 18:35:03 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:35:03 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:35:03 --> Could not find the language line "Edit Prospect Status"
ERROR - 2024-08-31 18:35:03 --> Could not find the language line "Name"
ERROR - 2024-08-31 18:35:03 --> Could not find the language line "Description"
ERROR - 2024-08-31 18:35:03 --> Could not find the language line "Status"
ERROR - 2024-08-31 18:35:03 --> Could not find the language line "Save Changes"
ERROR - 2024-08-31 18:35:03 --> admin
ERROR - 2024-08-31 18:35:03 --> 12
ERROR - 2024-08-31 18:35:03 --> admin
ERROR - 2024-08-31 13:35:03 --> 404 Page Not Found: /index
ERROR - 2024-08-31 18:35:38 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:35:38 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:35:38 --> Could not find the language line "Edit Prospect Status"
ERROR - 2024-08-31 18:35:38 --> Could not find the language line "Name"
ERROR - 2024-08-31 18:35:38 --> Could not find the language line "Description"
ERROR - 2024-08-31 18:35:38 --> Could not find the language line "Status"
ERROR - 2024-08-31 18:35:38 --> Could not find the language line "Save Changes"
ERROR - 2024-08-31 18:35:38 --> admin
ERROR - 2024-08-31 18:35:38 --> 12
ERROR - 2024-08-31 18:35:38 --> admin
ERROR - 2024-08-31 13:35:39 --> 404 Page Not Found: /index
ERROR - 2024-08-31 18:35:43 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:35:43 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:35:44 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:35:44 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:35:44 --> Could not find the language line "New Prospect Status"
ERROR - 2024-08-31 18:35:44 --> Could not find the language line "Name"
ERROR - 2024-08-31 18:35:44 --> Could not find the language line "Description"
ERROR - 2024-08-31 18:35:44 --> Could not find the language line "Actions"
ERROR - 2024-08-31 18:35:44 --> admin
ERROR - 2024-08-31 18:35:44 --> 12
ERROR - 2024-08-31 18:35:44 --> admin
ERROR - 2024-08-31 13:35:44 --> 404 Page Not Found: /index
ERROR - 2024-08-31 18:35:47 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:35:47 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:35:48 --> Could not find the language line "Edit Prospect Status"
ERROR - 2024-08-31 18:35:48 --> Could not find the language line "Name"
ERROR - 2024-08-31 18:35:48 --> Could not find the language line "Description"
ERROR - 2024-08-31 18:35:48 --> Could not find the language line "Status"
ERROR - 2024-08-31 18:35:48 --> Could not find the language line "Save Changes"
ERROR - 2024-08-31 18:35:48 --> admin
ERROR - 2024-08-31 18:35:48 --> 12
ERROR - 2024-08-31 18:35:48 --> admin
ERROR - 2024-08-31 13:35:48 --> 404 Page Not Found: /index
ERROR - 2024-08-31 18:35:51 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:35:51 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:35:51 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:35:51 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:35:51 --> Could not find the language line "New Prospect Status"
ERROR - 2024-08-31 18:35:51 --> Could not find the language line "Name"
ERROR - 2024-08-31 18:35:51 --> Could not find the language line "Description"
ERROR - 2024-08-31 18:35:51 --> Could not find the language line "Actions"
ERROR - 2024-08-31 18:35:51 --> admin
ERROR - 2024-08-31 18:35:51 --> 12
ERROR - 2024-08-31 18:35:51 --> admin
ERROR - 2024-08-31 13:35:51 --> 404 Page Not Found: /index
ERROR - 2024-08-31 18:35:54 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:35:54 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:35:54 --> Could not find the language line "Edit Prospect Status"
ERROR - 2024-08-31 18:35:54 --> Could not find the language line "Name"
ERROR - 2024-08-31 18:35:54 --> Could not find the language line "Description"
ERROR - 2024-08-31 18:35:54 --> Could not find the language line "Status"
ERROR - 2024-08-31 18:35:54 --> Could not find the language line "Save Changes"
ERROR - 2024-08-31 18:35:54 --> admin
ERROR - 2024-08-31 18:35:54 --> 12
ERROR - 2024-08-31 18:35:54 --> admin
ERROR - 2024-08-31 13:35:55 --> 404 Page Not Found: /index
ERROR - 2024-08-31 18:37:30 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:37:30 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:37:30 --> Could not find the language line "Edit Prospect Status"
ERROR - 2024-08-31 18:37:30 --> Could not find the language line "Name"
ERROR - 2024-08-31 18:37:30 --> Could not find the language line "Description"
ERROR - 2024-08-31 18:37:30 --> Could not find the language line "Status"
ERROR - 2024-08-31 18:37:30 --> Could not find the language line "Save Changes"
ERROR - 2024-08-31 18:37:30 --> admin
ERROR - 2024-08-31 18:37:30 --> 12
ERROR - 2024-08-31 18:37:30 --> admin
ERROR - 2024-08-31 13:37:30 --> 404 Page Not Found: /index
ERROR - 2024-08-31 18:37:33 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:37:33 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:37:56 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:37:56 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:37:57 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:37:57 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:37:57 --> Could not find the language line "New Prospect Status"
ERROR - 2024-08-31 18:37:57 --> Could not find the language line "Name"
ERROR - 2024-08-31 18:37:57 --> Could not find the language line "Description"
ERROR - 2024-08-31 18:37:57 --> Could not find the language line "Actions"
ERROR - 2024-08-31 18:37:57 --> admin
ERROR - 2024-08-31 18:37:57 --> 12
ERROR - 2024-08-31 18:37:57 --> admin
ERROR - 2024-08-31 13:37:57 --> 404 Page Not Found: /index
ERROR - 2024-08-31 18:38:00 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:38:00 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:38:01 --> Could not find the language line "Edit Prospect Status"
ERROR - 2024-08-31 18:38:01 --> Could not find the language line "Name"
ERROR - 2024-08-31 18:38:01 --> Could not find the language line "Description"
ERROR - 2024-08-31 18:38:01 --> Could not find the language line "Status"
ERROR - 2024-08-31 18:38:01 --> Could not find the language line "Save Changes"
ERROR - 2024-08-31 18:38:01 --> admin
ERROR - 2024-08-31 18:38:01 --> 12
ERROR - 2024-08-31 18:38:01 --> admin
ERROR - 2024-08-31 13:38:01 --> 404 Page Not Found: /index
ERROR - 2024-08-31 18:38:19 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:38:19 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:38:19 --> Could not find the language line "Edit Prospect Status"
ERROR - 2024-08-31 18:38:19 --> Could not find the language line "Name"
ERROR - 2024-08-31 18:38:19 --> Could not find the language line "Description"
ERROR - 2024-08-31 18:38:19 --> Could not find the language line "Status"
ERROR - 2024-08-31 18:38:19 --> Could not find the language line "Save Changes"
ERROR - 2024-08-31 18:38:19 --> admin
ERROR - 2024-08-31 18:38:19 --> 12
ERROR - 2024-08-31 18:38:19 --> admin
ERROR - 2024-08-31 13:38:20 --> 404 Page Not Found: /index
ERROR - 2024-08-31 18:38:24 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:38:24 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:38:24 --> Could not find the language line "Edit Prospect Status"
ERROR - 2024-08-31 18:38:24 --> Could not find the language line "Name"
ERROR - 2024-08-31 18:38:24 --> Could not find the language line "Description"
ERROR - 2024-08-31 18:38:24 --> Could not find the language line "Status"
ERROR - 2024-08-31 18:38:24 --> Could not find the language line "Save Changes"
ERROR - 2024-08-31 18:38:24 --> admin
ERROR - 2024-08-31 18:38:24 --> 12
ERROR - 2024-08-31 18:38:24 --> admin
ERROR - 2024-08-31 13:38:25 --> 404 Page Not Found: /index
ERROR - 2024-08-31 18:38:28 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:38:28 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:38:29 --> Could not find the language line "New Prospect Status"
ERROR - 2024-08-31 18:38:29 --> Could not find the language line "Name"
ERROR - 2024-08-31 18:38:29 --> Could not find the language line "Description"
ERROR - 2024-08-31 18:38:29 --> Could not find the language line "Actions"
ERROR - 2024-08-31 18:38:29 --> admin
ERROR - 2024-08-31 18:38:29 --> 12
ERROR - 2024-08-31 18:38:29 --> admin
ERROR - 2024-08-31 18:38:32 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:38:32 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:38:32 --> Could not find the language line "Edit Prospect Status"
ERROR - 2024-08-31 18:38:32 --> Could not find the language line "Name"
ERROR - 2024-08-31 18:38:32 --> Could not find the language line "Description"
ERROR - 2024-08-31 18:38:32 --> Could not find the language line "Status"
ERROR - 2024-08-31 18:38:32 --> Could not find the language line "Save Changes"
ERROR - 2024-08-31 18:38:32 --> admin
ERROR - 2024-08-31 18:38:32 --> 12
ERROR - 2024-08-31 18:38:32 --> admin
ERROR - 2024-08-31 13:38:32 --> 404 Page Not Found: /index
ERROR - 2024-08-31 18:38:42 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:38:42 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:38:42 --> Could not find the language line "Edit Prospect Status"
ERROR - 2024-08-31 18:38:42 --> Could not find the language line "Name"
ERROR - 2024-08-31 18:38:42 --> Could not find the language line "Description"
ERROR - 2024-08-31 18:38:42 --> Could not find the language line "Status"
ERROR - 2024-08-31 18:38:42 --> Could not find the language line "Save Changes"
ERROR - 2024-08-31 18:38:42 --> admin
ERROR - 2024-08-31 18:38:42 --> 12
ERROR - 2024-08-31 18:38:42 --> admin
ERROR - 2024-08-31 13:38:43 --> 404 Page Not Found: /index
ERROR - 2024-08-31 18:39:01 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:39:01 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:39:01 --> Severity: Warning --> Undefined variable $data C:\laragon\www\perfex_crm\application\controllers\admin\leadevo\Prospect_status.php 43
ERROR - 2024-08-31 18:39:01 --> Severity: Warning --> Trying to access array offset on value of type null C:\laragon\www\perfex_crm\application\controllers\admin\leadevo\Prospect_status.php 43
ERROR - 2024-08-31 18:39:19 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:39:19 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:39:19 --> Severity: Warning --> Undefined variable $data C:\laragon\www\perfex_crm\application\controllers\admin\leadevo\Prospect_status.php 43
ERROR - 2024-08-31 18:40:35 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:40:35 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:40:35 --> Could not find the language line "Edit Prospect Status"
ERROR - 2024-08-31 18:40:35 --> Could not find the language line "Name"
ERROR - 2024-08-31 18:40:35 --> Could not find the language line "Description"
ERROR - 2024-08-31 18:40:35 --> Could not find the language line "Status"
ERROR - 2024-08-31 18:40:35 --> Could not find the language line "Save Changes"
ERROR - 2024-08-31 18:40:35 --> admin
ERROR - 2024-08-31 18:40:35 --> 12
ERROR - 2024-08-31 18:40:35 --> admin
ERROR - 2024-08-31 13:40:36 --> 404 Page Not Found: /index
ERROR - 2024-08-31 18:41:13 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:41:13 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:41:13 --> Could not find the language line "Edit Prospect Status"
ERROR - 2024-08-31 18:41:13 --> Could not find the language line "Name"
ERROR - 2024-08-31 18:41:13 --> Could not find the language line "Description"
ERROR - 2024-08-31 18:41:13 --> Could not find the language line "Status"
ERROR - 2024-08-31 18:41:13 --> Could not find the language line "Save Changes"
ERROR - 2024-08-31 18:41:13 --> admin
ERROR - 2024-08-31 18:41:13 --> 12
ERROR - 2024-08-31 18:41:13 --> admin
ERROR - 2024-08-31 13:41:13 --> 404 Page Not Found: /index
ERROR - 2024-08-31 18:41:16 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:41:16 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:41:16 --> Could not find the language line "Edit Prospect Status"
ERROR - 2024-08-31 18:41:16 --> Could not find the language line "Name"
ERROR - 2024-08-31 18:41:16 --> Could not find the language line "Description"
ERROR - 2024-08-31 18:41:16 --> Could not find the language line "Status"
ERROR - 2024-08-31 18:41:16 --> Could not find the language line "Save Changes"
ERROR - 2024-08-31 18:41:16 --> admin
ERROR - 2024-08-31 18:41:16 --> 12
ERROR - 2024-08-31 18:41:16 --> admin
ERROR - 2024-08-31 13:41:16 --> 404 Page Not Found: /index
ERROR - 2024-08-31 18:41:44 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:41:44 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:41:44 --> Could not find the language line "Edit Prospect Status"
ERROR - 2024-08-31 18:41:44 --> Could not find the language line "Name"
ERROR - 2024-08-31 18:41:44 --> Could not find the language line "Description"
ERROR - 2024-08-31 18:41:44 --> Could not find the language line "Status"
ERROR - 2024-08-31 18:41:44 --> Could not find the language line "Save Changes"
ERROR - 2024-08-31 18:41:44 --> admin
ERROR - 2024-08-31 18:41:44 --> 12
ERROR - 2024-08-31 18:41:44 --> admin
ERROR - 2024-08-31 13:41:44 --> 404 Page Not Found: /index
ERROR - 2024-08-31 18:42:33 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:42:33 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:42:34 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:42:34 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:42:34 --> Could not find the language line "New Prospect Status"
ERROR - 2024-08-31 18:42:34 --> Could not find the language line "Name"
ERROR - 2024-08-31 18:42:34 --> Could not find the language line "Description"
ERROR - 2024-08-31 18:42:34 --> Could not find the language line "Actions"
ERROR - 2024-08-31 18:42:34 --> admin
ERROR - 2024-08-31 18:42:34 --> 12
ERROR - 2024-08-31 18:42:34 --> admin
ERROR - 2024-08-31 13:42:34 --> 404 Page Not Found: /index
ERROR - 2024-08-31 18:42:37 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:42:37 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:42:38 --> Could not find the language line "Edit Prospect Status"
ERROR - 2024-08-31 18:42:38 --> Could not find the language line "Name"
ERROR - 2024-08-31 18:42:38 --> Could not find the language line "Description"
ERROR - 2024-08-31 18:42:38 --> Could not find the language line "Status"
ERROR - 2024-08-31 18:42:38 --> Could not find the language line "Save Changes"
ERROR - 2024-08-31 18:42:38 --> admin
ERROR - 2024-08-31 18:42:38 --> 12
ERROR - 2024-08-31 18:42:38 --> admin
ERROR - 2024-08-31 13:42:38 --> 404 Page Not Found: /index
ERROR - 2024-08-31 18:43:55 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:43:55 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:43:55 --> Could not find the language line "Edit Prospect Status"
ERROR - 2024-08-31 18:43:55 --> Could not find the language line "Name"
ERROR - 2024-08-31 18:43:55 --> Could not find the language line "Description"
ERROR - 2024-08-31 18:43:55 --> Could not find the language line "Status"
ERROR - 2024-08-31 18:43:55 --> Could not find the language line "Save Changes"
ERROR - 2024-08-31 18:43:55 --> admin
ERROR - 2024-08-31 18:43:55 --> 12
ERROR - 2024-08-31 18:43:55 --> admin
ERROR - 2024-08-31 13:43:55 --> 404 Page Not Found: /index
ERROR - 2024-08-31 18:43:58 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:43:58 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:44:41 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:44:41 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:44:42 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:44:42 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:44:42 --> Could not find the language line "New Prospect Status"
ERROR - 2024-08-31 18:44:42 --> Could not find the language line "Name"
ERROR - 2024-08-31 18:44:42 --> Could not find the language line "Description"
ERROR - 2024-08-31 18:44:42 --> Could not find the language line "Actions"
ERROR - 2024-08-31 18:44:42 --> admin
ERROR - 2024-08-31 18:44:42 --> 12
ERROR - 2024-08-31 18:44:42 --> admin
ERROR - 2024-08-31 13:44:42 --> 404 Page Not Found: /index
ERROR - 2024-08-31 18:44:45 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:44:45 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:44:45 --> Could not find the language line "Edit Prospect Status"
ERROR - 2024-08-31 18:44:45 --> Could not find the language line "Name"
ERROR - 2024-08-31 18:44:45 --> Could not find the language line "Description"
ERROR - 2024-08-31 18:44:45 --> Could not find the language line "Status"
ERROR - 2024-08-31 18:44:45 --> Could not find the language line "Save Changes"
ERROR - 2024-08-31 18:44:46 --> admin
ERROR - 2024-08-31 18:44:46 --> 12
ERROR - 2024-08-31 18:44:46 --> admin
ERROR - 2024-08-31 13:44:46 --> 404 Page Not Found: /index
ERROR - 2024-08-31 18:44:57 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:44:57 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:44:57 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:44:57 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:44:58 --> Could not find the language line "New Prospect Status"
ERROR - 2024-08-31 18:44:58 --> Could not find the language line "Name"
ERROR - 2024-08-31 18:44:58 --> Could not find the language line "Description"
ERROR - 2024-08-31 18:44:58 --> Could not find the language line "Actions"
ERROR - 2024-08-31 18:44:58 --> admin
ERROR - 2024-08-31 18:44:58 --> 12
ERROR - 2024-08-31 18:44:58 --> admin
ERROR - 2024-08-31 13:44:58 --> 404 Page Not Found: /index
ERROR - 2024-08-31 18:45:01 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:45:01 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:45:02 --> Could not find the language line "Edit Prospect Status"
ERROR - 2024-08-31 18:45:02 --> Could not find the language line "Name"
ERROR - 2024-08-31 18:45:02 --> Could not find the language line "Description"
ERROR - 2024-08-31 18:45:02 --> Could not find the language line "Status"
ERROR - 2024-08-31 18:45:02 --> Could not find the language line "Save Changes"
ERROR - 2024-08-31 18:45:02 --> admin
ERROR - 2024-08-31 18:45:02 --> 12
ERROR - 2024-08-31 18:45:02 --> admin
ERROR - 2024-08-31 13:45:02 --> 404 Page Not Found: /index
ERROR - 2024-08-31 18:45:29 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:45:29 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:45:29 --> Could not find the language line "Edit Prospect Status"
ERROR - 2024-08-31 18:45:29 --> Could not find the language line "Name"
ERROR - 2024-08-31 18:45:29 --> Could not find the language line "Description"
ERROR - 2024-08-31 18:45:29 --> Could not find the language line "Status"
ERROR - 2024-08-31 18:45:29 --> Could not find the language line "Save Changes"
ERROR - 2024-08-31 18:45:29 --> admin
ERROR - 2024-08-31 18:45:29 --> 12
ERROR - 2024-08-31 18:45:29 --> admin
ERROR - 2024-08-31 13:45:29 --> 404 Page Not Found: /index
ERROR - 2024-08-31 18:46:29 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:46:29 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:46:30 --> Could not find the language line "Edit Prospect Status"
ERROR - 2024-08-31 18:46:30 --> Could not find the language line "Name"
ERROR - 2024-08-31 18:46:30 --> Could not find the language line "Description"
ERROR - 2024-08-31 18:46:30 --> Could not find the language line "Status"
ERROR - 2024-08-31 18:46:30 --> Could not find the language line "Save Changes"
ERROR - 2024-08-31 18:46:30 --> admin
ERROR - 2024-08-31 18:46:30 --> 12
ERROR - 2024-08-31 18:46:30 --> admin
ERROR - 2024-08-31 13:46:30 --> 404 Page Not Found: /index
ERROR - 2024-08-31 18:46:33 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:46:33 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:46:34 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:46:34 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:46:34 --> Could not find the language line "New Prospect Status"
ERROR - 2024-08-31 18:46:34 --> Could not find the language line "Name"
ERROR - 2024-08-31 18:46:34 --> Could not find the language line "Description"
ERROR - 2024-08-31 18:46:34 --> Could not find the language line "Actions"
ERROR - 2024-08-31 18:46:34 --> admin
ERROR - 2024-08-31 18:46:34 --> 12
ERROR - 2024-08-31 18:46:34 --> admin
ERROR - 2024-08-31 13:46:34 --> 404 Page Not Found: /index
ERROR - 2024-08-31 18:49:35 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:49:35 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:49:35 --> Could not find the language line "Edit Prospect Status"
ERROR - 2024-08-31 18:49:35 --> Could not find the language line "Name"
ERROR - 2024-08-31 18:49:35 --> Could not find the language line "Description"
ERROR - 2024-08-31 18:49:35 --> Could not find the language line "Status"
ERROR - 2024-08-31 18:49:35 --> Could not find the language line "Save Changes"
ERROR - 2024-08-31 18:49:35 --> admin
ERROR - 2024-08-31 18:49:35 --> 12
ERROR - 2024-08-31 18:49:35 --> admin
ERROR - 2024-08-31 13:49:35 --> 404 Page Not Found: /index
ERROR - 2024-08-31 18:50:02 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:50:02 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:50:02 --> Could not find the language line "Edit Prospect Status"
ERROR - 2024-08-31 18:50:02 --> Could not find the language line "Name"
ERROR - 2024-08-31 18:50:02 --> Could not find the language line "Description"
ERROR - 2024-08-31 18:50:02 --> Could not find the language line "Status"
ERROR - 2024-08-31 18:50:02 --> Could not find the language line "Save Changes"
ERROR - 2024-08-31 18:50:02 --> admin
ERROR - 2024-08-31 18:50:02 --> 12
ERROR - 2024-08-31 18:50:02 --> admin
ERROR - 2024-08-31 13:50:02 --> 404 Page Not Found: /index
ERROR - 2024-08-31 18:50:05 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:50:05 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:50:06 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:50:06 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:50:06 --> Could not find the language line "New Prospect Status"
ERROR - 2024-08-31 18:50:06 --> Could not find the language line "No prospect statuses found."
ERROR - 2024-08-31 18:50:06 --> admin
ERROR - 2024-08-31 18:50:06 --> 12
ERROR - 2024-08-31 18:50:06 --> admin
ERROR - 2024-08-31 13:50:07 --> 404 Page Not Found: /index
ERROR - 2024-08-31 18:53:48 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:53:48 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:53:48 --> Could not find the language line "New Prospect Status"
ERROR - 2024-08-31 18:53:48 --> Could not find the language line "Name"
ERROR - 2024-08-31 18:53:48 --> Could not find the language line "Description"
ERROR - 2024-08-31 18:53:48 --> Could not find the language line "Actions"
ERROR - 2024-08-31 18:53:48 --> admin
ERROR - 2024-08-31 18:53:48 --> 12
ERROR - 2024-08-31 18:53:48 --> admin
ERROR - 2024-08-31 13:53:49 --> 404 Page Not Found: /index
ERROR - 2024-08-31 18:53:53 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:53:53 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:53:54 --> Could not find the language line "Edit Prospect Status"
ERROR - 2024-08-31 18:53:54 --> Severity: Warning --> Attempt to read property "id" on null C:\laragon\www\perfex_crm\application\views\admin\setup\prospect_status\prospect_status_edit.php 12
ERROR - 2024-08-31 18:53:54 --> Could not find the language line "Name"
ERROR - 2024-08-31 18:53:54 --> Severity: Warning --> Attempt to read property "name" on null C:\laragon\www\perfex_crm\application\views\admin\setup\prospect_status\prospect_status_edit.php 16
ERROR - 2024-08-31 18:53:54 --> Could not find the language line "Description"
ERROR - 2024-08-31 18:53:54 --> Severity: Warning --> Attempt to read property "description" on null C:\laragon\www\perfex_crm\application\views\admin\setup\prospect_status\prospect_status_edit.php 21
ERROR - 2024-08-31 18:53:54 --> Could not find the language line "Status"
ERROR - 2024-08-31 18:53:54 --> Severity: Warning --> Attempt to read property "is_active" on null C:\laragon\www\perfex_crm\application\views\admin\setup\prospect_status\prospect_status_edit.php 26
ERROR - 2024-08-31 18:53:54 --> Severity: Warning --> Attempt to read property "is_active" on null C:\laragon\www\perfex_crm\application\views\admin\setup\prospect_status\prospect_status_edit.php 32
ERROR - 2024-08-31 18:53:54 --> Could not find the language line "Save Changes"
ERROR - 2024-08-31 18:53:54 --> admin
ERROR - 2024-08-31 18:53:54 --> 12
ERROR - 2024-08-31 18:53:54 --> admin
ERROR - 2024-08-31 13:53:54 --> 404 Page Not Found: /index
ERROR - 2024-08-31 18:54:27 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:54:27 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:54:28 --> Could not find the language line "New Prospect Status"
ERROR - 2024-08-31 18:54:28 --> Could not find the language line "No prospect statuses found."
ERROR - 2024-08-31 18:54:28 --> admin
ERROR - 2024-08-31 18:54:28 --> 12
ERROR - 2024-08-31 18:54:28 --> admin
ERROR - 2024-08-31 18:54:30 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:54:30 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:54:31 --> Could not find the language line "New Prospect Status"
ERROR - 2024-08-31 18:54:31 --> Could not find the language line "No prospect statuses found."
ERROR - 2024-08-31 18:54:31 --> admin
ERROR - 2024-08-31 18:54:31 --> 12
ERROR - 2024-08-31 18:54:31 --> admin
ERROR - 2024-08-31 13:54:31 --> 404 Page Not Found: /index
ERROR - 2024-08-31 18:54:37 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:54:37 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:54:38 --> Could not find the language line "New Prospect Status"
ERROR - 2024-08-31 18:54:38 --> Could not find the language line "Name"
ERROR - 2024-08-31 18:54:38 --> Could not find the language line "Description"
ERROR - 2024-08-31 18:54:38 --> Could not find the language line "Actions"
ERROR - 2024-08-31 18:54:38 --> admin
ERROR - 2024-08-31 18:54:38 --> 12
ERROR - 2024-08-31 18:54:38 --> admin
ERROR - 2024-08-31 13:54:38 --> 404 Page Not Found: /index
ERROR - 2024-08-31 18:54:40 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:54:40 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:54:41 --> Could not find the language line "Edit Prospect Status"
ERROR - 2024-08-31 18:54:41 --> Severity: Warning --> Attempt to read property "id" on null C:\laragon\www\perfex_crm\application\views\admin\setup\prospect_status\prospect_status_edit.php 12
ERROR - 2024-08-31 18:54:41 --> Could not find the language line "Name"
ERROR - 2024-08-31 18:54:41 --> Severity: Warning --> Attempt to read property "name" on null C:\laragon\www\perfex_crm\application\views\admin\setup\prospect_status\prospect_status_edit.php 16
ERROR - 2024-08-31 18:54:41 --> Could not find the language line "Description"
ERROR - 2024-08-31 18:54:41 --> Severity: Warning --> Attempt to read property "description" on null C:\laragon\www\perfex_crm\application\views\admin\setup\prospect_status\prospect_status_edit.php 21
ERROR - 2024-08-31 18:54:41 --> Could not find the language line "Status"
ERROR - 2024-08-31 18:54:41 --> Severity: Warning --> Attempt to read property "is_active" on null C:\laragon\www\perfex_crm\application\views\admin\setup\prospect_status\prospect_status_edit.php 26
ERROR - 2024-08-31 18:54:41 --> Severity: Warning --> Attempt to read property "is_active" on null C:\laragon\www\perfex_crm\application\views\admin\setup\prospect_status\prospect_status_edit.php 32
ERROR - 2024-08-31 18:54:41 --> Could not find the language line "Save Changes"
ERROR - 2024-08-31 18:54:41 --> admin
ERROR - 2024-08-31 18:54:41 --> 12
ERROR - 2024-08-31 18:54:41 --> admin
ERROR - 2024-08-31 13:54:41 --> 404 Page Not Found: /index
ERROR - 2024-08-31 18:55:15 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:55:15 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:55:15 --> Could not find the language line "Edit Prospect Status"
ERROR - 2024-08-31 18:55:15 --> Severity: Warning --> Attempt to read property "id" on null C:\laragon\www\perfex_crm\application\views\admin\setup\prospect_status\prospect_status_edit.php 12
ERROR - 2024-08-31 18:55:15 --> Could not find the language line "Name"
ERROR - 2024-08-31 18:55:15 --> Severity: Warning --> Attempt to read property "name" on null C:\laragon\www\perfex_crm\application\views\admin\setup\prospect_status\prospect_status_edit.php 16
ERROR - 2024-08-31 18:55:15 --> Could not find the language line "Description"
ERROR - 2024-08-31 18:55:15 --> Severity: Warning --> Attempt to read property "description" on null C:\laragon\www\perfex_crm\application\views\admin\setup\prospect_status\prospect_status_edit.php 21
ERROR - 2024-08-31 18:55:15 --> Could not find the language line "Status"
ERROR - 2024-08-31 18:55:15 --> Severity: Warning --> Attempt to read property "is_active" on null C:\laragon\www\perfex_crm\application\views\admin\setup\prospect_status\prospect_status_edit.php 26
ERROR - 2024-08-31 18:55:15 --> Severity: Warning --> Attempt to read property "is_active" on null C:\laragon\www\perfex_crm\application\views\admin\setup\prospect_status\prospect_status_edit.php 32
ERROR - 2024-08-31 18:55:15 --> Could not find the language line "Save Changes"
ERROR - 2024-08-31 18:55:15 --> admin
ERROR - 2024-08-31 18:55:15 --> 12
ERROR - 2024-08-31 18:55:15 --> admin
ERROR - 2024-08-31 13:55:15 --> 404 Page Not Found: /index
ERROR - 2024-08-31 18:55:24 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:55:24 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:55:24 --> Could not find the language line "Edit Prospect Status"
ERROR - 2024-08-31 18:55:24 --> Could not find the language line "Name"
ERROR - 2024-08-31 18:55:24 --> Could not find the language line "Description"
ERROR - 2024-08-31 18:55:24 --> Could not find the language line "Status"
ERROR - 2024-08-31 18:55:24 --> Could not find the language line "Save Changes"
ERROR - 2024-08-31 18:55:24 --> admin
ERROR - 2024-08-31 18:55:24 --> 12
ERROR - 2024-08-31 18:55:24 --> admin
ERROR - 2024-08-31 13:55:24 --> 404 Page Not Found: /index
ERROR - 2024-08-31 18:55:44 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:55:44 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:55:45 --> Could not find the language line "Edit Prospect Status"
ERROR - 2024-08-31 18:55:45 --> Could not find the language line "Name"
ERROR - 2024-08-31 18:55:45 --> Could not find the language line "Description"
ERROR - 2024-08-31 18:55:45 --> Could not find the language line "Status"
ERROR - 2024-08-31 18:55:45 --> Could not find the language line "Save Changes"
ERROR - 2024-08-31 18:55:45 --> admin
ERROR - 2024-08-31 18:55:45 --> 12
ERROR - 2024-08-31 18:55:45 --> admin
ERROR - 2024-08-31 13:55:45 --> 404 Page Not Found: /index
ERROR - 2024-08-31 18:55:47 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:55:47 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:55:48 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:55:48 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:55:48 --> Could not find the language line "New Prospect Status"
ERROR - 2024-08-31 18:55:48 --> Could not find the language line "Name"
ERROR - 2024-08-31 18:55:48 --> Could not find the language line "Description"
ERROR - 2024-08-31 18:55:48 --> Could not find the language line "Actions"
ERROR - 2024-08-31 18:55:48 --> admin
ERROR - 2024-08-31 18:55:48 --> 12
ERROR - 2024-08-31 18:55:48 --> admin
ERROR - 2024-08-31 13:55:48 --> 404 Page Not Found: /index
ERROR - 2024-08-31 18:55:54 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:55:54 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:55:54 --> Could not find the language line "Edit Prospect Status"
ERROR - 2024-08-31 18:55:54 --> Could not find the language line "Name"
ERROR - 2024-08-31 18:55:54 --> Could not find the language line "Description"
ERROR - 2024-08-31 18:55:54 --> Could not find the language line "Status"
ERROR - 2024-08-31 18:55:54 --> Could not find the language line "Save Changes"
ERROR - 2024-08-31 18:55:54 --> admin
ERROR - 2024-08-31 18:55:54 --> 12
ERROR - 2024-08-31 18:55:54 --> admin
ERROR - 2024-08-31 13:55:54 --> 404 Page Not Found: /index
ERROR - 2024-08-31 18:55:57 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:55:57 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:55:57 --> Could not find the language line "New Prospect Status"
ERROR - 2024-08-31 18:55:57 --> Could not find the language line "Name"
ERROR - 2024-08-31 18:55:57 --> Could not find the language line "Description"
ERROR - 2024-08-31 18:55:57 --> Could not find the language line "Actions"
ERROR - 2024-08-31 18:55:57 --> admin
ERROR - 2024-08-31 18:55:57 --> 12
ERROR - 2024-08-31 18:55:57 --> admin
ERROR - 2024-08-31 18:56:05 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:56:05 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:56:05 --> Could not find the language line "Edit Prospect Status"
ERROR - 2024-08-31 18:56:05 --> Could not find the language line "Name"
ERROR - 2024-08-31 18:56:05 --> Could not find the language line "Description"
ERROR - 2024-08-31 18:56:05 --> Could not find the language line "Status"
ERROR - 2024-08-31 18:56:05 --> Could not find the language line "Save Changes"
ERROR - 2024-08-31 18:56:05 --> admin
ERROR - 2024-08-31 18:56:05 --> 12
ERROR - 2024-08-31 18:56:05 --> admin
ERROR - 2024-08-31 13:56:05 --> 404 Page Not Found: /index
ERROR - 2024-08-31 18:56:08 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:56:08 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:56:08 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:56:08 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:56:09 --> Could not find the language line "New Prospect Status"
ERROR - 2024-08-31 18:56:09 --> Could not find the language line "Name"
ERROR - 2024-08-31 18:56:09 --> Could not find the language line "Description"
ERROR - 2024-08-31 18:56:09 --> Could not find the language line "Actions"
ERROR - 2024-08-31 18:56:09 --> admin
ERROR - 2024-08-31 18:56:09 --> 12
ERROR - 2024-08-31 18:56:09 --> admin
ERROR - 2024-08-31 13:56:09 --> 404 Page Not Found: /index
ERROR - 2024-08-31 18:56:11 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:56:11 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:56:11 --> Could not find the language line "Edit Prospect Status"
ERROR - 2024-08-31 18:56:11 --> Could not find the language line "Name"
ERROR - 2024-08-31 18:56:11 --> Could not find the language line "Description"
ERROR - 2024-08-31 18:56:11 --> Could not find the language line "Status"
ERROR - 2024-08-31 18:56:11 --> Could not find the language line "Save Changes"
ERROR - 2024-08-31 18:56:11 --> admin
ERROR - 2024-08-31 18:56:11 --> 12
ERROR - 2024-08-31 18:56:11 --> admin
ERROR - 2024-08-31 13:56:11 --> 404 Page Not Found: /index
ERROR - 2024-08-31 18:56:14 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:56:14 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:56:15 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:56:15 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:56:15 --> Could not find the language line "New Prospect Status"
ERROR - 2024-08-31 18:56:15 --> Could not find the language line "Name"
ERROR - 2024-08-31 18:56:15 --> Could not find the language line "Description"
ERROR - 2024-08-31 18:56:15 --> Could not find the language line "Actions"
ERROR - 2024-08-31 18:56:15 --> admin
ERROR - 2024-08-31 18:56:15 --> 12
ERROR - 2024-08-31 18:56:15 --> admin
ERROR - 2024-08-31 13:56:15 --> 404 Page Not Found: /index
ERROR - 2024-08-31 18:56:21 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 18:56:21 --> Could not find the language line "billings"
ERROR - 2024-08-31 18:56:21 --> Could not find the language line "Edit Prospect Status"
ERROR - 2024-08-31 18:56:21 --> Could not find the language line "Name"
ERROR - 2024-08-31 18:56:21 --> Could not find the language line "Description"
ERROR - 2024-08-31 18:56:21 --> Could not find the language line "Status"
ERROR - 2024-08-31 18:56:21 --> Could not find the language line "Save Changes"
ERROR - 2024-08-31 18:56:21 --> admin
ERROR - 2024-08-31 18:56:21 --> 12
ERROR - 2024-08-31 18:56:21 --> admin
ERROR - 2024-08-31 13:56:21 --> 404 Page Not Found: /index
ERROR - 2024-08-31 19:07:13 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 19:07:13 --> Could not find the language line "billings"
ERROR - 2024-08-31 19:07:14 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 19:07:14 --> Could not find the language line "billings"
ERROR - 2024-08-31 19:07:14 --> Could not find the language line "New Prospect Status"
ERROR - 2024-08-31 19:07:14 --> Could not find the language line "Name"
ERROR - 2024-08-31 19:07:14 --> Could not find the language line "Description"
ERROR - 2024-08-31 19:07:14 --> Could not find the language line "Actions"
ERROR - 2024-08-31 19:07:14 --> admin
ERROR - 2024-08-31 19:07:14 --> 12
ERROR - 2024-08-31 19:07:14 --> admin
ERROR - 2024-08-31 14:07:15 --> 404 Page Not Found: /index
ERROR - 2024-08-31 19:07:32 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 19:07:32 --> Could not find the language line "billings"
ERROR - 2024-08-31 19:07:33 --> Could not find the language line "Create Prospect Status"
ERROR - 2024-08-31 19:07:33 --> Could not find the language line "Name"
ERROR - 2024-08-31 19:07:33 --> Could not find the language line "Description"
ERROR - 2024-08-31 19:07:33 --> Could not find the language line "Status"
ERROR - 2024-08-31 19:07:33 --> Could not find the language line "Create"
ERROR - 2024-08-31 19:07:33 --> admin
ERROR - 2024-08-31 19:07:33 --> 12
ERROR - 2024-08-31 19:07:33 --> admin
ERROR - 2024-08-31 14:07:33 --> 404 Page Not Found: /index
ERROR - 2024-08-31 19:08:43 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 19:08:43 --> Could not find the language line "billings"
ERROR - 2024-08-31 19:08:43 --> admin
ERROR - 2024-08-31 19:08:43 --> 12
ERROR - 2024-08-31 19:08:43 --> admin
ERROR - 2024-08-31 14:08:43 --> 404 Page Not Found: /index
ERROR - 2024-08-31 14:08:43 --> 404 Page Not Found: /index
ERROR - 2024-08-31 19:09:24 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 19:09:24 --> Could not find the language line "billings"
ERROR - 2024-08-31 19:09:24 --> admin
ERROR - 2024-08-31 19:09:24 --> 12
ERROR - 2024-08-31 19:09:24 --> admin
ERROR - 2024-08-31 14:09:25 --> 404 Page Not Found: /index
ERROR - 2024-08-31 19:09:31 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 19:09:31 --> Could not find the language line "billings"
ERROR - 2024-08-31 19:09:31 --> admin
ERROR - 2024-08-31 19:09:31 --> 12
ERROR - 2024-08-31 19:09:31 --> admin
ERROR - 2024-08-31 14:09:32 --> 404 Page Not Found: /index
ERROR - 2024-08-31 19:10:21 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 19:10:21 --> Could not find the language line "billings"
ERROR - 2024-08-31 19:10:44 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 19:10:44 --> Could not find the language line "billings"
ERROR - 2024-08-31 19:10:44 --> admin
ERROR - 2024-08-31 19:10:44 --> 12
ERROR - 2024-08-31 19:10:44 --> admin
ERROR - 2024-08-31 14:10:44 --> 404 Page Not Found: /index
ERROR - 2024-08-31 19:10:46 --> Could not find the language line "Information Points"
ERROR - 2024-08-31 19:10:46 --> Could not find the language line "billings"
