<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-09-01 04:00:17 --> Severity: error --> Exception: No connection could be made because the target machine actively refused it C:\laragon\www\perfex_crm\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2024-09-01 04:00:18 --> Severity: error --> Exception: No connection could be made because the target machine actively refused it C:\laragon\www\perfex_crm\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2024-09-01 04:00:19 --> Severity: error --> Exception: No connection could be made because the target machine actively refused it C:\laragon\www\perfex_crm\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2024-09-01 09:02:20 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:02:20 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:02:20 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:02:20 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:02:31 --> admin
ERROR - 2024-09-01 09:02:31 --> admin
ERROR - 2024-09-01 09:02:31 --> 12
ERROR - 2024-09-01 09:02:31 --> 12
ERROR - 2024-09-01 09:02:31 --> admin
ERROR - 2024-09-01 09:02:31 --> admin
ERROR - 2024-09-01 04:02:32 --> 404 Page Not Found: /index
ERROR - 2024-09-01 04:02:32 --> 404 Page Not Found: /index
ERROR - 2024-09-01 09:02:35 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:02:35 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:03:13 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:03:13 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:03:19 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:03:19 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:03:20 --> Could not find the language line "New Prospect Status"
ERROR - 2024-09-01 09:03:20 --> Could not find the language line "Name"
ERROR - 2024-09-01 09:03:20 --> Could not find the language line "Description"
ERROR - 2024-09-01 09:03:20 --> Could not find the language line "Actions"
ERROR - 2024-09-01 09:03:20 --> admin
ERROR - 2024-09-01 09:03:20 --> 12
ERROR - 2024-09-01 09:03:20 --> admin
ERROR - 2024-09-01 04:03:20 --> 404 Page Not Found: /index
ERROR - 2024-09-01 09:07:21 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:07:21 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:07:22 --> Could not find the language line "New Prospect Status"
ERROR - 2024-09-01 09:07:22 --> Could not find the language line "Name"
ERROR - 2024-09-01 09:07:22 --> Could not find the language line "Description"
ERROR - 2024-09-01 09:07:22 --> Could not find the language line "Status"
ERROR - 2024-09-01 09:07:22 --> Could not find the language line "Actions"
ERROR - 2024-09-01 09:07:22 --> admin
ERROR - 2024-09-01 09:07:22 --> 12
ERROR - 2024-09-01 09:07:22 --> admin
ERROR - 2024-09-01 04:07:22 --> 404 Page Not Found: /index
ERROR - 2024-09-01 09:07:25 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:07:25 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:07:26 --> Could not find the language line "Edit Prospect Status"
ERROR - 2024-09-01 09:07:26 --> Could not find the language line "Name"
ERROR - 2024-09-01 09:07:26 --> Could not find the language line "Description"
ERROR - 2024-09-01 09:07:26 --> Could not find the language line "Status"
ERROR - 2024-09-01 09:07:26 --> Could not find the language line "Save Changes"
ERROR - 2024-09-01 09:07:26 --> admin
ERROR - 2024-09-01 09:07:26 --> 12
ERROR - 2024-09-01 09:07:26 --> admin
ERROR - 2024-09-01 04:07:26 --> 404 Page Not Found: /index
ERROR - 2024-09-01 09:07:29 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:07:29 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:07:29 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:07:29 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:07:30 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:07:30 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:07:30 --> Could not find the language line "New Prospect Status"
ERROR - 2024-09-01 09:07:30 --> Could not find the language line "Name"
ERROR - 2024-09-01 09:07:30 --> Could not find the language line "Description"
ERROR - 2024-09-01 09:07:30 --> Could not find the language line "Status"
ERROR - 2024-09-01 09:07:30 --> Could not find the language line "Actions"
ERROR - 2024-09-01 09:07:30 --> admin
ERROR - 2024-09-01 09:07:30 --> 12
ERROR - 2024-09-01 09:07:30 --> admin
ERROR - 2024-09-01 04:07:30 --> 404 Page Not Found: /index
ERROR - 2024-09-01 09:10:43 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:10:43 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:10:43 --> Could not find the language line "New Prospect Type"
ERROR - 2024-09-01 09:10:43 --> Could not find the language line "No prospect types found."
ERROR - 2024-09-01 09:10:43 --> admin
ERROR - 2024-09-01 09:10:43 --> 12
ERROR - 2024-09-01 09:10:43 --> admin
ERROR - 2024-09-01 04:10:43 --> 404 Page Not Found: /index
ERROR - 2024-09-01 09:10:45 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:10:45 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:10:46 --> Could not find the language line "Create Prospect Type"
ERROR - 2024-09-01 09:10:46 --> Could not find the language line "Name"
ERROR - 2024-09-01 09:10:46 --> Could not find the language line "Description"
ERROR - 2024-09-01 09:10:46 --> Could not find the language line "Create"
ERROR - 2024-09-01 09:10:46 --> admin
ERROR - 2024-09-01 09:10:46 --> 12
ERROR - 2024-09-01 09:10:46 --> admin
ERROR - 2024-09-01 04:10:46 --> 404 Page Not Found: /index
ERROR - 2024-09-01 09:13:51 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:13:51 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:13:51 --> Could not find the language line "Create Prospect Type"
ERROR - 2024-09-01 09:13:51 --> Could not find the language line "Name"
ERROR - 2024-09-01 09:13:51 --> Could not find the language line "Description"
ERROR - 2024-09-01 09:13:51 --> Could not find the language line "Create"
ERROR - 2024-09-01 09:13:51 --> admin
ERROR - 2024-09-01 09:13:51 --> 12
ERROR - 2024-09-01 09:13:51 --> admin
ERROR - 2024-09-01 04:13:52 --> 404 Page Not Found: /index
ERROR - 2024-09-01 09:13:59 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:13:59 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:13:59 --> Could not find the language line "Create Prospect Type"
ERROR - 2024-09-01 09:13:59 --> Could not find the language line "Name"
ERROR - 2024-09-01 09:13:59 --> Could not find the language line "Description"
ERROR - 2024-09-01 09:13:59 --> Could not find the language line "Status"
ERROR - 2024-09-01 09:13:59 --> Could not find the language line "Create"
ERROR - 2024-09-01 09:13:59 --> admin
ERROR - 2024-09-01 09:13:59 --> 12
ERROR - 2024-09-01 09:13:59 --> admin
ERROR - 2024-09-01 04:13:59 --> 404 Page Not Found: /index
ERROR - 2024-09-01 09:16:13 --> client
ERROR - 2024-09-01 09:16:13 --> 12
ERROR - 2024-09-01 09:16:13 --> client
ERROR - 2024-09-01 09:16:17 --> client
ERROR - 2024-09-01 09:16:17 --> 12
ERROR - 2024-09-01 09:16:17 --> client
ERROR - 2024-09-01 09:17:08 --> client
ERROR - 2024-09-01 09:17:08 --> 12
ERROR - 2024-09-01 09:17:08 --> client
ERROR - 2024-09-01 09:17:44 --> client
ERROR - 2024-09-01 09:17:44 --> 12
ERROR - 2024-09-01 09:17:44 --> client
ERROR - 2024-09-01 09:17:56 --> client
ERROR - 2024-09-01 09:17:56 --> 12
ERROR - 2024-09-01 09:17:56 --> client
ERROR - 2024-09-01 09:18:03 --> client
ERROR - 2024-09-01 09:18:03 --> 12
ERROR - 2024-09-01 09:18:03 --> client
ERROR - 2024-09-01 09:18:07 --> client
ERROR - 2024-09-01 09:18:07 --> 12
ERROR - 2024-09-01 09:18:07 --> client
ERROR - 2024-09-01 09:18:22 --> client
ERROR - 2024-09-01 09:18:22 --> 12
ERROR - 2024-09-01 09:18:22 --> client
ERROR - 2024-09-01 09:19:11 --> client
ERROR - 2024-09-01 09:19:11 --> 12
ERROR - 2024-09-01 09:19:11 --> client
ERROR - 2024-09-01 09:19:41 --> client
ERROR - 2024-09-01 09:19:41 --> 12
ERROR - 2024-09-01 09:19:41 --> client
ERROR - 2024-09-01 09:19:49 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:19:49 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:19:49 --> admin
ERROR - 2024-09-01 09:19:49 --> 12
ERROR - 2024-09-01 09:19:49 --> admin
ERROR - 2024-09-01 04:19:50 --> 404 Page Not Found: /index
ERROR - 2024-09-01 09:19:58 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:19:58 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:19:58 --> admin
ERROR - 2024-09-01 09:19:58 --> 12
ERROR - 2024-09-01 09:19:58 --> admin
ERROR - 2024-09-01 04:19:58 --> 404 Page Not Found: /index
ERROR - 2024-09-01 09:20:02 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:20:02 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:20:02 --> admin
ERROR - 2024-09-01 09:20:02 --> 12
ERROR - 2024-09-01 09:20:02 --> admin
ERROR - 2024-09-01 04:20:02 --> 404 Page Not Found: /index
ERROR - 2024-09-01 09:20:03 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:20:03 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:20:09 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:20:09 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:20:11 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:20:11 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:20:12 --> admin
ERROR - 2024-09-01 09:20:12 --> 12
ERROR - 2024-09-01 09:20:12 --> admin
ERROR - 2024-09-01 04:20:12 --> 404 Page Not Found: /index
ERROR - 2024-09-01 09:20:13 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:20:13 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:20:17 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:20:17 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:20:18 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:20:18 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:20:19 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:20:19 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:20:22 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:20:22 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:20:24 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:20:24 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:20:25 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:20:25 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:20:39 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:20:39 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:20:40 --> admin
ERROR - 2024-09-01 09:20:40 --> 12
ERROR - 2024-09-01 09:20:40 --> admin
ERROR - 2024-09-01 04:20:40 --> 404 Page Not Found: /index
ERROR - 2024-09-01 09:20:46 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:20:46 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:20:47 --> admin
ERROR - 2024-09-01 09:20:47 --> 12
ERROR - 2024-09-01 09:20:47 --> admin
ERROR - 2024-09-01 04:20:47 --> 404 Page Not Found: /index
ERROR - 2024-09-01 09:20:47 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:20:47 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:20:51 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:20:51 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:20:51 --> admin
ERROR - 2024-09-01 09:20:51 --> 12
ERROR - 2024-09-01 09:20:51 --> admin
ERROR - 2024-09-01 04:20:51 --> 404 Page Not Found: /index
ERROR - 2024-09-01 09:20:56 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:20:56 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:20:57 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:20:57 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:20:57 --> admin
ERROR - 2024-09-01 09:20:57 --> 12
ERROR - 2024-09-01 09:20:57 --> admin
ERROR - 2024-09-01 04:20:57 --> 404 Page Not Found: /index
ERROR - 2024-09-01 09:22:20 --> client
ERROR - 2024-09-01 09:22:20 --> 12
ERROR - 2024-09-01 09:22:20 --> client
ERROR - 2024-09-01 09:24:05 --> client
ERROR - 2024-09-01 09:24:05 --> 12
ERROR - 2024-09-01 09:24:05 --> client
ERROR - 2024-09-01 09:24:09 --> client
ERROR - 2024-09-01 09:24:09 --> 12
ERROR - 2024-09-01 09:24:09 --> client
ERROR - 2024-09-01 09:24:14 --> client
ERROR - 2024-09-01 09:24:14 --> 12
ERROR - 2024-09-01 09:24:14 --> client
ERROR - 2024-09-01 09:24:19 --> client
ERROR - 2024-09-01 09:24:19 --> 12
ERROR - 2024-09-01 09:24:19 --> client
ERROR - 2024-09-01 09:24:24 --> client
ERROR - 2024-09-01 09:24:24 --> 12
ERROR - 2024-09-01 09:24:24 --> client
ERROR - 2024-09-01 09:24:53 --> client
ERROR - 2024-09-01 09:24:53 --> 12
ERROR - 2024-09-01 09:24:53 --> client
ERROR - 2024-09-01 09:24:59 --> client
ERROR - 2024-09-01 09:24:59 --> 12
ERROR - 2024-09-01 09:24:59 --> client
ERROR - 2024-09-01 09:25:01 --> client
ERROR - 2024-09-01 09:25:01 --> 12
ERROR - 2024-09-01 09:25:01 --> client
ERROR - 2024-09-01 09:25:03 --> client
ERROR - 2024-09-01 09:25:03 --> 12
ERROR - 2024-09-01 09:25:03 --> client
ERROR - 2024-09-01 09:25:06 --> client
ERROR - 2024-09-01 09:25:06 --> 12
ERROR - 2024-09-01 09:25:06 --> client
ERROR - 2024-09-01 09:25:08 --> client
ERROR - 2024-09-01 09:25:08 --> 12
ERROR - 2024-09-01 09:25:08 --> client
ERROR - 2024-09-01 09:25:14 --> client
ERROR - 2024-09-01 09:25:14 --> 12
ERROR - 2024-09-01 09:25:14 --> client
ERROR - 2024-09-01 09:25:17 --> client
ERROR - 2024-09-01 09:25:17 --> 12
ERROR - 2024-09-01 09:25:17 --> client
ERROR - 2024-09-01 09:25:20 --> client
ERROR - 2024-09-01 09:25:20 --> 12
ERROR - 2024-09-01 09:25:20 --> client
ERROR - 2024-09-01 09:26:12 --> client
ERROR - 2024-09-01 09:26:12 --> 12
ERROR - 2024-09-01 09:26:12 --> client
ERROR - 2024-09-01 09:26:17 --> client
ERROR - 2024-09-01 09:26:17 --> 12
ERROR - 2024-09-01 09:26:17 --> client
ERROR - 2024-09-01 09:26:21 --> client
ERROR - 2024-09-01 09:26:21 --> 12
ERROR - 2024-09-01 09:26:21 --> client
ERROR - 2024-09-01 09:26:25 --> client
ERROR - 2024-09-01 09:26:25 --> 12
ERROR - 2024-09-01 09:26:25 --> client
ERROR - 2024-09-01 09:26:43 --> Severity: error --> Exception: In aggregated query without GROUP BY, expression #2 of SELECT list contains nonaggregated column 'reported.reported_today'; this is incompatible with sql_mode=only_full_group_by C:\laragon\www\perfex_crm\system\database\drivers\mysqli\mysqli_driver.php 307
ERROR - 2024-09-01 09:26:47 --> Severity: error --> Exception: In aggregated query without GROUP BY, expression #2 of SELECT list contains nonaggregated column 'reported.reported_today'; this is incompatible with sql_mode=only_full_group_by C:\laragon\www\perfex_crm\system\database\drivers\mysqli\mysqli_driver.php 307
ERROR - 2024-09-01 09:26:51 --> Severity: error --> Exception: In aggregated query without GROUP BY, expression #2 of SELECT list contains nonaggregated column 'reported.reported_today'; this is incompatible with sql_mode=only_full_group_by C:\laragon\www\perfex_crm\system\database\drivers\mysqli\mysqli_driver.php 307
ERROR - 2024-09-01 09:26:54 --> Severity: error --> Exception: In aggregated query without GROUP BY, expression #2 of SELECT list contains nonaggregated column 'reported.reported_today'; this is incompatible with sql_mode=only_full_group_by C:\laragon\www\perfex_crm\system\database\drivers\mysqli\mysqli_driver.php 307
ERROR - 2024-09-01 09:26:56 --> Severity: error --> Exception: In aggregated query without GROUP BY, expression #2 of SELECT list contains nonaggregated column 'reported.reported_today'; this is incompatible with sql_mode=only_full_group_by C:\laragon\www\perfex_crm\system\database\drivers\mysqli\mysqli_driver.php 307
ERROR - 2024-09-01 09:27:02 --> client
ERROR - 2024-09-01 09:27:02 --> 12
ERROR - 2024-09-01 09:27:02 --> client
ERROR - 2024-09-01 09:27:25 --> Severity: error --> Exception: In aggregated query without GROUP BY, expression #2 of SELECT list contains nonaggregated column 'reported.reported_today'; this is incompatible with sql_mode=only_full_group_by C:\laragon\www\perfex_crm\system\database\drivers\mysqli\mysqli_driver.php 307
ERROR - 2024-09-01 09:27:53 --> Severity: error --> Exception: In aggregated query without GROUP BY, expression #2 of SELECT list contains nonaggregated column 'reported.reported_today'; this is incompatible with sql_mode=only_full_group_by C:\laragon\www\perfex_crm\system\database\drivers\mysqli\mysqli_driver.php 307
ERROR - 2024-09-01 09:27:55 --> Severity: error --> Exception: In aggregated query without GROUP BY, expression #2 of SELECT list contains nonaggregated column 'reported.reported_today'; this is incompatible with sql_mode=only_full_group_by C:\laragon\www\perfex_crm\system\database\drivers\mysqli\mysqli_driver.php 307
ERROR - 2024-09-01 09:28:01 --> Severity: error --> Exception: In aggregated query without GROUP BY, expression #2 of SELECT list contains nonaggregated column 'reported.reported_today'; this is incompatible with sql_mode=only_full_group_by C:\laragon\www\perfex_crm\system\database\drivers\mysqli\mysqli_driver.php 307
ERROR - 2024-09-01 09:28:12 --> Severity: error --> Exception: In aggregated query without GROUP BY, expression #2 of SELECT list contains nonaggregated column 'reported.reported_today'; this is incompatible with sql_mode=only_full_group_by C:\laragon\www\perfex_crm\system\database\drivers\mysqli\mysqli_driver.php 307
ERROR - 2024-09-01 09:28:27 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:28:27 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:28:27 --> admin
ERROR - 2024-09-01 09:28:27 --> 12
ERROR - 2024-09-01 09:28:27 --> admin
ERROR - 2024-09-01 04:28:28 --> 404 Page Not Found: /index
ERROR - 2024-09-01 09:28:58 --> Severity: Warning --> Undefined variable $query C:\laragon\www\perfex_crm\application\models\leadevo\Stats_model.php 31
ERROR - 2024-09-01 09:28:58 --> Severity: error --> Exception: Call to a member function result() on null C:\laragon\www\perfex_crm\application\models\leadevo\Stats_model.php 31
ERROR - 2024-09-01 09:29:12 --> Severity: error --> Exception: Call to a member function result() on string C:\laragon\www\perfex_crm\application\models\leadevo\Stats_model.php 31
ERROR - 2024-09-01 09:29:21 --> Severity: error --> Exception: In aggregated query without GROUP BY, expression #2 of SELECT list contains nonaggregated column 'reported.reported_today'; this is incompatible with sql_mode=only_full_group_by C:\laragon\www\perfex_crm\system\database\drivers\mysqli\mysqli_driver.php 307
ERROR - 2024-09-01 09:29:58 --> Severity: error --> Exception: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ') AS reported
                  WHERE l.client_id = 30 AND l.campaign_id IS NOT' at line 15 C:\laragon\www\perfex_crm\system\database\drivers\mysqli\mysqli_driver.php 307
ERROR - 2024-09-01 09:30:46 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:30:46 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:30:46 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:30:46 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:30:46 --> Could not find the language line "New Prospect Type"
ERROR - 2024-09-01 09:30:46 --> Could not find the language line "Name"
ERROR - 2024-09-01 09:30:46 --> Could not find the language line "Description"
ERROR - 2024-09-01 09:30:46 --> Could not find the language line "Actions"
ERROR - 2024-09-01 09:30:46 --> admin
ERROR - 2024-09-01 09:30:46 --> 12
ERROR - 2024-09-01 09:30:46 --> admin
ERROR - 2024-09-01 04:30:46 --> 404 Page Not Found: /index
ERROR - 2024-09-01 09:31:43 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:31:43 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:31:43 --> Could not find the language line "New Prospect Type"
ERROR - 2024-09-01 09:31:43 --> Could not find the language line "Name"
ERROR - 2024-09-01 09:31:43 --> Could not find the language line "Description"
ERROR - 2024-09-01 09:31:43 --> Could not find the language line "Status"
ERROR - 2024-09-01 09:31:43 --> Could not find the language line "Actions"
ERROR - 2024-09-01 09:31:43 --> admin
ERROR - 2024-09-01 09:31:43 --> 12
ERROR - 2024-09-01 09:31:43 --> admin
ERROR - 2024-09-01 04:31:43 --> 404 Page Not Found: /index
ERROR - 2024-09-01 09:31:46 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:31:46 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:31:47 --> Could not find the language line "Name"
ERROR - 2024-09-01 09:31:47 --> Could not find the language line "Description"
ERROR - 2024-09-01 09:31:47 --> Could not find the language line "Status"
ERROR - 2024-09-01 09:31:47 --> Could not find the language line "Save"
ERROR - 2024-09-01 09:31:47 --> admin
ERROR - 2024-09-01 09:31:47 --> 12
ERROR - 2024-09-01 09:31:47 --> admin
ERROR - 2024-09-01 04:31:47 --> 404 Page Not Found: /index
ERROR - 2024-09-01 09:31:49 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:31:49 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:31:50 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:31:50 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:31:50 --> Could not find the language line "New Prospect Type"
ERROR - 2024-09-01 09:31:50 --> Could not find the language line "No prospect types found."
ERROR - 2024-09-01 09:31:50 --> admin
ERROR - 2024-09-01 09:31:50 --> 12
ERROR - 2024-09-01 09:31:50 --> admin
ERROR - 2024-09-01 04:31:50 --> 404 Page Not Found: /index
ERROR - 2024-09-01 09:32:10 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:32:10 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:32:10 --> Could not find the language line "New Prospect Type"
ERROR - 2024-09-01 09:32:10 --> Could not find the language line "Name"
ERROR - 2024-09-01 09:32:10 --> Could not find the language line "Description"
ERROR - 2024-09-01 09:32:10 --> Could not find the language line "Status"
ERROR - 2024-09-01 09:32:10 --> Could not find the language line "Actions"
ERROR - 2024-09-01 09:32:10 --> admin
ERROR - 2024-09-01 09:32:10 --> 12
ERROR - 2024-09-01 09:32:10 --> admin
ERROR - 2024-09-01 04:32:10 --> 404 Page Not Found: /index
ERROR - 2024-09-01 09:32:51 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:32:51 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:32:51 --> Could not find the language line "Name"
ERROR - 2024-09-01 09:32:51 --> Severity: Warning --> Attempt to read property "name" on null C:\laragon\www\perfex_crm\application\views\admin\setup\prospect_types\prospect_type_edit.php 14
ERROR - 2024-09-01 09:32:51 --> Could not find the language line "Description"
ERROR - 2024-09-01 09:32:51 --> Severity: Warning --> Attempt to read property "description" on null C:\laragon\www\perfex_crm\application\views\admin\setup\prospect_types\prospect_type_edit.php 19
ERROR - 2024-09-01 09:32:51 --> Could not find the language line "Status"
ERROR - 2024-09-01 09:32:51 --> Severity: Warning --> Attempt to read property "is_active" on null C:\laragon\www\perfex_crm\application\views\admin\setup\prospect_types\prospect_type_edit.php 24
ERROR - 2024-09-01 09:32:51 --> Severity: Warning --> Attempt to read property "is_active" on null C:\laragon\www\perfex_crm\application\views\admin\setup\prospect_types\prospect_type_edit.php 30
ERROR - 2024-09-01 09:32:51 --> Could not find the language line "Save"
ERROR - 2024-09-01 09:32:51 --> admin
ERROR - 2024-09-01 09:32:51 --> 12
ERROR - 2024-09-01 09:32:51 --> admin
ERROR - 2024-09-01 04:32:51 --> 404 Page Not Found: /index
ERROR - 2024-09-01 09:33:28 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:33:28 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:33:28 --> Could not find the language line "Name"
ERROR - 2024-09-01 09:33:28 --> Could not find the language line "Description"
ERROR - 2024-09-01 09:33:28 --> Could not find the language line "Status"
ERROR - 2024-09-01 09:33:28 --> Could not find the language line "Save"
ERROR - 2024-09-01 09:33:28 --> admin
ERROR - 2024-09-01 09:33:28 --> 12
ERROR - 2024-09-01 09:33:28 --> admin
ERROR - 2024-09-01 04:33:28 --> 404 Page Not Found: /index
ERROR - 2024-09-01 09:33:33 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:33:33 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:33:34 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:33:34 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:33:34 --> Could not find the language line "New Prospect Type"
ERROR - 2024-09-01 09:33:34 --> Could not find the language line "Name"
ERROR - 2024-09-01 09:33:34 --> Could not find the language line "Description"
ERROR - 2024-09-01 09:33:34 --> Could not find the language line "Status"
ERROR - 2024-09-01 09:33:34 --> Could not find the language line "Actions"
ERROR - 2024-09-01 09:33:34 --> admin
ERROR - 2024-09-01 09:33:34 --> 12
ERROR - 2024-09-01 09:33:34 --> admin
ERROR - 2024-09-01 04:33:34 --> 404 Page Not Found: /index
ERROR - 2024-09-01 09:34:12 --> client
ERROR - 2024-09-01 09:34:12 --> 12
ERROR - 2024-09-01 09:34:12 --> client
ERROR - 2024-09-01 09:34:20 --> client
ERROR - 2024-09-01 09:34:20 --> 12
ERROR - 2024-09-01 09:34:20 --> client
ERROR - 2024-09-01 09:34:27 --> client
ERROR - 2024-09-01 09:34:27 --> 12
ERROR - 2024-09-01 09:34:27 --> client
ERROR - 2024-09-01 09:38:33 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:38:33 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:38:33 --> Severity: error --> Exception: Too few arguments to function Prospect_types_model::get_all(), 0 passed in C:\laragon\www\perfex_crm\application\controllers\admin\leadevo\Prospect_types.php on line 16 and exactly 1 expected C:\laragon\www\perfex_crm\application\models\leadevo\Prospect_types_model.php 12
ERROR - 2024-09-01 09:38:46 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:38:46 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:38:46 --> Could not find the language line "New Prospect Type"
ERROR - 2024-09-01 09:38:46 --> Could not find the language line "Name"
ERROR - 2024-09-01 09:38:46 --> Could not find the language line "Description"
ERROR - 2024-09-01 09:38:46 --> Could not find the language line "Status"
ERROR - 2024-09-01 09:38:46 --> Could not find the language line "Actions"
ERROR - 2024-09-01 09:38:46 --> admin
ERROR - 2024-09-01 09:38:46 --> 12
ERROR - 2024-09-01 09:38:46 --> admin
ERROR - 2024-09-01 04:38:47 --> 404 Page Not Found: /index
ERROR - 2024-09-01 09:38:49 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:38:49 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:38:50 --> Could not find the language line "Name"
ERROR - 2024-09-01 09:38:50 --> Could not find the language line "Description"
ERROR - 2024-09-01 09:38:50 --> Could not find the language line "Status"
ERROR - 2024-09-01 09:38:50 --> Could not find the language line "Save"
ERROR - 2024-09-01 09:38:50 --> admin
ERROR - 2024-09-01 09:38:50 --> 12
ERROR - 2024-09-01 09:38:50 --> admin
ERROR - 2024-09-01 04:38:50 --> 404 Page Not Found: /index
ERROR - 2024-09-01 09:38:52 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:38:52 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:38:52 --> Could not find the language line "New Prospect Type"
ERROR - 2024-09-01 09:38:52 --> Could not find the language line "Name"
ERROR - 2024-09-01 09:38:52 --> Could not find the language line "Description"
ERROR - 2024-09-01 09:38:52 --> Could not find the language line "Status"
ERROR - 2024-09-01 09:38:52 --> Could not find the language line "Actions"
ERROR - 2024-09-01 09:38:52 --> admin
ERROR - 2024-09-01 09:38:52 --> 12
ERROR - 2024-09-01 09:38:52 --> admin
ERROR - 2024-09-01 09:40:37 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:40:37 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:40:37 --> Could not find the language line "New Prospect Type"
ERROR - 2024-09-01 09:40:37 --> Could not find the language line "Name"
ERROR - 2024-09-01 09:40:37 --> Could not find the language line "Description"
ERROR - 2024-09-01 09:40:37 --> Could not find the language line "Status"
ERROR - 2024-09-01 09:40:37 --> Could not find the language line "Actions"
ERROR - 2024-09-01 09:40:37 --> admin
ERROR - 2024-09-01 09:40:37 --> 12
ERROR - 2024-09-01 09:40:37 --> admin
ERROR - 2024-09-01 04:40:37 --> 404 Page Not Found: /index
ERROR - 2024-09-01 09:41:15 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:41:15 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:41:21 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:41:21 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:41:21 --> Could not find the language line "New Prospect category"
ERROR - 2024-09-01 09:41:21 --> Could not find the language line "No prospect categories found."
ERROR - 2024-09-01 09:41:21 --> admin
ERROR - 2024-09-01 09:41:21 --> 12
ERROR - 2024-09-01 09:41:21 --> admin
ERROR - 2024-09-01 04:41:21 --> 404 Page Not Found: /index
ERROR - 2024-09-01 09:41:23 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:41:23 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:41:23 --> Could not find the language line "Create Prospect Category"
ERROR - 2024-09-01 09:41:23 --> Could not find the language line "Name"
ERROR - 2024-09-01 09:41:23 --> Could not find the language line "Description"
ERROR - 2024-09-01 09:41:23 --> Could not find the language line "Create"
ERROR - 2024-09-01 09:41:23 --> admin
ERROR - 2024-09-01 09:41:23 --> 12
ERROR - 2024-09-01 09:41:23 --> admin
ERROR - 2024-09-01 04:41:24 --> 404 Page Not Found: /index
ERROR - 2024-09-01 09:43:38 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:43:38 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:43:38 --> Could not find the language line "Create Prospect Category"
ERROR - 2024-09-01 09:43:38 --> Could not find the language line "Name"
ERROR - 2024-09-01 09:43:38 --> Could not find the language line "Description"
ERROR - 2024-09-01 09:43:38 --> Could not find the language line "Status"
ERROR - 2024-09-01 09:43:38 --> Could not find the language line "Create"
ERROR - 2024-09-01 09:43:38 --> admin
ERROR - 2024-09-01 09:43:38 --> 12
ERROR - 2024-09-01 09:43:38 --> admin
ERROR - 2024-09-01 04:43:39 --> 404 Page Not Found: /index
ERROR - 2024-09-01 09:44:21 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:44:21 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:44:21 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:44:21 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:44:22 --> Could not find the language line "New Prospect category"
ERROR - 2024-09-01 09:44:22 --> Could not find the language line "Name"
ERROR - 2024-09-01 09:44:22 --> Could not find the language line "Description"
ERROR - 2024-09-01 09:44:22 --> Could not find the language line "Actions"
ERROR - 2024-09-01 09:44:22 --> admin
ERROR - 2024-09-01 09:44:22 --> 12
ERROR - 2024-09-01 09:44:22 --> admin
ERROR - 2024-09-01 04:44:22 --> 404 Page Not Found: /index
ERROR - 2024-09-01 09:44:53 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:44:53 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:44:54 --> Could not find the language line "New Prospect category"
ERROR - 2024-09-01 09:44:54 --> Could not find the language line "Name"
ERROR - 2024-09-01 09:44:54 --> Could not find the language line "Description"
ERROR - 2024-09-01 09:44:54 --> Could not find the language line "Status"
ERROR - 2024-09-01 09:44:54 --> Could not find the language line "Actions"
ERROR - 2024-09-01 09:44:54 --> admin
ERROR - 2024-09-01 09:44:54 --> 12
ERROR - 2024-09-01 09:44:54 --> admin
ERROR - 2024-09-01 04:44:54 --> 404 Page Not Found: /index
ERROR - 2024-09-01 09:44:56 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:44:56 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:44:56 --> Could not find the language line "Edit Prospect Category"
ERROR - 2024-09-01 09:44:56 --> Could not find the language line "Name"
ERROR - 2024-09-01 09:44:56 --> Could not find the language line "Description"
ERROR - 2024-09-01 09:44:56 --> Could not find the language line "Status"
ERROR - 2024-09-01 09:44:56 --> Could not find the language line "Save Changes"
ERROR - 2024-09-01 09:44:56 --> admin
ERROR - 2024-09-01 09:44:56 --> 12
ERROR - 2024-09-01 09:44:56 --> admin
ERROR - 2024-09-01 04:44:57 --> 404 Page Not Found: /index
ERROR - 2024-09-01 09:44:59 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:44:59 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:45:00 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:45:00 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:45:00 --> Could not find the language line "New Prospect category"
ERROR - 2024-09-01 09:45:00 --> Could not find the language line "Name"
ERROR - 2024-09-01 09:45:00 --> Could not find the language line "Description"
ERROR - 2024-09-01 09:45:00 --> Could not find the language line "Status"
ERROR - 2024-09-01 09:45:00 --> Could not find the language line "Actions"
ERROR - 2024-09-01 09:45:00 --> admin
ERROR - 2024-09-01 09:45:00 --> 12
ERROR - 2024-09-01 09:45:00 --> admin
ERROR - 2024-09-01 04:45:00 --> 404 Page Not Found: /index
ERROR - 2024-09-01 09:45:03 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:45:03 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:45:03 --> Could not find the language line "Edit Prospect Category"
ERROR - 2024-09-01 09:45:03 --> Could not find the language line "Name"
ERROR - 2024-09-01 09:45:03 --> Could not find the language line "Description"
ERROR - 2024-09-01 09:45:03 --> Could not find the language line "Status"
ERROR - 2024-09-01 09:45:03 --> Could not find the language line "Save Changes"
ERROR - 2024-09-01 09:45:03 --> admin
ERROR - 2024-09-01 09:45:03 --> 12
ERROR - 2024-09-01 09:45:03 --> admin
ERROR - 2024-09-01 04:45:03 --> 404 Page Not Found: /index
ERROR - 2024-09-01 09:45:05 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:45:05 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:45:06 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:45:06 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:45:06 --> Could not find the language line "New Prospect category"
ERROR - 2024-09-01 09:45:06 --> Could not find the language line "Name"
ERROR - 2024-09-01 09:45:06 --> Could not find the language line "Description"
ERROR - 2024-09-01 09:45:06 --> Could not find the language line "Status"
ERROR - 2024-09-01 09:45:06 --> Could not find the language line "Actions"
ERROR - 2024-09-01 09:45:06 --> admin
ERROR - 2024-09-01 09:45:06 --> 12
ERROR - 2024-09-01 09:45:06 --> admin
ERROR - 2024-09-01 04:45:06 --> 404 Page Not Found: /index
ERROR - 2024-09-01 09:45:17 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:45:17 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:45:18 --> Could not find the language line "New Industry"
ERROR - 2024-09-01 09:45:18 --> Could not find the language line "No industries found."
ERROR - 2024-09-01 09:45:18 --> admin
ERROR - 2024-09-01 09:45:18 --> 12
ERROR - 2024-09-01 09:45:18 --> admin
ERROR - 2024-09-01 04:45:18 --> 404 Page Not Found: /index
ERROR - 2024-09-01 09:46:38 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:46:38 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:46:39 --> Could not find the language line "Create New Industry"
ERROR - 2024-09-01 09:46:39 --> Could not find the language line "Name"
ERROR - 2024-09-01 09:46:39 --> Could not find the language line "Description"
ERROR - 2024-09-01 09:46:39 --> Could not find the language line "Category"
ERROR - 2024-09-01 09:46:39 --> Could not find the language line "Save"
ERROR - 2024-09-01 09:46:39 --> admin
ERROR - 2024-09-01 09:46:39 --> 12
ERROR - 2024-09-01 09:46:39 --> admin
ERROR - 2024-09-01 04:46:39 --> 404 Page Not Found: /index
ERROR - 2024-09-01 09:46:52 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:46:52 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:46:52 --> Could not find the language line "Create New Industry"
ERROR - 2024-09-01 09:46:52 --> Could not find the language line "Name"
ERROR - 2024-09-01 09:46:52 --> Could not find the language line "Description"
ERROR - 2024-09-01 09:46:52 --> Could not find the language line "Category"
ERROR - 2024-09-01 09:46:52 --> Could not find the language line "Status"
ERROR - 2024-09-01 09:46:52 --> Could not find the language line "Save"
ERROR - 2024-09-01 09:46:52 --> admin
ERROR - 2024-09-01 09:46:52 --> 12
ERROR - 2024-09-01 09:46:52 --> admin
ERROR - 2024-09-01 04:46:53 --> 404 Page Not Found: /index
ERROR - 2024-09-01 09:47:39 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:47:39 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:47:40 --> Could not find the language line "Create New Industry"
ERROR - 2024-09-01 09:47:40 --> Could not find the language line "Name"
ERROR - 2024-09-01 09:47:40 --> Could not find the language line "Description"
ERROR - 2024-09-01 09:47:40 --> Could not find the language line "Category"
ERROR - 2024-09-01 09:47:40 --> Could not find the language line "Status"
ERROR - 2024-09-01 09:47:40 --> Could not find the language line "Save"
ERROR - 2024-09-01 09:47:40 --> admin
ERROR - 2024-09-01 09:47:40 --> 12
ERROR - 2024-09-01 09:47:40 --> admin
ERROR - 2024-09-01 04:47:40 --> 404 Page Not Found: /index
ERROR - 2024-09-01 09:47:56 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:47:56 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:47:56 --> Could not find the language line "New Industry"
ERROR - 2024-09-01 09:47:56 --> Could not find the language line "No industries found."
ERROR - 2024-09-01 09:47:56 --> admin
ERROR - 2024-09-01 09:47:56 --> 12
ERROR - 2024-09-01 09:47:56 --> admin
ERROR - 2024-09-01 09:47:58 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:47:58 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:47:59 --> Could not find the language line "New Industry Category"
ERROR - 2024-09-01 09:47:59 --> Could not find the language line "No industry categories found."
ERROR - 2024-09-01 09:47:59 --> admin
ERROR - 2024-09-01 09:47:59 --> 12
ERROR - 2024-09-01 09:47:59 --> admin
ERROR - 2024-09-01 04:47:59 --> 404 Page Not Found: /index
ERROR - 2024-09-01 09:48:01 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:48:01 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:48:01 --> Could not find the language line "New Industry Category"
ERROR - 2024-09-01 09:48:01 --> Could not find the language line "Name"
ERROR - 2024-09-01 09:48:01 --> Could not find the language line "Description"
ERROR - 2024-09-01 09:48:01 --> Could not find the language line "Save"
ERROR - 2024-09-01 09:48:01 --> admin
ERROR - 2024-09-01 09:48:01 --> 12
ERROR - 2024-09-01 09:48:01 --> admin
ERROR - 2024-09-01 04:48:01 --> 404 Page Not Found: /index
ERROR - 2024-09-01 09:48:10 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:48:10 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:48:11 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:48:11 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:48:11 --> Could not find the language line "New Industry Category"
ERROR - 2024-09-01 09:48:11 --> Could not find the language line "Name"
ERROR - 2024-09-01 09:48:11 --> Could not find the language line "Description"
ERROR - 2024-09-01 09:48:11 --> admin
ERROR - 2024-09-01 09:48:11 --> 12
ERROR - 2024-09-01 09:48:11 --> admin
ERROR - 2024-09-01 04:48:11 --> 404 Page Not Found: /index
ERROR - 2024-09-01 09:48:13 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:48:13 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:48:13 --> Could not find the language line "New Industry"
ERROR - 2024-09-01 09:48:13 --> Could not find the language line "No industries found."
ERROR - 2024-09-01 09:48:13 --> admin
ERROR - 2024-09-01 09:48:13 --> 12
ERROR - 2024-09-01 09:48:13 --> admin
ERROR - 2024-09-01 04:48:14 --> 404 Page Not Found: /index
ERROR - 2024-09-01 09:48:15 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:48:15 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:48:16 --> Could not find the language line "Create New Industry"
ERROR - 2024-09-01 09:48:16 --> Could not find the language line "Name"
ERROR - 2024-09-01 09:48:16 --> Could not find the language line "Description"
ERROR - 2024-09-01 09:48:16 --> Could not find the language line "Category"
ERROR - 2024-09-01 09:48:16 --> Could not find the language line "Status"
ERROR - 2024-09-01 09:48:16 --> Could not find the language line "Save"
ERROR - 2024-09-01 09:48:16 --> admin
ERROR - 2024-09-01 09:48:16 --> 12
ERROR - 2024-09-01 09:48:16 --> admin
ERROR - 2024-09-01 04:48:16 --> 404 Page Not Found: /index
ERROR - 2024-09-01 09:48:24 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:48:24 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:48:24 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:48:24 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:48:24 --> Could not find the language line "New Industry"
ERROR - 2024-09-01 09:48:24 --> Could not find the language line "Name"
ERROR - 2024-09-01 09:48:24 --> Could not find the language line "Description"
ERROR - 2024-09-01 09:48:24 --> Could not find the language line "Category"
ERROR - 2024-09-01 09:48:24 --> Could not find the language line "Status"
ERROR - 2024-09-01 09:48:24 --> Could not find the language line "Actions"
ERROR - 2024-09-01 09:48:24 --> admin
ERROR - 2024-09-01 09:48:24 --> 12
ERROR - 2024-09-01 09:48:24 --> admin
ERROR - 2024-09-01 04:48:25 --> 404 Page Not Found: /index
ERROR - 2024-09-01 09:48:27 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:48:27 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:48:28 --> Could not find the language line "Edit Industry"
ERROR - 2024-09-01 09:48:28 --> Could not find the language line "Name"
ERROR - 2024-09-01 09:48:28 --> Could not find the language line "Description"
ERROR - 2024-09-01 09:48:28 --> Could not find the language line "Category"
ERROR - 2024-09-01 09:48:28 --> Could not find the language line "Status"
ERROR - 2024-09-01 09:48:28 --> Could not find the language line "Save Changes"
ERROR - 2024-09-01 09:48:28 --> admin
ERROR - 2024-09-01 09:48:28 --> 12
ERROR - 2024-09-01 09:48:28 --> admin
ERROR - 2024-09-01 04:48:28 --> 404 Page Not Found: /index
ERROR - 2024-09-01 09:48:30 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:48:30 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:48:30 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:48:30 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:48:31 --> Could not find the language line "New Industry"
ERROR - 2024-09-01 09:48:31 --> Could not find the language line "Name"
ERROR - 2024-09-01 09:48:31 --> Could not find the language line "Description"
ERROR - 2024-09-01 09:48:31 --> Could not find the language line "Category"
ERROR - 2024-09-01 09:48:31 --> Could not find the language line "Status"
ERROR - 2024-09-01 09:48:31 --> Could not find the language line "Actions"
ERROR - 2024-09-01 09:48:31 --> admin
ERROR - 2024-09-01 09:48:31 --> 12
ERROR - 2024-09-01 09:48:31 --> admin
ERROR - 2024-09-01 04:48:31 --> 404 Page Not Found: /index
ERROR - 2024-09-01 09:48:34 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:48:34 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:48:34 --> Could not find the language line "Edit Industry"
ERROR - 2024-09-01 09:48:34 --> Could not find the language line "Name"
ERROR - 2024-09-01 09:48:34 --> Could not find the language line "Description"
ERROR - 2024-09-01 09:48:34 --> Could not find the language line "Category"
ERROR - 2024-09-01 09:48:34 --> Could not find the language line "Status"
ERROR - 2024-09-01 09:48:34 --> Could not find the language line "Save Changes"
ERROR - 2024-09-01 09:48:34 --> admin
ERROR - 2024-09-01 09:48:34 --> 12
ERROR - 2024-09-01 09:48:34 --> admin
ERROR - 2024-09-01 04:48:35 --> 404 Page Not Found: /index
ERROR - 2024-09-01 09:48:39 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:48:39 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:48:40 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:48:40 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:48:40 --> Could not find the language line "New Industry"
ERROR - 2024-09-01 09:48:40 --> Could not find the language line "Name"
ERROR - 2024-09-01 09:48:40 --> Could not find the language line "Description"
ERROR - 2024-09-01 09:48:40 --> Could not find the language line "Category"
ERROR - 2024-09-01 09:48:40 --> Could not find the language line "Status"
ERROR - 2024-09-01 09:48:40 --> Could not find the language line "Actions"
ERROR - 2024-09-01 09:48:40 --> admin
ERROR - 2024-09-01 09:48:40 --> 12
ERROR - 2024-09-01 09:48:40 --> admin
ERROR - 2024-09-01 04:48:40 --> 404 Page Not Found: /index
ERROR - 2024-09-01 09:51:06 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:51:06 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:51:07 --> Could not find the language line "New Industry"
ERROR - 2024-09-01 09:51:07 --> Could not find the language line "Name"
ERROR - 2024-09-01 09:51:07 --> Could not find the language line "Description"
ERROR - 2024-09-01 09:51:07 --> Could not find the language line "Category"
ERROR - 2024-09-01 09:51:07 --> Could not find the language line "Status"
ERROR - 2024-09-01 09:51:07 --> Could not find the language line "Actions"
ERROR - 2024-09-01 09:51:07 --> admin
ERROR - 2024-09-01 09:51:07 --> 12
ERROR - 2024-09-01 09:51:07 --> admin
ERROR - 2024-09-01 04:51:07 --> 404 Page Not Found: /index
ERROR - 2024-09-01 09:51:09 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:51:09 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:51:10 --> Could not find the language line "Edit Industry"
ERROR - 2024-09-01 09:51:10 --> Could not find the language line "Name"
ERROR - 2024-09-01 09:51:10 --> Could not find the language line "Description"
ERROR - 2024-09-01 09:51:10 --> Could not find the language line "Category"
ERROR - 2024-09-01 09:51:10 --> Could not find the language line "Status"
ERROR - 2024-09-01 09:51:10 --> Could not find the language line "Save Changes"
ERROR - 2024-09-01 09:51:10 --> admin
ERROR - 2024-09-01 09:51:10 --> 12
ERROR - 2024-09-01 09:51:10 --> admin
ERROR - 2024-09-01 04:51:10 --> 404 Page Not Found: /index
ERROR - 2024-09-01 09:51:13 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:51:13 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:51:13 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:51:13 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:51:13 --> Could not find the language line "New Industry"
ERROR - 2024-09-01 09:51:13 --> Could not find the language line "Name"
ERROR - 2024-09-01 09:51:13 --> Could not find the language line "Description"
ERROR - 2024-09-01 09:51:13 --> Could not find the language line "Category"
ERROR - 2024-09-01 09:51:13 --> Could not find the language line "Status"
ERROR - 2024-09-01 09:51:13 --> Could not find the language line "Actions"
ERROR - 2024-09-01 09:51:13 --> admin
ERROR - 2024-09-01 09:51:13 --> 12
ERROR - 2024-09-01 09:51:13 --> admin
ERROR - 2024-09-01 04:51:13 --> 404 Page Not Found: /index
ERROR - 2024-09-01 09:51:16 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:51:16 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:51:16 --> Could not find the language line "Edit Industry"
ERROR - 2024-09-01 09:51:16 --> Could not find the language line "Name"
ERROR - 2024-09-01 09:51:16 --> Could not find the language line "Description"
ERROR - 2024-09-01 09:51:16 --> Could not find the language line "Category"
ERROR - 2024-09-01 09:51:16 --> Could not find the language line "Status"
ERROR - 2024-09-01 09:51:16 --> Could not find the language line "Save Changes"
ERROR - 2024-09-01 09:51:16 --> admin
ERROR - 2024-09-01 09:51:16 --> 12
ERROR - 2024-09-01 09:51:16 --> admin
ERROR - 2024-09-01 04:51:16 --> 404 Page Not Found: /index
ERROR - 2024-09-01 09:51:53 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:51:53 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:51:53 --> Could not find the language line "Edit Industry"
ERROR - 2024-09-01 09:51:53 --> Could not find the language line "Name"
ERROR - 2024-09-01 09:51:53 --> Could not find the language line "Description"
ERROR - 2024-09-01 09:51:53 --> Could not find the language line "Category"
ERROR - 2024-09-01 09:51:53 --> Could not find the language line "Status"
ERROR - 2024-09-01 09:51:53 --> Could not find the language line "Save Changes"
ERROR - 2024-09-01 09:51:53 --> admin
ERROR - 2024-09-01 09:51:53 --> 12
ERROR - 2024-09-01 09:51:53 --> admin
ERROR - 2024-09-01 04:51:53 --> 404 Page Not Found: /index
ERROR - 2024-09-01 09:51:56 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:51:56 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:51:57 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:51:57 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:51:57 --> Could not find the language line "New Industry"
ERROR - 2024-09-01 09:51:57 --> Could not find the language line "Name"
ERROR - 2024-09-01 09:51:57 --> Could not find the language line "Description"
ERROR - 2024-09-01 09:51:57 --> Could not find the language line "Category"
ERROR - 2024-09-01 09:51:57 --> Could not find the language line "Status"
ERROR - 2024-09-01 09:51:57 --> Could not find the language line "Actions"
ERROR - 2024-09-01 09:51:57 --> admin
ERROR - 2024-09-01 09:51:57 --> 12
ERROR - 2024-09-01 09:51:57 --> admin
ERROR - 2024-09-01 04:51:57 --> 404 Page Not Found: /index
ERROR - 2024-09-01 09:51:59 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:51:59 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:51:59 --> Could not find the language line "Edit Industry"
ERROR - 2024-09-01 09:51:59 --> Could not find the language line "Name"
ERROR - 2024-09-01 09:51:59 --> Could not find the language line "Description"
ERROR - 2024-09-01 09:51:59 --> Could not find the language line "Category"
ERROR - 2024-09-01 09:51:59 --> Could not find the language line "Status"
ERROR - 2024-09-01 09:51:59 --> Could not find the language line "Save Changes"
ERROR - 2024-09-01 09:51:59 --> admin
ERROR - 2024-09-01 09:51:59 --> 12
ERROR - 2024-09-01 09:51:59 --> admin
ERROR - 2024-09-01 04:52:00 --> 404 Page Not Found: /index
ERROR - 2024-09-01 09:52:02 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:52:02 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:52:03 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:52:03 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:52:03 --> Could not find the language line "New Industry"
ERROR - 2024-09-01 09:52:03 --> Could not find the language line "Name"
ERROR - 2024-09-01 09:52:03 --> Could not find the language line "Description"
ERROR - 2024-09-01 09:52:03 --> Could not find the language line "Category"
ERROR - 2024-09-01 09:52:03 --> Could not find the language line "Status"
ERROR - 2024-09-01 09:52:03 --> Could not find the language line "Actions"
ERROR - 2024-09-01 09:52:03 --> admin
ERROR - 2024-09-01 09:52:03 --> 12
ERROR - 2024-09-01 09:52:03 --> admin
ERROR - 2024-09-01 04:52:03 --> 404 Page Not Found: /index
ERROR - 2024-09-01 09:54:57 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:54:57 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:54:57 --> Could not find the language line "New Industry Category"
ERROR - 2024-09-01 09:54:57 --> Could not find the language line "Name"
ERROR - 2024-09-01 09:54:57 --> Could not find the language line "Description"
ERROR - 2024-09-01 09:54:57 --> Could not find the language line "Status"
ERROR - 2024-09-01 09:54:57 --> admin
ERROR - 2024-09-01 09:54:57 --> 12
ERROR - 2024-09-01 09:54:57 --> admin
ERROR - 2024-09-01 04:54:58 --> 404 Page Not Found: /index
ERROR - 2024-09-01 09:54:59 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:54:59 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:54:59 --> Could not find the language line "New Industry Category"
ERROR - 2024-09-01 09:54:59 --> Could not find the language line "Name"
ERROR - 2024-09-01 09:54:59 --> Could not find the language line "Description"
ERROR - 2024-09-01 09:54:59 --> Could not find the language line "Status"
ERROR - 2024-09-01 09:54:59 --> admin
ERROR - 2024-09-01 09:54:59 --> 12
ERROR - 2024-09-01 09:54:59 --> admin
ERROR - 2024-09-01 04:54:59 --> 404 Page Not Found: /index
ERROR - 2024-09-01 09:55:01 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:55:01 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:55:01 --> Could not find the language line "Edit Industry Category"
ERROR - 2024-09-01 09:55:01 --> Could not find the language line "Name"
ERROR - 2024-09-01 09:55:01 --> Could not find the language line "Description"
ERROR - 2024-09-01 09:55:01 --> Could not find the language line "Save Changes"
ERROR - 2024-09-01 09:55:01 --> admin
ERROR - 2024-09-01 09:55:01 --> 12
ERROR - 2024-09-01 09:55:01 --> admin
ERROR - 2024-09-01 04:55:01 --> 404 Page Not Found: /index
ERROR - 2024-09-01 09:55:18 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:55:18 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:55:18 --> Could not find the language line "Edit Industry Category"
ERROR - 2024-09-01 09:55:18 --> Could not find the language line "Name"
ERROR - 2024-09-01 09:55:18 --> Could not find the language line "Description"
ERROR - 2024-09-01 09:55:18 --> Could not find the language line "Save Changes"
ERROR - 2024-09-01 09:55:18 --> admin
ERROR - 2024-09-01 09:55:18 --> 12
ERROR - 2024-09-01 09:55:18 --> admin
ERROR - 2024-09-01 04:55:18 --> 404 Page Not Found: /index
ERROR - 2024-09-01 09:55:22 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:55:22 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:55:22 --> Could not find the language line "Edit Industry Category"
ERROR - 2024-09-01 09:55:22 --> Could not find the language line "Name"
ERROR - 2024-09-01 09:55:22 --> Could not find the language line "Description"
ERROR - 2024-09-01 09:55:22 --> Could not find the language line "Save Changes"
ERROR - 2024-09-01 09:55:22 --> admin
ERROR - 2024-09-01 09:55:22 --> 12
ERROR - 2024-09-01 09:55:22 --> admin
ERROR - 2024-09-01 04:55:22 --> 404 Page Not Found: /index
ERROR - 2024-09-01 09:55:29 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:55:29 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:55:30 --> Could not find the language line "Edit Industry Category"
ERROR - 2024-09-01 09:55:30 --> Could not find the language line "Name"
ERROR - 2024-09-01 09:55:30 --> Could not find the language line "Description"
ERROR - 2024-09-01 09:55:30 --> Could not find the language line "Save Changes"
ERROR - 2024-09-01 09:55:30 --> admin
ERROR - 2024-09-01 09:55:30 --> 12
ERROR - 2024-09-01 09:55:30 --> admin
ERROR - 2024-09-01 04:55:30 --> 404 Page Not Found: /index
ERROR - 2024-09-01 09:55:37 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:55:37 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:55:37 --> Could not find the language line "New Industry Category"
ERROR - 2024-09-01 09:55:37 --> Could not find the language line "Name"
ERROR - 2024-09-01 09:55:37 --> Could not find the language line "Description"
ERROR - 2024-09-01 09:55:37 --> Could not find the language line "Status"
ERROR - 2024-09-01 09:55:37 --> admin
ERROR - 2024-09-01 09:55:37 --> 12
ERROR - 2024-09-01 09:55:37 --> admin
ERROR - 2024-09-01 09:55:38 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:55:38 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:55:38 --> Could not find the language line "New Industry Category"
ERROR - 2024-09-01 09:55:38 --> Could not find the language line "Name"
ERROR - 2024-09-01 09:55:38 --> Could not find the language line "Description"
ERROR - 2024-09-01 09:55:38 --> Could not find the language line "Status"
ERROR - 2024-09-01 09:55:38 --> Could not find the language line "Save"
ERROR - 2024-09-01 09:55:38 --> admin
ERROR - 2024-09-01 09:55:38 --> 12
ERROR - 2024-09-01 09:55:38 --> admin
ERROR - 2024-09-01 04:55:39 --> 404 Page Not Found: /index
ERROR - 2024-09-01 09:56:13 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:56:13 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:56:14 --> Could not find the language line "New Industry Category"
ERROR - 2024-09-01 09:56:14 --> Could not find the language line "Name"
ERROR - 2024-09-01 09:56:14 --> Could not find the language line "Description"
ERROR - 2024-09-01 09:56:14 --> Could not find the language line "Status"
ERROR - 2024-09-01 09:56:14 --> admin
ERROR - 2024-09-01 09:56:14 --> 12
ERROR - 2024-09-01 09:56:14 --> admin
ERROR - 2024-09-01 09:56:16 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:56:16 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:56:16 --> Could not find the language line "Edit Industry Category"
ERROR - 2024-09-01 09:56:16 --> Could not find the language line "Name"
ERROR - 2024-09-01 09:56:16 --> Could not find the language line "Description"
ERROR - 2024-09-01 09:56:16 --> Could not find the language line "Status"
ERROR - 2024-09-01 09:56:16 --> Severity: Warning --> Undefined variable $status C:\laragon\www\perfex_crm\application\views\admin\setup\industry_categories\industry_category_edit.php 39
ERROR - 2024-09-01 09:56:16 --> Severity: Warning --> Attempt to read property "is_active" on null C:\laragon\www\perfex_crm\application\views\admin\setup\industry_categories\industry_category_edit.php 39
ERROR - 2024-09-01 09:56:16 --> Severity: Warning --> Undefined variable $status C:\laragon\www\perfex_crm\application\views\admin\setup\industry_categories\industry_category_edit.php 45
ERROR - 2024-09-01 09:56:16 --> Severity: Warning --> Attempt to read property "is_active" on null C:\laragon\www\perfex_crm\application\views\admin\setup\industry_categories\industry_category_edit.php 45
ERROR - 2024-09-01 09:56:16 --> Could not find the language line "Save Changes"
ERROR - 2024-09-01 09:56:16 --> admin
ERROR - 2024-09-01 09:56:16 --> 12
ERROR - 2024-09-01 09:56:16 --> admin
ERROR - 2024-09-01 04:56:16 --> 404 Page Not Found: /index
ERROR - 2024-09-01 09:56:29 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:56:29 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:56:29 --> Could not find the language line "Edit Industry Category"
ERROR - 2024-09-01 09:56:29 --> Could not find the language line "Name"
ERROR - 2024-09-01 09:56:29 --> Could not find the language line "Description"
ERROR - 2024-09-01 09:56:29 --> Could not find the language line "Status"
ERROR - 2024-09-01 09:56:29 --> Could not find the language line "Save Changes"
ERROR - 2024-09-01 09:56:29 --> admin
ERROR - 2024-09-01 09:56:29 --> 12
ERROR - 2024-09-01 09:56:29 --> admin
ERROR - 2024-09-01 04:56:29 --> 404 Page Not Found: /index
ERROR - 2024-09-01 09:56:32 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:56:32 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:56:32 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:56:32 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:56:32 --> Could not find the language line "New Industry Category"
ERROR - 2024-09-01 09:56:32 --> Could not find the language line "Name"
ERROR - 2024-09-01 09:56:32 --> Could not find the language line "Description"
ERROR - 2024-09-01 09:56:32 --> Could not find the language line "Status"
ERROR - 2024-09-01 09:56:32 --> admin
ERROR - 2024-09-01 09:56:32 --> 12
ERROR - 2024-09-01 09:56:32 --> admin
ERROR - 2024-09-01 04:56:32 --> 404 Page Not Found: /index
ERROR - 2024-09-01 09:59:44 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:59:44 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:59:45 --> Could not find the language line "New Industry Category"
ERROR - 2024-09-01 09:59:45 --> Could not find the language line "Name"
ERROR - 2024-09-01 09:59:45 --> Could not find the language line "Description"
ERROR - 2024-09-01 09:59:45 --> Could not find the language line "Status"
ERROR - 2024-09-01 09:59:45 --> admin
ERROR - 2024-09-01 09:59:45 --> 12
ERROR - 2024-09-01 09:59:45 --> admin
ERROR - 2024-09-01 04:59:45 --> 404 Page Not Found: /index
ERROR - 2024-09-01 09:59:46 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:59:46 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:59:47 --> Could not find the language line "Edit Industry Category"
ERROR - 2024-09-01 09:59:47 --> Could not find the language line "Name"
ERROR - 2024-09-01 09:59:47 --> Could not find the language line "Description"
ERROR - 2024-09-01 09:59:47 --> Could not find the language line "Status"
ERROR - 2024-09-01 09:59:47 --> Could not find the language line "Save Changes"
ERROR - 2024-09-01 09:59:47 --> admin
ERROR - 2024-09-01 09:59:47 --> 12
ERROR - 2024-09-01 09:59:47 --> admin
ERROR - 2024-09-01 04:59:47 --> 404 Page Not Found: /index
ERROR - 2024-09-01 09:59:49 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:59:49 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:59:50 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:59:50 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:59:50 --> Could not find the language line "New Industry Category"
ERROR - 2024-09-01 09:59:50 --> Could not find the language line "Name"
ERROR - 2024-09-01 09:59:50 --> Could not find the language line "Description"
ERROR - 2024-09-01 09:59:50 --> Could not find the language line "Status"
ERROR - 2024-09-01 09:59:50 --> admin
ERROR - 2024-09-01 09:59:50 --> 12
ERROR - 2024-09-01 09:59:50 --> admin
ERROR - 2024-09-01 04:59:50 --> 404 Page Not Found: /index
ERROR - 2024-09-01 09:59:52 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:59:52 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:59:52 --> Could not find the language line "Edit Industry Category"
ERROR - 2024-09-01 09:59:52 --> Could not find the language line "Name"
ERROR - 2024-09-01 09:59:52 --> Could not find the language line "Description"
ERROR - 2024-09-01 09:59:52 --> Could not find the language line "Status"
ERROR - 2024-09-01 09:59:52 --> Could not find the language line "Save Changes"
ERROR - 2024-09-01 09:59:52 --> admin
ERROR - 2024-09-01 09:59:52 --> 12
ERROR - 2024-09-01 09:59:52 --> admin
ERROR - 2024-09-01 04:59:52 --> 404 Page Not Found: /index
ERROR - 2024-09-01 09:59:54 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:59:54 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:59:54 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 09:59:54 --> Could not find the language line "billings"
ERROR - 2024-09-01 09:59:55 --> Could not find the language line "New Industry Category"
ERROR - 2024-09-01 09:59:55 --> Could not find the language line "Name"
ERROR - 2024-09-01 09:59:55 --> Could not find the language line "Description"
ERROR - 2024-09-01 09:59:55 --> Could not find the language line "Status"
ERROR - 2024-09-01 09:59:55 --> admin
ERROR - 2024-09-01 09:59:55 --> 12
ERROR - 2024-09-01 09:59:55 --> admin
ERROR - 2024-09-01 04:59:55 --> 404 Page Not Found: /index
ERROR - 2024-09-01 10:00:58 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:00:58 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:00:58 --> Could not find the language line "New Industry"
ERROR - 2024-09-01 10:00:58 --> Could not find the language line "Name"
ERROR - 2024-09-01 10:00:58 --> Could not find the language line "Description"
ERROR - 2024-09-01 10:00:58 --> Could not find the language line "Category"
ERROR - 2024-09-01 10:00:58 --> Could not find the language line "Status"
ERROR - 2024-09-01 10:00:58 --> Could not find the language line "Actions"
ERROR - 2024-09-01 10:00:58 --> admin
ERROR - 2024-09-01 10:00:58 --> 12
ERROR - 2024-09-01 10:00:58 --> admin
ERROR - 2024-09-01 05:00:58 --> 404 Page Not Found: /index
ERROR - 2024-09-01 10:01:02 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:01:02 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:01:03 --> Could not find the language line "New Prospect category"
ERROR - 2024-09-01 10:01:03 --> Could not find the language line "Name"
ERROR - 2024-09-01 10:01:03 --> Could not find the language line "Description"
ERROR - 2024-09-01 10:01:03 --> Could not find the language line "Status"
ERROR - 2024-09-01 10:01:03 --> Could not find the language line "Actions"
ERROR - 2024-09-01 10:01:03 --> admin
ERROR - 2024-09-01 10:01:03 --> 12
ERROR - 2024-09-01 10:01:03 --> admin
ERROR - 2024-09-01 05:01:03 --> 404 Page Not Found: /index
ERROR - 2024-09-01 10:01:04 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:01:04 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:01:04 --> Could not find the language line "New Prospect Type"
ERROR - 2024-09-01 10:01:04 --> Could not find the language line "Name"
ERROR - 2024-09-01 10:01:04 --> Could not find the language line "Description"
ERROR - 2024-09-01 10:01:04 --> Could not find the language line "Status"
ERROR - 2024-09-01 10:01:04 --> Could not find the language line "Actions"
ERROR - 2024-09-01 10:01:04 --> admin
ERROR - 2024-09-01 10:01:04 --> 12
ERROR - 2024-09-01 10:01:04 --> admin
ERROR - 2024-09-01 05:01:05 --> 404 Page Not Found: /index
ERROR - 2024-09-01 10:01:07 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:01:07 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:01:07 --> Could not find the language line "New Prospect Status"
ERROR - 2024-09-01 10:01:07 --> Could not find the language line "Name"
ERROR - 2024-09-01 10:01:07 --> Could not find the language line "Description"
ERROR - 2024-09-01 10:01:07 --> Could not find the language line "Status"
ERROR - 2024-09-01 10:01:07 --> Could not find the language line "Actions"
ERROR - 2024-09-01 10:01:07 --> admin
ERROR - 2024-09-01 10:01:07 --> 12
ERROR - 2024-09-01 10:01:07 --> admin
ERROR - 2024-09-01 05:01:07 --> 404 Page Not Found: /index
ERROR - 2024-09-01 10:01:11 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:01:11 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:01:13 --> Could not find the language line "New Acquisition Channel"
ERROR - 2024-09-01 10:01:13 --> Could not find the language line "No acquisition channels found."
ERROR - 2024-09-01 10:01:13 --> admin
ERROR - 2024-09-01 10:01:13 --> 12
ERROR - 2024-09-01 10:01:13 --> admin
ERROR - 2024-09-01 05:01:13 --> 404 Page Not Found: /index
ERROR - 2024-09-01 10:01:28 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:01:28 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:01:28 --> Could not find the language line "Create New Acquisition Channel"
ERROR - 2024-09-01 10:01:28 --> Could not find the language line "Name"
ERROR - 2024-09-01 10:01:28 --> Could not find the language line "Description"
ERROR - 2024-09-01 10:01:28 --> Could not find the language line "Save"
ERROR - 2024-09-01 10:01:28 --> admin
ERROR - 2024-09-01 10:01:28 --> 12
ERROR - 2024-09-01 10:01:28 --> admin
ERROR - 2024-09-01 05:01:28 --> 404 Page Not Found: /index
ERROR - 2024-09-01 10:01:30 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:01:30 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:01:30 --> Could not find the language line "New Acquisition Channel"
ERROR - 2024-09-01 10:01:30 --> Could not find the language line "No acquisition channels found."
ERROR - 2024-09-01 10:01:30 --> admin
ERROR - 2024-09-01 10:01:30 --> 12
ERROR - 2024-09-01 10:01:30 --> admin
ERROR - 2024-09-01 10:02:57 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:02:57 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:02:57 --> Could not find the language line "New Industry Category"
ERROR - 2024-09-01 10:02:57 --> Could not find the language line "Name"
ERROR - 2024-09-01 10:02:57 --> Could not find the language line "Description"
ERROR - 2024-09-01 10:02:57 --> Could not find the language line "Status"
ERROR - 2024-09-01 10:02:57 --> admin
ERROR - 2024-09-01 10:02:57 --> 12
ERROR - 2024-09-01 10:02:57 --> admin
ERROR - 2024-09-01 05:02:57 --> 404 Page Not Found: /index
ERROR - 2024-09-01 10:02:59 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:02:59 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:03:00 --> Could not find the language line "New Industry Category"
ERROR - 2024-09-01 10:03:00 --> Could not find the language line "Name"
ERROR - 2024-09-01 10:03:00 --> Could not find the language line "Description"
ERROR - 2024-09-01 10:03:00 --> Could not find the language line "Status"
ERROR - 2024-09-01 10:03:00 --> Could not find the language line "Save"
ERROR - 2024-09-01 10:03:00 --> admin
ERROR - 2024-09-01 10:03:00 --> 12
ERROR - 2024-09-01 10:03:00 --> admin
ERROR - 2024-09-01 05:03:00 --> 404 Page Not Found: /index
ERROR - 2024-09-01 10:03:55 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:03:55 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:03:55 --> Could not find the language line "New Acquisition Channel"
ERROR - 2024-09-01 10:03:55 --> Could not find the language line "No acquisition channels found."
ERROR - 2024-09-01 10:03:55 --> admin
ERROR - 2024-09-01 10:03:55 --> 12
ERROR - 2024-09-01 10:03:55 --> admin
ERROR - 2024-09-01 05:03:55 --> 404 Page Not Found: /index
ERROR - 2024-09-01 10:03:59 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:03:59 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:04:00 --> Could not find the language line "Create New Acquisition Channel"
ERROR - 2024-09-01 10:04:00 --> Could not find the language line "Name"
ERROR - 2024-09-01 10:04:00 --> Could not find the language line "Description"
ERROR - 2024-09-01 10:04:00 --> Could not find the language line "Save"
ERROR - 2024-09-01 10:04:00 --> admin
ERROR - 2024-09-01 10:04:00 --> 12
ERROR - 2024-09-01 10:04:00 --> admin
ERROR - 2024-09-01 05:04:00 --> 404 Page Not Found: /index
ERROR - 2024-09-01 10:05:59 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:05:59 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:05:59 --> Could not find the language line "Create New Acquisition Channel"
ERROR - 2024-09-01 10:05:59 --> Could not find the language line "Name"
ERROR - 2024-09-01 10:05:59 --> Could not find the language line "Description"
ERROR - 2024-09-01 10:05:59 --> Could not find the language line "Status"
ERROR - 2024-09-01 10:05:59 --> Could not find the language line "Save"
ERROR - 2024-09-01 10:05:59 --> admin
ERROR - 2024-09-01 10:05:59 --> 12
ERROR - 2024-09-01 10:05:59 --> admin
ERROR - 2024-09-01 05:05:59 --> 404 Page Not Found: /index
ERROR - 2024-09-01 10:07:32 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:07:32 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:07:33 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:07:33 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:07:33 --> Could not find the language line "New Acquisition Channel"
ERROR - 2024-09-01 10:07:33 --> Could not find the language line "Name"
ERROR - 2024-09-01 10:07:33 --> Could not find the language line "Description"
ERROR - 2024-09-01 10:07:33 --> Could not find the language line "Status"
ERROR - 2024-09-01 10:07:33 --> Could not find the language line "Actions"
ERROR - 2024-09-01 10:07:33 --> admin
ERROR - 2024-09-01 10:07:33 --> 12
ERROR - 2024-09-01 10:07:33 --> admin
ERROR - 2024-09-01 05:07:33 --> 404 Page Not Found: /index
ERROR - 2024-09-01 10:07:59 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:07:59 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:07:59 --> Could not find the language line "New Acquisition Channel"
ERROR - 2024-09-01 10:07:59 --> Could not find the language line "Name"
ERROR - 2024-09-01 10:07:59 --> Could not find the language line "Description"
ERROR - 2024-09-01 10:07:59 --> Could not find the language line "Status"
ERROR - 2024-09-01 10:07:59 --> Could not find the language line "Actions"
ERROR - 2024-09-01 10:07:59 --> admin
ERROR - 2024-09-01 10:07:59 --> 12
ERROR - 2024-09-01 10:07:59 --> admin
ERROR - 2024-09-01 05:08:00 --> 404 Page Not Found: /index
ERROR - 2024-09-01 10:08:05 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:08:05 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:08:05 --> Could not find the language line "Edit Acquisition Channel"
ERROR - 2024-09-01 10:08:05 --> Could not find the language line "Name"
ERROR - 2024-09-01 10:08:05 --> Could not find the language line "Description"
ERROR - 2024-09-01 10:08:05 --> Could not find the language line "Status"
ERROR - 2024-09-01 10:08:05 --> Could not find the language line "Save Changes"
ERROR - 2024-09-01 10:08:05 --> admin
ERROR - 2024-09-01 10:08:05 --> 12
ERROR - 2024-09-01 10:08:05 --> admin
ERROR - 2024-09-01 05:08:05 --> 404 Page Not Found: /index
ERROR - 2024-09-01 10:08:08 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:08:08 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:08:09 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:08:09 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:08:09 --> Could not find the language line "New Acquisition Channel"
ERROR - 2024-09-01 10:08:09 --> Could not find the language line "Name"
ERROR - 2024-09-01 10:08:09 --> Could not find the language line "Description"
ERROR - 2024-09-01 10:08:09 --> Could not find the language line "Status"
ERROR - 2024-09-01 10:08:09 --> Could not find the language line "Actions"
ERROR - 2024-09-01 10:08:09 --> admin
ERROR - 2024-09-01 10:08:09 --> 12
ERROR - 2024-09-01 10:08:09 --> admin
ERROR - 2024-09-01 05:08:09 --> 404 Page Not Found: /index
ERROR - 2024-09-01 10:09:06 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:09:06 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:09:06 --> Could not find the language line "New Campaign Status"
ERROR - 2024-09-01 10:09:06 --> Could not find the language line "No campaign statuses found."
ERROR - 2024-09-01 10:09:06 --> admin
ERROR - 2024-09-01 10:09:06 --> 12
ERROR - 2024-09-01 10:09:06 --> admin
ERROR - 2024-09-01 05:09:06 --> 404 Page Not Found: /index
ERROR - 2024-09-01 10:09:08 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:09:08 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:09:08 --> Could not find the language line "Create New Campaign Status"
ERROR - 2024-09-01 10:09:08 --> Could not find the language line "Name"
ERROR - 2024-09-01 10:09:08 --> Could not find the language line "Description"
ERROR - 2024-09-01 10:09:08 --> Could not find the language line "Save"
ERROR - 2024-09-01 10:09:08 --> admin
ERROR - 2024-09-01 10:09:08 --> 12
ERROR - 2024-09-01 10:09:08 --> admin
ERROR - 2024-09-01 05:09:08 --> 404 Page Not Found: /index
ERROR - 2024-09-01 10:10:48 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:10:48 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:10:48 --> Could not find the language line "Create New Campaign Status"
ERROR - 2024-09-01 10:10:48 --> Could not find the language line "Name"
ERROR - 2024-09-01 10:10:48 --> Could not find the language line "Description"
ERROR - 2024-09-01 10:10:48 --> Could not find the language line "Status"
ERROR - 2024-09-01 10:10:48 --> Could not find the language line "Save"
ERROR - 2024-09-01 10:10:48 --> admin
ERROR - 2024-09-01 10:10:48 --> 12
ERROR - 2024-09-01 10:10:48 --> admin
ERROR - 2024-09-01 05:10:48 --> 404 Page Not Found: /index
ERROR - 2024-09-01 10:10:54 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:10:54 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:10:55 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:10:55 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:10:55 --> Could not find the language line "New Campaign Status"
ERROR - 2024-09-01 10:10:55 --> Could not find the language line "Name"
ERROR - 2024-09-01 10:10:55 --> Could not find the language line "Description"
ERROR - 2024-09-01 10:10:55 --> Could not find the language line "Actions"
ERROR - 2024-09-01 10:10:55 --> admin
ERROR - 2024-09-01 10:10:55 --> 12
ERROR - 2024-09-01 10:10:55 --> admin
ERROR - 2024-09-01 05:10:55 --> 404 Page Not Found: /index
ERROR - 2024-09-01 10:11:26 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:11:26 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:11:26 --> Could not find the language line "New Campaign Status"
ERROR - 2024-09-01 10:11:26 --> Could not find the language line "Name"
ERROR - 2024-09-01 10:11:26 --> Could not find the language line "Description"
ERROR - 2024-09-01 10:11:26 --> Could not find the language line "Status"
ERROR - 2024-09-01 10:11:26 --> Could not find the language line "Actions"
ERROR - 2024-09-01 10:11:26 --> admin
ERROR - 2024-09-01 10:11:26 --> 12
ERROR - 2024-09-01 10:11:26 --> admin
ERROR - 2024-09-01 05:11:27 --> 404 Page Not Found: /index
ERROR - 2024-09-01 10:14:07 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:14:07 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:14:07 --> Could not find the language line "New Campaign Status"
ERROR - 2024-09-01 10:14:07 --> Could not find the language line "Name"
ERROR - 2024-09-01 10:14:07 --> Could not find the language line "Description"
ERROR - 2024-09-01 10:14:07 --> Could not find the language line "Status"
ERROR - 2024-09-01 10:14:07 --> Could not find the language line "Actions"
ERROR - 2024-09-01 10:14:07 --> admin
ERROR - 2024-09-01 10:14:07 --> 12
ERROR - 2024-09-01 10:14:07 --> admin
ERROR - 2024-09-01 05:14:07 --> 404 Page Not Found: /index
ERROR - 2024-09-01 10:14:09 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:14:09 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:14:09 --> Could not find the language line "Edit Campaign Status"
ERROR - 2024-09-01 10:14:09 --> Could not find the language line "Name"
ERROR - 2024-09-01 10:14:09 --> Could not find the language line "Description"
ERROR - 2024-09-01 10:14:09 --> Could not find the language line "Status"
ERROR - 2024-09-01 10:14:09 --> Could not find the language line "Save Changes"
ERROR - 2024-09-01 10:14:09 --> admin
ERROR - 2024-09-01 10:14:09 --> 12
ERROR - 2024-09-01 10:14:09 --> admin
ERROR - 2024-09-01 05:14:09 --> 404 Page Not Found: /index
ERROR - 2024-09-01 10:14:11 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:14:11 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:14:12 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:14:12 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:14:12 --> Could not find the language line "New Campaign Status"
ERROR - 2024-09-01 10:14:12 --> Could not find the language line "Name"
ERROR - 2024-09-01 10:14:12 --> Could not find the language line "Description"
ERROR - 2024-09-01 10:14:12 --> Could not find the language line "Status"
ERROR - 2024-09-01 10:14:12 --> Could not find the language line "Actions"
ERROR - 2024-09-01 10:14:12 --> admin
ERROR - 2024-09-01 10:14:12 --> 12
ERROR - 2024-09-01 10:14:12 --> admin
ERROR - 2024-09-01 05:14:12 --> 404 Page Not Found: /index
ERROR - 2024-09-01 10:14:17 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:14:17 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:14:17 --> Could not find the language line "Edit Campaign Status"
ERROR - 2024-09-01 10:14:17 --> Could not find the language line "Name"
ERROR - 2024-09-01 10:14:17 --> Could not find the language line "Description"
ERROR - 2024-09-01 10:14:17 --> Could not find the language line "Status"
ERROR - 2024-09-01 10:14:17 --> Could not find the language line "Save Changes"
ERROR - 2024-09-01 10:14:17 --> admin
ERROR - 2024-09-01 10:14:17 --> 12
ERROR - 2024-09-01 10:14:17 --> admin
ERROR - 2024-09-01 05:14:17 --> 404 Page Not Found: /index
ERROR - 2024-09-01 10:14:19 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:14:19 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:14:20 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:14:20 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:14:20 --> Could not find the language line "New Campaign Status"
ERROR - 2024-09-01 10:14:20 --> Could not find the language line "Name"
ERROR - 2024-09-01 10:14:20 --> Could not find the language line "Description"
ERROR - 2024-09-01 10:14:20 --> Could not find the language line "Status"
ERROR - 2024-09-01 10:14:20 --> Could not find the language line "Actions"
ERROR - 2024-09-01 10:14:20 --> admin
ERROR - 2024-09-01 10:14:20 --> 12
ERROR - 2024-09-01 10:14:20 --> admin
ERROR - 2024-09-01 05:14:20 --> 404 Page Not Found: /index
ERROR - 2024-09-01 10:14:23 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:14:23 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:14:23 --> Could not find the language line "No lead reasons found."
ERROR - 2024-09-01 10:14:23 --> admin
ERROR - 2024-09-01 10:14:23 --> 12
ERROR - 2024-09-01 10:14:23 --> admin
ERROR - 2024-09-01 05:14:24 --> 404 Page Not Found: /index
ERROR - 2024-09-01 10:15:24 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:15:24 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:15:24 --> Could not find the language line "Create New Lead Reason"
ERROR - 2024-09-01 10:15:24 --> Could not find the language line "Name"
ERROR - 2024-09-01 10:15:24 --> Could not find the language line "Description"
ERROR - 2024-09-01 10:15:24 --> Could not find the language line "Save"
ERROR - 2024-09-01 10:15:24 --> admin
ERROR - 2024-09-01 10:15:24 --> 12
ERROR - 2024-09-01 10:15:24 --> admin
ERROR - 2024-09-01 05:15:24 --> 404 Page Not Found: /index
ERROR - 2024-09-01 10:17:27 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:17:27 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:17:27 --> Could not find the language line "Create New Lead Reason"
ERROR - 2024-09-01 10:17:27 --> Could not find the language line "Name"
ERROR - 2024-09-01 10:17:27 --> Could not find the language line "Description"
ERROR - 2024-09-01 10:17:27 --> Could not find the language line "Status"
ERROR - 2024-09-01 10:17:27 --> Could not find the language line "Save"
ERROR - 2024-09-01 10:17:27 --> admin
ERROR - 2024-09-01 10:17:27 --> 12
ERROR - 2024-09-01 10:17:27 --> admin
ERROR - 2024-09-01 05:17:28 --> 404 Page Not Found: /index
ERROR - 2024-09-01 10:17:32 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:17:32 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:17:33 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:17:33 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:17:33 --> Could not find the language line "Name"
ERROR - 2024-09-01 10:17:33 --> Could not find the language line "Description"
ERROR - 2024-09-01 10:17:33 --> Could not find the language line "Status"
ERROR - 2024-09-01 10:17:33 --> Could not find the language line "Actions"
ERROR - 2024-09-01 10:17:33 --> admin
ERROR - 2024-09-01 10:17:33 --> 12
ERROR - 2024-09-01 10:17:33 --> admin
ERROR - 2024-09-01 05:17:33 --> 404 Page Not Found: /index
ERROR - 2024-09-01 10:17:35 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:17:35 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:17:36 --> Could not find the language line "Edit Lead Reason"
ERROR - 2024-09-01 10:17:36 --> Could not find the language line "Name"
ERROR - 2024-09-01 10:17:36 --> Could not find the language line "Description"
ERROR - 2024-09-01 10:17:36 --> Could not find the language line "Status"
ERROR - 2024-09-01 10:17:36 --> Could not find the language line "Save Changes"
ERROR - 2024-09-01 10:17:36 --> admin
ERROR - 2024-09-01 10:17:36 --> 12
ERROR - 2024-09-01 10:17:36 --> admin
ERROR - 2024-09-01 05:17:36 --> 404 Page Not Found: /index
ERROR - 2024-09-01 10:17:37 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:17:37 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:17:38 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:17:38 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:17:38 --> Could not find the language line "Name"
ERROR - 2024-09-01 10:17:38 --> Could not find the language line "Description"
ERROR - 2024-09-01 10:17:38 --> Could not find the language line "Status"
ERROR - 2024-09-01 10:17:38 --> Could not find the language line "Actions"
ERROR - 2024-09-01 10:17:38 --> admin
ERROR - 2024-09-01 10:17:38 --> 12
ERROR - 2024-09-01 10:17:38 --> admin
ERROR - 2024-09-01 05:17:38 --> 404 Page Not Found: /index
ERROR - 2024-09-01 10:17:42 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:17:42 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:17:42 --> Could not find the language line "New Lead Status"
ERROR - 2024-09-01 10:17:42 --> Could not find the language line "No lead statuses found."
ERROR - 2024-09-01 10:17:42 --> admin
ERROR - 2024-09-01 10:17:42 --> 12
ERROR - 2024-09-01 10:17:42 --> admin
ERROR - 2024-09-01 05:17:43 --> 404 Page Not Found: /index
ERROR - 2024-09-01 10:18:56 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:18:56 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:18:56 --> Could not find the language line "New Lead Status"
ERROR - 2024-09-01 10:18:56 --> Could not find the language line "No lead statuses found."
ERROR - 2024-09-01 10:18:56 --> admin
ERROR - 2024-09-01 10:18:56 --> 12
ERROR - 2024-09-01 10:18:56 --> admin
ERROR - 2024-09-01 05:18:57 --> 404 Page Not Found: /index
ERROR - 2024-09-01 10:18:58 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:18:58 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:18:58 --> Could not find the language line "Create New Lead Status"
ERROR - 2024-09-01 10:18:58 --> Could not find the language line "Name"
ERROR - 2024-09-01 10:18:58 --> Could not find the language line "Description"
ERROR - 2024-09-01 10:18:58 --> Could not find the language line "Status"
ERROR - 2024-09-01 10:18:58 --> Could not find the language line "Save"
ERROR - 2024-09-01 10:18:58 --> admin
ERROR - 2024-09-01 10:18:58 --> 12
ERROR - 2024-09-01 10:18:58 --> admin
ERROR - 2024-09-01 05:18:58 --> 404 Page Not Found: /index
ERROR - 2024-09-01 10:20:15 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:20:15 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:20:15 --> Could not find the language line "Create New Lead Status"
ERROR - 2024-09-01 10:20:15 --> Could not find the language line "Name"
ERROR - 2024-09-01 10:20:15 --> Could not find the language line "Description"
ERROR - 2024-09-01 10:20:15 --> Could not find the language line "Status"
ERROR - 2024-09-01 10:20:15 --> Could not find the language line "Save"
ERROR - 2024-09-01 10:20:15 --> admin
ERROR - 2024-09-01 10:20:15 --> 12
ERROR - 2024-09-01 10:20:15 --> admin
ERROR - 2024-09-01 05:20:15 --> 404 Page Not Found: /index
ERROR - 2024-09-01 10:20:20 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:20:20 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:20:21 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:20:21 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:20:21 --> Could not find the language line "New Lead Status"
ERROR - 2024-09-01 10:20:21 --> Could not find the language line "Name"
ERROR - 2024-09-01 10:20:21 --> Could not find the language line "Description"
ERROR - 2024-09-01 10:20:21 --> Could not find the language line "Status"
ERROR - 2024-09-01 10:20:21 --> Could not find the language line "Actions"
ERROR - 2024-09-01 10:20:21 --> admin
ERROR - 2024-09-01 10:20:21 --> 12
ERROR - 2024-09-01 10:20:21 --> admin
ERROR - 2024-09-01 05:20:21 --> 404 Page Not Found: /index
ERROR - 2024-09-01 10:20:29 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:20:29 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:20:29 --> Could not find the language line "Edit Lead Status"
ERROR - 2024-09-01 10:20:29 --> Could not find the language line "Name"
ERROR - 2024-09-01 10:20:29 --> Could not find the language line "Description"
ERROR - 2024-09-01 10:20:29 --> Could not find the language line "Status"
ERROR - 2024-09-01 10:20:29 --> Could not find the language line "Save Changes"
ERROR - 2024-09-01 10:20:29 --> admin
ERROR - 2024-09-01 10:20:29 --> 12
ERROR - 2024-09-01 10:20:29 --> admin
ERROR - 2024-09-01 05:20:29 --> 404 Page Not Found: /index
ERROR - 2024-09-01 10:20:39 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:20:39 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:20:39 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:20:39 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:20:39 --> Could not find the language line "New Lead Status"
ERROR - 2024-09-01 10:20:39 --> Could not find the language line "Name"
ERROR - 2024-09-01 10:20:39 --> Could not find the language line "Description"
ERROR - 2024-09-01 10:20:39 --> Could not find the language line "Status"
ERROR - 2024-09-01 10:20:39 --> Could not find the language line "Actions"
ERROR - 2024-09-01 10:20:39 --> admin
ERROR - 2024-09-01 10:20:39 --> 12
ERROR - 2024-09-01 10:20:39 --> admin
ERROR - 2024-09-01 05:20:39 --> 404 Page Not Found: /index
ERROR - 2024-09-01 10:20:41 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:20:41 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:20:41 --> Could not find the language line "Edit Lead Status"
ERROR - 2024-09-01 10:20:41 --> Could not find the language line "Name"
ERROR - 2024-09-01 10:20:41 --> Could not find the language line "Description"
ERROR - 2024-09-01 10:20:41 --> Could not find the language line "Status"
ERROR - 2024-09-01 10:20:41 --> Could not find the language line "Save Changes"
ERROR - 2024-09-01 10:20:41 --> admin
ERROR - 2024-09-01 10:20:41 --> 12
ERROR - 2024-09-01 10:20:41 --> admin
ERROR - 2024-09-01 05:20:41 --> 404 Page Not Found: /index
ERROR - 2024-09-01 10:20:43 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:20:43 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:20:43 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:20:43 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:20:44 --> Could not find the language line "New Lead Status"
ERROR - 2024-09-01 10:20:44 --> Could not find the language line "Name"
ERROR - 2024-09-01 10:20:44 --> Could not find the language line "Description"
ERROR - 2024-09-01 10:20:44 --> Could not find the language line "Status"
ERROR - 2024-09-01 10:20:44 --> Could not find the language line "Actions"
ERROR - 2024-09-01 10:20:44 --> admin
ERROR - 2024-09-01 10:20:44 --> 12
ERROR - 2024-09-01 10:20:44 --> admin
ERROR - 2024-09-01 05:20:44 --> 404 Page Not Found: /index
ERROR - 2024-09-01 10:20:46 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:20:46 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:20:46 --> Could not find the language line "Edit Lead Status"
ERROR - 2024-09-01 10:20:46 --> Could not find the language line "Name"
ERROR - 2024-09-01 10:20:46 --> Could not find the language line "Description"
ERROR - 2024-09-01 10:20:46 --> Could not find the language line "Status"
ERROR - 2024-09-01 10:20:46 --> Could not find the language line "Save Changes"
ERROR - 2024-09-01 10:20:46 --> admin
ERROR - 2024-09-01 10:20:46 --> 12
ERROR - 2024-09-01 10:20:46 --> admin
ERROR - 2024-09-01 05:20:46 --> 404 Page Not Found: /index
ERROR - 2024-09-01 10:20:50 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:20:50 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:20:51 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:20:51 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:20:51 --> Could not find the language line "New Lead Status"
ERROR - 2024-09-01 10:20:51 --> Could not find the language line "Name"
ERROR - 2024-09-01 10:20:51 --> Could not find the language line "Description"
ERROR - 2024-09-01 10:20:51 --> Could not find the language line "Status"
ERROR - 2024-09-01 10:20:51 --> Could not find the language line "Actions"
ERROR - 2024-09-01 10:20:51 --> admin
ERROR - 2024-09-01 10:20:51 --> 12
ERROR - 2024-09-01 10:20:51 --> admin
ERROR - 2024-09-01 05:20:51 --> 404 Page Not Found: /index
ERROR - 2024-09-01 10:21:10 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:21:10 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:21:10 --> Could not find the language line "Create New Lead Status"
ERROR - 2024-09-01 10:21:10 --> Could not find the language line "Name"
ERROR - 2024-09-01 10:21:10 --> Could not find the language line "Description"
ERROR - 2024-09-01 10:21:10 --> Could not find the language line "Status"
ERROR - 2024-09-01 10:21:10 --> Could not find the language line "Save"
ERROR - 2024-09-01 10:21:10 --> admin
ERROR - 2024-09-01 10:21:10 --> 12
ERROR - 2024-09-01 10:21:10 --> admin
ERROR - 2024-09-01 05:21:10 --> 404 Page Not Found: /index
ERROR - 2024-09-01 10:21:39 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:21:39 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:21:39 --> Could not find the language line "Create New Lead Status"
ERROR - 2024-09-01 10:21:39 --> Could not find the language line "Name"
ERROR - 2024-09-01 10:21:39 --> Could not find the language line "Description"
ERROR - 2024-09-01 10:21:39 --> Could not find the language line "Status"
ERROR - 2024-09-01 10:21:39 --> Could not find the language line "Save"
ERROR - 2024-09-01 10:21:39 --> admin
ERROR - 2024-09-01 10:21:39 --> 12
ERROR - 2024-09-01 10:21:39 --> admin
ERROR - 2024-09-01 05:21:39 --> 404 Page Not Found: /index
ERROR - 2024-09-01 10:21:43 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:21:43 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:22:24 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:22:24 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:22:26 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:22:26 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:22:26 --> Could not find the language line "Create New Lead Status"
ERROR - 2024-09-01 10:22:26 --> Could not find the language line "Name"
ERROR - 2024-09-01 10:22:26 --> Could not find the language line "Description"
ERROR - 2024-09-01 10:22:26 --> Could not find the language line "Status"
ERROR - 2024-09-01 10:22:26 --> Could not find the language line "Save"
ERROR - 2024-09-01 10:22:26 --> admin
ERROR - 2024-09-01 10:22:26 --> 12
ERROR - 2024-09-01 10:22:26 --> admin
ERROR - 2024-09-01 10:22:28 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:22:28 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:22:33 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:22:33 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:22:34 --> Could not find the language line "Create New Lead Status"
ERROR - 2024-09-01 10:22:34 --> Could not find the language line "Name"
ERROR - 2024-09-01 10:22:34 --> Could not find the language line "Description"
ERROR - 2024-09-01 10:22:34 --> Could not find the language line "Status"
ERROR - 2024-09-01 10:22:34 --> Could not find the language line "Save"
ERROR - 2024-09-01 10:22:34 --> admin
ERROR - 2024-09-01 10:22:34 --> 12
ERROR - 2024-09-01 10:22:34 --> admin
ERROR - 2024-09-01 10:22:35 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:22:35 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:22:35 --> Could not find the language line "Create New Lead Status"
ERROR - 2024-09-01 10:22:35 --> Could not find the language line "Name"
ERROR - 2024-09-01 10:22:35 --> Could not find the language line "Description"
ERROR - 2024-09-01 10:22:35 --> Could not find the language line "Status"
ERROR - 2024-09-01 10:22:35 --> Could not find the language line "Save"
ERROR - 2024-09-01 10:22:35 --> admin
ERROR - 2024-09-01 10:22:35 --> 12
ERROR - 2024-09-01 10:22:35 --> admin
ERROR - 2024-09-01 05:22:35 --> 404 Page Not Found: /index
ERROR - 2024-09-01 10:22:40 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:22:40 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:23:07 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:23:07 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:23:07 --> Could not find the language line "Create New Lead Status"
ERROR - 2024-09-01 10:23:07 --> Could not find the language line "Name"
ERROR - 2024-09-01 10:23:07 --> Could not find the language line "Description"
ERROR - 2024-09-01 10:23:07 --> Could not find the language line "Status"
ERROR - 2024-09-01 10:23:07 --> Could not find the language line "Save"
ERROR - 2024-09-01 10:23:07 --> admin
ERROR - 2024-09-01 10:23:07 --> 12
ERROR - 2024-09-01 10:23:07 --> admin
ERROR - 2024-09-01 10:23:09 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:23:09 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:23:23 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:23:23 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:23:23 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:23:23 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:23:23 --> Could not find the language line "New Lead Status"
ERROR - 2024-09-01 10:23:23 --> Could not find the language line "Name"
ERROR - 2024-09-01 10:23:23 --> Could not find the language line "Description"
ERROR - 2024-09-01 10:23:23 --> Could not find the language line "Status"
ERROR - 2024-09-01 10:23:23 --> Could not find the language line "Actions"
ERROR - 2024-09-01 10:23:23 --> admin
ERROR - 2024-09-01 10:23:23 --> 12
ERROR - 2024-09-01 10:23:23 --> admin
ERROR - 2024-09-01 05:23:23 --> 404 Page Not Found: /index
ERROR - 2024-09-01 10:23:28 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:23:28 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:23:28 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:23:28 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:23:29 --> Could not find the language line "New Lead Status"
ERROR - 2024-09-01 10:23:29 --> Could not find the language line "Name"
ERROR - 2024-09-01 10:23:29 --> Could not find the language line "Description"
ERROR - 2024-09-01 10:23:29 --> Could not find the language line "Status"
ERROR - 2024-09-01 10:23:29 --> Could not find the language line "Actions"
ERROR - 2024-09-01 10:23:29 --> admin
ERROR - 2024-09-01 10:23:29 --> 12
ERROR - 2024-09-01 10:23:29 --> admin
ERROR - 2024-09-01 05:23:29 --> 404 Page Not Found: /index
ERROR - 2024-09-01 10:25:29 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:25:29 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:25:29 --> admin
ERROR - 2024-09-01 10:25:29 --> 12
ERROR - 2024-09-01 10:25:29 --> admin
ERROR - 2024-09-01 05:25:29 --> 404 Page Not Found: /index
ERROR - 2024-09-01 10:25:35 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:25:35 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:25:35 --> admin
ERROR - 2024-09-01 10:25:35 --> 12
ERROR - 2024-09-01 10:25:35 --> admin
ERROR - 2024-09-01 05:25:36 --> 404 Page Not Found: /index
ERROR - 2024-09-01 10:25:36 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:25:36 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:27:27 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:27:27 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:27:28 --> admin
ERROR - 2024-09-01 10:27:28 --> 12
ERROR - 2024-09-01 10:27:28 --> admin
ERROR - 2024-09-01 05:27:28 --> 404 Page Not Found: /index
ERROR - 2024-09-01 10:29:47 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:29:47 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:29:51 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:29:51 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:29:52 --> admin
ERROR - 2024-09-01 10:29:52 --> 12
ERROR - 2024-09-01 10:29:52 --> admin
ERROR - 2024-09-01 05:29:52 --> 404 Page Not Found: /index
ERROR - 2024-09-01 10:29:53 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:29:53 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:29:56 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:29:56 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:29:57 --> admin
ERROR - 2024-09-01 10:29:57 --> 12
ERROR - 2024-09-01 10:29:57 --> admin
ERROR - 2024-09-01 05:29:57 --> 404 Page Not Found: /index
ERROR - 2024-09-01 10:30:03 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:30:03 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:30:03 --> admin
ERROR - 2024-09-01 10:30:03 --> 12
ERROR - 2024-09-01 10:30:03 --> admin
ERROR - 2024-09-01 10:30:04 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:30:04 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:33:35 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:33:35 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:35:26 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:35:26 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:36:17 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:36:17 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:36:17 --> admin
ERROR - 2024-09-01 10:36:17 --> 12
ERROR - 2024-09-01 10:36:17 --> admin
ERROR - 2024-09-01 05:36:17 --> 404 Page Not Found: /index
ERROR - 2024-09-01 10:36:19 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:36:19 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:36:29 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:36:29 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:36:33 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:36:33 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:39:56 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:39:56 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:39:56 --> admin
ERROR - 2024-09-01 10:39:56 --> 12
ERROR - 2024-09-01 10:39:56 --> admin
ERROR - 2024-09-01 05:39:56 --> 404 Page Not Found: /index
ERROR - 2024-09-01 10:39:58 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:39:58 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:40:01 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:40:01 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:43:22 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:43:22 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:43:22 --> admin
ERROR - 2024-09-01 10:43:22 --> 12
ERROR - 2024-09-01 10:43:22 --> admin
ERROR - 2024-09-01 05:43:22 --> 404 Page Not Found: /index
ERROR - 2024-09-01 10:43:24 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:43:24 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:43:30 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:43:30 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:45:29 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:45:29 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:45:29 --> admin
ERROR - 2024-09-01 10:45:29 --> 12
ERROR - 2024-09-01 10:45:29 --> admin
ERROR - 2024-09-01 05:45:29 --> 404 Page Not Found: /index
ERROR - 2024-09-01 10:45:31 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:45:31 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:45:34 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:45:34 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:45:34 --> Severity: Warning --> Undefined array key "max_sell_times" C:\laragon\www\perfex_crm\application\controllers\admin\leadevo\Settings.php 45
ERROR - 2024-09-01 10:45:54 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:45:54 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:45:54 --> admin
ERROR - 2024-09-01 10:45:54 --> 12
ERROR - 2024-09-01 10:45:54 --> admin
ERROR - 2024-09-01 05:45:55 --> 404 Page Not Found: /index
ERROR - 2024-09-01 10:45:56 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:45:56 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:46:02 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:46:02 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:46:02 --> Severity: Warning --> Undefined array key "max_sell_times" C:\laragon\www\perfex_crm\application\controllers\admin\leadevo\Settings.php 45
ERROR - 2024-09-01 10:46:09 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:46:09 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:46:09 --> admin
ERROR - 2024-09-01 10:46:09 --> 12
ERROR - 2024-09-01 10:46:09 --> admin
ERROR - 2024-09-01 05:46:09 --> 404 Page Not Found: /index
ERROR - 2024-09-01 10:46:10 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:46:10 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:50:01 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:50:01 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:50:01 --> admin
ERROR - 2024-09-01 10:50:01 --> 12
ERROR - 2024-09-01 10:50:01 --> admin
ERROR - 2024-09-01 05:50:01 --> 404 Page Not Found: /index
ERROR - 2024-09-01 10:50:03 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:50:03 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:50:06 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:50:06 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:51:19 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:51:19 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:51:20 --> admin
ERROR - 2024-09-01 10:51:20 --> 12
ERROR - 2024-09-01 10:51:20 --> admin
ERROR - 2024-09-01 05:51:20 --> 404 Page Not Found: /index
ERROR - 2024-09-01 10:51:21 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:51:21 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:51:26 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:51:26 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:52:42 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:52:42 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:52:42 --> admin
ERROR - 2024-09-01 10:52:42 --> 12
ERROR - 2024-09-01 10:52:42 --> admin
ERROR - 2024-09-01 05:52:42 --> 404 Page Not Found: /index
ERROR - 2024-09-01 10:52:43 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:52:43 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:53:35 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:53:35 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:53:35 --> admin
ERROR - 2024-09-01 10:53:35 --> 12
ERROR - 2024-09-01 10:53:35 --> admin
ERROR - 2024-09-01 05:53:35 --> 404 Page Not Found: /index
ERROR - 2024-09-01 10:53:36 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:53:36 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:53:39 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:53:39 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:53:39 --> Severity: Warning --> Undefined variable $settings_status C:\laragon\www\perfex_crm\application\controllers\admin\leadevo\Settings.php 57
ERROR - 2024-09-01 10:53:39 --> Severity: Warning --> Undefined variable $max_sell_times C:\laragon\www\perfex_crm\application\controllers\admin\leadevo\Settings.php 58
ERROR - 2024-09-01 10:53:39 --> Severity: Warning --> Undefined variable $days_to_discount C:\laragon\www\perfex_crm\application\controllers\admin\leadevo\Settings.php 59
ERROR - 2024-09-01 10:53:39 --> Severity: Warning --> Undefined variable $discount_type C:\laragon\www\perfex_crm\application\controllers\admin\leadevo\Settings.php 60
ERROR - 2024-09-01 10:53:39 --> Severity: Warning --> Undefined variable $discount_amount C:\laragon\www\perfex_crm\application\controllers\admin\leadevo\Settings.php 61
ERROR - 2024-09-01 10:53:42 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:53:42 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:53:42 --> admin
ERROR - 2024-09-01 10:53:42 --> 12
ERROR - 2024-09-01 10:53:42 --> admin
ERROR - 2024-09-01 05:53:42 --> 404 Page Not Found: /index
ERROR - 2024-09-01 10:53:43 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:53:43 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:53:46 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:53:46 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:53:46 --> Severity: Warning --> Undefined variable $settings_status C:\laragon\www\perfex_crm\application\controllers\admin\leadevo\Settings.php 57
ERROR - 2024-09-01 10:53:46 --> Severity: Warning --> Undefined variable $max_sell_times C:\laragon\www\perfex_crm\application\controllers\admin\leadevo\Settings.php 58
ERROR - 2024-09-01 10:53:46 --> Severity: Warning --> Undefined variable $days_to_discount C:\laragon\www\perfex_crm\application\controllers\admin\leadevo\Settings.php 59
ERROR - 2024-09-01 10:53:46 --> Severity: Warning --> Undefined variable $discount_type C:\laragon\www\perfex_crm\application\controllers\admin\leadevo\Settings.php 60
ERROR - 2024-09-01 10:53:46 --> Severity: Warning --> Undefined variable $discount_amount C:\laragon\www\perfex_crm\application\controllers\admin\leadevo\Settings.php 61
ERROR - 2024-09-01 10:54:57 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:54:57 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:54:58 --> admin
ERROR - 2024-09-01 10:54:58 --> 12
ERROR - 2024-09-01 10:54:58 --> admin
ERROR - 2024-09-01 05:54:58 --> 404 Page Not Found: /index
ERROR - 2024-09-01 10:54:59 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:54:59 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:55:03 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:55:03 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:55:07 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:55:07 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:55:07 --> admin
ERROR - 2024-09-01 10:55:07 --> 12
ERROR - 2024-09-01 10:55:07 --> admin
ERROR - 2024-09-01 05:55:08 --> 404 Page Not Found: /index
ERROR - 2024-09-01 10:55:09 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:55:09 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:55:12 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:55:12 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:55:35 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:55:35 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:55:35 --> admin
ERROR - 2024-09-01 10:55:35 --> 12
ERROR - 2024-09-01 10:55:35 --> admin
ERROR - 2024-09-01 05:55:35 --> 404 Page Not Found: /index
ERROR - 2024-09-01 10:55:37 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:55:37 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:55:44 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:55:44 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:55:49 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:55:49 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:55:49 --> admin
ERROR - 2024-09-01 10:55:49 --> 12
ERROR - 2024-09-01 10:55:49 --> admin
ERROR - 2024-09-01 10:55:52 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:55:52 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:55:52 --> admin
ERROR - 2024-09-01 10:55:52 --> 12
ERROR - 2024-09-01 10:55:52 --> admin
ERROR - 2024-09-01 05:55:53 --> 404 Page Not Found: /index
ERROR - 2024-09-01 10:55:53 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:55:53 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:55:59 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:55:59 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:56:13 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:56:13 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:56:14 --> admin
ERROR - 2024-09-01 10:56:14 --> 12
ERROR - 2024-09-01 10:56:14 --> admin
ERROR - 2024-09-01 05:56:14 --> 404 Page Not Found: /index
ERROR - 2024-09-01 10:56:15 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:56:15 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:56:25 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:56:25 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:56:58 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:56:58 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:56:59 --> admin
ERROR - 2024-09-01 10:56:59 --> 12
ERROR - 2024-09-01 10:56:59 --> admin
ERROR - 2024-09-01 05:56:59 --> 404 Page Not Found: /index
ERROR - 2024-09-01 10:57:00 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:57:00 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:57:03 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:57:03 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:57:03 --> Severity: Warning --> Undefined array key "discount_type" C:\laragon\www\perfex_crm\application\controllers\admin\leadevo\Settings.php 47
ERROR - 2024-09-01 10:58:59 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:58:59 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:58:59 --> admin
ERROR - 2024-09-01 10:58:59 --> 12
ERROR - 2024-09-01 10:58:59 --> admin
ERROR - 2024-09-01 05:58:59 --> 404 Page Not Found: /index
ERROR - 2024-09-01 10:59:00 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:59:00 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:59:05 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:59:05 --> Could not find the language line "billings"
ERROR - 2024-09-01 10:59:05 --> Severity: Warning --> Undefined array key "discount_type" C:\laragon\www\perfex_crm\application\controllers\admin\leadevo\Settings.php 47
ERROR - 2024-09-01 10:59:46 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 10:59:46 --> Could not find the language line "billings"
ERROR - 2024-09-01 11:00:50 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 11:00:50 --> Could not find the language line "billings"
ERROR - 2024-09-01 11:02:00 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 11:02:00 --> Could not find the language line "billings"
ERROR - 2024-09-01 11:02:00 --> admin
ERROR - 2024-09-01 11:02:00 --> 12
ERROR - 2024-09-01 11:02:00 --> admin
ERROR - 2024-09-01 06:02:00 --> 404 Page Not Found: /index
ERROR - 2024-09-01 11:02:02 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 11:02:02 --> Could not find the language line "billings"
ERROR - 2024-09-01 11:02:03 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 11:02:03 --> Could not find the language line "billings"
ERROR - 2024-09-01 11:02:04 --> Severity: Warning --> Undefined array key "discount_type" C:\laragon\www\perfex_crm\application\controllers\admin\leadevo\Settings.php 47
ERROR - 2024-09-01 11:03:20 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 11:03:20 --> Could not find the language line "billings"
ERROR - 2024-09-01 11:04:15 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 11:04:15 --> Could not find the language line "billings"
ERROR - 2024-09-01 11:04:15 --> admin
ERROR - 2024-09-01 11:04:15 --> 12
ERROR - 2024-09-01 11:04:15 --> admin
ERROR - 2024-09-01 06:04:16 --> 404 Page Not Found: /index
ERROR - 2024-09-01 11:04:17 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 11:04:17 --> Could not find the language line "billings"
ERROR - 2024-09-01 11:04:18 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 11:04:18 --> Could not find the language line "billings"
ERROR - 2024-09-01 11:04:18 --> Severity: Warning --> Undefined array key "discount_type" C:\laragon\www\perfex_crm\application\controllers\admin\leadevo\Settings.php 47
ERROR - 2024-09-01 11:04:22 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 11:04:22 --> Could not find the language line "billings"
ERROR - 2024-09-01 11:04:22 --> Severity: Warning --> Undefined array key "discount_type" C:\laragon\www\perfex_crm\application\controllers\admin\leadevo\Settings.php 47
ERROR - 2024-09-01 11:04:41 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 11:04:41 --> Could not find the language line "billings"
ERROR - 2024-09-01 11:04:41 --> admin
ERROR - 2024-09-01 11:04:41 --> 12
ERROR - 2024-09-01 11:04:41 --> admin
ERROR - 2024-09-01 06:04:42 --> 404 Page Not Found: /index
ERROR - 2024-09-01 11:04:43 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 11:04:43 --> Could not find the language line "billings"
ERROR - 2024-09-01 11:04:44 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 11:04:44 --> Could not find the language line "billings"
ERROR - 2024-09-01 11:04:44 --> Severity: Warning --> Undefined array key "discount_type" C:\laragon\www\perfex_crm\application\controllers\admin\leadevo\Settings.php 47
ERROR - 2024-09-01 11:05:54 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 11:05:54 --> Could not find the language line "billings"
ERROR - 2024-09-01 11:05:59 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 11:05:59 --> Could not find the language line "billings"
ERROR - 2024-09-01 11:06:09 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 11:06:09 --> Could not find the language line "billings"
ERROR - 2024-09-01 11:06:09 --> admin
ERROR - 2024-09-01 11:06:09 --> 12
ERROR - 2024-09-01 11:06:09 --> admin
ERROR - 2024-09-01 06:06:09 --> 404 Page Not Found: /index
ERROR - 2024-09-01 11:06:10 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 11:06:10 --> Could not find the language line "billings"
ERROR - 2024-09-01 11:08:23 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 11:08:23 --> Could not find the language line "billings"
ERROR - 2024-09-01 11:08:24 --> admin
ERROR - 2024-09-01 11:08:24 --> 12
ERROR - 2024-09-01 11:08:24 --> admin
ERROR - 2024-09-01 06:08:24 --> 404 Page Not Found: /index
ERROR - 2024-09-01 11:08:25 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 11:08:25 --> Could not find the language line "billings"
ERROR - 2024-09-01 11:08:29 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 11:08:29 --> Could not find the language line "billings"
ERROR - 2024-09-01 11:10:50 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 11:10:50 --> Could not find the language line "billings"
ERROR - 2024-09-01 11:10:50 --> admin
ERROR - 2024-09-01 11:10:50 --> 12
ERROR - 2024-09-01 11:10:50 --> admin
ERROR - 2024-09-01 06:10:50 --> 404 Page Not Found: /index
ERROR - 2024-09-01 11:10:51 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 11:10:51 --> Could not find the language line "billings"
ERROR - 2024-09-01 11:10:56 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 11:10:56 --> Could not find the language line "billings"
ERROR - 2024-09-01 11:11:03 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 11:11:03 --> Could not find the language line "billings"
ERROR - 2024-09-01 11:12:14 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 11:12:14 --> Could not find the language line "billings"
ERROR - 2024-09-01 11:12:23 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 11:12:23 --> Could not find the language line "billings"
ERROR - 2024-09-01 11:19:22 --> client
ERROR - 2024-09-01 11:19:22 --> 12
ERROR - 2024-09-01 11:19:22 --> client
ERROR - 2024-09-01 11:19:33 --> client
ERROR - 2024-09-01 11:19:33 --> 12
ERROR - 2024-09-01 11:19:33 --> client
ERROR - 2024-09-01 11:21:26 --> client
ERROR - 2024-09-01 11:21:26 --> 12
ERROR - 2024-09-01 11:21:26 --> client
ERROR - 2024-09-01 11:21:28 --> client
ERROR - 2024-09-01 11:21:28 --> 12
ERROR - 2024-09-01 11:21:28 --> client
ERROR - 2024-09-01 11:23:30 --> client
ERROR - 2024-09-01 11:23:30 --> 12
ERROR - 2024-09-01 11:23:30 --> client
ERROR - 2024-09-01 11:25:16 --> client
ERROR - 2024-09-01 11:25:16 --> 12
ERROR - 2024-09-01 11:25:16 --> client
ERROR - 2024-09-01 11:25:56 --> client
ERROR - 2024-09-01 11:25:56 --> 12
ERROR - 2024-09-01 11:25:56 --> client
ERROR - 2024-09-01 11:29:49 --> Could not find the language line "Onboarding"
ERROR - 2024-09-01 11:29:49 --> Could not find the language line "Onboarding"
ERROR - 2024-09-01 11:29:49 --> Could not find the language line "Invite Friend"
ERROR - 2024-09-01 11:29:49 --> Could not find the language line "Join our private Facebook group"
ERROR - 2024-09-01 11:29:49 --> Could not find the language line "group dedicated specifically for ambassadors. In the group, you'll get access to other successful ambassadors, learn the latest marketing strategies, get help from our support team, and stay informed on all the latest product updates."
ERROR - 2024-09-01 11:29:49 --> Could not find the language line "Sign Up for Alerts"
ERROR - 2024-09-01 11:29:49 --> Could not find the language line "Sign up for our email alerts to stay informed about the latest updates, opportunities, and important information."
ERROR - 2024-09-01 11:29:49 --> Could not find the language line "Complete and Continue"
ERROR - 2024-09-01 11:29:49 --> Could not find the language line "Continue"
ERROR - 2024-09-01 11:29:49 --> Could not find the language line "Onboarding Progress"
ERROR - 2024-09-01 11:29:49 --> Could not find the language line "Watch welcome message"
ERROR - 2024-09-01 11:29:49 --> Could not find the language line "Join Facebook group"
ERROR - 2024-09-01 11:29:49 --> Could not find the language line "Sign up for email alerts"
ERROR - 2024-09-01 11:29:49 --> Could not find the language line "Watch portal walkthrough"
ERROR - 2024-09-01 11:29:49 --> Could not find the language line "Understand the opportunity"
ERROR - 2024-09-01 11:29:49 --> Could not find the language line "Review available products"
ERROR - 2024-09-01 11:29:49 --> Could not find the language line "Who do you want to invite?"
ERROR - 2024-09-01 11:29:49 --> Could not find the language line "Send Invitation"
ERROR - 2024-09-01 11:29:49 --> Could not find the language line "Sign Up for Alerts"
ERROR - 2024-09-01 11:29:49 --> Could not find the language line "<i class="fa fa-exclamation-circle tw-mr-1"></i> We'll never send marketing emails through these alerts. These email alerts are strictly to inform you about Ambassador Program latest updates."
ERROR - 2024-09-01 11:29:49 --> Could not find the language line "Sign Up and Continue"
ERROR - 2024-09-01 11:29:49 --> Could not find the language line "Invitation sent!"
ERROR - 2024-09-01 11:29:49 --> Could not find the language line "Invitation failed!"
ERROR - 2024-09-01 11:29:49 --> client
ERROR - 2024-09-01 11:29:49 --> 12
ERROR - 2024-09-01 11:29:49 --> client
ERROR - 2024-09-01 11:29:53 --> Could not find the language line "Onboarding"
ERROR - 2024-09-01 11:29:53 --> Could not find the language line "Onboarding"
ERROR - 2024-09-01 11:29:53 --> Could not find the language line "Invite Friend"
ERROR - 2024-09-01 11:29:53 --> Could not find the language line "Join our private Facebook group"
ERROR - 2024-09-01 11:29:53 --> Could not find the language line "group dedicated specifically for ambassadors. In the group, you'll get access to other successful ambassadors, learn the latest marketing strategies, get help from our support team, and stay informed on all the latest product updates."
ERROR - 2024-09-01 11:29:53 --> Could not find the language line "Sign Up for Alerts"
ERROR - 2024-09-01 11:29:53 --> Could not find the language line "Sign up for our email alerts to stay informed about the latest updates, opportunities, and important information."
ERROR - 2024-09-01 11:29:53 --> Could not find the language line "Complete and Continue"
ERROR - 2024-09-01 11:29:53 --> Could not find the language line "Continue"
ERROR - 2024-09-01 11:29:53 --> Could not find the language line "Onboarding Progress"
ERROR - 2024-09-01 11:29:53 --> Could not find the language line "Watch welcome message"
ERROR - 2024-09-01 11:29:53 --> Could not find the language line "Join Facebook group"
ERROR - 2024-09-01 11:29:53 --> Could not find the language line "Sign up for email alerts"
ERROR - 2024-09-01 11:29:53 --> Could not find the language line "Watch portal walkthrough"
ERROR - 2024-09-01 11:29:53 --> Could not find the language line "Understand the opportunity"
ERROR - 2024-09-01 11:29:53 --> Could not find the language line "Review available products"
ERROR - 2024-09-01 11:29:53 --> Could not find the language line "Who do you want to invite?"
ERROR - 2024-09-01 11:29:53 --> Could not find the language line "Send Invitation"
ERROR - 2024-09-01 11:29:53 --> Could not find the language line "Sign Up for Alerts"
ERROR - 2024-09-01 11:29:53 --> Could not find the language line "<i class="fa fa-exclamation-circle tw-mr-1"></i> We'll never send marketing emails through these alerts. These email alerts are strictly to inform you about Ambassador Program latest updates."
ERROR - 2024-09-01 11:29:53 --> Could not find the language line "Sign Up and Continue"
ERROR - 2024-09-01 11:29:53 --> Could not find the language line "Invitation sent!"
ERROR - 2024-09-01 11:29:53 --> Could not find the language line "Invitation failed!"
ERROR - 2024-09-01 11:29:53 --> client
ERROR - 2024-09-01 11:29:53 --> 12
ERROR - 2024-09-01 11:29:53 --> client
ERROR - 2024-09-01 11:29:57 --> Could not find the language line "Onboarding"
ERROR - 2024-09-01 11:29:57 --> Could not find the language line "Onboarding"
ERROR - 2024-09-01 11:29:57 --> Could not find the language line "Invite Friend"
ERROR - 2024-09-01 11:29:57 --> Could not find the language line "Join our private Facebook group"
ERROR - 2024-09-01 11:29:57 --> Could not find the language line "group dedicated specifically for ambassadors. In the group, you'll get access to other successful ambassadors, learn the latest marketing strategies, get help from our support team, and stay informed on all the latest product updates."
ERROR - 2024-09-01 11:29:57 --> Could not find the language line "Sign Up for Alerts"
ERROR - 2024-09-01 11:29:57 --> Could not find the language line "Sign up for our email alerts to stay informed about the latest updates, opportunities, and important information."
ERROR - 2024-09-01 11:29:57 --> Could not find the language line "Complete and Continue"
ERROR - 2024-09-01 11:29:57 --> Could not find the language line "Continue"
ERROR - 2024-09-01 11:29:57 --> Could not find the language line "Onboarding Progress"
ERROR - 2024-09-01 11:29:57 --> Could not find the language line "Watch welcome message"
ERROR - 2024-09-01 11:29:57 --> Could not find the language line "Join Facebook group"
ERROR - 2024-09-01 11:29:57 --> Could not find the language line "Sign up for email alerts"
ERROR - 2024-09-01 11:29:57 --> Could not find the language line "Watch portal walkthrough"
ERROR - 2024-09-01 11:29:57 --> Could not find the language line "Understand the opportunity"
ERROR - 2024-09-01 11:29:57 --> Could not find the language line "Review available products"
ERROR - 2024-09-01 11:29:57 --> Could not find the language line "Who do you want to invite?"
ERROR - 2024-09-01 11:29:57 --> Could not find the language line "Send Invitation"
ERROR - 2024-09-01 11:29:57 --> Could not find the language line "Sign Up for Alerts"
ERROR - 2024-09-01 11:29:57 --> Could not find the language line "<i class="fa fa-exclamation-circle tw-mr-1"></i> We'll never send marketing emails through these alerts. These email alerts are strictly to inform you about Ambassador Program latest updates."
ERROR - 2024-09-01 11:29:57 --> Could not find the language line "Sign Up and Continue"
ERROR - 2024-09-01 11:29:57 --> Could not find the language line "Invitation sent!"
ERROR - 2024-09-01 11:29:57 --> Could not find the language line "Invitation failed!"
ERROR - 2024-09-01 11:29:57 --> client
ERROR - 2024-09-01 11:29:57 --> 12
ERROR - 2024-09-01 11:29:57 --> client
ERROR - 2024-09-01 11:30:01 --> Could not find the language line "Onboarding"
ERROR - 2024-09-01 11:30:01 --> Could not find the language line "Onboarding"
ERROR - 2024-09-01 11:30:01 --> Could not find the language line "Invite Friend"
ERROR - 2024-09-01 11:30:01 --> Could not find the language line "Join our private Facebook group"
ERROR - 2024-09-01 11:30:01 --> Could not find the language line "group dedicated specifically for ambassadors. In the group, you'll get access to other successful ambassadors, learn the latest marketing strategies, get help from our support team, and stay informed on all the latest product updates."
ERROR - 2024-09-01 11:30:01 --> Could not find the language line "Sign Up for Alerts"
ERROR - 2024-09-01 11:30:01 --> Could not find the language line "Sign up for our email alerts to stay informed about the latest updates, opportunities, and important information."
ERROR - 2024-09-01 11:30:01 --> Could not find the language line "Complete and Continue"
ERROR - 2024-09-01 11:30:01 --> Could not find the language line "Continue"
ERROR - 2024-09-01 11:30:01 --> Could not find the language line "Onboarding Progress"
ERROR - 2024-09-01 11:30:01 --> Could not find the language line "Watch welcome message"
ERROR - 2024-09-01 11:30:01 --> Could not find the language line "Join Facebook group"
ERROR - 2024-09-01 11:30:01 --> Could not find the language line "Sign up for email alerts"
ERROR - 2024-09-01 11:30:01 --> Could not find the language line "Watch portal walkthrough"
ERROR - 2024-09-01 11:30:01 --> Could not find the language line "Understand the opportunity"
ERROR - 2024-09-01 11:30:01 --> Could not find the language line "Review available products"
ERROR - 2024-09-01 11:30:01 --> Could not find the language line "Who do you want to invite?"
ERROR - 2024-09-01 11:30:01 --> Could not find the language line "Send Invitation"
ERROR - 2024-09-01 11:30:01 --> Could not find the language line "Sign Up for Alerts"
ERROR - 2024-09-01 11:30:01 --> Could not find the language line "<i class="fa fa-exclamation-circle tw-mr-1"></i> We'll never send marketing emails through these alerts. These email alerts are strictly to inform you about Ambassador Program latest updates."
ERROR - 2024-09-01 11:30:01 --> Could not find the language line "Sign Up and Continue"
ERROR - 2024-09-01 11:30:01 --> Could not find the language line "Invitation sent!"
ERROR - 2024-09-01 11:30:01 --> Could not find the language line "Invitation failed!"
ERROR - 2024-09-01 11:30:01 --> client
ERROR - 2024-09-01 11:30:01 --> 12
ERROR - 2024-09-01 11:30:01 --> client
ERROR - 2024-09-01 11:30:03 --> Could not find the language line "Onboarding"
ERROR - 2024-09-01 11:30:03 --> Could not find the language line "Onboarding"
ERROR - 2024-09-01 11:30:03 --> Could not find the language line "Invite Friend"
ERROR - 2024-09-01 11:30:03 --> Could not find the language line "Join our private Facebook group"
ERROR - 2024-09-01 11:30:03 --> Could not find the language line "group dedicated specifically for ambassadors. In the group, you'll get access to other successful ambassadors, learn the latest marketing strategies, get help from our support team, and stay informed on all the latest product updates."
ERROR - 2024-09-01 11:30:03 --> Could not find the language line "Sign Up for Alerts"
ERROR - 2024-09-01 11:30:03 --> Could not find the language line "Sign up for our email alerts to stay informed about the latest updates, opportunities, and important information."
ERROR - 2024-09-01 11:30:03 --> Could not find the language line "Complete and Continue"
ERROR - 2024-09-01 11:30:03 --> Could not find the language line "Continue"
ERROR - 2024-09-01 11:30:03 --> Could not find the language line "Onboarding Progress"
ERROR - 2024-09-01 11:30:03 --> Could not find the language line "Watch welcome message"
ERROR - 2024-09-01 11:30:03 --> Could not find the language line "Join Facebook group"
ERROR - 2024-09-01 11:30:03 --> Could not find the language line "Sign up for email alerts"
ERROR - 2024-09-01 11:30:03 --> Could not find the language line "Watch portal walkthrough"
ERROR - 2024-09-01 11:30:03 --> Could not find the language line "Understand the opportunity"
ERROR - 2024-09-01 11:30:03 --> Could not find the language line "Review available products"
ERROR - 2024-09-01 11:30:03 --> Could not find the language line "Who do you want to invite?"
ERROR - 2024-09-01 11:30:03 --> Could not find the language line "Send Invitation"
ERROR - 2024-09-01 11:30:03 --> Could not find the language line "Sign Up for Alerts"
ERROR - 2024-09-01 11:30:03 --> Could not find the language line "<i class="fa fa-exclamation-circle tw-mr-1"></i> We'll never send marketing emails through these alerts. These email alerts are strictly to inform you about Ambassador Program latest updates."
ERROR - 2024-09-01 11:30:03 --> Could not find the language line "Sign Up and Continue"
ERROR - 2024-09-01 11:30:03 --> Could not find the language line "Invitation sent!"
ERROR - 2024-09-01 11:30:03 --> Could not find the language line "Invitation failed!"
ERROR - 2024-09-01 11:30:03 --> client
ERROR - 2024-09-01 11:30:03 --> 12
ERROR - 2024-09-01 11:30:03 --> client
ERROR - 2024-09-01 11:30:05 --> Could not find the language line "Onboarding"
ERROR - 2024-09-01 11:30:05 --> Could not find the language line "Onboarding"
ERROR - 2024-09-01 11:30:05 --> Could not find the language line "Invite Friend"
ERROR - 2024-09-01 11:30:05 --> Could not find the language line "Join our private Facebook group"
ERROR - 2024-09-01 11:30:05 --> Could not find the language line "group dedicated specifically for ambassadors. In the group, you'll get access to other successful ambassadors, learn the latest marketing strategies, get help from our support team, and stay informed on all the latest product updates."
ERROR - 2024-09-01 11:30:05 --> Could not find the language line "Sign Up for Alerts"
ERROR - 2024-09-01 11:30:05 --> Could not find the language line "Sign up for our email alerts to stay informed about the latest updates, opportunities, and important information."
ERROR - 2024-09-01 11:30:05 --> Could not find the language line "Complete and Continue"
ERROR - 2024-09-01 11:30:05 --> Could not find the language line "Continue"
ERROR - 2024-09-01 11:30:05 --> Could not find the language line "Onboarding Progress"
ERROR - 2024-09-01 11:30:05 --> Could not find the language line "Watch welcome message"
ERROR - 2024-09-01 11:30:05 --> Could not find the language line "Join Facebook group"
ERROR - 2024-09-01 11:30:05 --> Could not find the language line "Sign up for email alerts"
ERROR - 2024-09-01 11:30:05 --> Could not find the language line "Watch portal walkthrough"
ERROR - 2024-09-01 11:30:05 --> Could not find the language line "Understand the opportunity"
ERROR - 2024-09-01 11:30:05 --> Could not find the language line "Review available products"
ERROR - 2024-09-01 11:30:05 --> Could not find the language line "Who do you want to invite?"
ERROR - 2024-09-01 11:30:05 --> Could not find the language line "Send Invitation"
ERROR - 2024-09-01 11:30:05 --> Could not find the language line "Sign Up for Alerts"
ERROR - 2024-09-01 11:30:05 --> Could not find the language line "<i class="fa fa-exclamation-circle tw-mr-1"></i> We'll never send marketing emails through these alerts. These email alerts are strictly to inform you about Ambassador Program latest updates."
ERROR - 2024-09-01 11:30:05 --> Could not find the language line "Sign Up and Continue"
ERROR - 2024-09-01 11:30:05 --> Could not find the language line "Invitation sent!"
ERROR - 2024-09-01 11:30:05 --> Could not find the language line "Invitation failed!"
ERROR - 2024-09-01 11:30:05 --> client
ERROR - 2024-09-01 11:30:05 --> 12
ERROR - 2024-09-01 11:30:05 --> client
ERROR - 2024-09-01 11:30:29 --> Severity: error --> Exception: In aggregated query without GROUP BY, expression #2 of SELECT list contains nonaggregated column 'reported.reported_today'; this is incompatible with sql_mode=only_full_group_by C:\laragon\www\perfex_crm\system\database\drivers\mysqli\mysqli_driver.php 307
ERROR - 2024-09-01 11:33:01 --> Severity: error --> Exception: In aggregated query without GROUP BY, expression #2 of SELECT list contains nonaggregated column 'reported.reported_today'; this is incompatible with sql_mode=only_full_group_by C:\laragon\www\perfex_crm\system\database\drivers\mysqli\mysqli_driver.php 307
ERROR - 2024-09-01 11:33:03 --> Severity: error --> Exception: In aggregated query without GROUP BY, expression #2 of SELECT list contains nonaggregated column 'reported.reported_today'; this is incompatible with sql_mode=only_full_group_by C:\laragon\www\perfex_crm\system\database\drivers\mysqli\mysqli_driver.php 307
ERROR - 2024-09-01 11:33:17 --> client
ERROR - 2024-09-01 11:33:17 --> 12
ERROR - 2024-09-01 11:33:17 --> client
ERROR - 2024-09-01 11:33:20 --> Could not find the language line "New Prospect"
ERROR - 2024-09-01 11:33:20 --> Could not find the language line "Search Prospects"
ERROR - 2024-09-01 11:33:20 --> Could not find the language line "Filter By"
ERROR - 2024-09-01 11:33:20 --> Could not find the language line "Active Prospects"
ERROR - 2024-09-01 11:33:20 --> Could not find the language line "Inactive Prospects"
ERROR - 2024-09-01 11:33:20 --> Could not find the language line "No prospects found."
ERROR - 2024-09-01 11:33:20 --> client
ERROR - 2024-09-01 11:33:20 --> 12
ERROR - 2024-09-01 11:33:20 --> client
ERROR - 2024-09-01 11:33:25 --> Severity: error --> Exception: Too few arguments to function Prospect_types_model::get_all(), 0 passed in C:\laragon\www\perfex_crm\application\controllers\Prospects.php on line 133 and exactly 1 expected C:\laragon\www\perfex_crm\application\models\leadevo\Prospect_types_model.php 12
ERROR - 2024-09-01 11:35:07 --> Severity: error --> Exception: Too few arguments to function Prospect_types_model::get_all(), 0 passed in C:\laragon\www\perfex_crm\application\controllers\Prospects.php on line 133 and exactly 1 expected C:\laragon\www\perfex_crm\application\models\leadevo\Prospect_types_model.php 12
ERROR - 2024-09-01 11:35:58 --> Severity: error --> Exception: Too few arguments to function Prospect_types_model::get_all(), 0 passed in C:\laragon\www\perfex_crm\application\controllers\Prospects.php on line 133 and exactly 1 expected C:\laragon\www\perfex_crm\application\models\leadevo\Prospect_types_model.php 12
ERROR - 2024-09-01 11:36:04 --> Severity: error --> Exception: Too few arguments to function Prospect_types_model::get_all(), 0 passed in C:\laragon\www\perfex_crm\application\controllers\Prospects.php on line 133 and exactly 1 expected C:\laragon\www\perfex_crm\application\models\leadevo\Prospect_types_model.php 12
ERROR - 2024-09-01 11:36:08 --> Severity: error --> Exception: syntax error, unexpected token "return", expecting "function" or "const" C:\laragon\www\perfex_crm\application\models\leadevo\Prospect_types_model.php 18
ERROR - 2024-09-01 11:36:12 --> Severity: error --> Exception: Too few arguments to function Prospect_types_model::get_all(), 0 passed in C:\laragon\www\perfex_crm\application\controllers\Prospects.php on line 133 and exactly 1 expected C:\laragon\www\perfex_crm\application\models\leadevo\Prospect_types_model.php 12
ERROR - 2024-09-01 11:36:36 --> Severity: error --> Exception: Too few arguments to function Prospect_categories_model::get_all(), 0 passed in C:\laragon\www\perfex_crm\application\controllers\Prospects.php on line 134 and exactly 1 expected C:\laragon\www\perfex_crm\application\models\leadevo\Prospect_categories_model.php 12
ERROR - 2024-09-01 11:36:44 --> Severity: error --> Exception: Too few arguments to function Prospect_categories_model::get_all(), 0 passed in C:\laragon\www\perfex_crm\application\controllers\Prospects.php on line 134 and exactly 1 expected C:\laragon\www\perfex_crm\application\models\leadevo\Prospect_categories_model.php 12
ERROR - 2024-09-01 11:36:50 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 11:36:50 --> Could not find the language line "billings"
ERROR - 2024-09-01 11:36:50 --> Could not find the language line "New Prospect Type"
ERROR - 2024-09-01 11:36:50 --> Could not find the language line "Name"
ERROR - 2024-09-01 11:36:50 --> Could not find the language line "Description"
ERROR - 2024-09-01 11:36:50 --> Could not find the language line "Status"
ERROR - 2024-09-01 11:36:50 --> Could not find the language line "Actions"
ERROR - 2024-09-01 11:36:50 --> admin
ERROR - 2024-09-01 11:36:50 --> 12
ERROR - 2024-09-01 11:36:50 --> admin
ERROR - 2024-09-01 06:36:50 --> 404 Page Not Found: /index
ERROR - 2024-09-01 11:37:38 --> Severity: error --> Exception: Too few arguments to function Prospect_types_model::get_all(), 0 passed in C:\laragon\www\perfex_crm\application\controllers\Prospects.php on line 133 and exactly 1 expected C:\laragon\www\perfex_crm\application\models\leadevo\Prospect_types_model.php 12
ERROR - 2024-09-01 11:39:30 --> Severity: error --> Exception: Too few arguments to function Prospect_types_model::get_all(), 0 passed in C:\laragon\www\perfex_crm\application\controllers\Prospects.php on line 133 and exactly 1 expected C:\laragon\www\perfex_crm\application\models\leadevo\Prospect_types_model.php 12
ERROR - 2024-09-01 11:39:43 --> Severity: error --> Exception: Too few arguments to function Prospect_types_model::get_all(), 0 passed in C:\laragon\www\perfex_crm\application\controllers\Prospects.php on line 133 and exactly 1 expected C:\laragon\www\perfex_crm\application\models\leadevo\Prospect_types_model.php 12
ERROR - 2024-09-01 11:39:58 --> Severity: error --> Exception: Too few arguments to function Prospect_types_model::get_all(), 0 passed in C:\laragon\www\perfex_crm\application\controllers\Prospects.php on line 133 and exactly 1 expected C:\laragon\www\perfex_crm\application\models\leadevo\Prospect_types_model.php 12
ERROR - 2024-09-01 11:40:34 --> Severity: error --> Exception: Too few arguments to function Prospect_types_model::get_all(), 0 passed in C:\laragon\www\perfex_crm\application\controllers\Prospects.php on line 133 and exactly 1 expected C:\laragon\www\perfex_crm\application\models\leadevo\Prospect_types_model.php 12
ERROR - 2024-09-01 11:40:42 --> Severity: error --> Exception: Too few arguments to function Prospect_categories_model::get_all(), 0 passed in C:\laragon\www\perfex_crm\application\controllers\Prospects.php on line 134 and exactly 1 expected C:\laragon\www\perfex_crm\application\models\leadevo\Prospect_categories_model.php 12
ERROR - 2024-09-01 11:40:51 --> Severity: error --> Exception: Too few arguments to function Acquisition_channels_model::get_all(), 0 passed in C:\laragon\www\perfex_crm\application\controllers\Prospects.php on line 135 and exactly 1 expected C:\laragon\www\perfex_crm\application\models\leadevo\Acquisition_channels_model.php 12
ERROR - 2024-09-01 11:40:57 --> Severity: error --> Exception: Too few arguments to function Industries_model::get_all(), 0 passed in C:\laragon\www\perfex_crm\application\controllers\Prospects.php on line 136 and exactly 1 expected C:\laragon\www\perfex_crm\application\models\leadevo\Industries_model.php 13
ERROR - 2024-09-01 11:41:02 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 11:41:02 --> Could not find the language line "billings"
ERROR - 2024-09-01 11:41:02 --> Could not find the language line "New Prospect Type"
ERROR - 2024-09-01 11:41:02 --> Could not find the language line "Name"
ERROR - 2024-09-01 11:41:02 --> Could not find the language line "Description"
ERROR - 2024-09-01 11:41:02 --> Could not find the language line "Status"
ERROR - 2024-09-01 11:41:02 --> Could not find the language line "Actions"
ERROR - 2024-09-01 11:41:02 --> admin
ERROR - 2024-09-01 11:41:02 --> 12
ERROR - 2024-09-01 11:41:02 --> admin
ERROR - 2024-09-01 06:41:03 --> 404 Page Not Found: /index
ERROR - 2024-09-01 11:41:05 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 11:41:05 --> Could not find the language line "billings"
ERROR - 2024-09-01 11:41:05 --> Could not find the language line "Name"
ERROR - 2024-09-01 11:41:05 --> Could not find the language line "Description"
ERROR - 2024-09-01 11:41:05 --> Could not find the language line "Status"
ERROR - 2024-09-01 11:41:05 --> Could not find the language line "Save"
ERROR - 2024-09-01 11:41:05 --> admin
ERROR - 2024-09-01 11:41:05 --> 12
ERROR - 2024-09-01 11:41:05 --> admin
ERROR - 2024-09-01 06:41:05 --> 404 Page Not Found: /index
ERROR - 2024-09-01 11:41:07 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 11:41:07 --> Could not find the language line "billings"
ERROR - 2024-09-01 11:41:07 --> Could not find the language line "New Prospect Type"
ERROR - 2024-09-01 11:41:07 --> Could not find the language line "Name"
ERROR - 2024-09-01 11:41:07 --> Could not find the language line "Description"
ERROR - 2024-09-01 11:41:07 --> Could not find the language line "Status"
ERROR - 2024-09-01 11:41:07 --> Could not find the language line "Actions"
ERROR - 2024-09-01 11:41:07 --> admin
ERROR - 2024-09-01 11:41:07 --> 12
ERROR - 2024-09-01 11:41:07 --> admin
ERROR - 2024-09-01 11:41:11 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 11:41:11 --> Could not find the language line "billings"
ERROR - 2024-09-01 11:41:11 --> Could not find the language line "New Acquisition Channel"
ERROR - 2024-09-01 11:41:11 --> Could not find the language line "Name"
ERROR - 2024-09-01 11:41:11 --> Could not find the language line "Description"
ERROR - 2024-09-01 11:41:11 --> Could not find the language line "Status"
ERROR - 2024-09-01 11:41:11 --> Could not find the language line "Actions"
ERROR - 2024-09-01 11:41:11 --> admin
ERROR - 2024-09-01 11:41:11 --> 12
ERROR - 2024-09-01 11:41:11 --> admin
ERROR - 2024-09-01 06:41:11 --> 404 Page Not Found: /index
ERROR - 2024-09-01 11:41:14 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 11:41:14 --> Could not find the language line "billings"
ERROR - 2024-09-01 11:41:14 --> Could not find the language line "Edit Acquisition Channel"
ERROR - 2024-09-01 11:41:14 --> Could not find the language line "Name"
ERROR - 2024-09-01 11:41:14 --> Could not find the language line "Description"
ERROR - 2024-09-01 11:41:14 --> Could not find the language line "Status"
ERROR - 2024-09-01 11:41:14 --> Could not find the language line "Save Changes"
ERROR - 2024-09-01 11:41:14 --> admin
ERROR - 2024-09-01 11:41:14 --> 12
ERROR - 2024-09-01 11:41:14 --> admin
ERROR - 2024-09-01 06:41:15 --> 404 Page Not Found: /index
ERROR - 2024-09-01 11:41:17 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 11:41:17 --> Could not find the language line "billings"
ERROR - 2024-09-01 11:41:18 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 11:41:18 --> Could not find the language line "billings"
ERROR - 2024-09-01 11:41:18 --> Could not find the language line "New Acquisition Channel"
ERROR - 2024-09-01 11:41:18 --> Could not find the language line "Name"
ERROR - 2024-09-01 11:41:18 --> Could not find the language line "Description"
ERROR - 2024-09-01 11:41:18 --> Could not find the language line "Status"
ERROR - 2024-09-01 11:41:18 --> Could not find the language line "Actions"
ERROR - 2024-09-01 11:41:18 --> admin
ERROR - 2024-09-01 11:41:18 --> 12
ERROR - 2024-09-01 11:41:18 --> admin
ERROR - 2024-09-01 06:41:18 --> 404 Page Not Found: /index
ERROR - 2024-09-01 11:41:32 --> Could not find the language line "Create Prospect"
ERROR - 2024-09-01 11:41:32 --> Could not find the language line "First Name"
ERROR - 2024-09-01 11:41:32 --> Could not find the language line "Last Name"
ERROR - 2024-09-01 11:41:32 --> Could not find the language line "Phone"
ERROR - 2024-09-01 11:41:32 --> Could not find the language line "Email"
ERROR - 2024-09-01 11:41:32 --> Could not find the language line "Status"
ERROR - 2024-09-01 11:41:32 --> Could not find the language line "Type"
ERROR - 2024-09-01 11:41:33 --> Could not find the language line "Category"
ERROR - 2024-09-01 11:41:33 --> Could not find the language line "Acquisition Channel"
ERROR - 2024-09-01 11:41:33 --> Could not find the language line "Industry"
ERROR - 2024-09-01 11:41:33 --> Could not find the language line "Desired Amount"
ERROR - 2024-09-01 11:41:33 --> Could not find the language line "Minimum Amount"
ERROR - 2024-09-01 11:41:33 --> Could not find the language line "Save Prospect"
ERROR - 2024-09-01 11:41:33 --> client
ERROR - 2024-09-01 11:41:33 --> 12
ERROR - 2024-09-01 11:41:33 --> client
ERROR - 2024-09-01 11:42:03 --> Could not find the language line "Search Prospect Alerts"
ERROR - 2024-09-01 11:42:03 --> Could not find the language line "Filter By"
ERROR - 2024-09-01 11:42:03 --> Could not find the language line "All"
ERROR - 2024-09-01 11:42:03 --> Could not find the language line "Active"
ERROR - 2024-09-01 11:42:03 --> Could not find the language line "Inactive"
ERROR - 2024-09-01 11:42:03 --> Could not find the language line "New Prospect Alert"
ERROR - 2024-09-01 11:42:03 --> Could not find the language line "No prospects found."
ERROR - 2024-09-01 11:42:03 --> client
ERROR - 2024-09-01 11:42:03 --> 12
ERROR - 2024-09-01 11:42:03 --> client
ERROR - 2024-09-01 11:42:05 --> Could not find the language line "Add New Prospect Alert"
ERROR - 2024-09-01 11:42:05 --> Could not find the language line "Name"
ERROR - 2024-09-01 11:42:05 --> Could not find the language line "Prospect Category"
ERROR - 2024-09-01 11:42:05 --> Could not find the language line "Select Prospect Category"
ERROR - 2024-09-01 11:42:05 --> Could not find the language line "Select Prospect Category"
ERROR - 2024-09-01 11:42:05 --> Could not find the language line "Prospect Industry"
ERROR - 2024-09-01 11:42:05 --> Could not find the language line "Select Prospect Industry"
ERROR - 2024-09-01 11:42:05 --> Could not find the language line "Select Prospect Industry"
ERROR - 2024-09-01 11:42:05 --> Could not find the language line "Acquisition Channel"
ERROR - 2024-09-01 11:42:05 --> Could not find the language line "Select Acquisition Channel"
ERROR - 2024-09-01 11:42:05 --> Could not find the language line "Select Acquisition Channel"
ERROR - 2024-09-01 11:42:05 --> Could not find the language line "Verification Methods"
ERROR - 2024-09-01 11:42:05 --> Could not find the language line "Verified via WhatsApp"
ERROR - 2024-09-01 11:42:05 --> Could not find the language line "Verified via SMS"
ERROR - 2024-09-01 11:42:05 --> Could not find the language line "Verified by Staff"
ERROR - 2024-09-01 11:42:05 --> Could not find the language line "Email"
ERROR - 2024-09-01 11:42:05 --> Could not find the language line "Phone"
ERROR - 2024-09-01 11:42:05 --> Could not find the language line "Save"
ERROR - 2024-09-01 11:42:05 --> Could not find the language line "Cancel"
ERROR - 2024-09-01 11:42:05 --> client
ERROR - 2024-09-01 11:42:05 --> 12
ERROR - 2024-09-01 11:42:05 --> client
ERROR - 2024-09-01 11:42:11 --> Could not find the language line "Search Prospect Alerts"
ERROR - 2024-09-01 11:42:11 --> Could not find the language line "Filter By"
ERROR - 2024-09-01 11:42:11 --> Could not find the language line "All"
ERROR - 2024-09-01 11:42:11 --> Could not find the language line "Active"
ERROR - 2024-09-01 11:42:11 --> Could not find the language line "Inactive"
ERROR - 2024-09-01 11:42:11 --> Could not find the language line "New Prospect Alert"
ERROR - 2024-09-01 11:42:11 --> Severity: 8192 --> htmlspecialchars(): Passing null to parameter #1 ($string) of type string is deprecated C:\laragon\www\perfex_crm\application\views\themes\perfex\views\clients\prospect_alerts\prospect_alerts.php 174
ERROR - 2024-09-01 11:42:11 --> Severity: 8192 --> htmlspecialchars(): Passing null to parameter #1 ($string) of type string is deprecated C:\laragon\www\perfex_crm\application\views\themes\perfex\views\clients\prospect_alerts\prospect_alerts.php 178
ERROR - 2024-09-01 11:42:11 --> client
ERROR - 2024-09-01 11:42:11 --> 12
ERROR - 2024-09-01 11:42:11 --> client
ERROR - 2024-09-01 11:42:19 --> Could not find the language line "Add New Prospect Alert"
ERROR - 2024-09-01 11:42:19 --> Could not find the language line "Name"
ERROR - 2024-09-01 11:42:19 --> Could not find the language line "Prospect Category"
ERROR - 2024-09-01 11:42:19 --> Could not find the language line "Select Prospect Category"
ERROR - 2024-09-01 11:42:19 --> Could not find the language line "Select Prospect Category"
ERROR - 2024-09-01 11:42:19 --> Could not find the language line "Prospect Industry"
ERROR - 2024-09-01 11:42:19 --> Could not find the language line "Select Prospect Industry"
ERROR - 2024-09-01 11:42:19 --> Could not find the language line "Select Prospect Industry"
ERROR - 2024-09-01 11:42:19 --> Could not find the language line "Acquisition Channel"
ERROR - 2024-09-01 11:42:19 --> Could not find the language line "Select Acquisition Channel"
ERROR - 2024-09-01 11:42:19 --> Could not find the language line "Select Acquisition Channel"
ERROR - 2024-09-01 11:42:19 --> Could not find the language line "Verification Methods"
ERROR - 2024-09-01 11:42:19 --> Could not find the language line "Verified via WhatsApp"
ERROR - 2024-09-01 11:42:19 --> Could not find the language line "Verified via SMS"
ERROR - 2024-09-01 11:42:19 --> Could not find the language line "Verified by Staff"
ERROR - 2024-09-01 11:42:19 --> Could not find the language line "Email"
ERROR - 2024-09-01 11:42:19 --> Could not find the language line "Phone"
ERROR - 2024-09-01 11:42:19 --> Could not find the language line "Save"
ERROR - 2024-09-01 11:42:19 --> Could not find the language line "Cancel"
ERROR - 2024-09-01 11:42:19 --> client
ERROR - 2024-09-01 11:42:19 --> 12
ERROR - 2024-09-01 11:42:19 --> client
ERROR - 2024-09-01 11:42:22 --> Could not find the language line "Add New Prospect Alert"
ERROR - 2024-09-01 11:42:22 --> Could not find the language line "Name"
ERROR - 2024-09-01 11:42:22 --> Could not find the language line "Prospect Category"
ERROR - 2024-09-01 11:42:22 --> Could not find the language line "Select Prospect Category"
ERROR - 2024-09-01 11:42:22 --> Could not find the language line "Select Prospect Category"
ERROR - 2024-09-01 11:42:22 --> Could not find the language line "Prospect Industry"
ERROR - 2024-09-01 11:42:22 --> Could not find the language line "Select Prospect Industry"
ERROR - 2024-09-01 11:42:22 --> Could not find the language line "Select Prospect Industry"
ERROR - 2024-09-01 11:42:22 --> Could not find the language line "Acquisition Channel"
ERROR - 2024-09-01 11:42:22 --> Could not find the language line "Select Acquisition Channel"
ERROR - 2024-09-01 11:42:22 --> Could not find the language line "Select Acquisition Channel"
ERROR - 2024-09-01 11:42:22 --> Could not find the language line "Verification Methods"
ERROR - 2024-09-01 11:42:22 --> Could not find the language line "Verified via WhatsApp"
ERROR - 2024-09-01 11:42:22 --> Could not find the language line "Verified via SMS"
ERROR - 2024-09-01 11:42:22 --> Could not find the language line "Verified by Staff"
ERROR - 2024-09-01 11:42:22 --> Could not find the language line "Email"
ERROR - 2024-09-01 11:42:22 --> Could not find the language line "Phone"
ERROR - 2024-09-01 11:42:22 --> Could not find the language line "Save"
ERROR - 2024-09-01 11:42:22 --> Could not find the language line "Cancel"
ERROR - 2024-09-01 11:42:22 --> client
ERROR - 2024-09-01 11:42:22 --> 12
ERROR - 2024-09-01 11:42:22 --> client
ERROR - 2024-09-01 11:42:26 --> Could not find the language line "Search Prospect Alerts"
ERROR - 2024-09-01 11:42:26 --> Could not find the language line "Filter By"
ERROR - 2024-09-01 11:42:26 --> Could not find the language line "All"
ERROR - 2024-09-01 11:42:26 --> Could not find the language line "Active"
ERROR - 2024-09-01 11:42:26 --> Could not find the language line "Inactive"
ERROR - 2024-09-01 11:42:26 --> Could not find the language line "New Prospect Alert"
ERROR - 2024-09-01 11:42:26 --> Severity: 8192 --> htmlspecialchars(): Passing null to parameter #1 ($string) of type string is deprecated C:\laragon\www\perfex_crm\application\views\themes\perfex\views\clients\prospect_alerts\prospect_alerts.php 174
ERROR - 2024-09-01 11:42:26 --> Severity: 8192 --> htmlspecialchars(): Passing null to parameter #1 ($string) of type string is deprecated C:\laragon\www\perfex_crm\application\views\themes\perfex\views\clients\prospect_alerts\prospect_alerts.php 178
ERROR - 2024-09-01 11:42:26 --> client
ERROR - 2024-09-01 11:42:26 --> 12
ERROR - 2024-09-01 11:42:26 --> client
ERROR - 2024-09-01 11:42:27 --> Could not find the language line "Create Prospect"
ERROR - 2024-09-01 11:42:27 --> Could not find the language line "First Name"
ERROR - 2024-09-01 11:42:27 --> Could not find the language line "Last Name"
ERROR - 2024-09-01 11:42:27 --> Could not find the language line "Phone"
ERROR - 2024-09-01 11:42:27 --> Could not find the language line "Email"
ERROR - 2024-09-01 11:42:27 --> Could not find the language line "Status"
ERROR - 2024-09-01 11:42:27 --> Could not find the language line "Type"
ERROR - 2024-09-01 11:42:27 --> Could not find the language line "Category"
ERROR - 2024-09-01 11:42:27 --> Could not find the language line "Acquisition Channel"
ERROR - 2024-09-01 11:42:27 --> Could not find the language line "Industry"
ERROR - 2024-09-01 11:42:27 --> Could not find the language line "Desired Amount"
ERROR - 2024-09-01 11:42:27 --> Could not find the language line "Minimum Amount"
ERROR - 2024-09-01 11:42:27 --> Could not find the language line "Save Prospect"
ERROR - 2024-09-01 11:42:27 --> client
ERROR - 2024-09-01 11:42:27 --> 12
ERROR - 2024-09-01 11:42:27 --> client
ERROR - 2024-09-01 11:42:28 --> Could not find the language line "New Prospect"
ERROR - 2024-09-01 11:42:28 --> Could not find the language line "Search Prospects"
ERROR - 2024-09-01 11:42:28 --> Could not find the language line "Filter By"
ERROR - 2024-09-01 11:42:28 --> Could not find the language line "Active Prospects"
ERROR - 2024-09-01 11:42:28 --> Could not find the language line "Inactive Prospects"
ERROR - 2024-09-01 11:42:28 --> Could not find the language line "No prospects found."
ERROR - 2024-09-01 11:42:28 --> client
ERROR - 2024-09-01 11:42:28 --> 12
ERROR - 2024-09-01 11:42:28 --> client
ERROR - 2024-09-01 11:42:30 --> client
ERROR - 2024-09-01 11:42:30 --> 12
ERROR - 2024-09-01 11:42:30 --> client
ERROR - 2024-09-01 11:42:33 --> Could not find the language line "New Prospect"
ERROR - 2024-09-01 11:42:33 --> Could not find the language line "Search Prospects"
ERROR - 2024-09-01 11:42:33 --> Could not find the language line "Filter By"
ERROR - 2024-09-01 11:42:33 --> Could not find the language line "Active Prospects"
ERROR - 2024-09-01 11:42:33 --> Could not find the language line "Inactive Prospects"
ERROR - 2024-09-01 11:42:33 --> Could not find the language line "No prospects found."
ERROR - 2024-09-01 11:42:33 --> client
ERROR - 2024-09-01 11:42:33 --> 12
ERROR - 2024-09-01 11:42:33 --> client
ERROR - 2024-09-01 11:42:34 --> Could not find the language line "Onboarding"
ERROR - 2024-09-01 11:42:34 --> Could not find the language line "Onboarding"
ERROR - 2024-09-01 11:42:34 --> Could not find the language line "Invite Friend"
ERROR - 2024-09-01 11:42:34 --> Could not find the language line "Join our private Facebook group"
ERROR - 2024-09-01 11:42:34 --> Could not find the language line "group dedicated specifically for ambassadors. In the group, you'll get access to other successful ambassadors, learn the latest marketing strategies, get help from our support team, and stay informed on all the latest product updates."
ERROR - 2024-09-01 11:42:34 --> Could not find the language line "Sign Up for Alerts"
ERROR - 2024-09-01 11:42:34 --> Could not find the language line "Sign up for our email alerts to stay informed about the latest updates, opportunities, and important information."
ERROR - 2024-09-01 11:42:34 --> Could not find the language line "Complete and Continue"
ERROR - 2024-09-01 11:42:34 --> Could not find the language line "Continue"
ERROR - 2024-09-01 11:42:34 --> Could not find the language line "Onboarding Progress"
ERROR - 2024-09-01 11:42:34 --> Could not find the language line "Watch welcome message"
ERROR - 2024-09-01 11:42:34 --> Could not find the language line "Join Facebook group"
ERROR - 2024-09-01 11:42:34 --> Could not find the language line "Sign up for email alerts"
ERROR - 2024-09-01 11:42:34 --> Could not find the language line "Watch portal walkthrough"
ERROR - 2024-09-01 11:42:34 --> Could not find the language line "Understand the opportunity"
ERROR - 2024-09-01 11:42:34 --> Could not find the language line "Review available products"
ERROR - 2024-09-01 11:42:34 --> Could not find the language line "Who do you want to invite?"
ERROR - 2024-09-01 11:42:34 --> Could not find the language line "Send Invitation"
ERROR - 2024-09-01 11:42:34 --> Could not find the language line "Sign Up for Alerts"
ERROR - 2024-09-01 11:42:34 --> Could not find the language line "<i class="fa fa-exclamation-circle tw-mr-1"></i> We'll never send marketing emails through these alerts. These email alerts are strictly to inform you about Ambassador Program latest updates."
ERROR - 2024-09-01 11:42:34 --> Could not find the language line "Sign Up and Continue"
ERROR - 2024-09-01 11:42:34 --> Could not find the language line "Invitation sent!"
ERROR - 2024-09-01 11:42:34 --> Could not find the language line "Invitation failed!"
ERROR - 2024-09-01 11:42:34 --> client
ERROR - 2024-09-01 11:42:34 --> 12
ERROR - 2024-09-01 11:42:34 --> client
ERROR - 2024-09-01 11:42:36 --> Could not find the language line "New Prospect"
ERROR - 2024-09-01 11:42:36 --> Could not find the language line "Search Prospects"
ERROR - 2024-09-01 11:42:36 --> Could not find the language line "Filter By"
ERROR - 2024-09-01 11:42:36 --> Could not find the language line "Active Prospects"
ERROR - 2024-09-01 11:42:36 --> Could not find the language line "Inactive Prospects"
ERROR - 2024-09-01 11:42:36 --> Could not find the language line "No prospects found."
ERROR - 2024-09-01 11:42:36 --> client
ERROR - 2024-09-01 11:42:36 --> 12
ERROR - 2024-09-01 11:42:36 --> client
ERROR - 2024-09-01 11:43:15 --> Could not find the language line "Create Prospect"
ERROR - 2024-09-01 11:43:15 --> Could not find the language line "First Name"
ERROR - 2024-09-01 11:43:15 --> Could not find the language line "Last Name"
ERROR - 2024-09-01 11:43:15 --> Could not find the language line "Phone"
ERROR - 2024-09-01 11:43:15 --> Could not find the language line "Email"
ERROR - 2024-09-01 11:43:15 --> Could not find the language line "Status"
ERROR - 2024-09-01 11:43:15 --> Could not find the language line "Type"
ERROR - 2024-09-01 11:43:15 --> Could not find the language line "Category"
ERROR - 2024-09-01 11:43:15 --> Could not find the language line "Acquisition Channel"
ERROR - 2024-09-01 11:43:15 --> Could not find the language line "Industry"
ERROR - 2024-09-01 11:43:15 --> Could not find the language line "Desired Amount"
ERROR - 2024-09-01 11:43:15 --> Could not find the language line "Minimum Amount"
ERROR - 2024-09-01 11:43:15 --> Could not find the language line "Save Prospect"
ERROR - 2024-09-01 11:43:15 --> client
ERROR - 2024-09-01 11:43:15 --> 12
ERROR - 2024-09-01 11:43:15 --> client
ERROR - 2024-09-01 11:45:41 --> Could not find the language line "New Prospect"
ERROR - 2024-09-01 11:45:41 --> Could not find the language line "Search Prospects"
ERROR - 2024-09-01 11:45:41 --> Could not find the language line "Filter By"
ERROR - 2024-09-01 11:45:41 --> Could not find the language line "Active Prospects"
ERROR - 2024-09-01 11:45:41 --> Could not find the language line "Inactive Prospects"
ERROR - 2024-09-01 11:45:41 --> Could not find the language line "No prospects found."
ERROR - 2024-09-01 11:45:41 --> client
ERROR - 2024-09-01 11:45:41 --> 12
ERROR - 2024-09-01 11:45:41 --> client
ERROR - 2024-09-01 11:45:46 --> Could not find the language line "Create Prospect"
ERROR - 2024-09-01 11:45:46 --> Could not find the language line "First Name"
ERROR - 2024-09-01 11:45:46 --> Could not find the language line "Last Name"
ERROR - 2024-09-01 11:45:46 --> Could not find the language line "Phone"
ERROR - 2024-09-01 11:45:46 --> Could not find the language line "Email"
ERROR - 2024-09-01 11:45:46 --> Could not find the language line "Status"
ERROR - 2024-09-01 11:45:46 --> Could not find the language line "Type"
ERROR - 2024-09-01 11:45:46 --> Could not find the language line "Category"
ERROR - 2024-09-01 11:45:46 --> Could not find the language line "Acquisition Channel"
ERROR - 2024-09-01 11:45:46 --> Could not find the language line "Industry"
ERROR - 2024-09-01 11:45:46 --> Could not find the language line "Desired Amount"
ERROR - 2024-09-01 11:45:46 --> Could not find the language line "Minimum Amount"
ERROR - 2024-09-01 11:45:46 --> Could not find the language line "Save Prospect"
ERROR - 2024-09-01 11:45:46 --> client
ERROR - 2024-09-01 11:45:46 --> 12
ERROR - 2024-09-01 11:45:46 --> client
ERROR - 2024-09-01 11:48:12 --> Could not find the language line "Create Prospect"
ERROR - 2024-09-01 11:48:12 --> Could not find the language line "First Name"
ERROR - 2024-09-01 11:48:12 --> Could not find the language line "Last Name"
ERROR - 2024-09-01 11:48:12 --> Could not find the language line "Phone"
ERROR - 2024-09-01 11:48:12 --> Could not find the language line "Email"
ERROR - 2024-09-01 11:48:12 --> Could not find the language line "Status"
ERROR - 2024-09-01 11:48:12 --> Could not find the language line "Type"
ERROR - 2024-09-01 11:48:12 --> Could not find the language line "Category"
ERROR - 2024-09-01 11:48:12 --> Could not find the language line "Acquisition Channel"
ERROR - 2024-09-01 11:48:12 --> Could not find the language line "Industry"
ERROR - 2024-09-01 11:48:12 --> Could not find the language line "Desired Amount"
ERROR - 2024-09-01 11:48:12 --> Could not find the language line "Minimum Amount"
ERROR - 2024-09-01 11:48:12 --> Could not find the language line "Save Prospect"
ERROR - 2024-09-01 11:48:12 --> client
ERROR - 2024-09-01 11:48:12 --> 12
ERROR - 2024-09-01 11:48:12 --> client
ERROR - 2024-09-01 11:48:22 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 11:48:22 --> Could not find the language line "billings"
ERROR - 2024-09-01 11:48:23 --> Could not find the language line "New Prospect Type"
ERROR - 2024-09-01 11:48:23 --> Could not find the language line "Name"
ERROR - 2024-09-01 11:48:23 --> Could not find the language line "Description"
ERROR - 2024-09-01 11:48:23 --> Could not find the language line "Status"
ERROR - 2024-09-01 11:48:23 --> Could not find the language line "Actions"
ERROR - 2024-09-01 11:48:23 --> admin
ERROR - 2024-09-01 11:48:23 --> 12
ERROR - 2024-09-01 11:48:23 --> admin
ERROR - 2024-09-01 06:48:23 --> 404 Page Not Found: /index
ERROR - 2024-09-01 11:48:28 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 11:48:28 --> Could not find the language line "billings"
ERROR - 2024-09-01 11:48:28 --> Could not find the language line "Name"
ERROR - 2024-09-01 11:48:28 --> Could not find the language line "Description"
ERROR - 2024-09-01 11:48:28 --> Could not find the language line "Status"
ERROR - 2024-09-01 11:48:28 --> Could not find the language line "Save"
ERROR - 2024-09-01 11:48:28 --> admin
ERROR - 2024-09-01 11:48:28 --> 12
ERROR - 2024-09-01 11:48:28 --> admin
ERROR - 2024-09-01 06:48:29 --> 404 Page Not Found: /index
ERROR - 2024-09-01 11:48:31 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 11:48:31 --> Could not find the language line "billings"
ERROR - 2024-09-01 11:48:32 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 11:48:32 --> Could not find the language line "billings"
ERROR - 2024-09-01 11:48:32 --> Could not find the language line "New Prospect Type"
ERROR - 2024-09-01 11:48:32 --> Could not find the language line "Name"
ERROR - 2024-09-01 11:48:32 --> Could not find the language line "Description"
ERROR - 2024-09-01 11:48:32 --> Could not find the language line "Status"
ERROR - 2024-09-01 11:48:32 --> Could not find the language line "Actions"
ERROR - 2024-09-01 11:48:32 --> admin
ERROR - 2024-09-01 11:48:32 --> 12
ERROR - 2024-09-01 11:48:32 --> admin
ERROR - 2024-09-01 06:48:33 --> 404 Page Not Found: /index
ERROR - 2024-09-01 11:49:57 --> Could not find the language line "Create Prospect"
ERROR - 2024-09-01 11:49:57 --> Could not find the language line "First Name"
ERROR - 2024-09-01 11:49:57 --> Could not find the language line "Last Name"
ERROR - 2024-09-01 11:49:57 --> Could not find the language line "Phone"
ERROR - 2024-09-01 11:49:57 --> Could not find the language line "Email"
ERROR - 2024-09-01 11:49:57 --> Could not find the language line "Status"
ERROR - 2024-09-01 11:49:57 --> Could not find the language line "Type"
ERROR - 2024-09-01 11:49:57 --> Could not find the language line "Category"
ERROR - 2024-09-01 11:49:57 --> Could not find the language line "Acquisition Channel"
ERROR - 2024-09-01 11:49:57 --> Could not find the language line "Industry"
ERROR - 2024-09-01 11:49:57 --> Could not find the language line "Desired Amount"
ERROR - 2024-09-01 11:49:57 --> Could not find the language line "Minimum Amount"
ERROR - 2024-09-01 11:49:57 --> Could not find the language line "Save Prospect"
ERROR - 2024-09-01 11:49:57 --> client
ERROR - 2024-09-01 11:49:57 --> 12
ERROR - 2024-09-01 11:49:57 --> client
ERROR - 2024-09-01 11:53:18 --> Could not find the language line "Create Prospect"
ERROR - 2024-09-01 11:53:18 --> Could not find the language line "First Name"
ERROR - 2024-09-01 11:53:18 --> Could not find the language line "Last Name"
ERROR - 2024-09-01 11:53:18 --> Could not find the language line "Phone"
ERROR - 2024-09-01 11:53:18 --> Could not find the language line "Email"
ERROR - 2024-09-01 11:53:18 --> Could not find the language line "Status"
ERROR - 2024-09-01 11:53:18 --> Could not find the language line "Type"
ERROR - 2024-09-01 11:53:18 --> Could not find the language line "Category"
ERROR - 2024-09-01 11:53:18 --> Could not find the language line "Acquisition Channel"
ERROR - 2024-09-01 11:53:18 --> Could not find the language line "Industry"
ERROR - 2024-09-01 11:53:18 --> Could not find the language line "Desired Amount"
ERROR - 2024-09-01 11:53:18 --> Could not find the language line "Minimum Amount"
ERROR - 2024-09-01 11:53:18 --> Could not find the language line "Save Prospect"
ERROR - 2024-09-01 11:53:18 --> client
ERROR - 2024-09-01 11:53:18 --> 12
ERROR - 2024-09-01 11:53:18 --> client
ERROR - 2024-09-01 11:54:02 --> Could not find the language line "Create Prospect"
ERROR - 2024-09-01 11:54:02 --> Could not find the language line "First Name"
ERROR - 2024-09-01 11:54:02 --> Could not find the language line "Last Name"
ERROR - 2024-09-01 11:54:02 --> Could not find the language line "Phone"
ERROR - 2024-09-01 11:54:02 --> Could not find the language line "Email"
ERROR - 2024-09-01 11:54:02 --> Could not find the language line "Status"
ERROR - 2024-09-01 11:54:02 --> Could not find the language line "Type"
ERROR - 2024-09-01 11:54:02 --> Could not find the language line "Category"
ERROR - 2024-09-01 11:54:02 --> Could not find the language line "Acquisition Channel"
ERROR - 2024-09-01 11:54:02 --> Could not find the language line "Industry"
ERROR - 2024-09-01 11:54:02 --> Could not find the language line "Desired Amount"
ERROR - 2024-09-01 11:54:02 --> Could not find the language line "Minimum Amount"
ERROR - 2024-09-01 11:54:02 --> Could not find the language line "Save Prospect"
ERROR - 2024-09-01 11:54:02 --> client
ERROR - 2024-09-01 11:54:02 --> 12
ERROR - 2024-09-01 11:54:02 --> client
ERROR - 2024-09-01 11:54:16 --> Could not find the language line "Create Prospect"
ERROR - 2024-09-01 11:54:16 --> Could not find the language line "First Name"
ERROR - 2024-09-01 11:54:16 --> Could not find the language line "Last Name"
ERROR - 2024-09-01 11:54:16 --> Could not find the language line "Phone"
ERROR - 2024-09-01 11:54:16 --> Could not find the language line "Email"
ERROR - 2024-09-01 11:54:16 --> Could not find the language line "Status"
ERROR - 2024-09-01 11:54:16 --> Could not find the language line "Type"
ERROR - 2024-09-01 11:54:16 --> Could not find the language line "Category"
ERROR - 2024-09-01 11:54:16 --> Could not find the language line "Acquisition Channel"
ERROR - 2024-09-01 11:54:16 --> Could not find the language line "Industry"
ERROR - 2024-09-01 11:54:16 --> Could not find the language line "Desired Amount"
ERROR - 2024-09-01 11:54:16 --> Could not find the language line "Minimum Amount"
ERROR - 2024-09-01 11:54:16 --> Could not find the language line "Save Prospect"
ERROR - 2024-09-01 11:54:16 --> client
ERROR - 2024-09-01 11:54:16 --> 12
ERROR - 2024-09-01 11:54:16 --> client
ERROR - 2024-09-01 11:54:53 --> Could not find the language line "Create Prospect"
ERROR - 2024-09-01 11:54:53 --> Could not find the language line "First Name"
ERROR - 2024-09-01 11:54:53 --> Could not find the language line "Last Name"
ERROR - 2024-09-01 11:54:53 --> Could not find the language line "Phone"
ERROR - 2024-09-01 11:54:53 --> Could not find the language line "Email"
ERROR - 2024-09-01 11:54:53 --> Could not find the language line "Status"
ERROR - 2024-09-01 11:54:53 --> Could not find the language line "Type"
ERROR - 2024-09-01 11:54:53 --> Could not find the language line "Category"
ERROR - 2024-09-01 11:54:53 --> Could not find the language line "Acquisition Channel"
ERROR - 2024-09-01 11:54:53 --> Could not find the language line "Industry"
ERROR - 2024-09-01 11:54:53 --> Could not find the language line "Desired Amount"
ERROR - 2024-09-01 11:54:53 --> Could not find the language line "Minimum Amount"
ERROR - 2024-09-01 11:54:53 --> Could not find the language line "Save Prospect"
ERROR - 2024-09-01 11:54:53 --> client
ERROR - 2024-09-01 11:54:53 --> 12
ERROR - 2024-09-01 11:54:53 --> client
ERROR - 2024-09-01 11:54:57 --> Could not find the language line "Create Prospect"
ERROR - 2024-09-01 11:54:57 --> Could not find the language line "First Name"
ERROR - 2024-09-01 11:54:57 --> Could not find the language line "Last Name"
ERROR - 2024-09-01 11:54:57 --> Could not find the language line "Phone"
ERROR - 2024-09-01 11:54:57 --> Could not find the language line "Email"
ERROR - 2024-09-01 11:54:57 --> Could not find the language line "Status"
ERROR - 2024-09-01 11:54:57 --> Could not find the language line "Type"
ERROR - 2024-09-01 11:54:57 --> Could not find the language line "Category"
ERROR - 2024-09-01 11:54:57 --> Could not find the language line "Acquisition Channel"
ERROR - 2024-09-01 11:54:57 --> Could not find the language line "Industry"
ERROR - 2024-09-01 11:54:57 --> Could not find the language line "Desired Amount"
ERROR - 2024-09-01 11:54:57 --> Could not find the language line "Minimum Amount"
ERROR - 2024-09-01 11:54:57 --> Could not find the language line "Save Prospect"
ERROR - 2024-09-01 11:54:57 --> client
ERROR - 2024-09-01 11:54:57 --> 12
ERROR - 2024-09-01 11:54:57 --> client
ERROR - 2024-09-01 12:01:38 --> Severity: Warning --> Undefined property: Prospects::$view C:\laragon\www\perfex_crm\application\core\ClientsController.php 98
ERROR - 2024-09-01 12:01:46 --> Could not find the language line "Create Prospect"
ERROR - 2024-09-01 12:01:46 --> Could not find the language line "First Name"
ERROR - 2024-09-01 12:01:46 --> Could not find the language line "Last Name"
ERROR - 2024-09-01 12:01:46 --> Could not find the language line "Phone"
ERROR - 2024-09-01 12:01:46 --> Could not find the language line "Email"
ERROR - 2024-09-01 12:01:46 --> Could not find the language line "Status"
ERROR - 2024-09-01 12:01:46 --> Could not find the language line "Type"
ERROR - 2024-09-01 12:01:46 --> Could not find the language line "Category"
ERROR - 2024-09-01 12:01:46 --> Could not find the language line "Acquisition Channel"
ERROR - 2024-09-01 12:01:46 --> Could not find the language line "Industry"
ERROR - 2024-09-01 12:01:46 --> Could not find the language line "Desired Amount"
ERROR - 2024-09-01 12:01:46 --> Could not find the language line "Minimum Amount"
ERROR - 2024-09-01 12:01:46 --> Could not find the language line "Save Prospect"
ERROR - 2024-09-01 12:01:46 --> client
ERROR - 2024-09-01 12:01:46 --> 12
ERROR - 2024-09-01 12:01:46 --> client
ERROR - 2024-09-01 12:04:33 --> Could not find the language line "Create Prospect"
ERROR - 2024-09-01 12:04:33 --> Could not find the language line "First Name"
ERROR - 2024-09-01 12:04:33 --> Could not find the language line "Last Name"
ERROR - 2024-09-01 12:04:33 --> Could not find the language line "Phone"
ERROR - 2024-09-01 12:04:33 --> Could not find the language line "Email"
ERROR - 2024-09-01 12:04:33 --> Could not find the language line "Status"
ERROR - 2024-09-01 12:04:33 --> Could not find the language line "Type"
ERROR - 2024-09-01 12:04:33 --> Could not find the language line "Category"
ERROR - 2024-09-01 12:04:33 --> Could not find the language line "Acquisition Channel"
ERROR - 2024-09-01 12:04:33 --> Could not find the language line "Industry"
ERROR - 2024-09-01 12:04:33 --> Could not find the language line "Desired Amount"
ERROR - 2024-09-01 12:04:33 --> Could not find the language line "Minimum Amount"
ERROR - 2024-09-01 12:04:33 --> Could not find the language line "Save Prospect"
ERROR - 2024-09-01 12:04:33 --> client
ERROR - 2024-09-01 12:04:33 --> 12
ERROR - 2024-09-01 12:04:33 --> client
ERROR - 2024-09-01 12:05:04 --> Could not find the language line "Create Prospect"
ERROR - 2024-09-01 12:05:04 --> Could not find the language line "First Name"
ERROR - 2024-09-01 12:05:04 --> Could not find the language line "Last Name"
ERROR - 2024-09-01 12:05:04 --> Could not find the language line "Phone"
ERROR - 2024-09-01 12:05:04 --> Could not find the language line "Email"
ERROR - 2024-09-01 12:05:04 --> Could not find the language line "Status"
ERROR - 2024-09-01 12:05:04 --> Could not find the language line "Type"
ERROR - 2024-09-01 12:05:04 --> Could not find the language line "Category"
ERROR - 2024-09-01 12:05:04 --> Could not find the language line "Acquisition Channel"
ERROR - 2024-09-01 12:05:04 --> Could not find the language line "Industry"
ERROR - 2024-09-01 12:05:04 --> Could not find the language line "Desired Amount"
ERROR - 2024-09-01 12:05:04 --> Could not find the language line "Minimum Amount"
ERROR - 2024-09-01 12:05:04 --> Could not find the language line "Save Prospect"
ERROR - 2024-09-01 12:05:04 --> client
ERROR - 2024-09-01 12:05:04 --> 12
ERROR - 2024-09-01 12:05:04 --> client
ERROR - 2024-09-01 12:05:34 --> Could not find the language line "Create Prospect"
ERROR - 2024-09-01 12:05:34 --> Could not find the language line "First Name"
ERROR - 2024-09-01 12:05:34 --> Could not find the language line "Last Name"
ERROR - 2024-09-01 12:05:34 --> Could not find the language line "Phone"
ERROR - 2024-09-01 12:05:34 --> Could not find the language line "Email"
ERROR - 2024-09-01 12:05:34 --> Could not find the language line "Status"
ERROR - 2024-09-01 12:05:34 --> Could not find the language line "Type"
ERROR - 2024-09-01 12:05:34 --> Could not find the language line "Category"
ERROR - 2024-09-01 12:05:34 --> Could not find the language line "Acquisition Channel"
ERROR - 2024-09-01 12:05:34 --> Could not find the language line "Industry"
ERROR - 2024-09-01 12:05:34 --> Could not find the language line "Desired Amount"
ERROR - 2024-09-01 12:05:34 --> Could not find the language line "Minimum Amount"
ERROR - 2024-09-01 12:05:34 --> Could not find the language line "Save Prospect"
ERROR - 2024-09-01 12:05:34 --> client
ERROR - 2024-09-01 12:05:34 --> 12
ERROR - 2024-09-01 12:05:34 --> client
ERROR - 2024-09-01 12:08:22 --> Could not find the language line "Create Prospect"
ERROR - 2024-09-01 12:08:22 --> Could not find the language line "First Name"
ERROR - 2024-09-01 12:08:22 --> Could not find the language line "Last Name"
ERROR - 2024-09-01 12:08:22 --> Could not find the language line "Phone"
ERROR - 2024-09-01 12:08:22 --> Could not find the language line "Email"
ERROR - 2024-09-01 12:08:22 --> Could not find the language line "Status"
ERROR - 2024-09-01 12:08:22 --> Could not find the language line "Type"
ERROR - 2024-09-01 12:08:22 --> Could not find the language line "Category"
ERROR - 2024-09-01 12:08:22 --> Could not find the language line "Acquisition Channel"
ERROR - 2024-09-01 12:08:22 --> Could not find the language line "Industry"
ERROR - 2024-09-01 12:08:22 --> Could not find the language line "Desired Amount"
ERROR - 2024-09-01 12:08:22 --> Could not find the language line "Minimum Amount"
ERROR - 2024-09-01 12:08:22 --> Could not find the language line "Save Prospect"
ERROR - 2024-09-01 12:08:22 --> client
ERROR - 2024-09-01 12:08:22 --> 12
ERROR - 2024-09-01 12:08:22 --> client
ERROR - 2024-09-01 12:10:30 --> Could not find the language line "Create Prospect"
ERROR - 2024-09-01 12:10:30 --> Could not find the language line "First Name"
ERROR - 2024-09-01 12:10:30 --> Could not find the language line "Last Name"
ERROR - 2024-09-01 12:10:30 --> Could not find the language line "Phone"
ERROR - 2024-09-01 12:10:30 --> Could not find the language line "Email"
ERROR - 2024-09-01 12:10:30 --> Could not find the language line "Status"
ERROR - 2024-09-01 12:10:30 --> Could not find the language line "Type"
ERROR - 2024-09-01 12:10:30 --> Could not find the language line "Category"
ERROR - 2024-09-01 12:10:30 --> Could not find the language line "Acquisition Channel"
ERROR - 2024-09-01 12:10:30 --> Could not find the language line "Industry"
ERROR - 2024-09-01 12:10:30 --> Could not find the language line "Desired Amount"
ERROR - 2024-09-01 12:10:30 --> Could not find the language line "Minimum Amount"
ERROR - 2024-09-01 12:10:30 --> Could not find the language line "Save Prospect"
ERROR - 2024-09-01 12:10:30 --> client
ERROR - 2024-09-01 12:10:30 --> 12
ERROR - 2024-09-01 12:10:30 --> client
ERROR - 2024-09-01 12:10:35 --> Could not find the language line "Create Prospect"
ERROR - 2024-09-01 12:10:35 --> Could not find the language line "First Name"
ERROR - 2024-09-01 12:10:35 --> Could not find the language line "Last Name"
ERROR - 2024-09-01 12:10:35 --> Could not find the language line "Phone"
ERROR - 2024-09-01 12:10:35 --> Could not find the language line "Email"
ERROR - 2024-09-01 12:10:35 --> Could not find the language line "Status"
ERROR - 2024-09-01 12:10:35 --> Could not find the language line "Type"
ERROR - 2024-09-01 12:10:35 --> Could not find the language line "Category"
ERROR - 2024-09-01 12:10:35 --> Could not find the language line "Acquisition Channel"
ERROR - 2024-09-01 12:10:35 --> Could not find the language line "Industry"
ERROR - 2024-09-01 12:10:35 --> Could not find the language line "Desired Amount"
ERROR - 2024-09-01 12:10:35 --> Could not find the language line "Minimum Amount"
ERROR - 2024-09-01 12:10:35 --> Could not find the language line "Save Prospect"
ERROR - 2024-09-01 12:10:35 --> client
ERROR - 2024-09-01 12:10:35 --> 12
ERROR - 2024-09-01 12:10:35 --> client
ERROR - 2024-09-01 12:11:12 --> Could not find the language line "Create Prospect"
ERROR - 2024-09-01 12:11:12 --> Could not find the language line "First Name"
ERROR - 2024-09-01 12:11:12 --> Could not find the language line "Last Name"
ERROR - 2024-09-01 12:11:12 --> Could not find the language line "Phone"
ERROR - 2024-09-01 12:11:12 --> Could not find the language line "Email"
ERROR - 2024-09-01 12:11:12 --> Could not find the language line "Status"
ERROR - 2024-09-01 12:11:12 --> Could not find the language line "Type"
ERROR - 2024-09-01 12:11:12 --> Could not find the language line "Category"
ERROR - 2024-09-01 12:11:12 --> Could not find the language line "Acquisition Channel"
ERROR - 2024-09-01 12:11:12 --> Could not find the language line "Industry"
ERROR - 2024-09-01 12:11:12 --> Could not find the language line "Desired Amount"
ERROR - 2024-09-01 12:11:12 --> Could not find the language line "Minimum Amount"
ERROR - 2024-09-01 12:11:12 --> Could not find the language line "Save Prospect"
ERROR - 2024-09-01 12:11:12 --> client
ERROR - 2024-09-01 12:11:12 --> 12
ERROR - 2024-09-01 12:11:12 --> client
ERROR - 2024-09-01 12:11:15 --> Could not find the language line "New Prospect"
ERROR - 2024-09-01 12:11:15 --> Could not find the language line "Search Prospects"
ERROR - 2024-09-01 12:11:15 --> Could not find the language line "Filter By"
ERROR - 2024-09-01 12:11:15 --> Could not find the language line "Active Prospects"
ERROR - 2024-09-01 12:11:15 --> Could not find the language line "Inactive Prospects"
ERROR - 2024-09-01 12:11:15 --> Could not find the language line "No prospects found."
ERROR - 2024-09-01 12:11:15 --> client
ERROR - 2024-09-01 12:11:15 --> 12
ERROR - 2024-09-01 12:11:15 --> client
ERROR - 2024-09-01 12:11:16 --> Could not find the language line "Create Prospect"
ERROR - 2024-09-01 12:11:16 --> Could not find the language line "First Name"
ERROR - 2024-09-01 12:11:16 --> Could not find the language line "Last Name"
ERROR - 2024-09-01 12:11:16 --> Could not find the language line "Phone"
ERROR - 2024-09-01 12:11:16 --> Could not find the language line "Email"
ERROR - 2024-09-01 12:11:16 --> Could not find the language line "Status"
ERROR - 2024-09-01 12:11:16 --> Could not find the language line "Type"
ERROR - 2024-09-01 12:11:16 --> Could not find the language line "Category"
ERROR - 2024-09-01 12:11:16 --> Could not find the language line "Acquisition Channel"
ERROR - 2024-09-01 12:11:16 --> Could not find the language line "Industry"
ERROR - 2024-09-01 12:11:16 --> Could not find the language line "Desired Amount"
ERROR - 2024-09-01 12:11:16 --> Could not find the language line "Minimum Amount"
ERROR - 2024-09-01 12:11:16 --> Could not find the language line "Save Prospect"
ERROR - 2024-09-01 12:11:16 --> client
ERROR - 2024-09-01 12:11:16 --> 12
ERROR - 2024-09-01 12:11:16 --> client
ERROR - 2024-09-01 12:11:26 --> Could not find the language line "Create Prospect"
ERROR - 2024-09-01 12:11:26 --> Could not find the language line "First Name"
ERROR - 2024-09-01 12:11:26 --> Could not find the language line "Last Name"
ERROR - 2024-09-01 12:11:26 --> Could not find the language line "Phone"
ERROR - 2024-09-01 12:11:26 --> Could not find the language line "Email"
ERROR - 2024-09-01 12:11:26 --> Could not find the language line "Status"
ERROR - 2024-09-01 12:11:26 --> Could not find the language line "Type"
ERROR - 2024-09-01 12:11:26 --> Could not find the language line "Category"
ERROR - 2024-09-01 12:11:26 --> Could not find the language line "Acquisition Channel"
ERROR - 2024-09-01 12:11:26 --> Could not find the language line "Industry"
ERROR - 2024-09-01 12:11:26 --> Could not find the language line "Desired Amount"
ERROR - 2024-09-01 12:11:26 --> Could not find the language line "Minimum Amount"
ERROR - 2024-09-01 12:11:26 --> Could not find the language line "Save Prospect"
ERROR - 2024-09-01 12:11:26 --> client
ERROR - 2024-09-01 12:11:26 --> 12
ERROR - 2024-09-01 12:11:26 --> client
ERROR - 2024-09-01 12:11:56 --> Could not find the language line "Create Prospect"
ERROR - 2024-09-01 12:11:56 --> Could not find the language line "First Name"
ERROR - 2024-09-01 12:11:56 --> Could not find the language line "Last Name"
ERROR - 2024-09-01 12:11:56 --> Could not find the language line "Phone"
ERROR - 2024-09-01 12:11:56 --> Could not find the language line "Email"
ERROR - 2024-09-01 12:11:56 --> Could not find the language line "Status"
ERROR - 2024-09-01 12:11:56 --> Could not find the language line "Type"
ERROR - 2024-09-01 12:11:56 --> Could not find the language line "Category"
ERROR - 2024-09-01 12:11:56 --> Could not find the language line "Acquisition Channel"
ERROR - 2024-09-01 12:11:56 --> Could not find the language line "Industry"
ERROR - 2024-09-01 12:11:56 --> Could not find the language line "Desired Amount"
ERROR - 2024-09-01 12:11:56 --> Could not find the language line "Minimum Amount"
ERROR - 2024-09-01 12:11:56 --> Could not find the language line "Save Prospect"
ERROR - 2024-09-01 12:11:56 --> client
ERROR - 2024-09-01 12:11:56 --> 12
ERROR - 2024-09-01 12:11:56 --> client
ERROR - 2024-09-01 12:12:15 --> Could not find the language line "Create Prospect"
ERROR - 2024-09-01 12:12:15 --> Could not find the language line "First Name"
ERROR - 2024-09-01 12:12:15 --> Could not find the language line "Last Name"
ERROR - 2024-09-01 12:12:15 --> Could not find the language line "Phone"
ERROR - 2024-09-01 12:12:15 --> Could not find the language line "Email"
ERROR - 2024-09-01 12:12:15 --> Could not find the language line "Status"
ERROR - 2024-09-01 12:12:15 --> Could not find the language line "Type"
ERROR - 2024-09-01 12:12:15 --> Could not find the language line "Category"
ERROR - 2024-09-01 12:12:15 --> Could not find the language line "Acquisition Channel"
ERROR - 2024-09-01 12:12:15 --> Could not find the language line "Industry"
ERROR - 2024-09-01 12:12:15 --> Could not find the language line "Desired Amount"
ERROR - 2024-09-01 12:12:15 --> Could not find the language line "Minimum Amount"
ERROR - 2024-09-01 12:12:15 --> Could not find the language line "Save Prospect"
ERROR - 2024-09-01 12:12:15 --> client
ERROR - 2024-09-01 12:12:15 --> 12
ERROR - 2024-09-01 12:12:15 --> client
ERROR - 2024-09-01 12:13:49 --> Could not find the language line "Create Prospect"
ERROR - 2024-09-01 12:13:49 --> Could not find the language line "First Name"
ERROR - 2024-09-01 12:13:49 --> Could not find the language line "Last Name"
ERROR - 2024-09-01 12:13:49 --> Could not find the language line "Phone"
ERROR - 2024-09-01 12:13:49 --> Could not find the language line "Email"
ERROR - 2024-09-01 12:13:49 --> Could not find the language line "Status"
ERROR - 2024-09-01 12:13:49 --> Could not find the language line "Type"
ERROR - 2024-09-01 12:13:49 --> Could not find the language line "Category"
ERROR - 2024-09-01 12:13:49 --> Could not find the language line "Acquisition Channel"
ERROR - 2024-09-01 12:13:49 --> Could not find the language line "Industry"
ERROR - 2024-09-01 12:13:49 --> Could not find the language line "Desired Amount"
ERROR - 2024-09-01 12:13:49 --> Could not find the language line "Minimum Amount"
ERROR - 2024-09-01 12:13:49 --> Could not find the language line "Save Prospect"
ERROR - 2024-09-01 12:13:49 --> client
ERROR - 2024-09-01 12:13:49 --> 12
ERROR - 2024-09-01 12:13:49 --> client
ERROR - 2024-09-01 12:13:56 --> Could not find the language line "Create Prospect"
ERROR - 2024-09-01 12:13:56 --> Could not find the language line "First Name"
ERROR - 2024-09-01 12:13:56 --> Could not find the language line "Last Name"
ERROR - 2024-09-01 12:13:56 --> Could not find the language line "Phone"
ERROR - 2024-09-01 12:13:56 --> Could not find the language line "Email"
ERROR - 2024-09-01 12:13:56 --> Could not find the language line "Status"
ERROR - 2024-09-01 12:13:56 --> Could not find the language line "Type"
ERROR - 2024-09-01 12:13:56 --> Could not find the language line "Category"
ERROR - 2024-09-01 12:13:56 --> Could not find the language line "Acquisition Channel"
ERROR - 2024-09-01 12:13:56 --> Could not find the language line "Industry"
ERROR - 2024-09-01 12:13:56 --> Could not find the language line "Desired Amount"
ERROR - 2024-09-01 12:13:56 --> Could not find the language line "Minimum Amount"
ERROR - 2024-09-01 12:13:56 --> Could not find the language line "Save Prospect"
ERROR - 2024-09-01 12:13:56 --> client
ERROR - 2024-09-01 12:13:56 --> 12
ERROR - 2024-09-01 12:13:56 --> client
ERROR - 2024-09-01 12:14:43 --> Could not find the language line "Create Prospect"
ERROR - 2024-09-01 12:14:43 --> Could not find the language line "First Name"
ERROR - 2024-09-01 12:14:43 --> Could not find the language line "Last Name"
ERROR - 2024-09-01 12:14:43 --> Could not find the language line "Phone"
ERROR - 2024-09-01 12:14:43 --> Could not find the language line "Email"
ERROR - 2024-09-01 12:14:43 --> Could not find the language line "Status"
ERROR - 2024-09-01 12:14:43 --> Could not find the language line "Type"
ERROR - 2024-09-01 12:14:43 --> Could not find the language line "Category"
ERROR - 2024-09-01 12:14:43 --> Could not find the language line "Acquisition Channel"
ERROR - 2024-09-01 12:14:43 --> Could not find the language line "Industry"
ERROR - 2024-09-01 12:14:43 --> Could not find the language line "Desired Amount"
ERROR - 2024-09-01 12:14:43 --> Could not find the language line "Minimum Amount"
ERROR - 2024-09-01 12:14:43 --> Could not find the language line "Save Prospect"
ERROR - 2024-09-01 12:14:43 --> client
ERROR - 2024-09-01 12:14:43 --> 12
ERROR - 2024-09-01 12:14:43 --> client
ERROR - 2024-09-01 12:14:57 --> Could not find the language line "Create Prospect"
ERROR - 2024-09-01 12:14:57 --> Could not find the language line "First Name"
ERROR - 2024-09-01 12:14:57 --> Could not find the language line "Last Name"
ERROR - 2024-09-01 12:14:57 --> Could not find the language line "Phone"
ERROR - 2024-09-01 12:14:57 --> Could not find the language line "Email"
ERROR - 2024-09-01 12:14:57 --> Could not find the language line "Status"
ERROR - 2024-09-01 12:14:57 --> Could not find the language line "Type"
ERROR - 2024-09-01 12:14:57 --> Could not find the language line "Category"
ERROR - 2024-09-01 12:14:57 --> Could not find the language line "Acquisition Channel"
ERROR - 2024-09-01 12:14:57 --> Could not find the language line "Industry"
ERROR - 2024-09-01 12:14:57 --> Could not find the language line "Desired Amount"
ERROR - 2024-09-01 12:14:57 --> Could not find the language line "Minimum Amount"
ERROR - 2024-09-01 12:14:57 --> Could not find the language line "Save Prospect"
ERROR - 2024-09-01 12:14:57 --> client
ERROR - 2024-09-01 12:14:57 --> 12
ERROR - 2024-09-01 12:14:57 --> client
ERROR - 2024-09-01 12:18:56 --> Could not find the language line "New Prospect"
ERROR - 2024-09-01 12:18:56 --> Could not find the language line "Search Prospects"
ERROR - 2024-09-01 12:18:56 --> Could not find the language line "Filter By"
ERROR - 2024-09-01 12:18:56 --> Could not find the language line "Active Prospects"
ERROR - 2024-09-01 12:18:56 --> Could not find the language line "Inactive Prospects"
ERROR - 2024-09-01 12:18:56 --> Could not find the language line "No prospects found."
ERROR - 2024-09-01 12:18:56 --> client
ERROR - 2024-09-01 12:18:56 --> 12
ERROR - 2024-09-01 12:18:56 --> client
ERROR - 2024-09-01 12:19:18 --> Could not find the language line "Create Prospect"
ERROR - 2024-09-01 12:19:18 --> Could not find the language line "First Name"
ERROR - 2024-09-01 12:19:18 --> Could not find the language line "Last Name"
ERROR - 2024-09-01 12:19:18 --> Could not find the language line "Phone"
ERROR - 2024-09-01 12:19:18 --> Could not find the language line "Email"
ERROR - 2024-09-01 12:19:18 --> Could not find the language line "Status"
ERROR - 2024-09-01 12:19:18 --> Could not find the language line "Type"
ERROR - 2024-09-01 12:19:18 --> Could not find the language line "Category"
ERROR - 2024-09-01 12:19:18 --> Could not find the language line "Acquisition Channel"
ERROR - 2024-09-01 12:19:18 --> Could not find the language line "Industry"
ERROR - 2024-09-01 12:19:18 --> Could not find the language line "Desired Amount"
ERROR - 2024-09-01 12:19:18 --> Could not find the language line "Minimum Amount"
ERROR - 2024-09-01 12:19:18 --> Could not find the language line "Save Prospect"
ERROR - 2024-09-01 12:19:18 --> client
ERROR - 2024-09-01 12:19:18 --> 12
ERROR - 2024-09-01 12:19:18 --> client
ERROR - 2024-09-01 12:19:28 --> Could not find the language line "New Prospect"
ERROR - 2024-09-01 12:19:28 --> Could not find the language line "Search Prospects"
ERROR - 2024-09-01 12:19:28 --> Could not find the language line "Filter By"
ERROR - 2024-09-01 12:19:28 --> Could not find the language line "Active Prospects"
ERROR - 2024-09-01 12:19:28 --> Could not find the language line "Inactive Prospects"
ERROR - 2024-09-01 12:19:28 --> Could not find the language line "Name"
ERROR - 2024-09-01 12:19:28 --> Could not find the language line "Status"
ERROR - 2024-09-01 12:19:28 --> Could not find the language line "Type"
ERROR - 2024-09-01 12:19:28 --> Could not find the language line "Category"
ERROR - 2024-09-01 12:19:28 --> Could not find the language line "Acquisition Channels"
ERROR - 2024-09-01 12:19:28 --> Could not find the language line "Desired Amount"
ERROR - 2024-09-01 12:19:28 --> Could not find the language line "Industry"
ERROR - 2024-09-01 12:19:28 --> client
ERROR - 2024-09-01 12:19:28 --> 12
ERROR - 2024-09-01 12:19:28 --> client
ERROR - 2024-09-01 12:19:42 --> Could not find the language line "Edit Prospect"
ERROR - 2024-09-01 12:19:42 --> Could not find the language line "First Name"
ERROR - 2024-09-01 12:19:42 --> Could not find the language line "Last Name"
ERROR - 2024-09-01 12:19:42 --> Could not find the language line "Phone"
ERROR - 2024-09-01 12:19:42 --> Could not find the language line "Email"
ERROR - 2024-09-01 12:19:42 --> Could not find the language line "Status"
ERROR - 2024-09-01 12:19:42 --> Could not find the language line "Type"
ERROR - 2024-09-01 12:19:42 --> Could not find the language line "Category"
ERROR - 2024-09-01 12:19:42 --> Could not find the language line "Acquisition Channel"
ERROR - 2024-09-01 12:19:42 --> Could not find the language line "Industry"
ERROR - 2024-09-01 12:19:42 --> Could not find the language line "Desired Amount"
ERROR - 2024-09-01 12:19:42 --> Could not find the language line "Minimum Amount"
ERROR - 2024-09-01 12:19:42 --> Could not find the language line "Update Prospect"
ERROR - 2024-09-01 12:19:42 --> client
ERROR - 2024-09-01 12:19:42 --> 12
ERROR - 2024-09-01 12:19:42 --> client
ERROR - 2024-09-01 12:20:57 --> Could not find the language line "Edit Prospect"
ERROR - 2024-09-01 12:20:57 --> Could not find the language line "First Name"
ERROR - 2024-09-01 12:20:57 --> Could not find the language line "Last Name"
ERROR - 2024-09-01 12:20:57 --> Could not find the language line "Phone"
ERROR - 2024-09-01 12:20:57 --> Could not find the language line "Email"
ERROR - 2024-09-01 12:20:57 --> Could not find the language line "Status"
ERROR - 2024-09-01 12:20:57 --> Could not find the language line "Type"
ERROR - 2024-09-01 12:20:57 --> Could not find the language line "Category"
ERROR - 2024-09-01 12:20:57 --> Could not find the language line "Acquisition Channel"
ERROR - 2024-09-01 12:20:57 --> Could not find the language line "Industry"
ERROR - 2024-09-01 12:20:57 --> Could not find the language line "Desired Amount"
ERROR - 2024-09-01 12:20:57 --> Could not find the language line "Minimum Amount"
ERROR - 2024-09-01 12:20:57 --> Could not find the language line "Update Prospect"
ERROR - 2024-09-01 12:20:57 --> client
ERROR - 2024-09-01 12:20:57 --> 12
ERROR - 2024-09-01 12:20:57 --> client
ERROR - 2024-09-01 12:21:01 --> Could not find the language line "New Prospect"
ERROR - 2024-09-01 12:21:01 --> Could not find the language line "Search Prospects"
ERROR - 2024-09-01 12:21:01 --> Could not find the language line "Filter By"
ERROR - 2024-09-01 12:21:01 --> Could not find the language line "Active Prospects"
ERROR - 2024-09-01 12:21:01 --> Could not find the language line "Inactive Prospects"
ERROR - 2024-09-01 12:21:01 --> Could not find the language line "Name"
ERROR - 2024-09-01 12:21:01 --> Could not find the language line "Status"
ERROR - 2024-09-01 12:21:01 --> Could not find the language line "Type"
ERROR - 2024-09-01 12:21:01 --> Could not find the language line "Category"
ERROR - 2024-09-01 12:21:01 --> Could not find the language line "Acquisition Channels"
ERROR - 2024-09-01 12:21:01 --> Could not find the language line "Desired Amount"
ERROR - 2024-09-01 12:21:01 --> Could not find the language line "Industry"
ERROR - 2024-09-01 12:21:01 --> client
ERROR - 2024-09-01 12:21:01 --> 12
ERROR - 2024-09-01 12:21:01 --> client
ERROR - 2024-09-01 12:21:14 --> Could not find the language line "Search Prospect Alerts"
ERROR - 2024-09-01 12:21:14 --> Could not find the language line "Filter By"
ERROR - 2024-09-01 12:21:14 --> Could not find the language line "All"
ERROR - 2024-09-01 12:21:14 --> Could not find the language line "Active"
ERROR - 2024-09-01 12:21:14 --> Could not find the language line "Inactive"
ERROR - 2024-09-01 12:21:14 --> Could not find the language line "New Prospect Alert"
ERROR - 2024-09-01 12:21:14 --> Severity: 8192 --> htmlspecialchars(): Passing null to parameter #1 ($string) of type string is deprecated C:\laragon\www\perfex_crm\application\views\themes\perfex\views\clients\prospect_alerts\prospect_alerts.php 174
ERROR - 2024-09-01 12:21:14 --> Severity: 8192 --> htmlspecialchars(): Passing null to parameter #1 ($string) of type string is deprecated C:\laragon\www\perfex_crm\application\views\themes\perfex\views\clients\prospect_alerts\prospect_alerts.php 178
ERROR - 2024-09-01 12:21:14 --> client
ERROR - 2024-09-01 12:21:14 --> 12
ERROR - 2024-09-01 12:21:14 --> client
ERROR - 2024-09-01 12:21:19 --> Could not find the language line "Add New Prospect Alert"
ERROR - 2024-09-01 12:21:19 --> Could not find the language line "Name"
ERROR - 2024-09-01 12:21:19 --> Could not find the language line "Prospect Category"
ERROR - 2024-09-01 12:21:19 --> Could not find the language line "Select Prospect Category"
ERROR - 2024-09-01 12:21:19 --> Could not find the language line "Select Prospect Category"
ERROR - 2024-09-01 12:21:19 --> Could not find the language line "Prospect Industry"
ERROR - 2024-09-01 12:21:19 --> Could not find the language line "Select Prospect Industry"
ERROR - 2024-09-01 12:21:19 --> Could not find the language line "Select Prospect Industry"
ERROR - 2024-09-01 12:21:19 --> Could not find the language line "Acquisition Channel"
ERROR - 2024-09-01 12:21:19 --> Could not find the language line "Select Acquisition Channel"
ERROR - 2024-09-01 12:21:19 --> Could not find the language line "Select Acquisition Channel"
ERROR - 2024-09-01 12:21:19 --> Could not find the language line "Verification Methods"
ERROR - 2024-09-01 12:21:19 --> Could not find the language line "Verified via WhatsApp"
ERROR - 2024-09-01 12:21:19 --> Could not find the language line "Verified via SMS"
ERROR - 2024-09-01 12:21:19 --> Could not find the language line "Verified by Staff"
ERROR - 2024-09-01 12:21:19 --> Could not find the language line "Email"
ERROR - 2024-09-01 12:21:19 --> Could not find the language line "Phone"
ERROR - 2024-09-01 12:21:19 --> Could not find the language line "Save"
ERROR - 2024-09-01 12:21:19 --> Could not find the language line "Cancel"
ERROR - 2024-09-01 12:21:19 --> client
ERROR - 2024-09-01 12:21:19 --> 12
ERROR - 2024-09-01 12:21:19 --> client
ERROR - 2024-09-01 12:21:22 --> Could not find the language line "Search Prospect Alerts"
ERROR - 2024-09-01 12:21:22 --> Could not find the language line "Filter By"
ERROR - 2024-09-01 12:21:22 --> Could not find the language line "All"
ERROR - 2024-09-01 12:21:22 --> Could not find the language line "Active"
ERROR - 2024-09-01 12:21:22 --> Could not find the language line "Inactive"
ERROR - 2024-09-01 12:21:22 --> Could not find the language line "New Prospect Alert"
ERROR - 2024-09-01 12:21:22 --> Severity: 8192 --> htmlspecialchars(): Passing null to parameter #1 ($string) of type string is deprecated C:\laragon\www\perfex_crm\application\views\themes\perfex\views\clients\prospect_alerts\prospect_alerts.php 174
ERROR - 2024-09-01 12:21:22 --> Severity: 8192 --> htmlspecialchars(): Passing null to parameter #1 ($string) of type string is deprecated C:\laragon\www\perfex_crm\application\views\themes\perfex\views\clients\prospect_alerts\prospect_alerts.php 178
ERROR - 2024-09-01 12:21:22 --> client
ERROR - 2024-09-01 12:21:22 --> 12
ERROR - 2024-09-01 12:21:22 --> client
ERROR - 2024-09-01 12:22:33 --> Could not find the language line "New Prospect"
ERROR - 2024-09-01 12:22:33 --> Could not find the language line "Search Prospects"
ERROR - 2024-09-01 12:22:33 --> Could not find the language line "Filter By"
ERROR - 2024-09-01 12:22:33 --> Could not find the language line "Active Prospects"
ERROR - 2024-09-01 12:22:33 --> Could not find the language line "Inactive Prospects"
ERROR - 2024-09-01 12:22:33 --> Could not find the language line "Name"
ERROR - 2024-09-01 12:22:33 --> Could not find the language line "Status"
ERROR - 2024-09-01 12:22:33 --> Could not find the language line "Type"
ERROR - 2024-09-01 12:22:33 --> Could not find the language line "Category"
ERROR - 2024-09-01 12:22:33 --> Could not find the language line "Acquisition Channels"
ERROR - 2024-09-01 12:22:33 --> Could not find the language line "Desired Amount"
ERROR - 2024-09-01 12:22:33 --> Could not find the language line "Industry"
ERROR - 2024-09-01 12:22:33 --> client
ERROR - 2024-09-01 12:22:33 --> 12
ERROR - 2024-09-01 12:22:33 --> client
ERROR - 2024-09-01 12:25:44 --> Could not find the language line "Edit Prospect"
ERROR - 2024-09-01 12:25:44 --> Could not find the language line "First Name"
ERROR - 2024-09-01 12:25:44 --> Could not find the language line "Last Name"
ERROR - 2024-09-01 12:25:44 --> Could not find the language line "Phone"
ERROR - 2024-09-01 12:25:44 --> Could not find the language line "Email"
ERROR - 2024-09-01 12:25:44 --> Could not find the language line "Status"
ERROR - 2024-09-01 12:25:44 --> Could not find the language line "Type"
ERROR - 2024-09-01 12:25:44 --> Could not find the language line "Category"
ERROR - 2024-09-01 12:25:44 --> Could not find the language line "Acquisition Channel"
ERROR - 2024-09-01 12:25:44 --> Could not find the language line "Industry"
ERROR - 2024-09-01 12:25:44 --> Could not find the language line "Desired Amount"
ERROR - 2024-09-01 12:25:44 --> Could not find the language line "Minimum Amount"
ERROR - 2024-09-01 12:25:44 --> Could not find the language line "Update Prospect"
ERROR - 2024-09-01 12:25:44 --> client
ERROR - 2024-09-01 12:25:44 --> 12
ERROR - 2024-09-01 12:25:44 --> client
ERROR - 2024-09-01 12:25:50 --> Could not find the language line "Edit Prospect"
ERROR - 2024-09-01 12:25:50 --> Could not find the language line "First Name"
ERROR - 2024-09-01 12:25:50 --> Could not find the language line "Last Name"
ERROR - 2024-09-01 12:25:50 --> Could not find the language line "Phone"
ERROR - 2024-09-01 12:25:50 --> Could not find the language line "Email"
ERROR - 2024-09-01 12:25:50 --> Could not find the language line "Status"
ERROR - 2024-09-01 12:25:50 --> Could not find the language line "Type"
ERROR - 2024-09-01 12:25:50 --> Could not find the language line "Category"
ERROR - 2024-09-01 12:25:50 --> Could not find the language line "Acquisition Channel"
ERROR - 2024-09-01 12:25:50 --> Could not find the language line "Industry"
ERROR - 2024-09-01 12:25:50 --> Could not find the language line "Desired Amount"
ERROR - 2024-09-01 12:25:50 --> Could not find the language line "Minimum Amount"
ERROR - 2024-09-01 12:25:50 --> Could not find the language line "Update Prospect"
ERROR - 2024-09-01 12:25:50 --> client
ERROR - 2024-09-01 12:25:50 --> 12
ERROR - 2024-09-01 12:25:50 --> client
ERROR - 2024-09-01 12:25:56 --> Could not find the language line "New Prospect"
ERROR - 2024-09-01 12:25:56 --> Could not find the language line "Search Prospects"
ERROR - 2024-09-01 12:25:56 --> Could not find the language line "Filter By"
ERROR - 2024-09-01 12:25:56 --> Could not find the language line "Active Prospects"
ERROR - 2024-09-01 12:25:56 --> Could not find the language line "Inactive Prospects"
ERROR - 2024-09-01 12:25:56 --> Could not find the language line "Name"
ERROR - 2024-09-01 12:25:56 --> Could not find the language line "Status"
ERROR - 2024-09-01 12:25:56 --> Could not find the language line "Type"
ERROR - 2024-09-01 12:25:56 --> Could not find the language line "Category"
ERROR - 2024-09-01 12:25:56 --> Could not find the language line "Acquisition Channels"
ERROR - 2024-09-01 12:25:56 --> Could not find the language line "Desired Amount"
ERROR - 2024-09-01 12:25:56 --> Could not find the language line "Industry"
ERROR - 2024-09-01 12:25:56 --> client
ERROR - 2024-09-01 12:25:56 --> 12
ERROR - 2024-09-01 12:25:56 --> client
ERROR - 2024-09-01 12:26:23 --> Could not find the language line "Search Prospect Alerts"
ERROR - 2024-09-01 12:26:23 --> Could not find the language line "Filter By"
ERROR - 2024-09-01 12:26:23 --> Could not find the language line "All"
ERROR - 2024-09-01 12:26:23 --> Could not find the language line "Active"
ERROR - 2024-09-01 12:26:23 --> Could not find the language line "Inactive"
ERROR - 2024-09-01 12:26:23 --> Could not find the language line "New Prospect Alert"
ERROR - 2024-09-01 12:26:23 --> Severity: 8192 --> htmlspecialchars(): Passing null to parameter #1 ($string) of type string is deprecated C:\laragon\www\perfex_crm\application\views\themes\perfex\views\clients\prospect_alerts\prospect_alerts.php 174
ERROR - 2024-09-01 12:26:23 --> Severity: 8192 --> htmlspecialchars(): Passing null to parameter #1 ($string) of type string is deprecated C:\laragon\www\perfex_crm\application\views\themes\perfex\views\clients\prospect_alerts\prospect_alerts.php 178
ERROR - 2024-09-01 12:26:23 --> client
ERROR - 2024-09-01 12:26:23 --> 12
ERROR - 2024-09-01 12:26:23 --> client
ERROR - 2024-09-01 12:27:36 --> Could not find the language line "Search Prospect Alerts"
ERROR - 2024-09-01 12:27:36 --> Could not find the language line "Filter By"
ERROR - 2024-09-01 12:27:36 --> Could not find the language line "All"
ERROR - 2024-09-01 12:27:36 --> Could not find the language line "Active"
ERROR - 2024-09-01 12:27:36 --> Could not find the language line "Inactive"
ERROR - 2024-09-01 12:27:36 --> Could not find the language line "New Prospect Alert"
ERROR - 2024-09-01 12:27:36 --> Severity: 8192 --> htmlspecialchars(): Passing null to parameter #1 ($string) of type string is deprecated C:\laragon\www\perfex_crm\application\views\themes\perfex\views\clients\prospect_alerts\prospect_alerts.php 174
ERROR - 2024-09-01 12:27:36 --> Severity: 8192 --> htmlspecialchars(): Passing null to parameter #1 ($string) of type string is deprecated C:\laragon\www\perfex_crm\application\views\themes\perfex\views\clients\prospect_alerts\prospect_alerts.php 178
ERROR - 2024-09-01 12:27:36 --> client
ERROR - 2024-09-01 12:27:36 --> 12
ERROR - 2024-09-01 12:27:36 --> client
ERROR - 2024-09-01 12:28:27 --> Could not find the language line "Add New Prospect Alert"
ERROR - 2024-09-01 12:28:27 --> Could not find the language line "Name"
ERROR - 2024-09-01 12:28:27 --> Could not find the language line "Prospect Category"
ERROR - 2024-09-01 12:28:27 --> Could not find the language line "Select Prospect Category"
ERROR - 2024-09-01 12:28:27 --> Could not find the language line "Select Prospect Category"
ERROR - 2024-09-01 12:28:27 --> Could not find the language line "Prospect Industry"
ERROR - 2024-09-01 12:28:27 --> Could not find the language line "Select Prospect Industry"
ERROR - 2024-09-01 12:28:27 --> Could not find the language line "Select Prospect Industry"
ERROR - 2024-09-01 12:28:27 --> Could not find the language line "Acquisition Channel"
ERROR - 2024-09-01 12:28:27 --> Could not find the language line "Select Acquisition Channel"
ERROR - 2024-09-01 12:28:27 --> Could not find the language line "Select Acquisition Channel"
ERROR - 2024-09-01 12:28:27 --> Could not find the language line "Verification Methods"
ERROR - 2024-09-01 12:28:27 --> Could not find the language line "Verified via WhatsApp"
ERROR - 2024-09-01 12:28:27 --> Could not find the language line "Verified via SMS"
ERROR - 2024-09-01 12:28:27 --> Could not find the language line "Verified by Staff"
ERROR - 2024-09-01 12:28:27 --> Could not find the language line "Email"
ERROR - 2024-09-01 12:28:27 --> Could not find the language line "Phone"
ERROR - 2024-09-01 12:28:27 --> Could not find the language line "Save"
ERROR - 2024-09-01 12:28:27 --> Could not find the language line "Cancel"
ERROR - 2024-09-01 12:28:27 --> client
ERROR - 2024-09-01 12:28:27 --> 12
ERROR - 2024-09-01 12:28:27 --> client
ERROR - 2024-09-01 12:28:34 --> Could not find the language line "Search Prospect Alerts"
ERROR - 2024-09-01 12:28:34 --> Could not find the language line "Filter By"
ERROR - 2024-09-01 12:28:34 --> Could not find the language line "All"
ERROR - 2024-09-01 12:28:34 --> Could not find the language line "Active"
ERROR - 2024-09-01 12:28:34 --> Could not find the language line "Inactive"
ERROR - 2024-09-01 12:28:34 --> Could not find the language line "New Prospect Alert"
ERROR - 2024-09-01 12:28:34 --> Severity: 8192 --> htmlspecialchars(): Passing null to parameter #1 ($string) of type string is deprecated C:\laragon\www\perfex_crm\application\views\themes\perfex\views\clients\prospect_alerts\prospect_alerts.php 174
ERROR - 2024-09-01 12:28:34 --> Severity: 8192 --> htmlspecialchars(): Passing null to parameter #1 ($string) of type string is deprecated C:\laragon\www\perfex_crm\application\views\themes\perfex\views\clients\prospect_alerts\prospect_alerts.php 178
ERROR - 2024-09-01 12:28:34 --> client
ERROR - 2024-09-01 12:28:34 --> 12
ERROR - 2024-09-01 12:28:34 --> client
ERROR - 2024-09-01 12:30:21 --> Could not find the language line "Search Prospect Alerts"
ERROR - 2024-09-01 12:30:21 --> Could not find the language line "Filter By"
ERROR - 2024-09-01 12:30:21 --> Could not find the language line "All"
ERROR - 2024-09-01 12:30:21 --> Could not find the language line "Active"
ERROR - 2024-09-01 12:30:21 --> Could not find the language line "Inactive"
ERROR - 2024-09-01 12:30:21 --> Could not find the language line "New Prospect Alert"
ERROR - 2024-09-01 12:30:21 --> Severity: 8192 --> htmlspecialchars(): Passing null to parameter #1 ($string) of type string is deprecated C:\laragon\www\perfex_crm\application\views\themes\perfex\views\clients\prospect_alerts\prospect_alerts.php 174
ERROR - 2024-09-01 12:30:21 --> Severity: 8192 --> htmlspecialchars(): Passing null to parameter #1 ($string) of type string is deprecated C:\laragon\www\perfex_crm\application\views\themes\perfex\views\clients\prospect_alerts\prospect_alerts.php 178
ERROR - 2024-09-01 12:30:21 --> client
ERROR - 2024-09-01 12:30:21 --> 12
ERROR - 2024-09-01 12:30:21 --> client
ERROR - 2024-09-01 12:30:24 --> Could not find the language line "Search Prospect Alerts"
ERROR - 2024-09-01 12:30:24 --> Could not find the language line "Filter By"
ERROR - 2024-09-01 12:30:24 --> Could not find the language line "All"
ERROR - 2024-09-01 12:30:24 --> Could not find the language line "Active"
ERROR - 2024-09-01 12:30:24 --> Could not find the language line "Inactive"
ERROR - 2024-09-01 12:30:24 --> Could not find the language line "New Prospect Alert"
ERROR - 2024-09-01 12:30:24 --> Severity: 8192 --> htmlspecialchars(): Passing null to parameter #1 ($string) of type string is deprecated C:\laragon\www\perfex_crm\application\views\themes\perfex\views\clients\prospect_alerts\prospect_alerts.php 174
ERROR - 2024-09-01 12:30:24 --> Severity: 8192 --> htmlspecialchars(): Passing null to parameter #1 ($string) of type string is deprecated C:\laragon\www\perfex_crm\application\views\themes\perfex\views\clients\prospect_alerts\prospect_alerts.php 178
ERROR - 2024-09-01 12:30:24 --> client
ERROR - 2024-09-01 12:30:24 --> 12
ERROR - 2024-09-01 12:30:24 --> client
ERROR - 2024-09-01 12:30:33 --> Could not find the language line "Search Prospect Alerts"
ERROR - 2024-09-01 12:30:33 --> Could not find the language line "Filter By"
ERROR - 2024-09-01 12:30:33 --> Could not find the language line "All"
ERROR - 2024-09-01 12:30:33 --> Could not find the language line "Active"
ERROR - 2024-09-01 12:30:33 --> Could not find the language line "Inactive"
ERROR - 2024-09-01 12:30:33 --> Could not find the language line "New Prospect Alert"
ERROR - 2024-09-01 12:30:33 --> Severity: 8192 --> htmlspecialchars(): Passing null to parameter #1 ($string) of type string is deprecated C:\laragon\www\perfex_crm\application\views\themes\perfex\views\clients\prospect_alerts\prospect_alerts.php 174
ERROR - 2024-09-01 12:30:33 --> Severity: 8192 --> htmlspecialchars(): Passing null to parameter #1 ($string) of type string is deprecated C:\laragon\www\perfex_crm\application\views\themes\perfex\views\clients\prospect_alerts\prospect_alerts.php 178
ERROR - 2024-09-01 12:30:33 --> client
ERROR - 2024-09-01 12:30:33 --> 12
ERROR - 2024-09-01 12:30:33 --> client
ERROR - 2024-09-01 12:31:17 --> Could not find the language line "Search Prospect Alerts"
ERROR - 2024-09-01 12:31:17 --> Could not find the language line "Filter By"
ERROR - 2024-09-01 12:31:17 --> Could not find the language line "All"
ERROR - 2024-09-01 12:31:17 --> Could not find the language line "Active"
ERROR - 2024-09-01 12:31:17 --> Could not find the language line "Inactive"
ERROR - 2024-09-01 12:31:17 --> Could not find the language line "New Prospect Alert"
ERROR - 2024-09-01 12:31:17 --> Severity: 8192 --> htmlspecialchars(): Passing null to parameter #1 ($string) of type string is deprecated C:\laragon\www\perfex_crm\application\views\themes\perfex\views\clients\prospect_alerts\prospect_alerts.php 174
ERROR - 2024-09-01 12:31:17 --> Severity: 8192 --> htmlspecialchars(): Passing null to parameter #1 ($string) of type string is deprecated C:\laragon\www\perfex_crm\application\views\themes\perfex\views\clients\prospect_alerts\prospect_alerts.php 178
ERROR - 2024-09-01 12:31:17 --> client
ERROR - 2024-09-01 12:31:17 --> 12
ERROR - 2024-09-01 12:31:17 --> client
ERROR - 2024-09-01 12:31:24 --> Could not find the language line "Search Prospect Alerts"
ERROR - 2024-09-01 12:31:24 --> Could not find the language line "Filter By"
ERROR - 2024-09-01 12:31:24 --> Could not find the language line "All"
ERROR - 2024-09-01 12:31:24 --> Could not find the language line "Active"
ERROR - 2024-09-01 12:31:24 --> Could not find the language line "Inactive"
ERROR - 2024-09-01 12:31:24 --> Could not find the language line "New Prospect Alert"
ERROR - 2024-09-01 12:31:24 --> Severity: 8192 --> htmlspecialchars(): Passing null to parameter #1 ($string) of type string is deprecated C:\laragon\www\perfex_crm\application\views\themes\perfex\views\clients\prospect_alerts\prospect_alerts.php 174
ERROR - 2024-09-01 12:31:24 --> Severity: 8192 --> htmlspecialchars(): Passing null to parameter #1 ($string) of type string is deprecated C:\laragon\www\perfex_crm\application\views\themes\perfex\views\clients\prospect_alerts\prospect_alerts.php 178
ERROR - 2024-09-01 12:31:24 --> client
ERROR - 2024-09-01 12:31:24 --> 12
ERROR - 2024-09-01 12:31:24 --> client
ERROR - 2024-09-01 12:31:30 --> Could not find the language line "Search Prospect Alerts"
ERROR - 2024-09-01 12:31:30 --> Could not find the language line "Filter By"
ERROR - 2024-09-01 12:31:30 --> Could not find the language line "All"
ERROR - 2024-09-01 12:31:30 --> Could not find the language line "Active"
ERROR - 2024-09-01 12:31:30 --> Could not find the language line "Inactive"
ERROR - 2024-09-01 12:31:30 --> Could not find the language line "New Prospect Alert"
ERROR - 2024-09-01 12:31:30 --> Severity: 8192 --> htmlspecialchars(): Passing null to parameter #1 ($string) of type string is deprecated C:\laragon\www\perfex_crm\application\views\themes\perfex\views\clients\prospect_alerts\prospect_alerts.php 174
ERROR - 2024-09-01 12:31:30 --> Severity: 8192 --> htmlspecialchars(): Passing null to parameter #1 ($string) of type string is deprecated C:\laragon\www\perfex_crm\application\views\themes\perfex\views\clients\prospect_alerts\prospect_alerts.php 178
ERROR - 2024-09-01 12:31:30 --> client
ERROR - 2024-09-01 12:31:30 --> 12
ERROR - 2024-09-01 12:31:30 --> client
ERROR - 2024-09-01 12:32:06 --> Could not find the language line "Search Prospect Alerts"
ERROR - 2024-09-01 12:32:06 --> Could not find the language line "Filter By"
ERROR - 2024-09-01 12:32:06 --> Could not find the language line "All"
ERROR - 2024-09-01 12:32:06 --> Could not find the language line "Active"
ERROR - 2024-09-01 12:32:06 --> Could not find the language line "Inactive"
ERROR - 2024-09-01 12:32:06 --> Could not find the language line "New Prospect Alert"
ERROR - 2024-09-01 12:32:06 --> Severity: 8192 --> htmlspecialchars(): Passing null to parameter #1 ($string) of type string is deprecated C:\laragon\www\perfex_crm\application\views\themes\perfex\views\clients\prospect_alerts\prospect_alerts.php 178
ERROR - 2024-09-01 12:32:06 --> client
ERROR - 2024-09-01 12:32:06 --> 12
ERROR - 2024-09-01 12:32:06 --> client
ERROR - 2024-09-01 12:33:13 --> Could not find the language line "Search Prospect Alerts"
ERROR - 2024-09-01 12:33:13 --> Could not find the language line "Filter By"
ERROR - 2024-09-01 12:33:13 --> Could not find the language line "All"
ERROR - 2024-09-01 12:33:13 --> Could not find the language line "Active"
ERROR - 2024-09-01 12:33:13 --> Could not find the language line "Inactive"
ERROR - 2024-09-01 12:33:13 --> Could not find the language line "New Prospect Alert"
ERROR - 2024-09-01 12:33:13 --> client
ERROR - 2024-09-01 12:33:13 --> 12
ERROR - 2024-09-01 12:33:13 --> client
ERROR - 2024-09-01 12:33:21 --> Could not find the language line "Edit Prospect Alert"
ERROR - 2024-09-01 12:33:21 --> Could not find the language line "Name"
ERROR - 2024-09-01 12:33:21 --> Could not find the language line "Prospect Category"
ERROR - 2024-09-01 12:33:21 --> Could not find the language line "Select Prospect Category"
ERROR - 2024-09-01 12:33:21 --> Could not find the language line "Select Prospect Category"
ERROR - 2024-09-01 12:33:21 --> Could not find the language line "Prospect Industry"
ERROR - 2024-09-01 12:33:21 --> Could not find the language line "Select Prospect Industry"
ERROR - 2024-09-01 12:33:21 --> Could not find the language line "Select Prospect Industry"
ERROR - 2024-09-01 12:33:21 --> Could not find the language line "Acquisition Channel"
ERROR - 2024-09-01 12:33:21 --> Could not find the language line "Select Acquisition Channel"
ERROR - 2024-09-01 12:33:21 --> Could not find the language line "Select Acquisition Channel"
ERROR - 2024-09-01 12:33:21 --> Could not find the language line "Email"
ERROR - 2024-09-01 12:33:21 --> Could not find the language line "Phone"
ERROR - 2024-09-01 12:33:21 --> Could not find the language line "Save"
ERROR - 2024-09-01 12:33:21 --> Could not find the language line "Cancel"
ERROR - 2024-09-01 12:33:21 --> client
ERROR - 2024-09-01 12:33:21 --> 12
ERROR - 2024-09-01 12:33:21 --> client
ERROR - 2024-09-01 12:33:30 --> Could not find the language line "Search Prospect Alerts"
ERROR - 2024-09-01 12:33:30 --> Could not find the language line "Filter By"
ERROR - 2024-09-01 12:33:30 --> Could not find the language line "All"
ERROR - 2024-09-01 12:33:30 --> Could not find the language line "Active"
ERROR - 2024-09-01 12:33:30 --> Could not find the language line "Inactive"
ERROR - 2024-09-01 12:33:30 --> Could not find the language line "New Prospect Alert"
ERROR - 2024-09-01 12:33:30 --> client
ERROR - 2024-09-01 12:33:30 --> 12
ERROR - 2024-09-01 12:33:30 --> client
ERROR - 2024-09-01 12:33:32 --> Could not find the language line "Add New Prospect Alert"
ERROR - 2024-09-01 12:33:32 --> Could not find the language line "Name"
ERROR - 2024-09-01 12:33:32 --> Could not find the language line "Prospect Category"
ERROR - 2024-09-01 12:33:32 --> Could not find the language line "Select Prospect Category"
ERROR - 2024-09-01 12:33:32 --> Could not find the language line "Select Prospect Category"
ERROR - 2024-09-01 12:33:32 --> Could not find the language line "Prospect Industry"
ERROR - 2024-09-01 12:33:32 --> Could not find the language line "Select Prospect Industry"
ERROR - 2024-09-01 12:33:32 --> Could not find the language line "Select Prospect Industry"
ERROR - 2024-09-01 12:33:32 --> Could not find the language line "Acquisition Channel"
ERROR - 2024-09-01 12:33:32 --> Could not find the language line "Select Acquisition Channel"
ERROR - 2024-09-01 12:33:32 --> Could not find the language line "Select Acquisition Channel"
ERROR - 2024-09-01 12:33:32 --> Could not find the language line "Verification Methods"
ERROR - 2024-09-01 12:33:32 --> Could not find the language line "Verified via WhatsApp"
ERROR - 2024-09-01 12:33:32 --> Could not find the language line "Verified via SMS"
ERROR - 2024-09-01 12:33:32 --> Could not find the language line "Verified by Staff"
ERROR - 2024-09-01 12:33:32 --> Could not find the language line "Email"
ERROR - 2024-09-01 12:33:32 --> Could not find the language line "Phone"
ERROR - 2024-09-01 12:33:32 --> Could not find the language line "Save"
ERROR - 2024-09-01 12:33:32 --> Could not find the language line "Cancel"
ERROR - 2024-09-01 12:33:32 --> client
ERROR - 2024-09-01 12:33:32 --> 12
ERROR - 2024-09-01 12:33:32 --> client
ERROR - 2024-09-01 12:33:35 --> Could not find the language line "Search Prospect Alerts"
ERROR - 2024-09-01 12:33:35 --> Could not find the language line "Filter By"
ERROR - 2024-09-01 12:33:35 --> Could not find the language line "All"
ERROR - 2024-09-01 12:33:35 --> Could not find the language line "Active"
ERROR - 2024-09-01 12:33:35 --> Could not find the language line "Inactive"
ERROR - 2024-09-01 12:33:35 --> Could not find the language line "New Prospect Alert"
ERROR - 2024-09-01 12:33:35 --> client
ERROR - 2024-09-01 12:33:35 --> 12
ERROR - 2024-09-01 12:33:35 --> client
ERROR - 2024-09-01 12:35:53 --> Could not find the language line "clients_list_value"
ERROR - 2024-09-01 12:35:53 --> Could not find the language line "clients_list_tags"
ERROR - 2024-09-01 12:35:53 --> Could not find the language line "clients_list_status"
ERROR - 2024-09-01 12:35:53 --> Could not find the language line "clients_list_source"
ERROR - 2024-09-01 12:35:53 --> Could not find the language line "Stars"
ERROR - 2024-09-01 12:35:53 --> Could not find the language line "Reasons"
ERROR - 2024-09-01 12:35:53 --> Could not find the language line "Select Reason"
ERROR - 2024-09-01 12:35:53 --> Could not find the language line "Select Reason"
ERROR - 2024-09-01 12:35:53 --> Could not find the language line "Details"
ERROR - 2024-09-01 12:35:53 --> Could not find the language line "Name"
ERROR - 2024-09-01 12:35:53 --> Could not find the language line "Status"
ERROR - 2024-09-01 12:35:53 --> Could not find the language line "Type"
ERROR - 2024-09-01 12:35:53 --> Could not find the language line "Category"
ERROR - 2024-09-01 12:35:53 --> Could not find the language line "Acquisition Channels"
ERROR - 2024-09-01 12:35:53 --> Could not find the language line "Desired Amount"
ERROR - 2024-09-01 12:35:53 --> Could not find the language line "Industry"
ERROR - 2024-09-01 12:35:53 --> Could not find the language line "Upload Evidence (MP3)"
ERROR - 2024-09-01 12:35:53 --> Could not find the language line "Target CRM"
ERROR - 2024-09-01 12:35:53 --> Could not find the language line "Target CRM"
ERROR - 2024-09-01 12:35:53 --> client
ERROR - 2024-09-01 12:35:53 --> 12
ERROR - 2024-09-01 12:35:53 --> client
ERROR - 2024-09-01 12:35:57 --> Could not find the language line "Search Reported Prospects"
ERROR - 2024-09-01 12:35:57 --> Could not find the language line "Filter By"
ERROR - 2024-09-01 12:35:57 --> Could not find the language line "Active Reported Prospects"
ERROR - 2024-09-01 12:35:57 --> Could not find the language line "Inactive Reported Prospects"
ERROR - 2024-09-01 12:35:57 --> Could not find the language line "No reported prospects found."
ERROR - 2024-09-01 12:35:57 --> client
ERROR - 2024-09-01 12:35:57 --> 12
ERROR - 2024-09-01 12:35:57 --> client
ERROR - 2024-09-01 12:36:04 --> Could not find the language line "New Campaign"
ERROR - 2024-09-01 12:36:04 --> Could not find the language line "no_campaigns_found"
ERROR - 2024-09-01 12:36:04 --> Could not find the language line "Industry"
ERROR - 2024-09-01 12:36:04 --> Could not find the language line "Select Industry"
ERROR - 2024-09-01 12:36:04 --> Could not find the language line "Select Industry"
ERROR - 2024-09-01 12:36:04 --> Could not find the language line "countries"
ERROR - 2024-09-01 12:36:04 --> Could not find the language line "Select Country"
ERROR - 2024-09-01 12:36:04 --> Could not find the language line "Select Country"
ERROR - 2024-09-01 12:36:04 --> client
ERROR - 2024-09-01 12:36:04 --> 12
ERROR - 2024-09-01 12:36:04 --> client
ERROR - 2024-09-01 12:36:32 --> Could not find the language line "Meet Industry's Most Advanced Real Estate Lead Marketplace"
ERROR - 2024-09-01 12:36:32 --> Could not find the language line "Buy Lead"
ERROR - 2024-09-01 12:36:32 --> Could not find the language line "Learn More"
ERROR - 2024-09-01 12:36:32 --> Could not find the language line "Zip Codes"
ERROR - 2024-09-01 12:36:32 --> Could not find the language line "Price Range start"
ERROR - 2024-09-01 12:36:32 --> Could not find the language line "Price Range end"
ERROR - 2024-09-01 12:36:32 --> Could not find the language line "From"
ERROR - 2024-09-01 12:36:32 --> Could not find the language line "To"
ERROR - 2024-09-01 12:36:32 --> Could not find the language line "deal"
ERROR - 2024-09-01 12:36:32 --> Could not find the language line "quality"
ERROR - 2024-09-01 12:36:32 --> Could not find the language line "Metadata"
ERROR - 2024-09-01 12:36:32 --> Could not find the language line "Lead"
ERROR - 2024-09-01 12:36:32 --> Could not find the language line "Contact"
ERROR - 2024-09-01 12:36:32 --> Could not find the language line "Lead Type"
ERROR - 2024-09-01 12:36:32 --> Could not find the language line "Actions"
ERROR - 2024-09-01 12:36:32 --> Could not find the language line "Prospect ID"
ERROR - 2024-09-01 12:36:32 --> Could not find the language line "Generated date"
ERROR - 2024-09-01 12:36:32 --> Could not find the language line "Industry"
ERROR - 2024-09-01 12:36:32 --> Could not find the language line "Zip code"
ERROR - 2024-09-01 12:36:32 --> Could not find the language line "Source"
ERROR - 2024-09-01 12:36:32 --> Could not find the language line "Deal"
ERROR - 2024-09-01 12:36:32 --> Could not find the language line "Quality"
ERROR - 2024-09-01 12:36:32 --> Could not find the language line "Quality"
ERROR - 2024-09-01 12:36:32 --> client
ERROR - 2024-09-01 12:36:32 --> 12
ERROR - 2024-09-01 12:36:32 --> client
ERROR - 2024-09-01 12:36:37 --> client
ERROR - 2024-09-01 12:36:37 --> 12
ERROR - 2024-09-01 12:36:37 --> client
ERROR - 2024-09-01 12:36:40 --> Could not find the language line "Meet Industry's Most Advanced Real Estate Lead Marketplace"
ERROR - 2024-09-01 12:36:40 --> Could not find the language line "Buy Lead"
ERROR - 2024-09-01 12:36:40 --> Could not find the language line "Learn More"
ERROR - 2024-09-01 12:36:40 --> Could not find the language line "Zip Codes"
ERROR - 2024-09-01 12:36:40 --> Could not find the language line "Price Range start"
ERROR - 2024-09-01 12:36:40 --> Could not find the language line "Price Range end"
ERROR - 2024-09-01 12:36:40 --> Could not find the language line "From"
ERROR - 2024-09-01 12:36:40 --> Could not find the language line "To"
ERROR - 2024-09-01 12:36:40 --> Could not find the language line "deal"
ERROR - 2024-09-01 12:36:40 --> Could not find the language line "quality"
ERROR - 2024-09-01 12:36:40 --> Could not find the language line "Metadata"
ERROR - 2024-09-01 12:36:40 --> Could not find the language line "Lead"
ERROR - 2024-09-01 12:36:40 --> Could not find the language line "Contact"
ERROR - 2024-09-01 12:36:40 --> Could not find the language line "Lead Type"
ERROR - 2024-09-01 12:36:40 --> Could not find the language line "Actions"
ERROR - 2024-09-01 12:36:40 --> Could not find the language line "Prospect ID"
ERROR - 2024-09-01 12:36:40 --> Could not find the language line "Generated date"
ERROR - 2024-09-01 12:36:40 --> Could not find the language line "Industry"
ERROR - 2024-09-01 12:36:40 --> Could not find the language line "Zip code"
ERROR - 2024-09-01 12:36:40 --> Could not find the language line "Source"
ERROR - 2024-09-01 12:36:40 --> Could not find the language line "Deal"
ERROR - 2024-09-01 12:36:40 --> Could not find the language line "Quality"
ERROR - 2024-09-01 12:36:40 --> Could not find the language line "Quality"
ERROR - 2024-09-01 12:36:40 --> client
ERROR - 2024-09-01 12:36:40 --> 12
ERROR - 2024-09-01 12:36:40 --> client
ERROR - 2024-09-01 12:36:46 --> external-form
ERROR - 2024-09-01 12:36:46 --> 8
ERROR - 2024-09-01 12:36:46 --> external-form
ERROR - 2024-09-01 12:36:49 --> Could not find the language line "Meet Industry's Most Advanced Real Estate Lead Marketplace"
ERROR - 2024-09-01 12:36:49 --> Could not find the language line "Buy Lead"
ERROR - 2024-09-01 12:36:49 --> Could not find the language line "Learn More"
ERROR - 2024-09-01 12:36:49 --> Could not find the language line "Zip Codes"
ERROR - 2024-09-01 12:36:49 --> Could not find the language line "Price Range start"
ERROR - 2024-09-01 12:36:49 --> Could not find the language line "Price Range end"
ERROR - 2024-09-01 12:36:49 --> Could not find the language line "From"
ERROR - 2024-09-01 12:36:49 --> Could not find the language line "To"
ERROR - 2024-09-01 12:36:49 --> Could not find the language line "deal"
ERROR - 2024-09-01 12:36:49 --> Could not find the language line "quality"
ERROR - 2024-09-01 12:36:49 --> Could not find the language line "Metadata"
ERROR - 2024-09-01 12:36:49 --> Could not find the language line "Lead"
ERROR - 2024-09-01 12:36:49 --> Could not find the language line "Contact"
ERROR - 2024-09-01 12:36:49 --> Could not find the language line "Lead Type"
ERROR - 2024-09-01 12:36:49 --> Could not find the language line "Actions"
ERROR - 2024-09-01 12:36:49 --> Could not find the language line "Prospect ID"
ERROR - 2024-09-01 12:36:49 --> Could not find the language line "Generated date"
ERROR - 2024-09-01 12:36:49 --> Could not find the language line "Industry"
ERROR - 2024-09-01 12:36:49 --> Could not find the language line "Zip code"
ERROR - 2024-09-01 12:36:49 --> Could not find the language line "Source"
ERROR - 2024-09-01 12:36:49 --> Could not find the language line "Deal"
ERROR - 2024-09-01 12:36:49 --> Could not find the language line "Quality"
ERROR - 2024-09-01 12:36:49 --> Could not find the language line "Quality"
ERROR - 2024-09-01 12:36:49 --> client
ERROR - 2024-09-01 12:36:49 --> 12
ERROR - 2024-09-01 12:36:49 --> client
ERROR - 2024-09-01 12:36:51 --> client
ERROR - 2024-09-01 12:36:51 --> 12
ERROR - 2024-09-01 12:36:52 --> client
ERROR - 2024-09-01 12:36:54 --> client
ERROR - 2024-09-01 12:36:54 --> 12
ERROR - 2024-09-01 12:36:54 --> client
ERROR - 2024-09-01 12:36:57 --> client
ERROR - 2024-09-01 12:36:57 --> 12
ERROR - 2024-09-01 12:36:57 --> client
ERROR - 2024-09-01 12:36:59 --> Could not find the language line "Meet Industry's Most Advanced Real Estate Lead Marketplace"
ERROR - 2024-09-01 12:36:59 --> Could not find the language line "Buy Lead"
ERROR - 2024-09-01 12:36:59 --> Could not find the language line "Learn More"
ERROR - 2024-09-01 12:36:59 --> Could not find the language line "Zip Codes"
ERROR - 2024-09-01 12:36:59 --> Could not find the language line "Price Range start"
ERROR - 2024-09-01 12:36:59 --> Could not find the language line "Price Range end"
ERROR - 2024-09-01 12:36:59 --> Could not find the language line "From"
ERROR - 2024-09-01 12:36:59 --> Could not find the language line "To"
ERROR - 2024-09-01 12:36:59 --> Could not find the language line "deal"
ERROR - 2024-09-01 12:36:59 --> Could not find the language line "quality"
ERROR - 2024-09-01 12:36:59 --> Could not find the language line "Metadata"
ERROR - 2024-09-01 12:36:59 --> Could not find the language line "Lead"
ERROR - 2024-09-01 12:36:59 --> Could not find the language line "Contact"
ERROR - 2024-09-01 12:36:59 --> Could not find the language line "Lead Type"
ERROR - 2024-09-01 12:36:59 --> Could not find the language line "Actions"
ERROR - 2024-09-01 12:36:59 --> Could not find the language line "Prospect ID"
ERROR - 2024-09-01 12:36:59 --> Could not find the language line "Generated date"
ERROR - 2024-09-01 12:36:59 --> Could not find the language line "Industry"
ERROR - 2024-09-01 12:36:59 --> Could not find the language line "Zip code"
ERROR - 2024-09-01 12:36:59 --> Could not find the language line "Source"
ERROR - 2024-09-01 12:36:59 --> Could not find the language line "Deal"
ERROR - 2024-09-01 12:36:59 --> Could not find the language line "Quality"
ERROR - 2024-09-01 12:36:59 --> Could not find the language line "Quality"
ERROR - 2024-09-01 12:36:59 --> client
ERROR - 2024-09-01 12:36:59 --> 12
ERROR - 2024-09-01 12:36:59 --> client
ERROR - 2024-09-01 12:37:04 --> client
ERROR - 2024-09-01 12:37:04 --> 12
ERROR - 2024-09-01 12:37:04 --> client
ERROR - 2024-09-01 12:37:07 --> client
ERROR - 2024-09-01 12:37:07 --> 12
ERROR - 2024-09-01 12:37:07 --> client
ERROR - 2024-09-01 12:37:12 --> client
ERROR - 2024-09-01 12:37:12 --> 12
ERROR - 2024-09-01 12:37:12 --> client
ERROR - 2024-09-01 12:37:16 --> client
ERROR - 2024-09-01 12:37:16 --> 12
ERROR - 2024-09-01 12:37:16 --> client
ERROR - 2024-09-01 12:37:19 --> client
ERROR - 2024-09-01 12:37:19 --> 12
ERROR - 2024-09-01 12:37:19 --> client
ERROR - 2024-09-01 12:37:22 --> external-form
ERROR - 2024-09-01 12:37:22 --> 8
ERROR - 2024-09-01 12:37:22 --> external-form
ERROR - 2024-09-01 12:37:29 --> client
ERROR - 2024-09-01 12:37:29 --> 12
ERROR - 2024-09-01 12:37:29 --> client
ERROR - 2024-09-01 12:37:31 --> external-form
ERROR - 2024-09-01 12:37:31 --> 8
ERROR - 2024-09-01 12:37:31 --> external-form
ERROR - 2024-09-01 12:37:33 --> client
ERROR - 2024-09-01 12:37:33 --> 12
ERROR - 2024-09-01 12:37:33 --> client
ERROR - 2024-09-01 14:11:59 --> Could not find the language line "New Prospect"
ERROR - 2024-09-01 14:11:59 --> Could not find the language line "Search Prospects"
ERROR - 2024-09-01 14:11:59 --> Could not find the language line "Filter By"
ERROR - 2024-09-01 14:11:59 --> Could not find the language line "Active Prospects"
ERROR - 2024-09-01 14:11:59 --> Could not find the language line "Inactive Prospects"
ERROR - 2024-09-01 14:11:59 --> Could not find the language line "Name"
ERROR - 2024-09-01 14:11:59 --> Could not find the language line "Status"
ERROR - 2024-09-01 14:11:59 --> Could not find the language line "Type"
ERROR - 2024-09-01 14:11:59 --> Could not find the language line "Category"
ERROR - 2024-09-01 14:11:59 --> Could not find the language line "Acquisition Channels"
ERROR - 2024-09-01 14:11:59 --> Could not find the language line "Desired Amount"
ERROR - 2024-09-01 14:11:59 --> Could not find the language line "Industry"
ERROR - 2024-09-01 14:11:59 --> client
ERROR - 2024-09-01 14:11:59 --> 12
ERROR - 2024-09-01 14:11:59 --> client
ERROR - 2024-09-01 14:12:06 --> client
ERROR - 2024-09-01 14:12:06 --> 12
ERROR - 2024-09-01 14:12:06 --> client
ERROR - 2024-09-01 14:18:24 --> Could not find the language line "New Prospect"
ERROR - 2024-09-01 14:18:24 --> Could not find the language line "Search Prospects"
ERROR - 2024-09-01 14:18:24 --> Could not find the language line "Filter By"
ERROR - 2024-09-01 14:18:24 --> Could not find the language line "Active Prospects"
ERROR - 2024-09-01 14:18:24 --> Could not find the language line "Inactive Prospects"
ERROR - 2024-09-01 14:18:24 --> Could not find the language line "Name"
ERROR - 2024-09-01 14:18:24 --> Could not find the language line "Status"
ERROR - 2024-09-01 14:18:24 --> Could not find the language line "Type"
ERROR - 2024-09-01 14:18:24 --> Could not find the language line "Category"
ERROR - 2024-09-01 14:18:24 --> Could not find the language line "Acquisition Channels"
ERROR - 2024-09-01 14:18:24 --> Could not find the language line "Desired Amount"
ERROR - 2024-09-01 14:18:24 --> Could not find the language line "Industry"
ERROR - 2024-09-01 14:18:24 --> client
ERROR - 2024-09-01 14:18:24 --> 12
ERROR - 2024-09-01 14:18:24 --> client
ERROR - 2024-09-01 14:18:37 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 14:18:37 --> Could not find the language line "billings"
ERROR - 2024-09-01 14:18:42 --> admin
ERROR - 2024-09-01 14:18:42 --> 12
ERROR - 2024-09-01 14:18:42 --> admin
ERROR - 2024-09-01 09:18:43 --> 404 Page Not Found: /index
ERROR - 2024-09-01 14:18:56 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 14:18:56 --> Could not find the language line "billings"
ERROR - 2024-09-01 14:19:03 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 14:19:03 --> Could not find the language line "billings"
ERROR - 2024-09-01 14:19:04 --> Could not find the language line "No campaigns found."
ERROR - 2024-09-01 14:19:04 --> admin
ERROR - 2024-09-01 14:19:04 --> 12
ERROR - 2024-09-01 14:19:04 --> admin
ERROR - 2024-09-01 09:19:04 --> 404 Page Not Found: /index
ERROR - 2024-09-01 14:19:08 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 14:19:08 --> Could not find the language line "billings"
ERROR - 2024-09-01 14:19:08 --> Could not find the language line "Add Affiliate Training Video"
ERROR - 2024-09-01 14:19:08 --> Could not find the language line "Id"
ERROR - 2024-09-01 14:19:08 --> Could not find the language line "Name"
ERROR - 2024-09-01 14:19:08 --> Could not find the language line "URL"
ERROR - 2024-09-01 14:19:08 --> Could not find the language line "Description"
ERROR - 2024-09-01 14:19:08 --> Could not find the language line "Order"
ERROR - 2024-09-01 14:19:08 --> Could not find the language line "Actions"
ERROR - 2024-09-01 14:19:08 --> Could not find the language line "Watch Video"
ERROR - 2024-09-01 14:19:08 --> admin
ERROR - 2024-09-01 14:19:08 --> 12
ERROR - 2024-09-01 14:19:08 --> admin
ERROR - 2024-09-01 09:19:08 --> 404 Page Not Found: /index
ERROR - 2024-09-01 14:19:14 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 14:19:14 --> Could not find the language line "billings"
ERROR - 2024-09-01 14:19:15 --> Could not find the language line "Key"
ERROR - 2024-09-01 14:19:15 --> Could not find the language line "Name"
ERROR - 2024-09-01 14:19:15 --> Could not find the language line "URL"
ERROR - 2024-09-01 14:19:15 --> Could not find the language line "Description"
ERROR - 2024-09-01 14:19:15 --> Could not find the language line "Actions"
ERROR - 2024-09-01 14:19:15 --> Could not find the language line "Watch Video"
ERROR - 2024-09-01 14:19:15 --> admin
ERROR - 2024-09-01 14:19:15 --> 12
ERROR - 2024-09-01 14:19:15 --> admin
ERROR - 2024-09-01 09:19:15 --> 404 Page Not Found: /index
ERROR - 2024-09-01 14:19:16 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 14:19:16 --> Could not find the language line "billings"
ERROR - 2024-09-01 14:19:16 --> admin
ERROR - 2024-09-01 14:19:16 --> 12
ERROR - 2024-09-01 14:19:16 --> admin
ERROR - 2024-09-01 09:19:17 --> 404 Page Not Found: /index
ERROR - 2024-09-01 14:19:18 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 14:19:18 --> Could not find the language line "billings"
ERROR - 2024-09-01 14:19:20 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 14:19:20 --> Could not find the language line "billings"
ERROR - 2024-09-01 14:19:20 --> Could not find the language line "Name"
ERROR - 2024-09-01 14:19:20 --> Could not find the language line "Status"
ERROR - 2024-09-01 14:19:20 --> Could not find the language line "Stars"
ERROR - 2024-09-01 14:19:20 --> Could not find the language line "Type"
ERROR - 2024-09-01 14:19:20 --> Could not find the language line "Category"
ERROR - 2024-09-01 14:19:20 --> Could not find the language line "Acquisition Channels"
ERROR - 2024-09-01 14:19:20 --> Could not find the language line "Industry"
ERROR - 2024-09-01 14:19:20 --> Could not find the language line "Status"
ERROR - 2024-09-01 14:19:20 --> Could not find the language line "deal"
ERROR - 2024-09-01 14:19:20 --> Could not find the language line "Desired Amount"
ERROR - 2024-09-01 14:19:20 --> Could not find the language line "Minimum Amount"
ERROR - 2024-09-01 14:19:20 --> admin
ERROR - 2024-09-01 14:19:20 --> 12
ERROR - 2024-09-01 14:19:20 --> admin
ERROR - 2024-09-01 09:19:21 --> 404 Page Not Found: /index
ERROR - 2024-09-01 14:19:27 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 14:19:27 --> Could not find the language line "billings"
ERROR - 2024-09-01 14:19:36 --> Could not find the language line "New Prospect"
ERROR - 2024-09-01 14:19:36 --> Could not find the language line "Search Prospects"
ERROR - 2024-09-01 14:19:36 --> Could not find the language line "Filter By"
ERROR - 2024-09-01 14:19:36 --> Could not find the language line "Active Prospects"
ERROR - 2024-09-01 14:19:36 --> Could not find the language line "Inactive Prospects"
ERROR - 2024-09-01 14:19:36 --> Could not find the language line "Name"
ERROR - 2024-09-01 14:19:36 --> Could not find the language line "Status"
ERROR - 2024-09-01 14:19:36 --> Could not find the language line "Type"
ERROR - 2024-09-01 14:19:36 --> Could not find the language line "Category"
ERROR - 2024-09-01 14:19:36 --> Could not find the language line "Acquisition Channels"
ERROR - 2024-09-01 14:19:36 --> Could not find the language line "Desired Amount"
ERROR - 2024-09-01 14:19:36 --> Could not find the language line "Industry"
ERROR - 2024-09-01 14:19:36 --> client
ERROR - 2024-09-01 14:19:36 --> 12
ERROR - 2024-09-01 14:19:36 --> client
ERROR - 2024-09-01 14:19:41 --> Could not find the language line "clients_list_value"
ERROR - 2024-09-01 14:19:41 --> Could not find the language line "clients_list_tags"
ERROR - 2024-09-01 14:19:41 --> Could not find the language line "clients_list_status"
ERROR - 2024-09-01 14:19:41 --> Could not find the language line "clients_list_source"
ERROR - 2024-09-01 14:19:41 --> Could not find the language line "Stars"
ERROR - 2024-09-01 14:19:41 --> Could not find the language line "Reasons"
ERROR - 2024-09-01 14:19:41 --> Could not find the language line "Select Reason"
ERROR - 2024-09-01 14:19:41 --> Could not find the language line "Select Reason"
ERROR - 2024-09-01 14:19:41 --> Could not find the language line "Details"
ERROR - 2024-09-01 14:19:41 --> Could not find the language line "Name"
ERROR - 2024-09-01 14:19:41 --> Could not find the language line "Status"
ERROR - 2024-09-01 14:19:41 --> Could not find the language line "Type"
ERROR - 2024-09-01 14:19:41 --> Could not find the language line "Category"
ERROR - 2024-09-01 14:19:41 --> Could not find the language line "Acquisition Channels"
ERROR - 2024-09-01 14:19:41 --> Could not find the language line "Desired Amount"
ERROR - 2024-09-01 14:19:41 --> Could not find the language line "Industry"
ERROR - 2024-09-01 14:19:41 --> Could not find the language line "Upload Evidence (MP3)"
ERROR - 2024-09-01 14:19:41 --> Could not find the language line "Target CRM"
ERROR - 2024-09-01 14:19:41 --> Could not find the language line "Target CRM"
ERROR - 2024-09-01 14:19:41 --> client
ERROR - 2024-09-01 14:19:41 --> 12
ERROR - 2024-09-01 14:19:41 --> client
ERROR - 2024-09-01 14:19:44 --> Could not find the language line "New Campaign"
ERROR - 2024-09-01 14:19:44 --> Could not find the language line "no_campaigns_found"
ERROR - 2024-09-01 14:19:44 --> Could not find the language line "Industry"
ERROR - 2024-09-01 14:19:44 --> Could not find the language line "Select Industry"
ERROR - 2024-09-01 14:19:44 --> Could not find the language line "Select Industry"
ERROR - 2024-09-01 14:19:44 --> Could not find the language line "countries"
ERROR - 2024-09-01 14:19:44 --> Could not find the language line "Select Country"
ERROR - 2024-09-01 14:19:44 --> Could not find the language line "Select Country"
ERROR - 2024-09-01 14:19:44 --> client
ERROR - 2024-09-01 14:19:44 --> 12
ERROR - 2024-09-01 14:19:44 --> client
ERROR - 2024-09-01 14:19:57 --> Could not find the language line "Meet Industry's Most Advanced Real Estate Lead Marketplace"
ERROR - 2024-09-01 14:19:57 --> Could not find the language line "Buy Lead"
ERROR - 2024-09-01 14:19:57 --> Could not find the language line "Learn More"
ERROR - 2024-09-01 14:19:57 --> Could not find the language line "Zip Codes"
ERROR - 2024-09-01 14:19:57 --> Could not find the language line "Price Range start"
ERROR - 2024-09-01 14:19:57 --> Could not find the language line "Price Range end"
ERROR - 2024-09-01 14:19:57 --> Could not find the language line "From"
ERROR - 2024-09-01 14:19:57 --> Could not find the language line "To"
ERROR - 2024-09-01 14:19:57 --> Could not find the language line "deal"
ERROR - 2024-09-01 14:19:57 --> Could not find the language line "quality"
ERROR - 2024-09-01 14:19:57 --> Could not find the language line "Metadata"
ERROR - 2024-09-01 14:19:57 --> Could not find the language line "Lead"
ERROR - 2024-09-01 14:19:57 --> Could not find the language line "Contact"
ERROR - 2024-09-01 14:19:57 --> Could not find the language line "Lead Type"
ERROR - 2024-09-01 14:19:57 --> Could not find the language line "Actions"
ERROR - 2024-09-01 14:19:57 --> Could not find the language line "Prospect ID"
ERROR - 2024-09-01 14:19:57 --> Could not find the language line "Generated date"
ERROR - 2024-09-01 14:19:57 --> Could not find the language line "Industry"
ERROR - 2024-09-01 14:19:57 --> Could not find the language line "Zip code"
ERROR - 2024-09-01 14:19:57 --> Could not find the language line "Source"
ERROR - 2024-09-01 14:19:57 --> Could not find the language line "Deal"
ERROR - 2024-09-01 14:19:57 --> Could not find the language line "Quality"
ERROR - 2024-09-01 14:19:57 --> Could not find the language line "Quality"
ERROR - 2024-09-01 14:19:57 --> client
ERROR - 2024-09-01 14:19:57 --> 12
ERROR - 2024-09-01 14:19:57 --> client
ERROR - 2024-09-01 14:20:39 --> Could not find the language line "Search Prospect Alerts"
ERROR - 2024-09-01 14:20:39 --> Could not find the language line "Filter By"
ERROR - 2024-09-01 14:20:39 --> Could not find the language line "All"
ERROR - 2024-09-01 14:20:39 --> Could not find the language line "Active"
ERROR - 2024-09-01 14:20:39 --> Could not find the language line "Inactive"
ERROR - 2024-09-01 14:20:39 --> Could not find the language line "New Prospect Alert"
ERROR - 2024-09-01 14:20:39 --> client
ERROR - 2024-09-01 14:20:39 --> 12
ERROR - 2024-09-01 14:20:39 --> client
ERROR - 2024-09-01 14:20:44 --> Could not find the language line "Edit Prospect Alert"
ERROR - 2024-09-01 14:20:44 --> Could not find the language line "Name"
ERROR - 2024-09-01 14:20:44 --> Could not find the language line "Prospect Category"
ERROR - 2024-09-01 14:20:44 --> Could not find the language line "Select Prospect Category"
ERROR - 2024-09-01 14:20:44 --> Could not find the language line "Select Prospect Category"
ERROR - 2024-09-01 14:20:44 --> Could not find the language line "Prospect Industry"
ERROR - 2024-09-01 14:20:44 --> Could not find the language line "Select Prospect Industry"
ERROR - 2024-09-01 14:20:44 --> Could not find the language line "Select Prospect Industry"
ERROR - 2024-09-01 14:20:44 --> Could not find the language line "Acquisition Channel"
ERROR - 2024-09-01 14:20:44 --> Could not find the language line "Select Acquisition Channel"
ERROR - 2024-09-01 14:20:44 --> Could not find the language line "Select Acquisition Channel"
ERROR - 2024-09-01 14:20:44 --> Could not find the language line "Email"
ERROR - 2024-09-01 14:20:44 --> Could not find the language line "Phone"
ERROR - 2024-09-01 14:20:44 --> Could not find the language line "Save"
ERROR - 2024-09-01 14:20:44 --> Could not find the language line "Cancel"
ERROR - 2024-09-01 14:20:44 --> client
ERROR - 2024-09-01 14:20:44 --> 12
ERROR - 2024-09-01 14:20:44 --> client
ERROR - 2024-09-01 14:20:52 --> Could not find the language line "New Prospect"
ERROR - 2024-09-01 14:20:52 --> Could not find the language line "Search Prospects"
ERROR - 2024-09-01 14:20:52 --> Could not find the language line "Filter By"
ERROR - 2024-09-01 14:20:52 --> Could not find the language line "Active Prospects"
ERROR - 2024-09-01 14:20:52 --> Could not find the language line "Inactive Prospects"
ERROR - 2024-09-01 14:20:52 --> Could not find the language line "Name"
ERROR - 2024-09-01 14:20:52 --> Could not find the language line "Status"
ERROR - 2024-09-01 14:20:52 --> Could not find the language line "Type"
ERROR - 2024-09-01 14:20:52 --> Could not find the language line "Category"
ERROR - 2024-09-01 14:20:52 --> Could not find the language line "Acquisition Channels"
ERROR - 2024-09-01 14:20:52 --> Could not find the language line "Desired Amount"
ERROR - 2024-09-01 14:20:52 --> Could not find the language line "Industry"
ERROR - 2024-09-01 14:20:52 --> client
ERROR - 2024-09-01 14:20:52 --> 12
ERROR - 2024-09-01 14:20:52 --> client
ERROR - 2024-09-01 14:20:56 --> Could not find the language line "Prospect Details"
ERROR - 2024-09-01 14:20:56 --> Could not find the language line "First Name"
ERROR - 2024-09-01 14:20:56 --> Could not find the language line "Last Name"
ERROR - 2024-09-01 14:20:56 --> Could not find the language line "Phone"
ERROR - 2024-09-01 14:20:56 --> Could not find the language line "Email"
ERROR - 2024-09-01 14:20:56 --> Could not find the language line "Industry"
ERROR - 2024-09-01 14:20:56 --> Could not find the language line "Acquisition Channel"
ERROR - 2024-09-01 14:20:56 --> Could not find the language line "Type"
ERROR - 2024-09-01 14:20:56 --> Could not find the language line "Edit"
ERROR - 2024-09-01 14:20:56 --> Could not find the language line "Back to List"
ERROR - 2024-09-01 14:20:56 --> client
ERROR - 2024-09-01 14:20:56 --> 12
ERROR - 2024-09-01 14:20:56 --> client
ERROR - 2024-09-01 14:21:06 --> Could not find the language line "New Prospect"
ERROR - 2024-09-01 14:21:06 --> Could not find the language line "Search Prospects"
ERROR - 2024-09-01 14:21:06 --> Could not find the language line "Filter By"
ERROR - 2024-09-01 14:21:06 --> Could not find the language line "Active Prospects"
ERROR - 2024-09-01 14:21:06 --> Could not find the language line "Inactive Prospects"
ERROR - 2024-09-01 14:21:06 --> Could not find the language line "Name"
ERROR - 2024-09-01 14:21:06 --> Could not find the language line "Status"
ERROR - 2024-09-01 14:21:06 --> Could not find the language line "Type"
ERROR - 2024-09-01 14:21:06 --> Could not find the language line "Category"
ERROR - 2024-09-01 14:21:06 --> Could not find the language line "Acquisition Channels"
ERROR - 2024-09-01 14:21:06 --> Could not find the language line "Desired Amount"
ERROR - 2024-09-01 14:21:06 --> Could not find the language line "Industry"
ERROR - 2024-09-01 14:21:06 --> client
ERROR - 2024-09-01 14:21:06 --> 12
ERROR - 2024-09-01 14:21:06 --> client
ERROR - 2024-09-01 14:29:52 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 14:29:52 --> Could not find the language line "billings"
ERROR - 2024-09-01 14:29:53 --> admin
ERROR - 2024-09-01 14:29:53 --> 12
ERROR - 2024-09-01 14:29:53 --> admin
ERROR - 2024-09-01 09:29:53 --> 404 Page Not Found: /index
ERROR - 2024-09-01 14:40:29 --> client
ERROR - 2024-09-01 14:40:29 --> 12
ERROR - 2024-09-01 14:40:29 --> client
ERROR - 2024-09-01 14:40:34 --> client
ERROR - 2024-09-01 14:40:34 --> 12
ERROR - 2024-09-01 14:40:34 --> client
ERROR - 2024-09-01 14:40:37 --> client
ERROR - 2024-09-01 14:40:37 --> 12
ERROR - 2024-09-01 14:40:37 --> client
ERROR - 2024-09-01 14:40:45 --> client
ERROR - 2024-09-01 14:40:45 --> 12
ERROR - 2024-09-01 14:40:45 --> client
ERROR - 2024-09-01 14:40:50 --> client
ERROR - 2024-09-01 14:40:50 --> 12
ERROR - 2024-09-01 14:40:50 --> client
ERROR - 2024-09-01 14:41:00 --> Could not find the language line "Meet Industry's Most Advanced Real Estate Lead Marketplace"
ERROR - 2024-09-01 14:41:00 --> Could not find the language line "Buy Lead"
ERROR - 2024-09-01 14:41:00 --> Could not find the language line "Learn More"
ERROR - 2024-09-01 14:41:00 --> Could not find the language line "Zip Codes"
ERROR - 2024-09-01 14:41:00 --> Could not find the language line "Price Range start"
ERROR - 2024-09-01 14:41:00 --> Could not find the language line "Price Range end"
ERROR - 2024-09-01 14:41:00 --> Could not find the language line "From"
ERROR - 2024-09-01 14:41:00 --> Could not find the language line "To"
ERROR - 2024-09-01 14:41:00 --> Could not find the language line "deal"
ERROR - 2024-09-01 14:41:00 --> Could not find the language line "quality"
ERROR - 2024-09-01 14:41:00 --> Could not find the language line "Metadata"
ERROR - 2024-09-01 14:41:00 --> Could not find the language line "Lead"
ERROR - 2024-09-01 14:41:00 --> Could not find the language line "Contact"
ERROR - 2024-09-01 14:41:00 --> Could not find the language line "Lead Type"
ERROR - 2024-09-01 14:41:00 --> Could not find the language line "Actions"
ERROR - 2024-09-01 14:41:00 --> Could not find the language line "Prospect ID"
ERROR - 2024-09-01 14:41:00 --> Could not find the language line "Generated date"
ERROR - 2024-09-01 14:41:00 --> Could not find the language line "Industry"
ERROR - 2024-09-01 14:41:00 --> Could not find the language line "Zip code"
ERROR - 2024-09-01 14:41:00 --> Could not find the language line "Source"
ERROR - 2024-09-01 14:41:00 --> Could not find the language line "Deal"
ERROR - 2024-09-01 14:41:00 --> Could not find the language line "Quality"
ERROR - 2024-09-01 14:41:00 --> Could not find the language line "Quality"
ERROR - 2024-09-01 14:41:00 --> client
ERROR - 2024-09-01 14:41:00 --> 12
ERROR - 2024-09-01 14:41:00 --> client
ERROR - 2024-09-01 14:41:13 --> Could not find the language line "New Prospect"
ERROR - 2024-09-01 14:41:13 --> Could not find the language line "Search Prospects"
ERROR - 2024-09-01 14:41:13 --> Could not find the language line "Filter By"
ERROR - 2024-09-01 14:41:13 --> Could not find the language line "Active Prospects"
ERROR - 2024-09-01 14:41:13 --> Could not find the language line "Inactive Prospects"
ERROR - 2024-09-01 14:41:13 --> Could not find the language line "Name"
ERROR - 2024-09-01 14:41:13 --> Could not find the language line "Status"
ERROR - 2024-09-01 14:41:13 --> Could not find the language line "Type"
ERROR - 2024-09-01 14:41:13 --> Could not find the language line "Category"
ERROR - 2024-09-01 14:41:13 --> Could not find the language line "Acquisition Channels"
ERROR - 2024-09-01 14:41:13 --> Could not find the language line "Desired Amount"
ERROR - 2024-09-01 14:41:13 --> Could not find the language line "Industry"
ERROR - 2024-09-01 14:41:13 --> client
ERROR - 2024-09-01 14:41:13 --> 12
ERROR - 2024-09-01 14:41:13 --> client
ERROR - 2024-09-01 14:41:36 --> Could not find the language line "Search Prospect Alerts"
ERROR - 2024-09-01 14:41:36 --> Could not find the language line "Filter By"
ERROR - 2024-09-01 14:41:36 --> Could not find the language line "All"
ERROR - 2024-09-01 14:41:36 --> Could not find the language line "Active"
ERROR - 2024-09-01 14:41:36 --> Could not find the language line "Inactive"
ERROR - 2024-09-01 14:41:36 --> Could not find the language line "New Prospect Alert"
ERROR - 2024-09-01 14:41:36 --> client
ERROR - 2024-09-01 14:41:36 --> 12
ERROR - 2024-09-01 14:41:36 --> client
ERROR - 2024-09-01 14:41:38 --> Could not find the language line "clients_list_value"
ERROR - 2024-09-01 14:41:38 --> Could not find the language line "clients_list_tags"
ERROR - 2024-09-01 14:41:38 --> Could not find the language line "clients_list_status"
ERROR - 2024-09-01 14:41:38 --> Could not find the language line "clients_list_source"
ERROR - 2024-09-01 14:41:38 --> Could not find the language line "Stars"
ERROR - 2024-09-01 14:41:38 --> Could not find the language line "Reasons"
ERROR - 2024-09-01 14:41:38 --> Could not find the language line "Select Reason"
ERROR - 2024-09-01 14:41:38 --> Could not find the language line "Select Reason"
ERROR - 2024-09-01 14:41:38 --> Could not find the language line "Details"
ERROR - 2024-09-01 14:41:38 --> Could not find the language line "Name"
ERROR - 2024-09-01 14:41:38 --> Could not find the language line "Status"
ERROR - 2024-09-01 14:41:38 --> Could not find the language line "Type"
ERROR - 2024-09-01 14:41:38 --> Could not find the language line "Category"
ERROR - 2024-09-01 14:41:38 --> Could not find the language line "Acquisition Channels"
ERROR - 2024-09-01 14:41:38 --> Could not find the language line "Desired Amount"
ERROR - 2024-09-01 14:41:38 --> Could not find the language line "Industry"
ERROR - 2024-09-01 14:41:38 --> Could not find the language line "Upload Evidence (MP3)"
ERROR - 2024-09-01 14:41:38 --> Could not find the language line "Target CRM"
ERROR - 2024-09-01 14:41:38 --> Could not find the language line "Target CRM"
ERROR - 2024-09-01 14:41:38 --> client
ERROR - 2024-09-01 14:41:38 --> 12
ERROR - 2024-09-01 14:41:38 --> client
ERROR - 2024-09-01 14:41:41 --> Could not find the language line "Search Prospect Alerts"
ERROR - 2024-09-01 14:41:41 --> Could not find the language line "Filter By"
ERROR - 2024-09-01 14:41:41 --> Could not find the language line "All"
ERROR - 2024-09-01 14:41:41 --> Could not find the language line "Active"
ERROR - 2024-09-01 14:41:41 --> Could not find the language line "Inactive"
ERROR - 2024-09-01 14:41:41 --> Could not find the language line "New Prospect Alert"
ERROR - 2024-09-01 14:41:41 --> client
ERROR - 2024-09-01 14:41:41 --> 12
ERROR - 2024-09-01 14:41:41 --> client
ERROR - 2024-09-01 14:41:43 --> Could not find the language line "clients_list_value"
ERROR - 2024-09-01 14:41:43 --> Could not find the language line "clients_list_tags"
ERROR - 2024-09-01 14:41:43 --> Could not find the language line "clients_list_status"
ERROR - 2024-09-01 14:41:43 --> Could not find the language line "clients_list_source"
ERROR - 2024-09-01 14:41:43 --> Could not find the language line "Stars"
ERROR - 2024-09-01 14:41:43 --> Could not find the language line "Reasons"
ERROR - 2024-09-01 14:41:43 --> Could not find the language line "Select Reason"
ERROR - 2024-09-01 14:41:43 --> Could not find the language line "Select Reason"
ERROR - 2024-09-01 14:41:43 --> Could not find the language line "Details"
ERROR - 2024-09-01 14:41:43 --> Could not find the language line "Name"
ERROR - 2024-09-01 14:41:43 --> Could not find the language line "Status"
ERROR - 2024-09-01 14:41:43 --> Could not find the language line "Type"
ERROR - 2024-09-01 14:41:43 --> Could not find the language line "Category"
ERROR - 2024-09-01 14:41:43 --> Could not find the language line "Acquisition Channels"
ERROR - 2024-09-01 14:41:43 --> Could not find the language line "Desired Amount"
ERROR - 2024-09-01 14:41:43 --> Could not find the language line "Industry"
ERROR - 2024-09-01 14:41:43 --> Could not find the language line "Upload Evidence (MP3)"
ERROR - 2024-09-01 14:41:43 --> Could not find the language line "Target CRM"
ERROR - 2024-09-01 14:41:43 --> Could not find the language line "Target CRM"
ERROR - 2024-09-01 14:41:43 --> client
ERROR - 2024-09-01 14:41:43 --> 12
ERROR - 2024-09-01 14:41:43 --> client
ERROR - 2024-09-01 14:41:45 --> Could not find the language line "Search Reported Prospects"
ERROR - 2024-09-01 14:41:45 --> Could not find the language line "Filter By"
ERROR - 2024-09-01 14:41:45 --> Could not find the language line "Active Reported Prospects"
ERROR - 2024-09-01 14:41:45 --> Could not find the language line "Inactive Reported Prospects"
ERROR - 2024-09-01 14:41:45 --> Could not find the language line "No reported prospects found."
ERROR - 2024-09-01 14:41:45 --> client
ERROR - 2024-09-01 14:41:45 --> 12
ERROR - 2024-09-01 14:41:45 --> client
ERROR - 2024-09-01 14:41:50 --> Could not find the language line "New Campaign"
ERROR - 2024-09-01 14:41:50 --> Could not find the language line "no_campaigns_found"
ERROR - 2024-09-01 14:41:50 --> Could not find the language line "Industry"
ERROR - 2024-09-01 14:41:50 --> Could not find the language line "Select Industry"
ERROR - 2024-09-01 14:41:50 --> Could not find the language line "Select Industry"
ERROR - 2024-09-01 14:41:50 --> Could not find the language line "countries"
ERROR - 2024-09-01 14:41:50 --> Could not find the language line "Select Country"
ERROR - 2024-09-01 14:41:50 --> Could not find the language line "Select Country"
ERROR - 2024-09-01 14:41:50 --> client
ERROR - 2024-09-01 14:41:50 --> 12
ERROR - 2024-09-01 14:41:50 --> client
ERROR - 2024-09-01 14:41:55 --> Could not find the language line "Meet Industry's Most Advanced Real Estate Lead Marketplace"
ERROR - 2024-09-01 14:41:55 --> Could not find the language line "Buy Lead"
ERROR - 2024-09-01 14:41:55 --> Could not find the language line "Learn More"
ERROR - 2024-09-01 14:41:55 --> Could not find the language line "Zip Codes"
ERROR - 2024-09-01 14:41:55 --> Could not find the language line "Price Range start"
ERROR - 2024-09-01 14:41:55 --> Could not find the language line "Price Range end"
ERROR - 2024-09-01 14:41:55 --> Could not find the language line "From"
ERROR - 2024-09-01 14:41:55 --> Could not find the language line "To"
ERROR - 2024-09-01 14:41:55 --> Could not find the language line "deal"
ERROR - 2024-09-01 14:41:55 --> Could not find the language line "quality"
ERROR - 2024-09-01 14:41:55 --> Could not find the language line "Metadata"
ERROR - 2024-09-01 14:41:55 --> Could not find the language line "Lead"
ERROR - 2024-09-01 14:41:55 --> Could not find the language line "Contact"
ERROR - 2024-09-01 14:41:55 --> Could not find the language line "Lead Type"
ERROR - 2024-09-01 14:41:55 --> Could not find the language line "Actions"
ERROR - 2024-09-01 14:41:55 --> Could not find the language line "Prospect ID"
ERROR - 2024-09-01 14:41:55 --> Could not find the language line "Generated date"
ERROR - 2024-09-01 14:41:55 --> Could not find the language line "Industry"
ERROR - 2024-09-01 14:41:55 --> Could not find the language line "Zip code"
ERROR - 2024-09-01 14:41:55 --> Could not find the language line "Source"
ERROR - 2024-09-01 14:41:55 --> Could not find the language line "Deal"
ERROR - 2024-09-01 14:41:55 --> Could not find the language line "Quality"
ERROR - 2024-09-01 14:41:55 --> Could not find the language line "Quality"
ERROR - 2024-09-01 14:41:55 --> client
ERROR - 2024-09-01 14:41:55 --> 12
ERROR - 2024-09-01 14:41:55 --> client
ERROR - 2024-09-01 14:45:50 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 14:45:50 --> Could not find the language line "billings"
ERROR - 2024-09-01 14:45:50 --> Could not find the language line "Meet Industry's Most Advanced Real Estate Lead Marketplace"
ERROR - 2024-09-01 14:45:50 --> Could not find the language line "Buy Lead"
ERROR - 2024-09-01 14:45:50 --> Could not find the language line "Learn More"
ERROR - 2024-09-01 14:45:50 --> Could not find the language line "Zip Codes"
ERROR - 2024-09-01 14:45:50 --> Could not find the language line "Price Range start"
ERROR - 2024-09-01 14:45:50 --> Could not find the language line "Price Range end"
ERROR - 2024-09-01 14:45:50 --> Could not find the language line "From"
ERROR - 2024-09-01 14:45:50 --> Could not find the language line "To"
ERROR - 2024-09-01 14:45:50 --> Could not find the language line "deal"
ERROR - 2024-09-01 14:45:50 --> Could not find the language line "quality"
ERROR - 2024-09-01 14:45:50 --> Could not find the language line "Prospect ID"
ERROR - 2024-09-01 14:45:50 --> Could not find the language line "Generated date"
ERROR - 2024-09-01 14:45:50 --> Could not find the language line "Industry"
ERROR - 2024-09-01 14:45:50 --> Could not find the language line "Zip code"
ERROR - 2024-09-01 14:45:50 --> Could not find the language line "Source"
ERROR - 2024-09-01 14:45:50 --> Could not find the language line "Deal"
ERROR - 2024-09-01 14:45:50 --> Could not find the language line "Quality"
ERROR - 2024-09-01 14:45:50 --> Could not find the language line "Quality"
ERROR - 2024-09-01 14:45:50 --> admin
ERROR - 2024-09-01 14:45:51 --> 12
ERROR - 2024-09-01 14:45:51 --> admin
ERROR - 2024-09-01 09:45:51 --> 404 Page Not Found: /index
ERROR - 2024-09-01 14:45:57 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 14:45:57 --> Could not find the language line "billings"
ERROR - 2024-09-01 14:45:58 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 14:45:58 --> Could not find the language line "billings"
ERROR - 2024-09-01 14:46:01 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 14:46:01 --> Could not find the language line "billings"
ERROR - 2024-09-01 14:46:01 --> Could not find the language line "Name"
ERROR - 2024-09-01 14:46:01 --> Could not find the language line "Status"
ERROR - 2024-09-01 14:46:01 --> Could not find the language line "Stars"
ERROR - 2024-09-01 14:46:01 --> Could not find the language line "Type"
ERROR - 2024-09-01 14:46:01 --> Could not find the language line "Category"
ERROR - 2024-09-01 14:46:01 --> Could not find the language line "Acquisition Channels"
ERROR - 2024-09-01 14:46:01 --> Could not find the language line "Industry"
ERROR - 2024-09-01 14:46:01 --> Could not find the language line "Status"
ERROR - 2024-09-01 14:46:01 --> Could not find the language line "deal"
ERROR - 2024-09-01 14:46:01 --> Could not find the language line "Desired Amount"
ERROR - 2024-09-01 14:46:01 --> Could not find the language line "Minimum Amount"
ERROR - 2024-09-01 14:46:01 --> admin
ERROR - 2024-09-01 14:46:01 --> 12
ERROR - 2024-09-01 14:46:01 --> admin
ERROR - 2024-09-01 09:46:01 --> 404 Page Not Found: /index
ERROR - 2024-09-01 14:46:26 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 14:46:26 --> Could not find the language line "billings"
ERROR - 2024-09-01 14:46:34 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 14:46:34 --> Could not find the language line "billings"
ERROR - 2024-09-01 14:46:34 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 14:46:34 --> Could not find the language line "billings"
ERROR - 2024-09-01 14:46:35 --> Could not find the language line "Name"
ERROR - 2024-09-01 14:46:35 --> Could not find the language line "Status"
ERROR - 2024-09-01 14:46:35 --> Could not find the language line "Stars"
ERROR - 2024-09-01 14:46:35 --> Could not find the language line "Type"
ERROR - 2024-09-01 14:46:35 --> Could not find the language line "Category"
ERROR - 2024-09-01 14:46:35 --> Could not find the language line "Acquisition Channels"
ERROR - 2024-09-01 14:46:35 --> Could not find the language line "Industry"
ERROR - 2024-09-01 14:46:35 --> Could not find the language line "Status"
ERROR - 2024-09-01 14:46:35 --> Could not find the language line "deal"
ERROR - 2024-09-01 14:46:35 --> Could not find the language line "Desired Amount"
ERROR - 2024-09-01 14:46:35 --> Could not find the language line "Minimum Amount"
ERROR - 2024-09-01 14:46:35 --> admin
ERROR - 2024-09-01 14:46:35 --> 12
ERROR - 2024-09-01 14:46:35 --> admin
ERROR - 2024-09-01 09:46:35 --> 404 Page Not Found: /index
ERROR - 2024-09-01 14:46:41 --> Could not find the language line "Meet Industry's Most Advanced Real Estate Lead Marketplace"
ERROR - 2024-09-01 14:46:41 --> Could not find the language line "Buy Lead"
ERROR - 2024-09-01 14:46:41 --> Could not find the language line "Learn More"
ERROR - 2024-09-01 14:46:41 --> Could not find the language line "Zip Codes"
ERROR - 2024-09-01 14:46:41 --> Could not find the language line "Price Range start"
ERROR - 2024-09-01 14:46:41 --> Could not find the language line "Price Range end"
ERROR - 2024-09-01 14:46:41 --> Could not find the language line "From"
ERROR - 2024-09-01 14:46:41 --> Could not find the language line "To"
ERROR - 2024-09-01 14:46:41 --> Could not find the language line "deal"
ERROR - 2024-09-01 14:46:41 --> Could not find the language line "quality"
ERROR - 2024-09-01 14:46:41 --> Could not find the language line "Metadata"
ERROR - 2024-09-01 14:46:41 --> Could not find the language line "Lead"
ERROR - 2024-09-01 14:46:41 --> Could not find the language line "Contact"
ERROR - 2024-09-01 14:46:41 --> Could not find the language line "Lead Type"
ERROR - 2024-09-01 14:46:41 --> Could not find the language line "Actions"
ERROR - 2024-09-01 14:46:41 --> Could not find the language line "Prospect ID"
ERROR - 2024-09-01 14:46:41 --> Could not find the language line "Generated date"
ERROR - 2024-09-01 14:46:41 --> Could not find the language line "Industry"
ERROR - 2024-09-01 14:46:41 --> Could not find the language line "Zip code"
ERROR - 2024-09-01 14:46:41 --> Could not find the language line "Source"
ERROR - 2024-09-01 14:46:41 --> Could not find the language line "Deal"
ERROR - 2024-09-01 14:46:41 --> Could not find the language line "Quality"
ERROR - 2024-09-01 14:46:41 --> Could not find the language line "Quality"
ERROR - 2024-09-01 14:46:41 --> client
ERROR - 2024-09-01 14:46:41 --> 12
ERROR - 2024-09-01 14:46:41 --> client
ERROR - 2024-09-01 14:46:44 --> Could not find the language line "Meet Industry's Most Advanced Real Estate Lead Marketplace"
ERROR - 2024-09-01 14:46:44 --> Could not find the language line "Buy Lead"
ERROR - 2024-09-01 14:46:44 --> Could not find the language line "Learn More"
ERROR - 2024-09-01 14:46:44 --> Could not find the language line "Zip Codes"
ERROR - 2024-09-01 14:46:44 --> Could not find the language line "Price Range start"
ERROR - 2024-09-01 14:46:44 --> Could not find the language line "Price Range end"
ERROR - 2024-09-01 14:46:44 --> Could not find the language line "From"
ERROR - 2024-09-01 14:46:44 --> Could not find the language line "To"
ERROR - 2024-09-01 14:46:44 --> Could not find the language line "deal"
ERROR - 2024-09-01 14:46:44 --> Could not find the language line "quality"
ERROR - 2024-09-01 14:46:44 --> Could not find the language line "Metadata"
ERROR - 2024-09-01 14:46:44 --> Could not find the language line "Lead"
ERROR - 2024-09-01 14:46:44 --> Could not find the language line "Contact"
ERROR - 2024-09-01 14:46:44 --> Could not find the language line "Lead Type"
ERROR - 2024-09-01 14:46:44 --> Could not find the language line "Actions"
ERROR - 2024-09-01 14:46:44 --> Could not find the language line "Prospect ID"
ERROR - 2024-09-01 14:46:44 --> Could not find the language line "Generated date"
ERROR - 2024-09-01 14:46:44 --> Could not find the language line "Industry"
ERROR - 2024-09-01 14:46:44 --> Could not find the language line "Zip code"
ERROR - 2024-09-01 14:46:44 --> Could not find the language line "Source"
ERROR - 2024-09-01 14:46:44 --> Could not find the language line "Deal"
ERROR - 2024-09-01 14:46:44 --> Could not find the language line "Quality"
ERROR - 2024-09-01 14:46:44 --> Could not find the language line "Quality"
ERROR - 2024-09-01 14:46:44 --> client
ERROR - 2024-09-01 14:46:44 --> 12
ERROR - 2024-09-01 14:46:44 --> client
ERROR - 2024-09-01 14:46:47 --> Could not find the language line "New Campaign"
ERROR - 2024-09-01 14:46:47 --> Could not find the language line "no_campaigns_found"
ERROR - 2024-09-01 14:46:47 --> Could not find the language line "Industry"
ERROR - 2024-09-01 14:46:47 --> Could not find the language line "Select Industry"
ERROR - 2024-09-01 14:46:47 --> Could not find the language line "Select Industry"
ERROR - 2024-09-01 14:46:47 --> Could not find the language line "countries"
ERROR - 2024-09-01 14:46:47 --> Could not find the language line "Select Country"
ERROR - 2024-09-01 14:46:47 --> Could not find the language line "Select Country"
ERROR - 2024-09-01 14:46:47 --> client
ERROR - 2024-09-01 14:46:47 --> 12
ERROR - 2024-09-01 14:46:47 --> client
ERROR - 2024-09-01 14:47:25 -->  creating invoice
ERROR - 2024-09-01 14:47:25 --> Could not find the language line "New Campaign"
ERROR - 2024-09-01 14:47:25 --> Could not find the language line "description"
ERROR - 2024-09-01 14:47:25 --> Could not find the language line "status"
ERROR - 2024-09-01 14:47:25 --> Could not find the language line "budget"
ERROR - 2024-09-01 14:47:25 --> Could not find the language line "deal"
ERROR - 2024-09-01 14:47:25 --> Could not find the language line "Start Date"
ERROR - 2024-09-01 14:47:25 --> Could not find the language line "End Date"
ERROR - 2024-09-01 14:47:25 --> Could not find the language line "Industry"
ERROR - 2024-09-01 14:47:25 --> Could not find the language line "Select Industry"
ERROR - 2024-09-01 14:47:25 --> Could not find the language line "Select Industry"
ERROR - 2024-09-01 14:47:25 --> Could not find the language line "countries"
ERROR - 2024-09-01 14:47:25 --> Could not find the language line "Select Country"
ERROR - 2024-09-01 14:47:25 --> Could not find the language line "Select Country"
ERROR - 2024-09-01 14:47:25 --> client
ERROR - 2024-09-01 14:47:25 --> 12
ERROR - 2024-09-01 14:47:25 --> client
ERROR - 2024-09-01 14:47:28 --> Could not find the language line "Status"
ERROR - 2024-09-01 14:47:28 --> client
ERROR - 2024-09-01 14:47:28 --> 12
ERROR - 2024-09-01 14:47:28 --> client
ERROR - 2024-09-01 14:47:32 --> Could not find the language line "New Campaign"
ERROR - 2024-09-01 14:47:32 --> Could not find the language line "description"
ERROR - 2024-09-01 14:47:32 --> Could not find the language line "status"
ERROR - 2024-09-01 14:47:32 --> Could not find the language line "budget"
ERROR - 2024-09-01 14:47:32 --> Could not find the language line "deal"
ERROR - 2024-09-01 14:47:32 --> Could not find the language line "Start Date"
ERROR - 2024-09-01 14:47:32 --> Could not find the language line "End Date"
ERROR - 2024-09-01 14:47:32 --> Could not find the language line "Industry"
ERROR - 2024-09-01 14:47:32 --> Could not find the language line "Select Industry"
ERROR - 2024-09-01 14:47:32 --> Could not find the language line "Select Industry"
ERROR - 2024-09-01 14:47:32 --> Could not find the language line "countries"
ERROR - 2024-09-01 14:47:32 --> Could not find the language line "Select Country"
ERROR - 2024-09-01 14:47:32 --> Could not find the language line "Select Country"
ERROR - 2024-09-01 14:47:32 --> client
ERROR - 2024-09-01 14:47:32 --> 12
ERROR - 2024-09-01 14:47:32 --> client
ERROR - 2024-09-01 14:47:35 --> Could not find the language line "Meet Industry's Most Advanced Real Estate Lead Marketplace"
ERROR - 2024-09-01 14:47:35 --> Could not find the language line "Buy Lead"
ERROR - 2024-09-01 14:47:35 --> Could not find the language line "Learn More"
ERROR - 2024-09-01 14:47:35 --> Could not find the language line "Zip Codes"
ERROR - 2024-09-01 14:47:35 --> Could not find the language line "Price Range start"
ERROR - 2024-09-01 14:47:35 --> Could not find the language line "Price Range end"
ERROR - 2024-09-01 14:47:35 --> Could not find the language line "From"
ERROR - 2024-09-01 14:47:35 --> Could not find the language line "To"
ERROR - 2024-09-01 14:47:35 --> Could not find the language line "deal"
ERROR - 2024-09-01 14:47:35 --> Could not find the language line "quality"
ERROR - 2024-09-01 14:47:35 --> Could not find the language line "Metadata"
ERROR - 2024-09-01 14:47:35 --> Could not find the language line "Lead"
ERROR - 2024-09-01 14:47:35 --> Could not find the language line "Contact"
ERROR - 2024-09-01 14:47:35 --> Could not find the language line "Lead Type"
ERROR - 2024-09-01 14:47:35 --> Could not find the language line "Actions"
ERROR - 2024-09-01 14:47:35 --> Could not find the language line "Prospect ID"
ERROR - 2024-09-01 14:47:35 --> Could not find the language line "Generated date"
ERROR - 2024-09-01 14:47:35 --> Could not find the language line "Industry"
ERROR - 2024-09-01 14:47:35 --> Could not find the language line "Zip code"
ERROR - 2024-09-01 14:47:35 --> Could not find the language line "Source"
ERROR - 2024-09-01 14:47:35 --> Could not find the language line "Deal"
ERROR - 2024-09-01 14:47:35 --> Could not find the language line "Quality"
ERROR - 2024-09-01 14:47:35 --> Could not find the language line "Quality"
ERROR - 2024-09-01 14:47:35 --> client
ERROR - 2024-09-01 14:47:35 --> 12
ERROR - 2024-09-01 14:47:35 --> client
ERROR - 2024-09-01 14:48:33 --> Could not find the language line "New Campaign"
ERROR - 2024-09-01 14:48:33 --> Could not find the language line "description"
ERROR - 2024-09-01 14:48:33 --> Could not find the language line "status"
ERROR - 2024-09-01 14:48:33 --> Could not find the language line "budget"
ERROR - 2024-09-01 14:48:33 --> Could not find the language line "deal"
ERROR - 2024-09-01 14:48:33 --> Could not find the language line "Start Date"
ERROR - 2024-09-01 14:48:33 --> Could not find the language line "End Date"
ERROR - 2024-09-01 14:48:33 --> Could not find the language line "Industry"
ERROR - 2024-09-01 14:48:33 --> Could not find the language line "Select Industry"
ERROR - 2024-09-01 14:48:33 --> Could not find the language line "Select Industry"
ERROR - 2024-09-01 14:48:33 --> Could not find the language line "countries"
ERROR - 2024-09-01 14:48:33 --> Could not find the language line "Select Country"
ERROR - 2024-09-01 14:48:33 --> Could not find the language line "Select Country"
ERROR - 2024-09-01 14:48:33 --> client
ERROR - 2024-09-01 14:48:33 --> 12
ERROR - 2024-09-01 14:48:33 --> client
ERROR - 2024-09-01 14:48:37 --> Could not find the language line "Search Prospect Alerts"
ERROR - 2024-09-01 14:48:37 --> Could not find the language line "Filter By"
ERROR - 2024-09-01 14:48:37 --> Could not find the language line "All"
ERROR - 2024-09-01 14:48:37 --> Could not find the language line "Active"
ERROR - 2024-09-01 14:48:37 --> Could not find the language line "Inactive"
ERROR - 2024-09-01 14:48:37 --> Could not find the language line "New Prospect Alert"
ERROR - 2024-09-01 14:48:37 --> client
ERROR - 2024-09-01 14:48:37 --> 12
ERROR - 2024-09-01 14:48:37 --> client
ERROR - 2024-09-01 14:48:41 --> Could not find the language line "Add New Prospect Alert"
ERROR - 2024-09-01 14:48:41 --> Could not find the language line "Name"
ERROR - 2024-09-01 14:48:41 --> Could not find the language line "Prospect Category"
ERROR - 2024-09-01 14:48:41 --> Could not find the language line "Select Prospect Category"
ERROR - 2024-09-01 14:48:41 --> Could not find the language line "Select Prospect Category"
ERROR - 2024-09-01 14:48:41 --> Could not find the language line "Prospect Industry"
ERROR - 2024-09-01 14:48:41 --> Could not find the language line "Select Prospect Industry"
ERROR - 2024-09-01 14:48:41 --> Could not find the language line "Select Prospect Industry"
ERROR - 2024-09-01 14:48:41 --> Could not find the language line "Acquisition Channel"
ERROR - 2024-09-01 14:48:41 --> Could not find the language line "Select Acquisition Channel"
ERROR - 2024-09-01 14:48:41 --> Could not find the language line "Select Acquisition Channel"
ERROR - 2024-09-01 14:48:41 --> Could not find the language line "Verification Methods"
ERROR - 2024-09-01 14:48:41 --> Could not find the language line "Verified via WhatsApp"
ERROR - 2024-09-01 14:48:41 --> Could not find the language line "Verified via SMS"
ERROR - 2024-09-01 14:48:41 --> Could not find the language line "Verified by Staff"
ERROR - 2024-09-01 14:48:41 --> Could not find the language line "Email"
ERROR - 2024-09-01 14:48:41 --> Could not find the language line "Phone"
ERROR - 2024-09-01 14:48:41 --> Could not find the language line "Save"
ERROR - 2024-09-01 14:48:41 --> Could not find the language line "Cancel"
ERROR - 2024-09-01 14:48:41 --> client
ERROR - 2024-09-01 14:48:41 --> 12
ERROR - 2024-09-01 14:48:41 --> client
ERROR - 2024-09-01 14:55:37 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 14:55:37 --> Could not find the language line "billings"
ERROR - 2024-09-01 14:55:38 --> Could not find the language line "Information Points"
ERROR - 2024-09-01 14:55:38 --> Could not find the language line "billings"
ERROR - 2024-09-01 14:55:38 --> Could not find the language line "Name"
ERROR - 2024-09-01 14:55:38 --> Could not find the language line "Status"
ERROR - 2024-09-01 14:55:38 --> Could not find the language line "Stars"
ERROR - 2024-09-01 14:55:38 --> Could not find the language line "Type"
ERROR - 2024-09-01 14:55:38 --> Could not find the language line "Category"
ERROR - 2024-09-01 14:55:38 --> Could not find the language line "Acquisition Channels"
ERROR - 2024-09-01 14:55:38 --> Could not find the language line "Industry"
ERROR - 2024-09-01 14:55:38 --> Could not find the language line "Status"
ERROR - 2024-09-01 14:55:38 --> Could not find the language line "deal"
ERROR - 2024-09-01 14:55:38 --> Could not find the language line "Desired Amount"
ERROR - 2024-09-01 14:55:38 --> Could not find the language line "Minimum Amount"
ERROR - 2024-09-01 14:55:38 --> admin
ERROR - 2024-09-01 14:55:38 --> 12
ERROR - 2024-09-01 14:55:38 --> admin
ERROR - 2024-09-01 09:55:39 --> 404 Page Not Found: /index
ERROR - 2024-09-01 14:55:44 --> Could not find the language line "Meet Industry's Most Advanced Real Estate Lead Marketplace"
ERROR - 2024-09-01 14:55:44 --> Could not find the language line "Buy Lead"
ERROR - 2024-09-01 14:55:44 --> Could not find the language line "Learn More"
ERROR - 2024-09-01 14:55:44 --> Could not find the language line "Zip Codes"
ERROR - 2024-09-01 14:55:44 --> Could not find the language line "Price Range start"
ERROR - 2024-09-01 14:55:44 --> Could not find the language line "Price Range end"
ERROR - 2024-09-01 14:55:44 --> Could not find the language line "From"
ERROR - 2024-09-01 14:55:44 --> Could not find the language line "To"
ERROR - 2024-09-01 14:55:44 --> Could not find the language line "deal"
ERROR - 2024-09-01 14:55:44 --> Could not find the language line "quality"
ERROR - 2024-09-01 14:55:44 --> Could not find the language line "Metadata"
ERROR - 2024-09-01 14:55:44 --> Could not find the language line "Lead"
ERROR - 2024-09-01 14:55:44 --> Could not find the language line "Contact"
ERROR - 2024-09-01 14:55:44 --> Could not find the language line "Lead Type"
ERROR - 2024-09-01 14:55:44 --> Could not find the language line "Actions"
ERROR - 2024-09-01 14:55:44 --> Could not find the language line "Prospect ID"
ERROR - 2024-09-01 14:55:44 --> Could not find the language line "date"
ERROR - 2024-09-01 14:55:44 --> Could not find the language line "Industry"
ERROR - 2024-09-01 14:55:44 --> Could not find the language line "Zip code"
ERROR - 2024-09-01 14:55:44 --> Could not find the language line "Source"
ERROR - 2024-09-01 14:55:44 --> Could not find the language line "Quality"
ERROR - 2024-09-01 14:55:44 --> Could not find the language line "Prospect ID"
ERROR - 2024-09-01 14:55:44 --> Could not find the language line "Generated date"
ERROR - 2024-09-01 14:55:44 --> Could not find the language line "Industry"
ERROR - 2024-09-01 14:55:44 --> Could not find the language line "Zip code"
ERROR - 2024-09-01 14:55:44 --> Could not find the language line "Source"
ERROR - 2024-09-01 14:55:44 --> Could not find the language line "Deal"
ERROR - 2024-09-01 14:55:44 --> Could not find the language line "Quality"
ERROR - 2024-09-01 14:55:44 --> Could not find the language line "Quality"
ERROR - 2024-09-01 14:55:44 --> client
ERROR - 2024-09-01 14:55:44 --> 12
ERROR - 2024-09-01 14:55:44 --> client
ERROR - 2024-09-01 14:55:49 --> Could not find the language line "Meet Industry's Most Advanced Real Estate Lead Marketplace"
ERROR - 2024-09-01 14:55:49 --> Could not find the language line "Buy Lead"
ERROR - 2024-09-01 14:55:49 --> Could not find the language line "Learn More"
ERROR - 2024-09-01 14:55:49 --> Could not find the language line "Zip Codes"
ERROR - 2024-09-01 14:55:49 --> Could not find the language line "Price Range start"
ERROR - 2024-09-01 14:55:49 --> Could not find the language line "Price Range end"
ERROR - 2024-09-01 14:55:49 --> Could not find the language line "From"
ERROR - 2024-09-01 14:55:49 --> Could not find the language line "To"
ERROR - 2024-09-01 14:55:49 --> Could not find the language line "deal"
ERROR - 2024-09-01 14:55:50 --> Could not find the language line "quality"
ERROR - 2024-09-01 14:55:50 --> Could not find the language line "Metadata"
ERROR - 2024-09-01 14:55:50 --> Could not find the language line "Lead"
ERROR - 2024-09-01 14:55:50 --> Could not find the language line "Contact"
ERROR - 2024-09-01 14:55:50 --> Could not find the language line "Lead Type"
ERROR - 2024-09-01 14:55:50 --> Could not find the language line "Actions"
ERROR - 2024-09-01 14:55:50 --> Could not find the language line "Prospect ID"
ERROR - 2024-09-01 14:55:50 --> Could not find the language line "date"
ERROR - 2024-09-01 14:55:50 --> Could not find the language line "Industry"
ERROR - 2024-09-01 14:55:50 --> Could not find the language line "Zip code"
ERROR - 2024-09-01 14:55:50 --> Could not find the language line "Source"
ERROR - 2024-09-01 14:55:50 --> Could not find the language line "Quality"
ERROR - 2024-09-01 14:55:50 --> Could not find the language line "Prospect ID"
ERROR - 2024-09-01 14:55:50 --> Could not find the language line "Generated date"
ERROR - 2024-09-01 14:55:50 --> Could not find the language line "Industry"
ERROR - 2024-09-01 14:55:50 --> Could not find the language line "Zip code"
ERROR - 2024-09-01 14:55:50 --> Could not find the language line "Source"
ERROR - 2024-09-01 14:55:50 --> Could not find the language line "Deal"
ERROR - 2024-09-01 14:55:50 --> Could not find the language line "Quality"
ERROR - 2024-09-01 14:55:50 --> Could not find the language line "Quality"
ERROR - 2024-09-01 14:55:50 --> client
ERROR - 2024-09-01 14:55:50 --> 12
ERROR - 2024-09-01 14:55:50 --> client
ERROR - 2024-09-01 14:56:02 --> client
ERROR - 2024-09-01 14:56:02 --> 12
ERROR - 2024-09-01 14:56:02 --> client
ERROR - 2024-09-01 14:56:05 --> Could not find the language line "Meet Industry's Most Advanced Real Estate Lead Marketplace"
ERROR - 2024-09-01 14:56:05 --> Could not find the language line "Buy Lead"
ERROR - 2024-09-01 14:56:05 --> Could not find the language line "Learn More"
ERROR - 2024-09-01 14:56:05 --> Could not find the language line "Zip Codes"
ERROR - 2024-09-01 14:56:05 --> Could not find the language line "Price Range start"
ERROR - 2024-09-01 14:56:05 --> Could not find the language line "Price Range end"
ERROR - 2024-09-01 14:56:05 --> Could not find the language line "From"
ERROR - 2024-09-01 14:56:05 --> Could not find the language line "To"
ERROR - 2024-09-01 14:56:05 --> Could not find the language line "deal"
ERROR - 2024-09-01 14:56:05 --> Could not find the language line "quality"
ERROR - 2024-09-01 14:56:05 --> Could not find the language line "Metadata"
ERROR - 2024-09-01 14:56:05 --> Could not find the language line "Lead"
ERROR - 2024-09-01 14:56:05 --> Could not find the language line "Contact"
ERROR - 2024-09-01 14:56:05 --> Could not find the language line "Lead Type"
ERROR - 2024-09-01 14:56:05 --> Could not find the language line "Actions"
ERROR - 2024-09-01 14:56:05 --> Could not find the language line "Prospect ID"
ERROR - 2024-09-01 14:56:05 --> Could not find the language line "date"
ERROR - 2024-09-01 14:56:05 --> Could not find the language line "Industry"
ERROR - 2024-09-01 14:56:05 --> Could not find the language line "Zip code"
ERROR - 2024-09-01 14:56:05 --> Could not find the language line "Source"
ERROR - 2024-09-01 14:56:05 --> Could not find the language line "Quality"
ERROR - 2024-09-01 14:56:05 --> Could not find the language line "Prospect ID"
ERROR - 2024-09-01 14:56:05 --> Could not find the language line "Generated date"
ERROR - 2024-09-01 14:56:05 --> Could not find the language line "Industry"
ERROR - 2024-09-01 14:56:05 --> Could not find the language line "Zip code"
ERROR - 2024-09-01 14:56:05 --> Could not find the language line "Source"
ERROR - 2024-09-01 14:56:05 --> Could not find the language line "Deal"
ERROR - 2024-09-01 14:56:05 --> Could not find the language line "Quality"
ERROR - 2024-09-01 14:56:05 --> Could not find the language line "Quality"
ERROR - 2024-09-01 14:56:05 --> client
ERROR - 2024-09-01 14:56:05 --> 12
ERROR - 2024-09-01 14:56:05 --> client
ERROR - 2024-09-01 14:56:19 --> Could not find the language line "New Campaign"
ERROR - 2024-09-01 14:56:19 --> Could not find the language line "description"
ERROR - 2024-09-01 14:56:19 --> Could not find the language line "status"
ERROR - 2024-09-01 14:56:19 --> Could not find the language line "budget"
ERROR - 2024-09-01 14:56:19 --> Could not find the language line "deal"
ERROR - 2024-09-01 14:56:19 --> Could not find the language line "Start Date"
ERROR - 2024-09-01 14:56:19 --> Could not find the language line "End Date"
ERROR - 2024-09-01 14:56:19 --> Could not find the language line "Industry"
ERROR - 2024-09-01 14:56:19 --> Could not find the language line "Select Industry"
ERROR - 2024-09-01 14:56:19 --> Could not find the language line "Select Industry"
ERROR - 2024-09-01 14:56:19 --> Could not find the language line "countries"
ERROR - 2024-09-01 14:56:19 --> Could not find the language line "Select Country"
ERROR - 2024-09-01 14:56:19 --> Could not find the language line "Select Country"
ERROR - 2024-09-01 14:56:19 --> client
ERROR - 2024-09-01 14:56:19 --> 12
ERROR - 2024-09-01 14:56:19 --> client
ERROR - 2024-09-01 14:56:25 --> external-form
ERROR - 2024-09-01 14:56:25 --> 8
ERROR - 2024-09-01 14:56:25 --> external-form
ERROR - 2024-09-01 14:56:34 --> Could not find the language line "New Campaign"
ERROR - 2024-09-01 14:56:34 --> Could not find the language line "description"
ERROR - 2024-09-01 14:56:34 --> Could not find the language line "status"
ERROR - 2024-09-01 14:56:34 --> Could not find the language line "budget"
ERROR - 2024-09-01 14:56:34 --> Could not find the language line "deal"
ERROR - 2024-09-01 14:56:34 --> Could not find the language line "Start Date"
ERROR - 2024-09-01 14:56:34 --> Could not find the language line "End Date"
ERROR - 2024-09-01 14:56:34 --> Could not find the language line "Industry"
ERROR - 2024-09-01 14:56:34 --> Could not find the language line "Select Industry"
ERROR - 2024-09-01 14:56:34 --> Could not find the language line "Select Industry"
ERROR - 2024-09-01 14:56:34 --> Could not find the language line "countries"
ERROR - 2024-09-01 14:56:34 --> Could not find the language line "Select Country"
ERROR - 2024-09-01 14:56:34 --> Could not find the language line "Select Country"
ERROR - 2024-09-01 14:56:34 --> client
ERROR - 2024-09-01 14:56:34 --> 12
ERROR - 2024-09-01 14:56:34 --> client
ERROR - 2024-09-01 14:56:36 --> client
ERROR - 2024-09-01 14:56:36 --> 12
ERROR - 2024-09-01 14:56:36 --> client
ERROR - 2024-09-01 14:56:38 --> Could not find the language line "New Campaign"
ERROR - 2024-09-01 14:56:38 --> Could not find the language line "description"
ERROR - 2024-09-01 14:56:38 --> Could not find the language line "status"
ERROR - 2024-09-01 14:56:38 --> Could not find the language line "budget"
ERROR - 2024-09-01 14:56:38 --> Could not find the language line "deal"
ERROR - 2024-09-01 14:56:38 --> Could not find the language line "Start Date"
ERROR - 2024-09-01 14:56:38 --> Could not find the language line "End Date"
ERROR - 2024-09-01 14:56:38 --> Could not find the language line "Industry"
ERROR - 2024-09-01 14:56:38 --> Could not find the language line "Select Industry"
ERROR - 2024-09-01 14:56:38 --> Could not find the language line "Select Industry"
ERROR - 2024-09-01 14:56:38 --> Could not find the language line "countries"
ERROR - 2024-09-01 14:56:38 --> Could not find the language line "Select Country"
ERROR - 2024-09-01 14:56:38 --> Could not find the language line "Select Country"
ERROR - 2024-09-01 14:56:38 --> client
ERROR - 2024-09-01 14:56:38 --> 12
ERROR - 2024-09-01 14:56:38 --> client
ERROR - 2024-09-01 14:56:40 --> client
ERROR - 2024-09-01 14:56:40 --> 12
ERROR - 2024-09-01 14:56:40 --> client
ERROR - 2024-09-01 14:56:44 --> client
ERROR - 2024-09-01 14:56:44 --> 12
ERROR - 2024-09-01 14:56:44 --> client
ERROR - 2024-09-01 14:56:49 --> Could not find the language line "Onboarding"
ERROR - 2024-09-01 14:56:49 --> Could not find the language line "Onboarding"
ERROR - 2024-09-01 14:56:49 --> Could not find the language line "Invite Friend"
ERROR - 2024-09-01 14:56:49 --> Could not find the language line "Join our private Facebook group"
ERROR - 2024-09-01 14:56:49 --> Could not find the language line "group dedicated specifically for ambassadors. In the group, you'll get access to other successful ambassadors, learn the latest marketing strategies, get help from our support team, and stay informed on all the latest product updates."
ERROR - 2024-09-01 14:56:49 --> Could not find the language line "Sign Up for Alerts"
ERROR - 2024-09-01 14:56:49 --> Could not find the language line "Sign up for our email alerts to stay informed about the latest updates, opportunities, and important information."
ERROR - 2024-09-01 14:56:49 --> Could not find the language line "Complete and Continue"
ERROR - 2024-09-01 14:56:49 --> Could not find the language line "Continue"
ERROR - 2024-09-01 14:56:49 --> Could not find the language line "Onboarding Progress"
ERROR - 2024-09-01 14:56:49 --> Could not find the language line "Watch welcome message"
ERROR - 2024-09-01 14:56:49 --> Could not find the language line "Join Facebook group"
ERROR - 2024-09-01 14:56:49 --> Could not find the language line "Sign up for email alerts"
ERROR - 2024-09-01 14:56:49 --> Could not find the language line "Watch portal walkthrough"
ERROR - 2024-09-01 14:56:49 --> Could not find the language line "Understand the opportunity"
ERROR - 2024-09-01 14:56:49 --> Could not find the language line "Review available products"
ERROR - 2024-09-01 14:56:49 --> Could not find the language line "Who do you want to invite?"
ERROR - 2024-09-01 14:56:49 --> Could not find the language line "Send Invitation"
ERROR - 2024-09-01 14:56:49 --> Could not find the language line "Sign Up for Alerts"
ERROR - 2024-09-01 14:56:49 --> Could not find the language line "<i class="fa fa-exclamation-circle tw-mr-1"></i> We'll never send marketing emails through these alerts. These email alerts are strictly to inform you about Ambassador Program latest updates."
ERROR - 2024-09-01 14:56:49 --> Could not find the language line "Sign Up and Continue"
ERROR - 2024-09-01 14:56:49 --> Could not find the language line "Invitation sent!"
ERROR - 2024-09-01 14:56:49 --> Could not find the language line "Invitation failed!"
ERROR - 2024-09-01 14:56:49 --> client
ERROR - 2024-09-01 14:56:49 --> 12
ERROR - 2024-09-01 14:56:49 --> client
ERROR - 2024-09-01 14:56:51 --> Could not find the language line "New Prospect"
ERROR - 2024-09-01 14:56:51 --> Could not find the language line "Search Prospects"
ERROR - 2024-09-01 14:56:51 --> Could not find the language line "Filter By"
ERROR - 2024-09-01 14:56:51 --> Could not find the language line "Active Prospects"
ERROR - 2024-09-01 14:56:51 --> Could not find the language line "Inactive Prospects"
ERROR - 2024-09-01 14:56:51 --> Could not find the language line "Name"
ERROR - 2024-09-01 14:56:51 --> Could not find the language line "Status"
ERROR - 2024-09-01 14:56:51 --> Could not find the language line "Type"
ERROR - 2024-09-01 14:56:51 --> Could not find the language line "Category"
ERROR - 2024-09-01 14:56:51 --> Could not find the language line "Acquisition Channels"
ERROR - 2024-09-01 14:56:51 --> Could not find the language line "Desired Amount"
ERROR - 2024-09-01 14:56:51 --> Could not find the language line "Industry"
ERROR - 2024-09-01 14:56:51 --> client
ERROR - 2024-09-01 14:56:51 --> 12
ERROR - 2024-09-01 14:56:51 --> client
ERROR - 2024-09-01 15:23:21 --> Could not find the language line "Search Prospect Alerts"
ERROR - 2024-09-01 15:23:21 --> Could not find the language line "Filter By"
ERROR - 2024-09-01 15:23:21 --> Could not find the language line "All"
ERROR - 2024-09-01 15:23:21 --> Could not find the language line "Active"
ERROR - 2024-09-01 15:23:21 --> Could not find the language line "Inactive"
ERROR - 2024-09-01 15:23:21 --> Could not find the language line "New Prospect Alert"
ERROR - 2024-09-01 15:23:21 --> client
ERROR - 2024-09-01 15:23:21 --> 12
ERROR - 2024-09-01 15:23:21 --> client
ERROR - 2024-09-01 15:23:24 --> Could not find the language line "Add New Prospect Alert"
ERROR - 2024-09-01 15:23:24 --> Could not find the language line "Name"
ERROR - 2024-09-01 15:23:24 --> Could not find the language line "Prospect Category"
ERROR - 2024-09-01 15:23:24 --> Could not find the language line "Select Prospect Category"
ERROR - 2024-09-01 15:23:24 --> Could not find the language line "Select Prospect Category"
ERROR - 2024-09-01 15:23:24 --> Could not find the language line "Prospect Industry"
ERROR - 2024-09-01 15:23:24 --> Could not find the language line "Select Prospect Industry"
ERROR - 2024-09-01 15:23:24 --> Could not find the language line "Select Prospect Industry"
ERROR - 2024-09-01 15:23:24 --> Could not find the language line "Acquisition Channel"
ERROR - 2024-09-01 15:23:24 --> Could not find the language line "Select Acquisition Channel"
ERROR - 2024-09-01 15:23:24 --> Could not find the language line "Select Acquisition Channel"
ERROR - 2024-09-01 15:23:24 --> Could not find the language line "Verification Methods"
ERROR - 2024-09-01 15:23:24 --> Could not find the language line "Verified via WhatsApp"
ERROR - 2024-09-01 15:23:24 --> Could not find the language line "Verified via SMS"
ERROR - 2024-09-01 15:23:24 --> Could not find the language line "Verified by Staff"
ERROR - 2024-09-01 15:23:24 --> Could not find the language line "Email"
ERROR - 2024-09-01 15:23:24 --> Could not find the language line "Phone"
ERROR - 2024-09-01 15:23:24 --> Could not find the language line "Save"
ERROR - 2024-09-01 15:23:24 --> Could not find the language line "Cancel"
ERROR - 2024-09-01 15:23:24 --> client
ERROR - 2024-09-01 15:23:24 --> 12
ERROR - 2024-09-01 15:23:24 --> client
ERROR - 2024-09-01 15:26:55 --> Could not find the language line "Add New Prospect Alert"
ERROR - 2024-09-01 15:26:55 --> Could not find the language line "Name"
ERROR - 2024-09-01 15:26:55 --> Could not find the language line "Prospect Category"
ERROR - 2024-09-01 15:26:55 --> Could not find the language line "Select Prospect Category"
ERROR - 2024-09-01 15:26:55 --> Could not find the language line "Select Prospect Category"
ERROR - 2024-09-01 15:26:55 --> Could not find the language line "Prospect Industry"
ERROR - 2024-09-01 15:26:55 --> Could not find the language line "Select Prospect Industry"
ERROR - 2024-09-01 15:26:55 --> Could not find the language line "Select Prospect Industry"
ERROR - 2024-09-01 15:26:55 --> Could not find the language line "Acquisition Channel"
ERROR - 2024-09-01 15:26:55 --> Could not find the language line "Select Acquisition Channel"
ERROR - 2024-09-01 15:26:55 --> Could not find the language line "Select Acquisition Channel"
ERROR - 2024-09-01 15:26:55 --> Could not find the language line "Verification Methods"
ERROR - 2024-09-01 15:26:55 --> Could not find the language line "Verified via WhatsApp"
ERROR - 2024-09-01 15:26:55 --> Could not find the language line "Verified via SMS"
ERROR - 2024-09-01 15:26:55 --> Could not find the language line "Verified by Staff"
ERROR - 2024-09-01 15:26:55 --> Could not find the language line "Email"
ERROR - 2024-09-01 15:26:55 --> Could not find the language line "Phone"
ERROR - 2024-09-01 15:26:55 --> Could not find the language line "Save"
ERROR - 2024-09-01 15:26:55 --> Could not find the language line "Cancel"
ERROR - 2024-09-01 15:26:55 --> client
ERROR - 2024-09-01 15:26:55 --> 12
ERROR - 2024-09-01 15:26:55 --> client
ERROR - 2024-09-01 15:26:58 --> Could not find the language line "Add New Prospect Alert"
ERROR - 2024-09-01 15:26:58 --> Could not find the language line "Name"
ERROR - 2024-09-01 15:26:58 --> Could not find the language line "Prospect Category"
ERROR - 2024-09-01 15:26:58 --> Could not find the language line "Select Prospect Category"
ERROR - 2024-09-01 15:26:58 --> Could not find the language line "Select Prospect Category"
ERROR - 2024-09-01 15:26:58 --> Could not find the language line "Prospect Industry"
ERROR - 2024-09-01 15:26:58 --> Could not find the language line "Select Prospect Industry"
ERROR - 2024-09-01 15:26:58 --> Could not find the language line "Select Prospect Industry"
ERROR - 2024-09-01 15:26:58 --> Could not find the language line "Acquisition Channel"
ERROR - 2024-09-01 15:26:58 --> Could not find the language line "Select Acquisition Channel"
ERROR - 2024-09-01 15:26:58 --> Could not find the language line "Select Acquisition Channel"
ERROR - 2024-09-01 15:26:58 --> Could not find the language line "Verification Methods"
ERROR - 2024-09-01 15:26:58 --> Could not find the language line "Verified via WhatsApp"
ERROR - 2024-09-01 15:26:58 --> Could not find the language line "Verified via SMS"
ERROR - 2024-09-01 15:26:58 --> Could not find the language line "Verified by Staff"
ERROR - 2024-09-01 15:26:58 --> Could not find the language line "Email"
ERROR - 2024-09-01 15:26:58 --> Could not find the language line "Phone"
ERROR - 2024-09-01 15:26:58 --> Could not find the language line "Save"
ERROR - 2024-09-01 15:26:58 --> Could not find the language line "Cancel"
ERROR - 2024-09-01 15:26:58 --> client
ERROR - 2024-09-01 15:26:58 --> 12
ERROR - 2024-09-01 15:26:58 --> client
ERROR - 2024-09-01 15:27:51 --> Could not find the language line "Add New Prospect Alert"
ERROR - 2024-09-01 15:27:51 --> Could not find the language line "Name"
ERROR - 2024-09-01 15:27:51 --> Could not find the language line "Prospect Category"
ERROR - 2024-09-01 15:27:51 --> Could not find the language line "Select Prospect Category"
ERROR - 2024-09-01 15:27:51 --> Could not find the language line "Select Prospect Category"
ERROR - 2024-09-01 15:27:51 --> Could not find the language line "Prospect Industry"
ERROR - 2024-09-01 15:27:51 --> Could not find the language line "Select Prospect Industry"
ERROR - 2024-09-01 15:27:51 --> Could not find the language line "Select Prospect Industry"
ERROR - 2024-09-01 15:27:51 --> Could not find the language line "Acquisition Channel"
ERROR - 2024-09-01 15:27:51 --> Could not find the language line "Select Acquisition Channel"
ERROR - 2024-09-01 15:27:51 --> Could not find the language line "Select Acquisition Channel"
ERROR - 2024-09-01 15:27:51 --> Could not find the language line "Verification Methods"
ERROR - 2024-09-01 15:27:51 --> Could not find the language line "Verified via WhatsApp"
ERROR - 2024-09-01 15:27:51 --> Could not find the language line "Verified via SMS"
ERROR - 2024-09-01 15:27:51 --> Could not find the language line "Verified by Staff"
ERROR - 2024-09-01 15:27:51 --> Could not find the language line "Email"
ERROR - 2024-09-01 15:27:51 --> Could not find the language line "Phone"
ERROR - 2024-09-01 15:27:51 --> Could not find the language line "Save"
ERROR - 2024-09-01 15:27:51 --> Could not find the language line "Cancel"
ERROR - 2024-09-01 15:27:52 --> client
ERROR - 2024-09-01 15:27:52 --> 12
ERROR - 2024-09-01 15:27:52 --> client
ERROR - 2024-09-01 15:27:54 --> Could not find the language line "Search Prospect Alerts"
ERROR - 2024-09-01 15:27:54 --> Could not find the language line "Filter By"
ERROR - 2024-09-01 15:27:54 --> Could not find the language line "All"
ERROR - 2024-09-01 15:27:54 --> Could not find the language line "Active"
ERROR - 2024-09-01 15:27:54 --> Could not find the language line "Inactive"
ERROR - 2024-09-01 15:27:54 --> Could not find the language line "New Prospect Alert"
ERROR - 2024-09-01 15:27:54 --> client
ERROR - 2024-09-01 15:27:54 --> 12
ERROR - 2024-09-01 15:27:54 --> client
ERROR - 2024-09-01 15:27:58 --> Could not find the language line "Edit Prospect Alert"
ERROR - 2024-09-01 15:27:58 --> Could not find the language line "Name"
ERROR - 2024-09-01 15:27:58 --> Could not find the language line "Prospect Category"
ERROR - 2024-09-01 15:27:58 --> Could not find the language line "Select Prospect Category"
ERROR - 2024-09-01 15:27:58 --> Could not find the language line "Select Prospect Category"
ERROR - 2024-09-01 15:27:58 --> Could not find the language line "Prospect Industry"
ERROR - 2024-09-01 15:27:58 --> Could not find the language line "Select Prospect Industry"
ERROR - 2024-09-01 15:27:58 --> Could not find the language line "Select Prospect Industry"
ERROR - 2024-09-01 15:27:58 --> Could not find the language line "Acquisition Channel"
ERROR - 2024-09-01 15:27:58 --> Could not find the language line "Select Acquisition Channel"
ERROR - 2024-09-01 15:27:58 --> Could not find the language line "Select Acquisition Channel"
ERROR - 2024-09-01 15:27:58 --> Could not find the language line "Email"
ERROR - 2024-09-01 15:27:58 --> Could not find the language line "Phone"
ERROR - 2024-09-01 15:27:58 --> Could not find the language line "Save"
ERROR - 2024-09-01 15:27:58 --> Could not find the language line "Cancel"
ERROR - 2024-09-01 15:27:58 --> client
ERROR - 2024-09-01 15:27:58 --> 12
ERROR - 2024-09-01 15:27:58 --> client
ERROR - 2024-09-01 15:28:00 --> Could not find the language line "Edit Prospect Alert"
ERROR - 2024-09-01 15:28:00 --> Could not find the language line "Name"
ERROR - 2024-09-01 15:28:00 --> Could not find the language line "Prospect Category"
ERROR - 2024-09-01 15:28:00 --> Could not find the language line "Select Prospect Category"
ERROR - 2024-09-01 15:28:00 --> Could not find the language line "Select Prospect Category"
ERROR - 2024-09-01 15:28:00 --> Could not find the language line "Prospect Industry"
ERROR - 2024-09-01 15:28:00 --> Could not find the language line "Select Prospect Industry"
ERROR - 2024-09-01 15:28:00 --> Could not find the language line "Select Prospect Industry"
ERROR - 2024-09-01 15:28:00 --> Could not find the language line "Acquisition Channel"
ERROR - 2024-09-01 15:28:00 --> Could not find the language line "Select Acquisition Channel"
ERROR - 2024-09-01 15:28:00 --> Could not find the language line "Select Acquisition Channel"
ERROR - 2024-09-01 15:28:00 --> Could not find the language line "Email"
ERROR - 2024-09-01 15:28:00 --> Could not find the language line "Phone"
ERROR - 2024-09-01 15:28:00 --> Could not find the language line "Save"
ERROR - 2024-09-01 15:28:00 --> Could not find the language line "Cancel"
ERROR - 2024-09-01 15:28:00 --> client
ERROR - 2024-09-01 15:28:00 --> 12
ERROR - 2024-09-01 15:28:00 --> client
ERROR - 2024-09-01 15:28:06 --> Could not find the language line "Edit Prospect Alert"
ERROR - 2024-09-01 15:28:06 --> Could not find the language line "Name"
ERROR - 2024-09-01 15:28:06 --> Could not find the language line "Prospect Category"
ERROR - 2024-09-01 15:28:06 --> Could not find the language line "Select Prospect Category"
ERROR - 2024-09-01 15:28:06 --> Could not find the language line "Select Prospect Category"
ERROR - 2024-09-01 15:28:06 --> Could not find the language line "Prospect Industry"
ERROR - 2024-09-01 15:28:06 --> Could not find the language line "Select Prospect Industry"
ERROR - 2024-09-01 15:28:06 --> Could not find the language line "Select Prospect Industry"
ERROR - 2024-09-01 15:28:06 --> Could not find the language line "Acquisition Channel"
ERROR - 2024-09-01 15:28:06 --> Could not find the language line "Select Acquisition Channel"
ERROR - 2024-09-01 15:28:06 --> Could not find the language line "Select Acquisition Channel"
ERROR - 2024-09-01 15:28:06 --> Could not find the language line "Email"
ERROR - 2024-09-01 15:28:06 --> Could not find the language line "Phone"
ERROR - 2024-09-01 15:28:06 --> Could not find the language line "Save"
ERROR - 2024-09-01 15:28:06 --> Could not find the language line "Cancel"
ERROR - 2024-09-01 15:28:06 --> client
ERROR - 2024-09-01 15:28:06 --> 12
ERROR - 2024-09-01 15:28:06 --> client
ERROR - 2024-09-01 15:28:20 --> Could not find the language line "Search Prospect Alerts"
ERROR - 2024-09-01 15:28:20 --> Could not find the language line "Filter By"
ERROR - 2024-09-01 15:28:20 --> Could not find the language line "All"
ERROR - 2024-09-01 15:28:20 --> Could not find the language line "Active"
ERROR - 2024-09-01 15:28:20 --> Could not find the language line "Inactive"
ERROR - 2024-09-01 15:28:20 --> Could not find the language line "New Prospect Alert"
ERROR - 2024-09-01 15:28:20 --> client
ERROR - 2024-09-01 15:28:20 --> 12
ERROR - 2024-09-01 15:28:20 --> client
