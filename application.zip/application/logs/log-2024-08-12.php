<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-08-12 09:10:01 --> init client assets
ERROR - 2024-08-12 09:10:06 --> init client assets
ERROR - 2024-08-12 09:10:12 --> Could not find the language line "total_campaigns"
ERROR - 2024-08-12 09:10:12 --> Could not find the language line "total_prospects"
ERROR - 2024-08-12 09:10:12 --> Could not find the language line "prospects_average_cost"
ERROR - 2024-08-12 09:10:13 --> Could not find the language line "reported_prospects"
ERROR - 2024-08-12 09:11:19 --> init client assets
ERROR - 2024-08-12 09:11:25 --> init client assets
ERROR - 2024-08-12 09:11:31 --> Could not find the language line "New Prospect"
ERROR - 2024-08-12 09:11:31 --> Could not find the language line "Search Prospects"
ERROR - 2024-08-12 09:11:31 --> Could not find the language line "Filter By"
ERROR - 2024-08-12 09:11:31 --> Could not find the language line "Active Prospects"
ERROR - 2024-08-12 09:11:31 --> Could not find the language line "Inactive Prospects"
ERROR - 2024-08-12 09:11:31 --> Could not find the language line "Name"
ERROR - 2024-08-12 09:11:31 --> Could not find the language line "Status Id"
ERROR - 2024-08-12 09:11:31 --> Could not find the language line "Type Id"
ERROR - 2024-08-12 09:11:31 --> Could not find the language line "Category Id"
ERROR - 2024-08-12 09:11:31 --> Could not find the language line "Acquisition Channels Id"
ERROR - 2024-08-12 09:11:31 --> Could not find the language line "Industry Id"
ERROR - 2024-08-12 09:11:31 --> Could not find the language line "Actions"
ERROR - 2024-08-12 09:12:12 --> init client assets
ERROR - 2024-08-12 09:12:18 --> init client assets
ERROR - 2024-08-12 09:12:24 --> Could not find the language line "New Campaign"
ERROR - 2024-08-12 09:12:24 --> Could not find the language line "Name"
ERROR - 2024-08-12 09:12:24 --> Could not find the language line "Description"
ERROR - 2024-08-12 09:12:24 --> Could not find the language line "Start Date"
ERROR - 2024-08-12 09:12:24 --> Could not find the language line "End Date"
ERROR - 2024-08-12 09:12:24 --> Could not find the language line "Active"
ERROR - 2024-08-12 09:12:24 --> Could not find the language line "Actions"
ERROR - 2024-08-12 09:12:24 --> Could not find the language line "Industry"
ERROR - 2024-08-12 09:12:24 --> Could not find the language line "Select Industry"
ERROR - 2024-08-12 09:12:24 --> Could not find the language line "Select Industry"
ERROR - 2024-08-12 09:12:24 --> Could not find the language line "countries"
ERROR - 2024-08-12 09:12:24 --> Could not find the language line "Select Country"
ERROR - 2024-08-12 09:12:24 --> Could not find the language line "Select Country"
ERROR - 2024-08-12 09:18:54 --> init client assets
ERROR - 2024-08-12 09:18:59 --> init client assets
ERROR - 2024-08-12 09:19:07 --> Could not find the language line "Meet Industry's Most Advanced Real Estate Lead Marketplace"
ERROR - 2024-08-12 09:19:07 --> Could not find the language line "Buy Lead"
ERROR - 2024-08-12 09:19:07 --> Could not find the language line "Learn More"
ERROR - 2024-08-12 09:19:07 --> Could not find the language line "Zip Codes"
ERROR - 2024-08-12 09:19:07 --> Could not find the language line "acquisition_channel"
ERROR - 2024-08-12 09:19:07 --> Could not find the language line "Price Range start"
ERROR - 2024-08-12 09:19:07 --> Could not find the language line "Price Range end"
ERROR - 2024-08-12 09:19:07 --> Could not find the language line "From"
ERROR - 2024-08-12 09:19:07 --> Could not find the language line "To"
ERROR - 2024-08-12 09:19:07 --> Could not find the language line "deal"
ERROR - 2024-08-12 09:19:07 --> Could not find the language line "quality"
ERROR - 2024-08-12 09:19:07 --> Could not find the language line "Metadata"
ERROR - 2024-08-12 09:19:07 --> Could not find the language line "Lead"
ERROR - 2024-08-12 09:19:07 --> Could not find the language line "Contact"
ERROR - 2024-08-12 09:19:07 --> Could not find the language line "Lead Type"
ERROR - 2024-08-12 09:19:07 --> Could not find the language line "Actions"
ERROR - 2024-08-12 09:19:07 --> Could not find the language line "Prospect ID"
ERROR - 2024-08-12 09:19:07 --> Could not find the language line "Generated date"
ERROR - 2024-08-12 09:19:07 --> Could not find the language line "Industry"
ERROR - 2024-08-12 09:19:07 --> Could not find the language line "Zip code"
ERROR - 2024-08-12 09:19:07 --> Could not find the language line "Source"
ERROR - 2024-08-12 09:19:07 --> Could not find the language line "Deal"
ERROR - 2024-08-12 09:19:07 --> Could not find the language line "Quality"
ERROR - 2024-08-12 09:19:07 --> Could not find the language line "Quality"
ERROR - 2024-08-12 09:20:39 --> init client assets
ERROR - 2024-08-12 09:20:44 --> init client assets
ERROR - 2024-08-12 09:20:49 --> Severity: error --> Exception: Unknown column 'nonexclusive_status' in 'where clause' C:\xampp\htdocs\perfex_crm\system\database\drivers\mysqli\mysqli_driver.php 307
ERROR - 2024-08-12 09:21:00 --> init client assets
ERROR - 2024-08-12 09:21:05 --> init client assets
ERROR - 2024-08-12 09:21:10 --> Severity: error --> Exception: Unknown column 'nonexclusive_status' in 'where clause' C:\xampp\htdocs\perfex_crm\system\database\drivers\mysqli\mysqli_driver.php 307
ERROR - 2024-08-12 09:21:21 --> init client assets
ERROR - 2024-08-12 09:21:26 --> init client assets
ERROR - 2024-08-12 09:21:31 --> Severity: error --> Exception: Unknown column 'nonexclusive_status' in 'where clause' C:\xampp\htdocs\perfex_crm\system\database\drivers\mysqli\mysqli_driver.php 307
ERROR - 2024-08-12 09:21:42 --> init client assets
ERROR - 2024-08-12 09:21:47 --> init client assets
ERROR - 2024-08-12 09:21:52 --> Severity: error --> Exception: Unknown column 'nonexclusive_status' in 'where clause' C:\xampp\htdocs\perfex_crm\system\database\drivers\mysqli\mysqli_driver.php 307
ERROR - 2024-08-12 09:22:03 --> init client assets
ERROR - 2024-08-12 09:22:09 --> init client assets
ERROR - 2024-08-12 09:22:14 --> Severity: error --> Exception: Unknown column 'nonexclusive_status' in 'where clause' C:\xampp\htdocs\perfex_crm\system\database\drivers\mysqli\mysqli_driver.php 307
ERROR - 2024-08-12 09:34:01 --> init client assets
ERROR - 2024-08-12 09:34:06 --> init client assets
ERROR - 2024-08-12 09:34:11 --> Severity: error --> Exception: Unknown column 'nonexclusive_status' in 'where clause' C:\xampp\htdocs\perfex_crm\system\database\drivers\mysqli\mysqli_driver.php 307
ERROR - 2024-08-12 09:34:21 --> init client assets
ERROR - 2024-08-12 09:34:26 --> init client assets
ERROR - 2024-08-12 09:34:31 --> Severity: error --> Exception: Unknown column 'nonexclusive_status' in 'where clause' C:\xampp\htdocs\perfex_crm\system\database\drivers\mysqli\mysqli_driver.php 307
ERROR - 2024-08-12 09:34:44 --> init client assets
ERROR - 2024-08-12 09:34:50 --> init client assets
ERROR - 2024-08-12 09:34:55 --> Severity: error --> Exception: Unknown column 'nonexclusive_status' in 'where clause' C:\xampp\htdocs\perfex_crm\system\database\drivers\mysqli\mysqli_driver.php 307
ERROR - 2024-08-12 09:42:00 --> init client assets
ERROR - 2024-08-12 09:42:05 --> init client assets
ERROR - 2024-08-12 09:42:11 --> Could not find the language line "total_campaigns"
ERROR - 2024-08-12 09:42:11 --> Could not find the language line "total_prospects"
ERROR - 2024-08-12 09:42:11 --> Could not find the language line "prospects_average_cost"
ERROR - 2024-08-12 09:42:11 --> Could not find the language line "reported_prospects"
ERROR - 2024-08-12 10:06:27 --> init client assets
ERROR - 2024-08-12 10:06:32 --> init client assets
ERROR - 2024-08-12 10:06:38 --> Could not find the language line "Meet Industry's Most Advanced Real Estate Lead Marketplace"
ERROR - 2024-08-12 10:06:38 --> Could not find the language line "Buy Lead"
ERROR - 2024-08-12 10:06:38 --> Could not find the language line "Learn More"
ERROR - 2024-08-12 10:06:38 --> Could not find the language line "Zip Codes"
ERROR - 2024-08-12 10:06:38 --> Could not find the language line "acquisition_channel"
ERROR - 2024-08-12 10:06:38 --> Could not find the language line "Price Range start"
ERROR - 2024-08-12 10:06:38 --> Could not find the language line "Price Range end"
ERROR - 2024-08-12 10:06:38 --> Could not find the language line "From"
ERROR - 2024-08-12 10:06:38 --> Could not find the language line "To"
ERROR - 2024-08-12 10:06:38 --> Could not find the language line "deal"
ERROR - 2024-08-12 10:06:38 --> Could not find the language line "quality"
ERROR - 2024-08-12 10:06:38 --> Could not find the language line "Metadata"
ERROR - 2024-08-12 10:06:38 --> Could not find the language line "Lead"
ERROR - 2024-08-12 10:06:38 --> Could not find the language line "Contact"
ERROR - 2024-08-12 10:06:38 --> Could not find the language line "Lead Type"
ERROR - 2024-08-12 10:06:38 --> Could not find the language line "Actions"
ERROR - 2024-08-12 10:06:38 --> Could not find the language line "Prospect ID"
ERROR - 2024-08-12 10:06:38 --> Could not find the language line "Generated date"
ERROR - 2024-08-12 10:06:38 --> Could not find the language line "Industry"
ERROR - 2024-08-12 10:06:38 --> Could not find the language line "Zip code"
ERROR - 2024-08-12 10:06:38 --> Could not find the language line "Source"
ERROR - 2024-08-12 10:06:38 --> Could not find the language line "Deal"
ERROR - 2024-08-12 10:06:38 --> Could not find the language line "Quality"
ERROR - 2024-08-12 10:06:38 --> Could not find the language line "Quality"
ERROR - 2024-08-12 10:11:40 --> Could not find the language line "billings"
ERROR - 2024-08-12 07:11:41 --> 404 Page Not Found: Prospects/reported
ERROR - 2024-08-12 10:11:58 --> init client assets
ERROR - 2024-08-12 10:12:03 --> init client assets
ERROR - 2024-08-12 10:12:10 --> Could not find the language line "Meet Industry's Most Advanced Real Estate Lead Marketplace"
ERROR - 2024-08-12 10:12:10 --> Could not find the language line "Buy Lead"
ERROR - 2024-08-12 10:12:10 --> Could not find the language line "Learn More"
ERROR - 2024-08-12 10:12:10 --> Could not find the language line "Zip Codes"
ERROR - 2024-08-12 10:12:10 --> Could not find the language line "acquisition_channel"
ERROR - 2024-08-12 10:12:10 --> Could not find the language line "Price Range start"
ERROR - 2024-08-12 10:12:10 --> Could not find the language line "Price Range end"
ERROR - 2024-08-12 10:12:10 --> Could not find the language line "From"
ERROR - 2024-08-12 10:12:10 --> Could not find the language line "To"
ERROR - 2024-08-12 10:12:10 --> Could not find the language line "deal"
ERROR - 2024-08-12 10:12:10 --> Could not find the language line "quality"
ERROR - 2024-08-12 10:12:10 --> Could not find the language line "Metadata"
ERROR - 2024-08-12 10:12:10 --> Could not find the language line "Lead"
ERROR - 2024-08-12 10:12:10 --> Could not find the language line "Contact"
ERROR - 2024-08-12 10:12:10 --> Could not find the language line "Lead Type"
ERROR - 2024-08-12 10:12:10 --> Could not find the language line "Actions"
ERROR - 2024-08-12 10:12:10 --> Could not find the language line "Prospect ID"
ERROR - 2024-08-12 10:12:10 --> Could not find the language line "Generated date"
ERROR - 2024-08-12 10:12:10 --> Could not find the language line "Industry"
ERROR - 2024-08-12 10:12:10 --> Could not find the language line "Zip code"
ERROR - 2024-08-12 10:12:10 --> Could not find the language line "Source"
ERROR - 2024-08-12 10:12:10 --> Could not find the language line "Deal"
ERROR - 2024-08-12 10:12:10 --> Could not find the language line "Quality"
ERROR - 2024-08-12 10:12:10 --> Could not find the language line "Quality"
ERROR - 2024-08-12 10:12:38 --> Could not find the language line "billings"
ERROR - 2024-08-12 10:12:57 --> Could not find the language line "billings"
ERROR - 2024-08-12 10:13:31 --> Could not find the language line "billings"
ERROR - 2024-08-12 10:13:59 --> Could not find the language line "billings"
ERROR - 2024-08-12 10:16:47 --> Could not find the language line "billings"
ERROR - 2024-08-12 10:17:21 --> Could not find the language line "billings"
ERROR - 2024-08-12 10:21:09 --> init client assets
ERROR - 2024-08-12 10:21:15 --> init client assets
ERROR - 2024-08-12 10:21:21 --> Could not find the language line "New Campaign"
ERROR - 2024-08-12 10:21:21 --> Could not find the language line "Name"
ERROR - 2024-08-12 10:21:21 --> Could not find the language line "Description"
ERROR - 2024-08-12 10:21:21 --> Could not find the language line "Start Date"
ERROR - 2024-08-12 10:21:21 --> Could not find the language line "End Date"
ERROR - 2024-08-12 10:21:21 --> Could not find the language line "Active"
ERROR - 2024-08-12 10:21:21 --> Could not find the language line "Actions"
ERROR - 2024-08-12 10:21:21 --> Could not find the language line "Industry"
ERROR - 2024-08-12 10:21:21 --> Could not find the language line "Select Industry"
ERROR - 2024-08-12 10:21:21 --> Could not find the language line "Select Industry"
ERROR - 2024-08-12 10:21:21 --> Could not find the language line "countries"
ERROR - 2024-08-12 10:21:21 --> Could not find the language line "Select Country"
ERROR - 2024-08-12 10:21:21 --> Could not find the language line "Select Country"
ERROR - 2024-08-12 07:22:04 --> 404 Page Not Found: Prospects/reported
ERROR - 2024-08-12 10:22:18 --> init client assets
ERROR - 2024-08-12 10:22:24 --> init client assets
ERROR - 2024-08-12 10:22:30 --> Could not find the language line "Meet Industry's Most Advanced Real Estate Lead Marketplace"
ERROR - 2024-08-12 10:22:30 --> Could not find the language line "Buy Lead"
ERROR - 2024-08-12 10:22:30 --> Could not find the language line "Learn More"
ERROR - 2024-08-12 10:22:30 --> Could not find the language line "Zip Codes"
ERROR - 2024-08-12 10:22:30 --> Could not find the language line "acquisition_channel"
ERROR - 2024-08-12 10:22:30 --> Could not find the language line "Price Range start"
ERROR - 2024-08-12 10:22:30 --> Could not find the language line "Price Range end"
ERROR - 2024-08-12 10:22:30 --> Could not find the language line "From"
ERROR - 2024-08-12 10:22:30 --> Could not find the language line "To"
ERROR - 2024-08-12 10:22:30 --> Could not find the language line "deal"
ERROR - 2024-08-12 10:22:30 --> Could not find the language line "quality"
ERROR - 2024-08-12 10:22:31 --> Could not find the language line "Metadata"
ERROR - 2024-08-12 10:22:31 --> Could not find the language line "Lead"
ERROR - 2024-08-12 10:22:31 --> Could not find the language line "Contact"
ERROR - 2024-08-12 10:22:31 --> Could not find the language line "Lead Type"
ERROR - 2024-08-12 10:22:31 --> Could not find the language line "Actions"
ERROR - 2024-08-12 10:22:31 --> Could not find the language line "Prospect ID"
ERROR - 2024-08-12 10:22:31 --> Could not find the language line "Generated date"
ERROR - 2024-08-12 10:22:31 --> Could not find the language line "Industry"
ERROR - 2024-08-12 10:22:31 --> Could not find the language line "Zip code"
ERROR - 2024-08-12 10:22:31 --> Could not find the language line "Source"
ERROR - 2024-08-12 10:22:31 --> Could not find the language line "Deal"
ERROR - 2024-08-12 10:22:31 --> Could not find the language line "Quality"
ERROR - 2024-08-12 10:22:31 --> Could not find the language line "Quality"
ERROR - 2024-08-12 10:27:19 --> Could not find the language line "billings"
ERROR - 2024-08-12 10:28:17 --> Could not find the language line "billings"
ERROR - 2024-08-12 10:29:06 --> init client assets
ERROR - 2024-08-12 10:29:11 --> init client assets
ERROR - 2024-08-12 10:29:19 --> Could not find the language line "New Prospect"
ERROR - 2024-08-12 10:29:19 --> Could not find the language line "Search Prospects"
ERROR - 2024-08-12 10:29:19 --> Could not find the language line "Filter By"
ERROR - 2024-08-12 10:29:19 --> Could not find the language line "Active Prospects"
ERROR - 2024-08-12 10:29:19 --> Could not find the language line "Inactive Prospects"
ERROR - 2024-08-12 10:29:19 --> Could not find the language line "Name"
ERROR - 2024-08-12 10:29:19 --> Could not find the language line "Status Id"
ERROR - 2024-08-12 10:29:19 --> Could not find the language line "Type Id"
ERROR - 2024-08-12 10:29:19 --> Could not find the language line "Category Id"
ERROR - 2024-08-12 10:29:19 --> Could not find the language line "Acquisition Channels Id"
ERROR - 2024-08-12 10:29:19 --> Could not find the language line "Industry Id"
ERROR - 2024-08-12 10:29:19 --> Could not find the language line "Actions"
ERROR - 2024-08-12 10:30:12 --> Could not find the language line "billings"
ERROR - 2024-08-12 10:30:31 --> Could not find the language line "billings"
ERROR - 2024-08-12 10:30:51 --> Could not find the language line "billings"
ERROR - 2024-08-12 10:32:17 --> Could not find the language line "billings"
ERROR - 2024-08-12 10:32:41 --> Could not find the language line "billings"
ERROR - 2024-08-12 10:34:00 --> init client assets
ERROR - 2024-08-12 10:34:05 --> init client assets
ERROR - 2024-08-12 10:34:14 --> Severity: Warning --> Attempt to read property "admin" on array C:\xampp\htdocs\perfex_crm\application\helpers\admin_helper.php 256
ERROR - 2024-08-12 10:34:30 --> init client assets
ERROR - 2024-08-12 10:34:35 --> init client assets
ERROR - 2024-08-12 10:37:11 --> init client assets
ERROR - 2024-08-12 10:37:17 --> init client assets
ERROR - 2024-08-12 10:37:25 --> Severity: Warning --> Attempt to read property "admin" on array C:\xampp\htdocs\perfex_crm\application\helpers\admin_helper.php 256
ERROR - 2024-08-12 10:37:38 --> init client assets
ERROR - 2024-08-12 10:37:43 --> init client assets
ERROR - 2024-08-12 10:37:52 --> Severity: Warning --> Attempt to read property "admin" on array C:\xampp\htdocs\perfex_crm\application\helpers\admin_helper.php 256
ERROR - 2024-08-12 10:38:49 --> Could not find the language line "billings"
ERROR - 2024-08-12 10:39:09 --> Could not find the language line "billings"
ERROR - 2024-08-12 10:51:54 --> init client assets
ERROR - 2024-08-12 10:52:00 --> init client assets
ERROR - 2024-08-12 10:52:09 --> Severity: Warning --> Attempt to read property "admin" on array C:\xampp\htdocs\perfex_crm\application\helpers\admin_helper.php 256
ERROR - 2024-08-12 10:52:19 --> Could not find the language line "billings"
ERROR - 2024-08-12 10:53:15 --> Could not find the language line "billings"
ERROR - 2024-08-12 10:53:28 --> init client assets
ERROR - 2024-08-12 10:53:33 --> init client assets
ERROR - 2024-08-12 10:53:46 --> Could not find the language line "billings"
ERROR - 2024-08-12 10:53:54 --> init client assets
ERROR - 2024-08-12 10:54:00 --> init client assets
ERROR - 2024-08-12 10:54:03 --> Could not find the language line "billings"
ERROR - 2024-08-12 10:54:12 --> Could not find the language line "Meet Industry's Most Advanced Real Estate Lead Marketplace"
ERROR - 2024-08-12 10:54:12 --> Could not find the language line "Buy Lead"
ERROR - 2024-08-12 10:54:12 --> Could not find the language line "Learn More"
ERROR - 2024-08-12 10:54:12 --> Could not find the language line "Zip Codes"
ERROR - 2024-08-12 10:54:12 --> Could not find the language line "acquisition_channel"
ERROR - 2024-08-12 10:54:12 --> Could not find the language line "Price Range start"
ERROR - 2024-08-12 10:54:12 --> Could not find the language line "Price Range end"
ERROR - 2024-08-12 10:54:13 --> Could not find the language line "From"
ERROR - 2024-08-12 10:54:13 --> Could not find the language line "To"
ERROR - 2024-08-12 10:54:13 --> Could not find the language line "deal"
ERROR - 2024-08-12 10:54:13 --> Could not find the language line "quality"
ERROR - 2024-08-12 10:54:13 --> Could not find the language line "Metadata"
ERROR - 2024-08-12 10:54:13 --> Could not find the language line "Lead"
ERROR - 2024-08-12 10:54:13 --> Could not find the language line "Contact"
ERROR - 2024-08-12 10:54:13 --> Could not find the language line "Lead Type"
ERROR - 2024-08-12 10:54:13 --> Could not find the language line "Actions"
ERROR - 2024-08-12 10:54:13 --> Could not find the language line "Prospect ID"
ERROR - 2024-08-12 10:54:13 --> Could not find the language line "Generated date"
ERROR - 2024-08-12 10:54:13 --> Could not find the language line "Industry"
ERROR - 2024-08-12 10:54:13 --> Could not find the language line "Zip code"
ERROR - 2024-08-12 10:54:13 --> Could not find the language line "Source"
ERROR - 2024-08-12 10:54:13 --> Could not find the language line "Deal"
ERROR - 2024-08-12 10:54:13 --> Could not find the language line "Quality"
ERROR - 2024-08-12 10:54:13 --> Could not find the language line "Quality"
ERROR - 2024-08-12 10:54:21 --> init client assets
ERROR - 2024-08-12 10:54:24 --> Could not find the language line "billings"
ERROR - 2024-08-12 10:54:27 --> init client assets
ERROR - 2024-08-12 10:54:42 --> Could not find the language line "billings"
ERROR - 2024-08-12 10:54:47 --> init client assets
ERROR - 2024-08-12 10:54:53 --> init client assets
ERROR - 2024-08-12 10:54:59 --> Could not find the language line "billings"
ERROR - 2024-08-12 10:55:07 --> Could not find the language line "New Prospect Status"
ERROR - 2024-08-12 10:55:07 --> Could not find the language line "Name"
ERROR - 2024-08-12 10:55:07 --> Could not find the language line "Description"
ERROR - 2024-08-12 10:55:07 --> Could not find the language line "Active"
ERROR - 2024-08-12 10:55:07 --> Could not find the language line "Actions"
ERROR - 2024-08-12 10:55:20 --> Could not find the language line "billings"
ERROR - 2024-08-12 10:55:27 --> Severity: error --> Exception: Table 'softosol_perfex.tblestimate_request_status' doesn't exist C:\xampp\htdocs\perfex_crm\system\database\drivers\mysqli\mysqli_driver.php 307
ERROR - 2024-08-12 10:55:39 --> Could not find the language line "billings"
ERROR - 2024-08-12 10:56:01 --> Could not find the language line "billings"
ERROR - 2024-08-12 10:56:07 --> Severity: error --> Exception: Table 'softosol_perfex.tblestimate_request_status' doesn't exist C:\xampp\htdocs\perfex_crm\system\database\drivers\mysqli\mysqli_driver.php 307
ERROR - 2024-08-12 11:01:22 --> init client assets
ERROR - 2024-08-12 11:01:28 --> init client assets
ERROR - 2024-08-12 11:03:35 --> init client assets
ERROR - 2024-08-12 11:03:41 --> init client assets
ERROR - 2024-08-12 11:03:48 --> Could not find the language line "New Prospect"
ERROR - 2024-08-12 11:03:48 --> Could not find the language line "Search Prospects"
ERROR - 2024-08-12 11:03:48 --> Could not find the language line "Filter By"
ERROR - 2024-08-12 11:03:48 --> Could not find the language line "Active Prospects"
ERROR - 2024-08-12 11:03:48 --> Could not find the language line "Inactive Prospects"
ERROR - 2024-08-12 11:03:48 --> Could not find the language line "Name"
ERROR - 2024-08-12 11:03:48 --> Could not find the language line "Status Id"
ERROR - 2024-08-12 11:03:48 --> Could not find the language line "Type Id"
ERROR - 2024-08-12 11:03:48 --> Could not find the language line "Category Id"
ERROR - 2024-08-12 11:03:48 --> Could not find the language line "Acquisition Channels Id"
ERROR - 2024-08-12 11:03:48 --> Could not find the language line "Industry Id"
ERROR - 2024-08-12 11:03:48 --> Could not find the language line "Actions"
ERROR - 2024-08-12 11:04:11 --> init client assets
ERROR - 2024-08-12 11:04:17 --> init client assets
ERROR - 2024-08-12 11:04:41 --> init client assets
ERROR - 2024-08-12 11:04:47 --> init client assets
ERROR - 2024-08-12 11:05:20 --> init client assets
ERROR - 2024-08-12 11:05:26 --> init client assets
ERROR - 2024-08-12 11:05:45 --> init client assets
ERROR - 2024-08-12 11:05:51 --> init client assets
ERROR - 2024-08-12 08:05:59 --> 404 Page Not Found: Prospects/reported
ERROR - 2024-08-12 11:06:09 --> init client assets
ERROR - 2024-08-12 11:06:14 --> init client assets
ERROR - 2024-08-12 11:06:35 --> init client assets
ERROR - 2024-08-12 11:06:35 --> init client assets
ERROR - 2024-08-12 11:06:40 --> init client assets
ERROR - 2024-08-12 11:06:41 --> init client assets
ERROR - 2024-08-12 08:06:57 --> 404 Page Not Found: Prospects/reported
ERROR - 2024-08-12 11:06:59 --> init client assets
ERROR - 2024-08-12 11:07:05 --> init client assets
ERROR - 2024-08-12 11:07:18 --> Severity: Error --> Maximum execution time of 120 seconds exceeded C:\xampp\htdocs\perfex_crm\system\database\drivers\mysqli\mysqli_driver.php 236
ERROR - 2024-08-12 08:07:20 --> Severity: Error --> Maximum execution time of 120 seconds exceeded C:\xampp\htdocs\perfex_crm\system\database\drivers\mysqli\mysqli_driver.php 307
ERROR - 2024-08-12 11:07:32 --> init client assets
ERROR - 2024-08-12 11:07:38 --> init client assets
ERROR - 2024-08-12 11:08:22 --> init client assets
ERROR - 2024-08-12 11:08:27 --> init client assets
ERROR - 2024-08-12 11:08:34 --> Could not find the language line "New Prospect"
ERROR - 2024-08-12 11:08:34 --> Could not find the language line "Search Prospects"
ERROR - 2024-08-12 11:08:34 --> Could not find the language line "Filter By"
ERROR - 2024-08-12 11:08:34 --> Could not find the language line "Active Prospects"
ERROR - 2024-08-12 11:08:34 --> Could not find the language line "Inactive Prospects"
ERROR - 2024-08-12 11:08:34 --> Could not find the language line "Name"
ERROR - 2024-08-12 11:08:34 --> Could not find the language line "Status Id"
ERROR - 2024-08-12 11:08:34 --> Could not find the language line "Type Id"
ERROR - 2024-08-12 11:08:34 --> Could not find the language line "Category Id"
ERROR - 2024-08-12 11:08:34 --> Could not find the language line "Acquisition Channels Id"
ERROR - 2024-08-12 11:08:34 --> Could not find the language line "Industry Id"
ERROR - 2024-08-12 11:08:34 --> Could not find the language line "Actions"
ERROR - 2024-08-12 08:08:40 --> 404 Page Not Found: Prospects/reported
ERROR - 2024-08-12 11:10:28 --> init client assets
ERROR - 2024-08-12 11:10:34 --> init client assets
ERROR - 2024-08-12 11:10:41 --> Could not find the language line "New Prospect"
ERROR - 2024-08-12 11:10:41 --> Could not find the language line "Search Prospects"
ERROR - 2024-08-12 11:10:41 --> Could not find the language line "Filter By"
ERROR - 2024-08-12 11:10:41 --> Could not find the language line "Active Prospects"
ERROR - 2024-08-12 11:10:41 --> Could not find the language line "Inactive Prospects"
ERROR - 2024-08-12 11:10:41 --> Could not find the language line "Name"
ERROR - 2024-08-12 11:10:41 --> Could not find the language line "Status Id"
ERROR - 2024-08-12 11:10:41 --> Could not find the language line "Type Id"
ERROR - 2024-08-12 11:10:41 --> Could not find the language line "Category Id"
ERROR - 2024-08-12 11:10:41 --> Could not find the language line "Acquisition Channels Id"
ERROR - 2024-08-12 11:10:41 --> Could not find the language line "Industry Id"
ERROR - 2024-08-12 11:10:41 --> Could not find the language line "Actions"
ERROR - 2024-08-12 08:11:47 --> 404 Page Not Found: Prospects/reported
ERROR - 2024-08-12 11:15:29 --> Could not find the language line "billings"
ERROR - 2024-08-12 11:15:30 --> Could not find the language line "billings"
ERROR - 2024-08-12 11:15:45 --> Could not find the language line "source_name"
ERROR - 2024-08-12 11:15:45 --> Could not find the language line "source_name"
ERROR - 2024-08-12 11:15:45 --> Severity: Warning --> Undefined array key "source_name" C:\xampp\htdocs\perfex_crm\modules\leads_reporting\views\index.php 198
ERROR - 2024-08-12 11:15:45 --> Severity: Warning --> Undefined array key "source_name" C:\xampp\htdocs\perfex_crm\modules\leads_reporting\views\index.php 198
ERROR - 2024-08-12 11:15:45 --> Severity: Warning --> Undefined array key "source_name" C:\xampp\htdocs\perfex_crm\modules\leads_reporting\views\index.php 198
ERROR - 2024-08-12 11:15:45 --> Severity: Warning --> Undefined array key "source_name" C:\xampp\htdocs\perfex_crm\modules\leads_reporting\views\index.php 198
ERROR - 2024-08-12 11:15:57 --> Could not find the language line "billings"
ERROR - 2024-08-12 11:16:09 --> Could not find the language line "source_name"
ERROR - 2024-08-12 11:16:09 --> Severity: Warning --> Undefined array key "source_name" C:\xampp\htdocs\perfex_crm\modules\leads_reporting\views\index.php 198
ERROR - 2024-08-12 11:16:09 --> Severity: Warning --> Undefined array key "source_name" C:\xampp\htdocs\perfex_crm\modules\leads_reporting\views\index.php 198
ERROR - 2024-08-12 11:16:39 --> init client assets
ERROR - 2024-08-12 11:16:45 --> init client assets
ERROR - 2024-08-12 11:16:51 --> Could not find the language line "New Prospect"
ERROR - 2024-08-12 11:16:51 --> Could not find the language line "Search Prospects"
ERROR - 2024-08-12 11:16:51 --> Could not find the language line "Filter By"
ERROR - 2024-08-12 11:16:51 --> Could not find the language line "Active Prospects"
ERROR - 2024-08-12 11:16:51 --> Could not find the language line "Inactive Prospects"
ERROR - 2024-08-12 11:16:51 --> Could not find the language line "Name"
ERROR - 2024-08-12 11:16:51 --> Could not find the language line "Status Id"
ERROR - 2024-08-12 11:16:51 --> Could not find the language line "Type Id"
ERROR - 2024-08-12 11:16:51 --> Could not find the language line "Category Id"
ERROR - 2024-08-12 11:16:51 --> Could not find the language line "Acquisition Channels Id"
ERROR - 2024-08-12 11:16:51 --> Could not find the language line "Industry Id"
ERROR - 2024-08-12 11:16:51 --> Could not find the language line "Actions"
ERROR - 2024-08-12 11:17:22 --> Could not find the language line "billings"
ERROR - 2024-08-12 11:18:22 --> Could not find the language line "billings"
ERROR - 2024-08-12 11:19:22 --> Could not find the language line "billings"
ERROR - 2024-08-12 08:19:46 --> 404 Page Not Found: Prospects/reported
ERROR - 2024-08-12 11:20:22 --> Could not find the language line "billings"
ERROR - 2024-08-12 11:20:59 --> init client assets
ERROR - 2024-08-12 11:21:04 --> init client assets
ERROR - 2024-08-12 11:21:11 --> Could not find the language line "New Prospect"
ERROR - 2024-08-12 11:21:11 --> Could not find the language line "Search Prospects"
ERROR - 2024-08-12 11:21:11 --> Could not find the language line "Filter By"
ERROR - 2024-08-12 11:21:11 --> Could not find the language line "Active Prospects"
ERROR - 2024-08-12 11:21:11 --> Could not find the language line "Inactive Prospects"
ERROR - 2024-08-12 11:21:11 --> Could not find the language line "Name"
ERROR - 2024-08-12 11:21:11 --> Could not find the language line "Status Id"
ERROR - 2024-08-12 11:21:11 --> Could not find the language line "Type Id"
ERROR - 2024-08-12 11:21:11 --> Could not find the language line "Category Id"
ERROR - 2024-08-12 11:21:11 --> Could not find the language line "Acquisition Channels Id"
ERROR - 2024-08-12 11:21:11 --> Could not find the language line "Industry Id"
ERROR - 2024-08-12 11:21:11 --> Could not find the language line "Actions"
ERROR - 2024-08-12 11:21:23 --> Could not find the language line "billings"
ERROR - 2024-08-12 11:22:24 --> Could not find the language line "billings"
ERROR - 2024-08-12 11:23:23 --> Could not find the language line "billings"
ERROR - 2024-08-12 11:24:24 --> Could not find the language line "billings"
ERROR - 2024-08-12 11:25:26 --> Could not find the language line "billings"
ERROR - 2024-08-12 11:26:27 --> Could not find the language line "billings"
ERROR - 2024-08-12 08:26:49 --> 404 Page Not Found: Prospects/reported
ERROR - 2024-08-12 08:27:07 --> 404 Page Not Found: /index
ERROR - 2024-08-12 08:27:19 --> 404 Page Not Found: /index
ERROR - 2024-08-12 11:27:27 --> Could not find the language line "billings"
ERROR - 2024-08-12 08:27:54 --> 404 Page Not Found: Prospects/prospect-reported
ERROR - 2024-08-12 08:28:09 --> 404 Page Not Found: Prospects/prospects-reported
ERROR - 2024-08-12 11:28:27 --> Could not find the language line "billings"
ERROR - 2024-08-12 08:28:32 --> 404 Page Not Found: Prospects/prospect-reported
ERROR - 2024-08-12 08:28:35 --> 404 Page Not Found: Prospects/prospect-reported
ERROR - 2024-08-12 08:28:36 --> 404 Page Not Found: Prospects/prospect-reported
ERROR - 2024-08-12 08:28:36 --> 404 Page Not Found: Prospects/prospect-reported
ERROR - 2024-08-12 08:28:36 --> 404 Page Not Found: Prospects/prospect-reported
ERROR - 2024-08-12 08:28:36 --> 404 Page Not Found: Prospects/prospect-reported
ERROR - 2024-08-12 08:28:47 --> 404 Page Not Found: Prospects/reported
ERROR - 2024-08-12 08:28:58 --> 404 Page Not Found: /index
ERROR - 2024-08-12 11:29:27 --> Could not find the language line "billings"
ERROR - 2024-08-12 11:30:27 --> Could not find the language line "billings"
ERROR - 2024-08-12 11:31:31 --> Could not find the language line "billings"
ERROR - 2024-08-12 08:31:37 --> 404 Page Not Found: /index
ERROR - 2024-08-12 08:31:38 --> 404 Page Not Found: /index
ERROR - 2024-08-12 08:31:39 --> 404 Page Not Found: /index
ERROR - 2024-08-12 11:31:55 --> init client assets
ERROR - 2024-08-12 11:31:55 --> init client assets
ERROR - 2024-08-12 11:32:00 --> init client assets
ERROR - 2024-08-12 11:32:00 --> init client assets
ERROR - 2024-08-12 11:32:05 --> Could not find the language line "New Prospect"
ERROR - 2024-08-12 11:32:05 --> Could not find the language line "Search Prospects"
ERROR - 2024-08-12 11:32:05 --> Could not find the language line "Filter By"
ERROR - 2024-08-12 11:32:05 --> Could not find the language line "Active Prospects"
ERROR - 2024-08-12 11:32:05 --> Could not find the language line "Inactive Prospects"
ERROR - 2024-08-12 11:32:05 --> Could not find the language line "Name"
ERROR - 2024-08-12 11:32:05 --> Could not find the language line "Status Id"
ERROR - 2024-08-12 11:32:05 --> Could not find the language line "Type Id"
ERROR - 2024-08-12 11:32:05 --> Could not find the language line "Category Id"
ERROR - 2024-08-12 11:32:05 --> Could not find the language line "Acquisition Channels Id"
ERROR - 2024-08-12 11:32:05 --> Could not find the language line "Industry Id"
ERROR - 2024-08-12 11:32:05 --> Could not find the language line "Actions"
ERROR - 2024-08-12 11:32:06 --> Could not find the language line "New Prospect"
ERROR - 2024-08-12 11:32:06 --> Could not find the language line "Search Prospects"
ERROR - 2024-08-12 11:32:06 --> Could not find the language line "Filter By"
ERROR - 2024-08-12 11:32:06 --> Could not find the language line "Active Prospects"
ERROR - 2024-08-12 11:32:06 --> Could not find the language line "Inactive Prospects"
ERROR - 2024-08-12 11:32:06 --> Could not find the language line "Name"
ERROR - 2024-08-12 11:32:06 --> Could not find the language line "Status Id"
ERROR - 2024-08-12 11:32:06 --> Could not find the language line "Type Id"
ERROR - 2024-08-12 11:32:06 --> Could not find the language line "Category Id"
ERROR - 2024-08-12 11:32:06 --> Could not find the language line "Acquisition Channels Id"
ERROR - 2024-08-12 11:32:06 --> Could not find the language line "Industry Id"
ERROR - 2024-08-12 11:32:06 --> Could not find the language line "Actions"
ERROR - 2024-08-12 11:32:17 --> init client assets
ERROR - 2024-08-12 11:32:22 --> init client assets
ERROR - 2024-08-12 11:32:27 --> Could not find the language line "total_campaigns"
ERROR - 2024-08-12 11:32:27 --> Could not find the language line "total_prospects"
ERROR - 2024-08-12 11:32:27 --> Could not find the language line "prospects_average_cost"
ERROR - 2024-08-12 11:32:27 --> Could not find the language line "reported_prospects"
ERROR - 2024-08-12 11:32:31 --> Could not find the language line "billings"
ERROR - 2024-08-12 11:33:09 --> init client assets
ERROR - 2024-08-12 11:33:09 --> init client assets
ERROR - 2024-08-12 11:33:09 --> Severity: error --> Exception: Unknown column 'p.is_fake' in 'field list' C:\xampp\htdocs\perfex_crm\system\database\drivers\mysqli\mysqli_driver.php 307
ERROR - 2024-08-12 08:33:20 --> 404 Page Not Found: /index
ERROR - 2024-08-12 08:34:40 --> 404 Page Not Found: /index
ERROR - 2024-08-12 08:34:52 --> 404 Page Not Found: Prospects/prospect_reported
ERROR - 2024-08-12 08:34:56 --> 404 Page Not Found: Prospects/prospect_reported
ERROR - 2024-08-12 08:35:01 --> 404 Page Not Found: Prospects/prospect_reported
ERROR - 2024-08-12 11:35:33 --> init client assets
ERROR - 2024-08-12 11:35:33 --> init client assets
ERROR - 2024-08-12 11:35:33 --> Severity: error --> Exception: Unknown column 'p.is_fake' in 'field list' C:\xampp\htdocs\perfex_crm\system\database\drivers\mysqli\mysqli_driver.php 307
ERROR - 2024-08-12 11:35:35 --> init client assets
ERROR - 2024-08-12 11:35:35 --> init client assets
ERROR - 2024-08-12 11:35:35 --> init client assets
ERROR - 2024-08-12 11:35:35 --> init client assets
ERROR - 2024-08-12 11:35:52 --> init client assets
ERROR - 2024-08-12 11:35:52 --> init client assets
ERROR - 2024-08-12 11:35:52 --> init client assets
ERROR - 2024-08-12 11:35:52 --> Severity: error --> Exception: Unknown column 'c.client_id' in 'where clause' C:\xampp\htdocs\perfex_crm\system\database\drivers\mysqli\mysqli_driver.php 307
ERROR - 2024-08-12 11:35:53 --> init client assets
ERROR - 2024-08-12 11:35:53 --> Severity: error --> Exception: Unknown column 'c.client_id' in 'where clause' C:\xampp\htdocs\perfex_crm\system\database\drivers\mysqli\mysqli_driver.php 307
ERROR - 2024-08-12 11:36:22 --> init client assets
ERROR - 2024-08-12 11:36:27 --> init client assets
ERROR - 2024-08-12 11:36:32 --> Could not find the language line "billings"
ERROR - 2024-08-12 11:36:33 --> Could not find the language line "total_campaigns"
ERROR - 2024-08-12 11:36:33 --> Could not find the language line "total_prospects"
ERROR - 2024-08-12 11:36:33 --> Could not find the language line "prospects_average_cost"
ERROR - 2024-08-12 11:36:33 --> Could not find the language line "reported_prospects"
ERROR - 2024-08-12 08:36:45 --> 404 Page Not Found: Prospects/reported
ERROR - 2024-08-12 11:37:31 --> Could not find the language line "billings"
ERROR - 2024-08-12 11:38:31 --> Could not find the language line "billings"
ERROR - 2024-08-12 08:38:44 --> Severity: Error --> Maximum execution time of 120 seconds exceeded C:\xampp\htdocs\perfex_crm\system\core\Common.php 601
ERROR - 2024-08-12 08:39:20 --> 404 Page Not Found: Prospects/reported
ERROR - 2024-08-12 11:39:31 --> Could not find the language line "billings"
ERROR - 2024-08-12 11:40:14 --> init client assets
ERROR - 2024-08-12 11:40:19 --> init client assets
ERROR - 2024-08-12 11:40:22 --> Could not find the language line "billings"
ERROR - 2024-08-12 11:40:25 --> Could not find the language line "total_campaigns"
ERROR - 2024-08-12 11:40:25 --> Could not find the language line "total_prospects"
ERROR - 2024-08-12 11:40:25 --> Could not find the language line "prospects_average_cost"
ERROR - 2024-08-12 11:40:25 --> Could not find the language line "reported_prospects"
ERROR - 2024-08-12 11:40:32 --> Could not find the language line "billings"
ERROR - 2024-08-12 11:40:35 --> Could not find the language line "source_name"
ERROR - 2024-08-12 11:40:35 --> Severity: Warning --> Undefined array key "source_name" C:\xampp\htdocs\perfex_crm\modules\leads_reporting\views\index.php 198
ERROR - 2024-08-12 11:40:35 --> Severity: Warning --> Undefined array key "source_name" C:\xampp\htdocs\perfex_crm\modules\leads_reporting\views\index.php 198
ERROR - 2024-08-12 11:40:54 --> Could not find the language line "billings"
ERROR - 2024-08-12 11:41:45 --> Could not find the language line "billings"
ERROR - 2024-08-12 11:41:52 --> Could not find the language line "Name"
ERROR - 2024-08-12 11:41:52 --> Could not find the language line "Status Id"
ERROR - 2024-08-12 11:41:52 --> Could not find the language line "Type Id"
ERROR - 2024-08-12 11:41:52 --> Could not find the language line "Category Id"
ERROR - 2024-08-12 11:41:52 --> Could not find the language line "Acquisition Channels Id"
ERROR - 2024-08-12 11:41:52 --> Could not find the language line "Industry Id"
ERROR - 2024-08-12 11:41:52 --> Could not find the language line "Status"
ERROR - 2024-08-12 11:41:52 --> Could not find the language line "Actions"
ERROR - 2024-08-12 11:42:02 --> Could not find the language line "billings"
ERROR - 2024-08-12 11:42:17 --> Could not find the language line "billings"
ERROR - 2024-08-12 11:42:25 --> Could not find the language line "Name"
ERROR - 2024-08-12 11:42:25 --> Could not find the language line "Status Id"
ERROR - 2024-08-12 11:42:25 --> Could not find the language line "Type Id"
ERROR - 2024-08-12 11:42:25 --> Could not find the language line "Category Id"
ERROR - 2024-08-12 11:42:25 --> Could not find the language line "Acquisition Channels Id"
ERROR - 2024-08-12 11:42:25 --> Could not find the language line "Industry Id"
ERROR - 2024-08-12 11:42:25 --> Could not find the language line "Status"
ERROR - 2024-08-12 11:42:25 --> Could not find the language line "Actions"
ERROR - 2024-08-12 11:42:35 --> Could not find the language line "billings"
ERROR - 2024-08-12 08:42:44 --> 404 Page Not Found: Prospects/prospect_reported.php
ERROR - 2024-08-12 08:42:46 --> 404 Page Not Found: Prospects/prospect_reported
ERROR - 2024-08-12 11:42:56 --> Could not find the language line "billings"
ERROR - 2024-08-12 11:44:05 --> init client assets
ERROR - 2024-08-12 11:44:10 --> init client assets
ERROR - 2024-08-12 11:44:15 --> Could not find the language line "total_campaigns"
ERROR - 2024-08-12 11:44:15 --> Could not find the language line "total_prospects"
ERROR - 2024-08-12 11:44:15 --> Could not find the language line "prospects_average_cost"
ERROR - 2024-08-12 11:44:15 --> Could not find the language line "reported_prospects"
ERROR - 2024-08-12 11:44:27 --> init client assets
ERROR - 2024-08-12 11:44:33 --> init client assets
ERROR - 2024-08-12 11:44:38 --> Could not find the language line "New Prospect"
ERROR - 2024-08-12 11:44:38 --> Could not find the language line "Search Prospects"
ERROR - 2024-08-12 11:44:38 --> Could not find the language line "Filter By"
ERROR - 2024-08-12 11:44:38 --> Could not find the language line "Active Prospects"
ERROR - 2024-08-12 11:44:38 --> Could not find the language line "Inactive Prospects"
ERROR - 2024-08-12 11:44:38 --> Could not find the language line "Name"
ERROR - 2024-08-12 11:44:38 --> Could not find the language line "Status Id"
ERROR - 2024-08-12 11:44:38 --> Could not find the language line "Type Id"
ERROR - 2024-08-12 11:44:38 --> Could not find the language line "Category Id"
ERROR - 2024-08-12 11:44:38 --> Could not find the language line "Acquisition Channels Id"
ERROR - 2024-08-12 11:44:38 --> Could not find the language line "Industry Id"
ERROR - 2024-08-12 11:44:38 --> Could not find the language line "Actions"
ERROR - 2024-08-12 11:45:41 --> init client assets
ERROR - 2024-08-12 11:45:46 --> init client assets
ERROR - 2024-08-12 11:46:25 --> init client assets
ERROR - 2024-08-12 11:46:30 --> init client assets
ERROR - 2024-08-12 11:46:59 --> init client assets
ERROR - 2024-08-12 11:47:04 --> init client assets
ERROR - 2024-08-12 11:47:10 --> Severity: Warning --> Attempt to read property "permissions" on array C:\xampp\htdocs\perfex_crm\application\helpers\admin_helper.php 130
ERROR - 2024-08-12 11:47:10 --> Severity: Warning --> Attempt to read property "permissions" on array C:\xampp\htdocs\perfex_crm\application\helpers\admin_helper.php 130
ERROR - 2024-08-12 11:47:10 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 326
ERROR - 2024-08-12 11:47:10 --> Severity: Warning --> Attempt to read property "is_not_staff" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 381
ERROR - 2024-08-12 11:47:10 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 326
ERROR - 2024-08-12 11:47:11 --> Severity: Warning --> Attempt to read property "is_not_staff" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 381
ERROR - 2024-08-12 11:47:11 --> Severity: Warning --> Attempt to read property "permissions" on array C:\xampp\htdocs\perfex_crm\application\helpers\admin_helper.php 130
ERROR - 2024-08-12 11:47:11 --> Severity: Warning --> Attempt to read property "total_unread_notifications" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\head.php 18
ERROR - 2024-08-12 11:47:11 --> Severity: Warning --> Attempt to read property "is_not_staff" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 381
ERROR - 2024-08-12 11:47:11 --> Severity: Warning --> Attempt to read property "is_not_staff" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 381
ERROR - 2024-08-12 11:47:11 --> Severity: Warning --> Attempt to read property "total_unfinished_todos" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 169
ERROR - 2024-08-12 11:47:11 --> Severity: Warning --> Attempt to read property "total_unfinished_todos" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 170
ERROR - 2024-08-12 11:47:11 --> Severity: Warning --> Attempt to read property "firstname" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 298
ERROR - 2024-08-12 11:47:12 --> Severity: Warning --> Attempt to read property "lastname" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 298
ERROR - 2024-08-12 11:47:12 --> Severity: Warning --> Attempt to read property "staffid" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 179
ERROR - 2024-08-12 11:47:12 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 247
ERROR - 2024-08-12 11:47:12 --> Severity: Warning --> Attempt to read property "profile_image" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 274
ERROR - 2024-08-12 11:47:12 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 194
ERROR - 2024-08-12 11:47:12 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:47:12 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:47:12 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:47:12 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:47:12 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:47:12 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:47:12 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:47:12 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:47:12 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:47:12 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:47:12 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:47:12 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:47:12 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:47:12 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:47:12 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:47:12 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:47:12 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:47:12 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:47:12 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:47:12 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:47:13 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:47:13 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:47:13 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:47:13 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:47:13 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:47:13 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:47:14 --> Severity: error --> Exception: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND `end_time` IS NULL' at line 3 C:\xampp\htdocs\perfex_crm\system\database\drivers\mysqli\mysqli_driver.php 307
ERROR - 2024-08-12 11:49:44 --> init client assets
ERROR - 2024-08-12 11:49:49 --> init client assets
ERROR - 2024-08-12 11:49:56 --> Severity: Warning --> Attempt to read property "permissions" on array C:\xampp\htdocs\perfex_crm\application\helpers\admin_helper.php 130
ERROR - 2024-08-12 11:49:56 --> Severity: Warning --> Attempt to read property "permissions" on array C:\xampp\htdocs\perfex_crm\application\helpers\admin_helper.php 130
ERROR - 2024-08-12 11:49:57 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 326
ERROR - 2024-08-12 11:49:57 --> Severity: Warning --> Attempt to read property "is_not_staff" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 381
ERROR - 2024-08-12 11:49:57 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 326
ERROR - 2024-08-12 11:49:57 --> Severity: Warning --> Attempt to read property "is_not_staff" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 381
ERROR - 2024-08-12 11:49:57 --> Severity: Warning --> Attempt to read property "permissions" on array C:\xampp\htdocs\perfex_crm\application\helpers\admin_helper.php 130
ERROR - 2024-08-12 11:49:57 --> Severity: Warning --> Attempt to read property "total_unread_notifications" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\head.php 18
ERROR - 2024-08-12 11:49:58 --> Severity: Warning --> Attempt to read property "is_not_staff" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 381
ERROR - 2024-08-12 11:49:58 --> Severity: Warning --> Attempt to read property "is_not_staff" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 381
ERROR - 2024-08-12 11:49:58 --> Severity: Warning --> Attempt to read property "total_unfinished_todos" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 169
ERROR - 2024-08-12 11:49:58 --> Severity: Warning --> Attempt to read property "total_unfinished_todos" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 170
ERROR - 2024-08-12 11:49:58 --> Severity: Warning --> Attempt to read property "firstname" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 298
ERROR - 2024-08-12 11:49:58 --> Severity: Warning --> Attempt to read property "lastname" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 298
ERROR - 2024-08-12 11:49:58 --> Severity: Warning --> Attempt to read property "staffid" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 179
ERROR - 2024-08-12 11:49:58 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 247
ERROR - 2024-08-12 11:49:58 --> Severity: Warning --> Attempt to read property "profile_image" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 274
ERROR - 2024-08-12 11:49:58 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 194
ERROR - 2024-08-12 11:49:58 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:49:58 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:49:58 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:49:58 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:49:58 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:49:58 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:49:58 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:49:58 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:49:58 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:49:58 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:49:58 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:49:58 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:49:58 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:49:58 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:49:58 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:49:58 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:49:58 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:49:58 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:49:58 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:49:58 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:49:58 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:49:58 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:49:58 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:49:58 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:49:58 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:49:58 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:49:58 --> Severity: error --> Exception: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND `end_time` IS NULL' at line 3 C:\xampp\htdocs\perfex_crm\system\database\drivers\mysqli\mysqli_driver.php 307
ERROR - 2024-08-12 11:50:28 --> init client assets
ERROR - 2024-08-12 11:50:33 --> init client assets
ERROR - 2024-08-12 11:50:40 --> Severity: Warning --> Attempt to read property "permissions" on array C:\xampp\htdocs\perfex_crm\application\helpers\admin_helper.php 130
ERROR - 2024-08-12 11:50:40 --> Severity: Warning --> Attempt to read property "permissions" on array C:\xampp\htdocs\perfex_crm\application\helpers\admin_helper.php 130
ERROR - 2024-08-12 11:50:40 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 326
ERROR - 2024-08-12 11:50:40 --> Severity: Warning --> Attempt to read property "is_not_staff" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 381
ERROR - 2024-08-12 11:50:40 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 326
ERROR - 2024-08-12 11:50:41 --> Severity: Warning --> Attempt to read property "is_not_staff" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 381
ERROR - 2024-08-12 11:50:41 --> Severity: Warning --> Attempt to read property "permissions" on array C:\xampp\htdocs\perfex_crm\application\helpers\admin_helper.php 130
ERROR - 2024-08-12 11:50:41 --> Severity: Warning --> Attempt to read property "total_unread_notifications" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\head.php 18
ERROR - 2024-08-12 11:50:41 --> Severity: Warning --> Attempt to read property "is_not_staff" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 381
ERROR - 2024-08-12 11:50:41 --> Severity: Warning --> Attempt to read property "is_not_staff" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 381
ERROR - 2024-08-12 11:50:41 --> Severity: Warning --> Attempt to read property "total_unfinished_todos" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 169
ERROR - 2024-08-12 11:50:41 --> Severity: Warning --> Attempt to read property "total_unfinished_todos" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 170
ERROR - 2024-08-12 11:50:41 --> Severity: Warning --> Attempt to read property "firstname" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 298
ERROR - 2024-08-12 11:50:41 --> Severity: Warning --> Attempt to read property "lastname" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 298
ERROR - 2024-08-12 11:50:41 --> Severity: Warning --> Attempt to read property "staffid" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 179
ERROR - 2024-08-12 11:50:41 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 247
ERROR - 2024-08-12 11:50:41 --> Severity: Warning --> Attempt to read property "profile_image" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 274
ERROR - 2024-08-12 11:50:41 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 194
ERROR - 2024-08-12 11:50:41 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:50:41 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:50:41 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:50:41 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:50:41 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:50:41 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:50:41 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:50:41 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:50:41 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:50:41 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:50:41 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:50:41 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:50:41 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:50:41 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:50:41 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:50:41 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:50:41 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:50:41 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:50:41 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:50:41 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:50:41 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:50:41 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:50:41 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:50:41 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:50:41 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:50:41 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:50:42 --> Severity: error --> Exception: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND `end_time` IS NULL' at line 3 C:\xampp\htdocs\perfex_crm\system\database\drivers\mysqli\mysqli_driver.php 307
ERROR - 2024-08-12 11:51:10 --> init client assets
ERROR - 2024-08-12 11:51:11 --> init client assets
ERROR - 2024-08-12 11:51:15 --> init client assets
ERROR - 2024-08-12 11:51:16 --> init client assets
ERROR - 2024-08-12 11:51:21 --> Could not find the language line "New Prospect"
ERROR - 2024-08-12 11:51:21 --> Could not find the language line "Search Prospects"
ERROR - 2024-08-12 11:51:21 --> Could not find the language line "Filter By"
ERROR - 2024-08-12 11:51:21 --> Could not find the language line "Active Prospects"
ERROR - 2024-08-12 11:51:21 --> Could not find the language line "Inactive Prospects"
ERROR - 2024-08-12 11:51:21 --> Could not find the language line "Name"
ERROR - 2024-08-12 11:51:21 --> Could not find the language line "Status Id"
ERROR - 2024-08-12 11:51:21 --> Could not find the language line "Type Id"
ERROR - 2024-08-12 11:51:21 --> Could not find the language line "Category Id"
ERROR - 2024-08-12 11:51:21 --> Could not find the language line "Acquisition Channels Id"
ERROR - 2024-08-12 11:51:21 --> Could not find the language line "Industry Id"
ERROR - 2024-08-12 11:51:21 --> Could not find the language line "Actions"
ERROR - 2024-08-12 11:51:22 --> Could not find the language line "total_campaigns"
ERROR - 2024-08-12 11:51:22 --> Could not find the language line "total_prospects"
ERROR - 2024-08-12 11:51:22 --> Could not find the language line "prospects_average_cost"
ERROR - 2024-08-12 11:51:22 --> Could not find the language line "reported_prospects"
ERROR - 2024-08-12 11:51:33 --> init client assets
ERROR - 2024-08-12 11:51:40 --> init client assets
ERROR - 2024-08-12 11:51:45 --> Could not find the language line "total_campaigns"
ERROR - 2024-08-12 11:51:45 --> Could not find the language line "total_prospects"
ERROR - 2024-08-12 11:51:45 --> Could not find the language line "prospects_average_cost"
ERROR - 2024-08-12 11:51:45 --> Could not find the language line "reported_prospects"
ERROR - 2024-08-12 11:51:58 --> init client assets
ERROR - 2024-08-12 11:52:03 --> init client assets
ERROR - 2024-08-12 11:52:08 --> Could not find the language line "Onboarding"
ERROR - 2024-08-12 11:52:09 --> Could not find the language line "Onboarding"
ERROR - 2024-08-12 11:52:09 --> Could not find the language line "Invite Friend"
ERROR - 2024-08-12 11:52:09 --> Could not find the language line "Join our private Facebook group"
ERROR - 2024-08-12 11:52:09 --> Could not find the language line "group dedicated specifically for ambassadors. In the group, you'll get access to other successful ambassadors, learn the latest marketing strategies, get help from our support team, and stay informed on all the latest product updates."
ERROR - 2024-08-12 11:52:09 --> Could not find the language line "Sign Up for Alerts"
ERROR - 2024-08-12 11:52:09 --> Could not find the language line "Sign up for our email alerts to stay informed about the latest updates, opportunities, and important information."
ERROR - 2024-08-12 11:52:09 --> Could not find the language line "Complete and Continue"
ERROR - 2024-08-12 11:52:09 --> Could not find the language line "Continue"
ERROR - 2024-08-12 11:52:09 --> Could not find the language line "Onboarding Progress"
ERROR - 2024-08-12 11:52:09 --> Could not find the language line "Watch welcome message"
ERROR - 2024-08-12 11:52:09 --> Could not find the language line "Join Facebook group"
ERROR - 2024-08-12 11:52:09 --> Could not find the language line "Sign up for email alerts"
ERROR - 2024-08-12 11:52:09 --> Could not find the language line "Watch portal walkthrough"
ERROR - 2024-08-12 11:52:09 --> Could not find the language line "Understand the opportunity"
ERROR - 2024-08-12 11:52:09 --> Could not find the language line "Review available products"
ERROR - 2024-08-12 11:52:09 --> Could not find the language line "Who do you want to invite?"
ERROR - 2024-08-12 11:52:09 --> Could not find the language line "Send Invitation"
ERROR - 2024-08-12 11:52:09 --> Could not find the language line "Sign Up for Alerts"
ERROR - 2024-08-12 11:52:09 --> Could not find the language line "<i class="fa fa-exclamation-circle tw-mr-1"></i> We'll never send marketing emails through these alerts. These email alerts are strictly to inform you about Ambassador Program latest updates."
ERROR - 2024-08-12 11:52:09 --> Could not find the language line "Sign Up and Continue"
ERROR - 2024-08-12 11:52:09 --> Could not find the language line "Invitation sent!"
ERROR - 2024-08-12 11:53:58 --> init client assets
ERROR - 2024-08-12 11:54:03 --> init client assets
ERROR - 2024-08-12 11:54:09 --> Severity: Warning --> Attempt to read property "permissions" on array C:\xampp\htdocs\perfex_crm\application\helpers\admin_helper.php 130
ERROR - 2024-08-12 11:54:09 --> Severity: Warning --> Attempt to read property "permissions" on array C:\xampp\htdocs\perfex_crm\application\helpers\admin_helper.php 130
ERROR - 2024-08-12 11:54:09 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 326
ERROR - 2024-08-12 11:54:09 --> Severity: Warning --> Attempt to read property "is_not_staff" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 381
ERROR - 2024-08-12 11:54:09 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 326
ERROR - 2024-08-12 11:54:09 --> Severity: Warning --> Attempt to read property "is_not_staff" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 381
ERROR - 2024-08-12 11:54:09 --> Severity: Warning --> Attempt to read property "permissions" on array C:\xampp\htdocs\perfex_crm\application\helpers\admin_helper.php 130
ERROR - 2024-08-12 11:54:09 --> Severity: Warning --> Attempt to read property "total_unread_notifications" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\head.php 18
ERROR - 2024-08-12 11:54:10 --> Severity: Warning --> Attempt to read property "is_not_staff" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 381
ERROR - 2024-08-12 11:54:10 --> Severity: Warning --> Attempt to read property "is_not_staff" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 381
ERROR - 2024-08-12 11:54:10 --> Severity: Warning --> Attempt to read property "total_unfinished_todos" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 169
ERROR - 2024-08-12 11:54:10 --> Severity: Warning --> Attempt to read property "total_unfinished_todos" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 170
ERROR - 2024-08-12 11:54:10 --> Severity: Warning --> Attempt to read property "firstname" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 298
ERROR - 2024-08-12 11:54:10 --> Severity: Warning --> Attempt to read property "lastname" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 298
ERROR - 2024-08-12 11:54:10 --> Severity: Warning --> Attempt to read property "staffid" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 179
ERROR - 2024-08-12 11:54:10 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 247
ERROR - 2024-08-12 11:54:10 --> Severity: Warning --> Attempt to read property "profile_image" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 274
ERROR - 2024-08-12 11:54:10 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 194
ERROR - 2024-08-12 11:54:10 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:54:10 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:54:10 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:54:10 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:54:10 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:54:10 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:54:10 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:54:10 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:54:10 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:54:10 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:54:10 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:54:10 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:54:10 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:54:10 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:54:10 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:54:10 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:54:10 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:54:10 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:54:10 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:54:10 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:54:10 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:54:10 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:54:10 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:54:10 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:54:10 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:54:10 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:54:10 --> Severity: error --> Exception: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND `end_time` IS NULL' at line 3 C:\xampp\htdocs\perfex_crm\system\database\drivers\mysqli\mysqli_driver.php 307
ERROR - 2024-08-12 11:56:40 --> init client assets
ERROR - 2024-08-12 11:56:42 --> init client assets
ERROR - 2024-08-12 11:56:47 --> init client assets
ERROR - 2024-08-12 11:56:48 --> init client assets
ERROR - 2024-08-12 11:56:51 --> Could not find the language line "Onboarding"
ERROR - 2024-08-12 11:56:53 --> Could not find the language line "Onboarding"
ERROR - 2024-08-12 11:56:53 --> Could not find the language line "Invite Friend"
ERROR - 2024-08-12 11:56:53 --> Could not find the language line "Join our private Facebook group"
ERROR - 2024-08-12 11:56:53 --> Could not find the language line "group dedicated specifically for ambassadors. In the group, you'll get access to other successful ambassadors, learn the latest marketing strategies, get help from our support team, and stay informed on all the latest product updates."
ERROR - 2024-08-12 11:56:53 --> Could not find the language line "Sign Up for Alerts"
ERROR - 2024-08-12 11:56:53 --> Could not find the language line "Sign up for our email alerts to stay informed about the latest updates, opportunities, and important information."
ERROR - 2024-08-12 11:56:53 --> Could not find the language line "Complete and Continue"
ERROR - 2024-08-12 11:56:53 --> Could not find the language line "Continue"
ERROR - 2024-08-12 11:56:53 --> Could not find the language line "Onboarding Progress"
ERROR - 2024-08-12 11:56:53 --> Could not find the language line "Watch welcome message"
ERROR - 2024-08-12 11:56:53 --> Could not find the language line "Join Facebook group"
ERROR - 2024-08-12 11:56:53 --> Could not find the language line "Sign up for email alerts"
ERROR - 2024-08-12 11:56:53 --> Could not find the language line "Watch portal walkthrough"
ERROR - 2024-08-12 11:56:53 --> Could not find the language line "Understand the opportunity"
ERROR - 2024-08-12 11:56:53 --> Could not find the language line "Review available products"
ERROR - 2024-08-12 11:56:53 --> Could not find the language line "Who do you want to invite?"
ERROR - 2024-08-12 11:56:53 --> Could not find the language line "Send Invitation"
ERROR - 2024-08-12 11:56:53 --> Could not find the language line "Sign Up for Alerts"
ERROR - 2024-08-12 11:56:53 --> Could not find the language line "<i class="fa fa-exclamation-circle tw-mr-1"></i> We'll never send marketing emails through these alerts. These email alerts are strictly to inform you about Ambassador Program latest updates."
ERROR - 2024-08-12 11:56:53 --> Could not find the language line "Sign Up and Continue"
ERROR - 2024-08-12 11:56:53 --> Could not find the language line "Invitation sent!"
ERROR - 2024-08-12 11:56:54 --> Could not find the language line "New Prospect"
ERROR - 2024-08-12 11:56:54 --> Could not find the language line "Search Prospects"
ERROR - 2024-08-12 11:56:54 --> Could not find the language line "Filter By"
ERROR - 2024-08-12 11:56:54 --> Could not find the language line "Active Prospects"
ERROR - 2024-08-12 11:56:54 --> Could not find the language line "Inactive Prospects"
ERROR - 2024-08-12 11:56:54 --> Could not find the language line "Name"
ERROR - 2024-08-12 11:56:54 --> Could not find the language line "Status Id"
ERROR - 2024-08-12 11:56:54 --> Could not find the language line "Type Id"
ERROR - 2024-08-12 11:56:54 --> Could not find the language line "Category Id"
ERROR - 2024-08-12 11:56:54 --> Could not find the language line "Acquisition Channels Id"
ERROR - 2024-08-12 11:56:54 --> Could not find the language line "Industry Id"
ERROR - 2024-08-12 11:56:54 --> Could not find the language line "Actions"
ERROR - 2024-08-12 11:57:08 --> init client assets
ERROR - 2024-08-12 11:57:13 --> init client assets
ERROR - 2024-08-12 11:57:20 --> Could not find the language line "total_campaigns"
ERROR - 2024-08-12 11:57:20 --> Could not find the language line "total_prospects"
ERROR - 2024-08-12 11:57:20 --> Could not find the language line "prospects_average_cost"
ERROR - 2024-08-12 11:57:20 --> Could not find the language line "reported_prospects"
ERROR - 2024-08-12 11:57:45 --> init client assets
ERROR - 2024-08-12 11:57:51 --> init client assets
ERROR - 2024-08-12 11:57:57 --> Could not find the language line "New Prospect"
ERROR - 2024-08-12 11:57:57 --> Could not find the language line "Search Prospects"
ERROR - 2024-08-12 11:57:57 --> Could not find the language line "Filter By"
ERROR - 2024-08-12 11:57:57 --> Could not find the language line "Active Prospects"
ERROR - 2024-08-12 11:57:57 --> Could not find the language line "Inactive Prospects"
ERROR - 2024-08-12 11:57:57 --> Could not find the language line "No prospects found."
ERROR - 2024-08-12 11:59:13 --> init client assets
ERROR - 2024-08-12 11:59:18 --> init client assets
ERROR - 2024-08-12 11:59:24 --> Severity: Warning --> Attempt to read property "permissions" on array C:\xampp\htdocs\perfex_crm\application\helpers\admin_helper.php 130
ERROR - 2024-08-12 11:59:24 --> Severity: Warning --> Attempt to read property "permissions" on array C:\xampp\htdocs\perfex_crm\application\helpers\admin_helper.php 130
ERROR - 2024-08-12 11:59:25 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 326
ERROR - 2024-08-12 11:59:25 --> Severity: Warning --> Attempt to read property "is_not_staff" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 381
ERROR - 2024-08-12 11:59:25 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 326
ERROR - 2024-08-12 11:59:25 --> Severity: Warning --> Attempt to read property "is_not_staff" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 381
ERROR - 2024-08-12 11:59:25 --> Severity: Warning --> Attempt to read property "permissions" on array C:\xampp\htdocs\perfex_crm\application\helpers\admin_helper.php 130
ERROR - 2024-08-12 11:59:25 --> Severity: Warning --> Attempt to read property "total_unread_notifications" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\head.php 18
ERROR - 2024-08-12 11:59:26 --> Severity: Warning --> Attempt to read property "is_not_staff" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 381
ERROR - 2024-08-12 11:59:26 --> Severity: Warning --> Attempt to read property "is_not_staff" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 381
ERROR - 2024-08-12 11:59:26 --> Severity: Warning --> Attempt to read property "total_unfinished_todos" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 169
ERROR - 2024-08-12 11:59:26 --> Severity: Warning --> Attempt to read property "total_unfinished_todos" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 170
ERROR - 2024-08-12 11:59:26 --> Severity: Warning --> Attempt to read property "firstname" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 298
ERROR - 2024-08-12 11:59:26 --> Severity: Warning --> Attempt to read property "lastname" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 298
ERROR - 2024-08-12 11:59:26 --> Severity: Warning --> Attempt to read property "staffid" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 179
ERROR - 2024-08-12 11:59:26 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 247
ERROR - 2024-08-12 11:59:26 --> Severity: Warning --> Attempt to read property "profile_image" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 274
ERROR - 2024-08-12 11:59:26 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 194
ERROR - 2024-08-12 11:59:26 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:59:26 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:59:26 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:59:26 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:59:26 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:59:26 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:59:26 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:59:26 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:59:26 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:59:26 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:59:26 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:59:26 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:59:26 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:59:26 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:59:26 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:59:26 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:59:26 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:59:26 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:59:26 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:59:27 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:59:27 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:59:27 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:59:27 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:59:27 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:59:27 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:59:27 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 11:59:28 --> Severity: error --> Exception: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND `end_time` IS NULL' at line 3 C:\xampp\htdocs\perfex_crm\system\database\drivers\mysqli\mysqli_driver.php 307
ERROR - 2024-08-12 12:00:00 --> init client assets
ERROR - 2024-08-12 12:00:06 --> init client assets
ERROR - 2024-08-12 12:00:12 --> Severity: Warning --> Attempt to read property "permissions" on array C:\xampp\htdocs\perfex_crm\application\helpers\admin_helper.php 130
ERROR - 2024-08-12 12:00:12 --> Severity: Warning --> Attempt to read property "permissions" on array C:\xampp\htdocs\perfex_crm\application\helpers\admin_helper.php 130
ERROR - 2024-08-12 12:00:12 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 326
ERROR - 2024-08-12 12:00:12 --> Severity: Warning --> Attempt to read property "is_not_staff" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 381
ERROR - 2024-08-12 12:00:12 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 326
ERROR - 2024-08-12 12:00:12 --> Severity: Warning --> Attempt to read property "is_not_staff" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 381
ERROR - 2024-08-12 12:00:12 --> Severity: Warning --> Attempt to read property "permissions" on array C:\xampp\htdocs\perfex_crm\application\helpers\admin_helper.php 130
ERROR - 2024-08-12 12:00:12 --> Severity: Warning --> Attempt to read property "total_unread_notifications" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\head.php 18
ERROR - 2024-08-12 12:00:13 --> Severity: Warning --> Attempt to read property "is_not_staff" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 381
ERROR - 2024-08-12 12:00:13 --> Severity: Warning --> Attempt to read property "is_not_staff" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 381
ERROR - 2024-08-12 12:00:13 --> Severity: Warning --> Attempt to read property "total_unfinished_todos" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 169
ERROR - 2024-08-12 12:00:13 --> Severity: Warning --> Attempt to read property "total_unfinished_todos" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 170
ERROR - 2024-08-12 12:00:13 --> Severity: Warning --> Attempt to read property "firstname" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 298
ERROR - 2024-08-12 12:00:13 --> Severity: Warning --> Attempt to read property "lastname" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 298
ERROR - 2024-08-12 12:00:13 --> Severity: Warning --> Attempt to read property "staffid" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 179
ERROR - 2024-08-12 12:00:13 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 247
ERROR - 2024-08-12 12:00:13 --> Severity: Warning --> Attempt to read property "profile_image" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 274
ERROR - 2024-08-12 12:00:13 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 194
ERROR - 2024-08-12 12:00:13 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:00:13 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:00:13 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:00:13 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:00:13 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:00:13 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:00:13 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:00:13 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:00:13 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:00:13 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:00:13 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:00:13 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:00:13 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:00:13 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:00:13 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:00:13 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:00:13 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:00:13 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:00:13 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:00:13 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:00:13 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:00:13 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:00:13 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:00:13 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:00:13 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:00:13 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:00:13 --> Severity: error --> Exception: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND `end_time` IS NULL' at line 3 C:\xampp\htdocs\perfex_crm\system\database\drivers\mysqli\mysqli_driver.php 307
ERROR - 2024-08-12 12:00:42 --> init client assets
ERROR - 2024-08-12 12:00:47 --> init client assets
ERROR - 2024-08-12 12:00:52 --> Could not find the language line "total_campaigns"
ERROR - 2024-08-12 12:00:52 --> Could not find the language line "total_prospects"
ERROR - 2024-08-12 12:00:52 --> Could not find the language line "prospects_average_cost"
ERROR - 2024-08-12 12:00:52 --> Could not find the language line "reported_prospects"
ERROR - 2024-08-12 12:01:16 --> init client assets
ERROR - 2024-08-12 12:01:21 --> init client assets
ERROR - 2024-08-12 12:01:27 --> Severity: Warning --> Attempt to read property "permissions" on array C:\xampp\htdocs\perfex_crm\application\helpers\admin_helper.php 130
ERROR - 2024-08-12 12:01:27 --> Severity: Warning --> Attempt to read property "permissions" on array C:\xampp\htdocs\perfex_crm\application\helpers\admin_helper.php 130
ERROR - 2024-08-12 12:01:28 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 326
ERROR - 2024-08-12 12:01:28 --> Severity: Warning --> Attempt to read property "is_not_staff" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 381
ERROR - 2024-08-12 12:01:28 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 326
ERROR - 2024-08-12 12:01:28 --> Severity: Warning --> Attempt to read property "is_not_staff" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 381
ERROR - 2024-08-12 12:01:28 --> Severity: Warning --> Attempt to read property "permissions" on array C:\xampp\htdocs\perfex_crm\application\helpers\admin_helper.php 130
ERROR - 2024-08-12 12:01:28 --> Severity: Warning --> Attempt to read property "total_unread_notifications" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\head.php 18
ERROR - 2024-08-12 12:01:29 --> Severity: Warning --> Attempt to read property "is_not_staff" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 381
ERROR - 2024-08-12 12:01:29 --> Severity: Warning --> Attempt to read property "is_not_staff" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 381
ERROR - 2024-08-12 12:01:29 --> Severity: Warning --> Attempt to read property "total_unfinished_todos" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 169
ERROR - 2024-08-12 12:01:29 --> Severity: Warning --> Attempt to read property "total_unfinished_todos" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 170
ERROR - 2024-08-12 12:01:29 --> Severity: Warning --> Attempt to read property "firstname" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 298
ERROR - 2024-08-12 12:01:29 --> Severity: Warning --> Attempt to read property "lastname" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 298
ERROR - 2024-08-12 12:01:29 --> Severity: Warning --> Attempt to read property "staffid" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 179
ERROR - 2024-08-12 12:01:29 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 247
ERROR - 2024-08-12 12:01:29 --> Severity: Warning --> Attempt to read property "profile_image" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 274
ERROR - 2024-08-12 12:01:29 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 194
ERROR - 2024-08-12 12:01:29 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:01:29 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:01:29 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:01:29 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:01:29 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:01:29 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:01:29 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:01:29 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:01:29 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:01:29 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:01:29 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:01:29 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:01:29 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:01:29 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:01:29 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:01:29 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:01:29 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:01:29 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:01:29 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:01:29 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:01:29 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:01:29 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:01:29 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:01:29 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:01:29 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:01:29 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:01:29 --> Severity: error --> Exception: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND `end_time` IS NULL' at line 3 C:\xampp\htdocs\perfex_crm\system\database\drivers\mysqli\mysqli_driver.php 307
ERROR - 2024-08-12 12:03:17 --> init client assets
ERROR - 2024-08-12 12:03:22 --> init client assets
ERROR - 2024-08-12 12:03:28 --> Severity: Warning --> Attempt to read property "permissions" on array C:\xampp\htdocs\perfex_crm\application\helpers\admin_helper.php 130
ERROR - 2024-08-12 12:03:28 --> Severity: Warning --> Attempt to read property "permissions" on array C:\xampp\htdocs\perfex_crm\application\helpers\admin_helper.php 130
ERROR - 2024-08-12 12:03:29 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 326
ERROR - 2024-08-12 12:03:29 --> Severity: Warning --> Attempt to read property "is_not_staff" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 381
ERROR - 2024-08-12 12:03:29 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 326
ERROR - 2024-08-12 12:03:29 --> Severity: Warning --> Attempt to read property "is_not_staff" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 381
ERROR - 2024-08-12 12:03:29 --> Severity: Warning --> Attempt to read property "permissions" on array C:\xampp\htdocs\perfex_crm\application\helpers\admin_helper.php 130
ERROR - 2024-08-12 12:03:29 --> Severity: Warning --> Attempt to read property "total_unread_notifications" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\head.php 18
ERROR - 2024-08-12 12:03:29 --> Severity: Warning --> Attempt to read property "is_not_staff" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 381
ERROR - 2024-08-12 12:03:29 --> Severity: Warning --> Attempt to read property "is_not_staff" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 381
ERROR - 2024-08-12 12:03:29 --> Severity: Warning --> Attempt to read property "total_unfinished_todos" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 169
ERROR - 2024-08-12 12:03:29 --> Severity: Warning --> Attempt to read property "total_unfinished_todos" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 170
ERROR - 2024-08-12 12:03:29 --> Severity: Warning --> Attempt to read property "firstname" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 298
ERROR - 2024-08-12 12:03:29 --> Severity: Warning --> Attempt to read property "lastname" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 298
ERROR - 2024-08-12 12:03:29 --> Severity: Warning --> Attempt to read property "staffid" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 179
ERROR - 2024-08-12 12:03:29 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 247
ERROR - 2024-08-12 12:03:29 --> Severity: Warning --> Attempt to read property "profile_image" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 274
ERROR - 2024-08-12 12:03:29 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 194
ERROR - 2024-08-12 12:03:29 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:03:29 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:03:29 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:03:29 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:03:29 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:03:29 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:03:29 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:03:29 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:03:29 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:03:29 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:03:29 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:03:29 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:03:30 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:03:30 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:03:30 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:03:30 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:03:30 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:03:30 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:03:30 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:03:30 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:03:30 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:03:30 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:03:30 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:03:30 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:03:30 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:03:30 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:03:30 --> Severity: error --> Exception: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND `end_time` IS NULL' at line 3 C:\xampp\htdocs\perfex_crm\system\database\drivers\mysqli\mysqli_driver.php 307
ERROR - 2024-08-12 12:09:09 --> init client assets
ERROR - 2024-08-12 12:09:14 --> init client assets
ERROR - 2024-08-12 12:09:21 --> Severity: Warning --> Attempt to read property "permissions" on array C:\xampp\htdocs\perfex_crm\application\helpers\admin_helper.php 130
ERROR - 2024-08-12 12:09:21 --> Severity: Warning --> Attempt to read property "permissions" on array C:\xampp\htdocs\perfex_crm\application\helpers\admin_helper.php 130
ERROR - 2024-08-12 12:09:21 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 326
ERROR - 2024-08-12 12:09:21 --> Severity: Warning --> Attempt to read property "is_not_staff" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 381
ERROR - 2024-08-12 12:09:21 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 326
ERROR - 2024-08-12 12:09:21 --> Severity: Warning --> Attempt to read property "is_not_staff" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 381
ERROR - 2024-08-12 12:09:21 --> Severity: Warning --> Attempt to read property "permissions" on array C:\xampp\htdocs\perfex_crm\application\helpers\admin_helper.php 130
ERROR - 2024-08-12 12:09:22 --> Severity: Warning --> Attempt to read property "total_unread_notifications" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\head.php 18
ERROR - 2024-08-12 12:09:22 --> Severity: Warning --> Attempt to read property "is_not_staff" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 381
ERROR - 2024-08-12 12:09:22 --> Severity: Warning --> Attempt to read property "is_not_staff" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 381
ERROR - 2024-08-12 12:09:22 --> Severity: Warning --> Attempt to read property "total_unfinished_todos" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 169
ERROR - 2024-08-12 12:09:22 --> Severity: Warning --> Attempt to read property "total_unfinished_todos" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 170
ERROR - 2024-08-12 12:09:22 --> Severity: Warning --> Attempt to read property "firstname" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 298
ERROR - 2024-08-12 12:09:22 --> Severity: Warning --> Attempt to read property "lastname" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 298
ERROR - 2024-08-12 12:09:22 --> Severity: Warning --> Attempt to read property "staffid" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 179
ERROR - 2024-08-12 12:09:22 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 247
ERROR - 2024-08-12 12:09:22 --> Severity: Warning --> Attempt to read property "profile_image" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 274
ERROR - 2024-08-12 12:09:22 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 194
ERROR - 2024-08-12 12:09:22 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:09:22 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:09:22 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:09:22 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:09:22 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:09:22 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:09:22 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:09:22 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:09:22 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:09:22 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:09:22 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:09:22 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:09:22 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:09:22 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:09:22 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:09:22 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:09:22 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:09:22 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:09:22 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:09:22 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:09:22 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:09:22 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:09:22 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:09:22 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:09:22 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:09:22 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:09:23 --> Severity: error --> Exception: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND `end_time` IS NULL' at line 3 C:\xampp\htdocs\perfex_crm\system\database\drivers\mysqli\mysqli_driver.php 307
ERROR - 2024-08-12 12:12:46 --> init client assets
ERROR - 2024-08-12 12:12:51 --> init client assets
ERROR - 2024-08-12 09:12:57 --> 404 Page Not Found: admin/Prospects/reported
ERROR - 2024-08-12 12:12:57 --> Severity: Warning --> Attempt to read property "permissions" on array C:\xampp\htdocs\perfex_crm\application\helpers\admin_helper.php 130
ERROR - 2024-08-12 12:12:57 --> Severity: Warning --> Attempt to read property "permissions" on array C:\xampp\htdocs\perfex_crm\application\helpers\admin_helper.php 130
ERROR - 2024-08-12 12:12:58 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 326
ERROR - 2024-08-12 12:12:58 --> Severity: Warning --> Attempt to read property "is_not_staff" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 381
ERROR - 2024-08-12 12:12:58 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 326
ERROR - 2024-08-12 12:12:58 --> Severity: Warning --> Attempt to read property "is_not_staff" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 381
ERROR - 2024-08-12 12:12:58 --> Severity: Warning --> Attempt to read property "permissions" on array C:\xampp\htdocs\perfex_crm\application\helpers\admin_helper.php 130
ERROR - 2024-08-12 12:12:58 --> Severity: Warning --> Attempt to read property "total_unread_notifications" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\head.php 18
ERROR - 2024-08-12 12:12:59 --> Severity: Warning --> Attempt to read property "is_not_staff" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 381
ERROR - 2024-08-12 12:12:59 --> Severity: Warning --> Attempt to read property "is_not_staff" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 381
ERROR - 2024-08-12 12:12:59 --> Severity: Warning --> Attempt to read property "total_unfinished_todos" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 169
ERROR - 2024-08-12 12:12:59 --> Severity: Warning --> Attempt to read property "total_unfinished_todos" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 170
ERROR - 2024-08-12 12:12:59 --> Severity: Warning --> Attempt to read property "firstname" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 298
ERROR - 2024-08-12 12:12:59 --> Severity: Warning --> Attempt to read property "lastname" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 298
ERROR - 2024-08-12 12:12:59 --> Severity: Warning --> Attempt to read property "staffid" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 179
ERROR - 2024-08-12 12:12:59 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 247
ERROR - 2024-08-12 12:12:59 --> Severity: Warning --> Attempt to read property "profile_image" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 274
ERROR - 2024-08-12 12:12:59 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 194
ERROR - 2024-08-12 12:12:59 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:12:59 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:12:59 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:12:59 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:12:59 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:12:59 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:12:59 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:12:59 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:12:59 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:12:59 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:12:59 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:12:59 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:12:59 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:12:59 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:12:59 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:12:59 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:12:59 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:12:59 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:12:59 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:12:59 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:12:59 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:12:59 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:12:59 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:12:59 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:12:59 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:12:59 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:12:59 --> Severity: error --> Exception: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND `end_time` IS NULL' at line 3 C:\xampp\htdocs\perfex_crm\system\database\drivers\mysqli\mysqli_driver.php 307
ERROR - 2024-08-12 09:13:08 --> 404 Page Not Found: admin/Prospects/reports.php
ERROR - 2024-08-12 09:13:11 --> 404 Page Not Found: admin/Prospects/reports
ERROR - 2024-08-12 12:13:28 --> Could not find the language line "billings"
ERROR - 2024-08-12 12:13:29 --> Could not find the language line "billings"
ERROR - 2024-08-12 12:13:36 --> Could not find the language line "Name"
ERROR - 2024-08-12 12:13:36 --> Could not find the language line "Status Id"
ERROR - 2024-08-12 12:13:36 --> Could not find the language line "Type Id"
ERROR - 2024-08-12 12:13:36 --> Could not find the language line "Category Id"
ERROR - 2024-08-12 12:13:36 --> Could not find the language line "Acquisition Channels Id"
ERROR - 2024-08-12 12:13:36 --> Could not find the language line "Industry Id"
ERROR - 2024-08-12 12:13:36 --> Could not find the language line "Status"
ERROR - 2024-08-12 12:13:36 --> Could not find the language line "Actions"
ERROR - 2024-08-12 12:13:39 --> Could not find the language line "source_name"
ERROR - 2024-08-12 12:13:39 --> Severity: Warning --> Undefined array key "source_name" C:\xampp\htdocs\perfex_crm\modules\leads_reporting\views\index.php 198
ERROR - 2024-08-12 12:13:39 --> Severity: Warning --> Undefined array key "source_name" C:\xampp\htdocs\perfex_crm\modules\leads_reporting\views\index.php 198
ERROR - 2024-08-12 12:14:53 --> Could not find the language line "billings"
ERROR - 2024-08-12 12:15:53 --> Could not find the language line "billings"
ERROR - 2024-08-12 12:16:14 --> init client assets
ERROR - 2024-08-12 12:16:19 --> init client assets
ERROR - 2024-08-12 12:16:53 --> Could not find the language line "billings"
ERROR - 2024-08-12 12:16:53 --> init client assets
ERROR - 2024-08-12 12:16:58 --> init client assets
ERROR - 2024-08-12 12:17:04 --> Severity: Warning --> Attempt to read property "permissions" on array C:\xampp\htdocs\perfex_crm\application\helpers\admin_helper.php 130
ERROR - 2024-08-12 12:17:04 --> Severity: Warning --> Attempt to read property "permissions" on array C:\xampp\htdocs\perfex_crm\application\helpers\admin_helper.php 130
ERROR - 2024-08-12 12:17:04 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 326
ERROR - 2024-08-12 12:17:04 --> Severity: Warning --> Attempt to read property "is_not_staff" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 381
ERROR - 2024-08-12 12:17:04 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 326
ERROR - 2024-08-12 12:17:05 --> Severity: Warning --> Attempt to read property "is_not_staff" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 381
ERROR - 2024-08-12 12:17:05 --> Severity: Warning --> Attempt to read property "permissions" on array C:\xampp\htdocs\perfex_crm\application\helpers\admin_helper.php 130
ERROR - 2024-08-12 12:17:05 --> Severity: Warning --> Attempt to read property "total_unread_notifications" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\head.php 18
ERROR - 2024-08-12 12:17:05 --> Severity: Warning --> Attempt to read property "is_not_staff" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 381
ERROR - 2024-08-12 12:17:05 --> Severity: Warning --> Attempt to read property "is_not_staff" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 381
ERROR - 2024-08-12 12:17:05 --> Severity: Warning --> Attempt to read property "total_unfinished_todos" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 169
ERROR - 2024-08-12 12:17:05 --> Severity: Warning --> Attempt to read property "total_unfinished_todos" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 170
ERROR - 2024-08-12 12:17:05 --> Severity: Warning --> Attempt to read property "firstname" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 298
ERROR - 2024-08-12 12:17:05 --> Severity: Warning --> Attempt to read property "lastname" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 298
ERROR - 2024-08-12 12:17:05 --> Severity: Warning --> Attempt to read property "staffid" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 179
ERROR - 2024-08-12 12:17:05 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 247
ERROR - 2024-08-12 12:17:05 --> Severity: Warning --> Attempt to read property "profile_image" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 274
ERROR - 2024-08-12 12:17:05 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 194
ERROR - 2024-08-12 12:17:05 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:17:05 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:17:05 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:17:05 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:17:05 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:17:05 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:17:05 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:17:05 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:17:05 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:17:05 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:17:05 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:17:05 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:17:05 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:17:05 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:17:05 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:17:05 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:17:05 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:17:05 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:17:05 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:17:05 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:17:05 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:17:05 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:17:05 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:17:05 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:17:05 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:17:05 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:17:06 --> Severity: error --> Exception: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND `end_time` IS NULL' at line 3 C:\xampp\htdocs\perfex_crm\system\database\drivers\mysqli\mysqli_driver.php 307
ERROR - 2024-08-12 12:17:36 --> init client assets
ERROR - 2024-08-12 12:17:41 --> init client assets
ERROR - 2024-08-12 12:17:47 --> Severity: Warning --> Attempt to read property "permissions" on array C:\xampp\htdocs\perfex_crm\application\helpers\admin_helper.php 130
ERROR - 2024-08-12 12:17:47 --> Severity: Warning --> Attempt to read property "permissions" on array C:\xampp\htdocs\perfex_crm\application\helpers\admin_helper.php 130
ERROR - 2024-08-12 12:17:48 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 326
ERROR - 2024-08-12 12:17:48 --> Severity: Warning --> Attempt to read property "is_not_staff" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 381
ERROR - 2024-08-12 12:17:48 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 326
ERROR - 2024-08-12 12:17:48 --> Severity: Warning --> Attempt to read property "is_not_staff" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 381
ERROR - 2024-08-12 12:17:48 --> Severity: Warning --> Attempt to read property "permissions" on array C:\xampp\htdocs\perfex_crm\application\helpers\admin_helper.php 130
ERROR - 2024-08-12 12:17:48 --> Severity: Warning --> Attempt to read property "total_unread_notifications" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\head.php 18
ERROR - 2024-08-12 12:17:48 --> Severity: Warning --> Attempt to read property "is_not_staff" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 381
ERROR - 2024-08-12 12:17:48 --> Severity: Warning --> Attempt to read property "is_not_staff" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 381
ERROR - 2024-08-12 12:17:48 --> Severity: Warning --> Attempt to read property "total_unfinished_todos" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 169
ERROR - 2024-08-12 12:17:48 --> Severity: Warning --> Attempt to read property "total_unfinished_todos" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 170
ERROR - 2024-08-12 12:17:48 --> Severity: Warning --> Attempt to read property "firstname" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 298
ERROR - 2024-08-12 12:17:48 --> Severity: Warning --> Attempt to read property "lastname" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 298
ERROR - 2024-08-12 12:17:48 --> Severity: Warning --> Attempt to read property "staffid" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 179
ERROR - 2024-08-12 12:17:48 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 247
ERROR - 2024-08-12 12:17:48 --> Severity: Warning --> Attempt to read property "profile_image" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 274
ERROR - 2024-08-12 12:17:48 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 194
ERROR - 2024-08-12 12:17:48 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:17:48 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:17:48 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:17:48 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:17:48 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:17:48 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:17:48 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:17:48 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:17:48 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:17:48 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:17:48 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:17:48 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:17:48 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:17:48 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:17:48 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:17:48 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:17:48 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:17:48 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:17:48 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:17:48 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:17:48 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:17:48 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:17:48 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:17:48 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:17:48 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:17:48 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:17:49 --> Severity: error --> Exception: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND `end_time` IS NULL' at line 3 C:\xampp\htdocs\perfex_crm\system\database\drivers\mysqli\mysqli_driver.php 307
ERROR - 2024-08-12 12:17:53 --> Could not find the language line "billings"
ERROR - 2024-08-12 12:18:53 --> Could not find the language line "billings"
ERROR - 2024-08-12 12:19:52 --> Could not find the language line "billings"
ERROR - 2024-08-12 12:20:40 --> init client assets
ERROR - 2024-08-12 12:20:45 --> init client assets
ERROR - 2024-08-12 12:20:51 --> Severity: Warning --> Attempt to read property "permissions" on array C:\xampp\htdocs\perfex_crm\application\helpers\admin_helper.php 130
ERROR - 2024-08-12 12:20:51 --> Severity: Warning --> Attempt to read property "permissions" on array C:\xampp\htdocs\perfex_crm\application\helpers\admin_helper.php 130
ERROR - 2024-08-12 12:20:51 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 326
ERROR - 2024-08-12 12:20:51 --> Severity: Warning --> Attempt to read property "is_not_staff" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 381
ERROR - 2024-08-12 12:20:51 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 326
ERROR - 2024-08-12 12:20:52 --> Severity: Warning --> Attempt to read property "is_not_staff" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 381
ERROR - 2024-08-12 12:20:52 --> Severity: Warning --> Attempt to read property "permissions" on array C:\xampp\htdocs\perfex_crm\application\helpers\admin_helper.php 130
ERROR - 2024-08-12 12:20:52 --> Severity: Warning --> Attempt to read property "total_unread_notifications" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\head.php 18
ERROR - 2024-08-12 12:20:53 --> Severity: Warning --> Attempt to read property "is_not_staff" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 381
ERROR - 2024-08-12 12:20:53 --> Severity: Warning --> Attempt to read property "is_not_staff" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 381
ERROR - 2024-08-12 12:20:53 --> Severity: Warning --> Attempt to read property "total_unfinished_todos" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 169
ERROR - 2024-08-12 12:20:53 --> Severity: Warning --> Attempt to read property "total_unfinished_todos" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 170
ERROR - 2024-08-12 12:20:53 --> Severity: Warning --> Attempt to read property "firstname" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 298
ERROR - 2024-08-12 12:20:53 --> Severity: Warning --> Attempt to read property "lastname" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 298
ERROR - 2024-08-12 12:20:53 --> Severity: Warning --> Attempt to read property "staffid" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 179
ERROR - 2024-08-12 12:20:53 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 247
ERROR - 2024-08-12 12:20:53 --> Severity: Warning --> Attempt to read property "profile_image" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 274
ERROR - 2024-08-12 12:20:53 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 194
ERROR - 2024-08-12 12:20:53 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:20:53 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:20:53 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:20:53 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:20:53 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:20:53 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:20:53 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:20:53 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:20:53 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:20:53 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:20:53 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:20:53 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:20:53 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:20:53 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:20:53 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:20:53 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:20:53 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:20:53 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:20:54 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:20:54 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:20:54 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:20:54 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:20:54 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:20:54 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:20:54 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:20:54 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:20:54 --> Severity: error --> Exception: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND `end_time` IS NULL' at line 3 C:\xampp\htdocs\perfex_crm\system\database\drivers\mysqli\mysqli_driver.php 307
ERROR - 2024-08-12 12:21:05 --> Could not find the language line "billings"
ERROR - 2024-08-12 12:22:00 --> Could not find the language line "billings"
ERROR - 2024-08-12 12:22:11 --> init client assets
ERROR - 2024-08-12 12:22:12 --> init client assets
ERROR - 2024-08-12 12:22:17 --> init client assets
ERROR - 2024-08-12 12:22:18 --> init client assets
ERROR - 2024-08-12 12:22:23 --> Severity: Warning --> Attempt to read property "permissions" on array C:\xampp\htdocs\perfex_crm\application\helpers\admin_helper.php 130
ERROR - 2024-08-12 12:22:23 --> Severity: Warning --> Attempt to read property "permissions" on array C:\xampp\htdocs\perfex_crm\application\helpers\admin_helper.php 130
ERROR - 2024-08-12 12:22:23 --> Severity: Warning --> Attempt to read property "permissions" on array C:\xampp\htdocs\perfex_crm\application\helpers\admin_helper.php 130
ERROR - 2024-08-12 12:22:23 --> Severity: Warning --> Attempt to read property "permissions" on array C:\xampp\htdocs\perfex_crm\application\helpers\admin_helper.php 130
ERROR - 2024-08-12 12:22:23 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 326
ERROR - 2024-08-12 12:22:23 --> Severity: Warning --> Attempt to read property "is_not_staff" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 381
ERROR - 2024-08-12 12:22:23 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 326
ERROR - 2024-08-12 12:22:24 --> Severity: Warning --> Attempt to read property "is_not_staff" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 381
ERROR - 2024-08-12 12:22:24 --> Severity: Warning --> Attempt to read property "permissions" on array C:\xampp\htdocs\perfex_crm\application\helpers\admin_helper.php 130
ERROR - 2024-08-12 12:22:24 --> Severity: Warning --> Attempt to read property "total_unread_notifications" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\head.php 18
ERROR - 2024-08-12 12:22:24 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 326
ERROR - 2024-08-12 12:22:24 --> Severity: Warning --> Attempt to read property "is_not_staff" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 381
ERROR - 2024-08-12 12:22:24 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 326
ERROR - 2024-08-12 12:22:24 --> Severity: Warning --> Attempt to read property "is_not_staff" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 381
ERROR - 2024-08-12 12:22:24 --> Severity: Warning --> Attempt to read property "permissions" on array C:\xampp\htdocs\perfex_crm\application\helpers\admin_helper.php 130
ERROR - 2024-08-12 12:22:24 --> Severity: Warning --> Attempt to read property "total_unread_notifications" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\head.php 18
ERROR - 2024-08-12 12:22:24 --> Severity: Warning --> Attempt to read property "is_not_staff" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 381
ERROR - 2024-08-12 12:22:24 --> Severity: Warning --> Attempt to read property "is_not_staff" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 381
ERROR - 2024-08-12 12:22:24 --> Severity: Warning --> Attempt to read property "total_unfinished_todos" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 169
ERROR - 2024-08-12 12:22:24 --> Severity: Warning --> Attempt to read property "total_unfinished_todos" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 170
ERROR - 2024-08-12 12:22:24 --> Severity: Warning --> Attempt to read property "firstname" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 298
ERROR - 2024-08-12 12:22:24 --> Severity: Warning --> Attempt to read property "lastname" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 298
ERROR - 2024-08-12 12:22:24 --> Severity: Warning --> Attempt to read property "staffid" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 179
ERROR - 2024-08-12 12:22:24 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 247
ERROR - 2024-08-12 12:22:24 --> Severity: Warning --> Attempt to read property "profile_image" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 274
ERROR - 2024-08-12 12:22:24 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 194
ERROR - 2024-08-12 12:22:24 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:22:24 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:22:24 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:22:24 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:22:24 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:22:24 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:22:24 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:22:24 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:22:24 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:22:24 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:22:24 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:22:24 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:22:24 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:22:24 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:22:24 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:22:24 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:22:24 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:22:24 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:22:24 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:22:24 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:22:24 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:22:24 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:22:24 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:22:24 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:22:24 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:22:24 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:22:25 --> Severity: error --> Exception: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND `end_time` IS NULL' at line 3 C:\xampp\htdocs\perfex_crm\system\database\drivers\mysqli\mysqli_driver.php 307
ERROR - 2024-08-12 12:22:25 --> Severity: Warning --> Attempt to read property "is_not_staff" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 381
ERROR - 2024-08-12 12:22:25 --> Severity: Warning --> Attempt to read property "is_not_staff" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 381
ERROR - 2024-08-12 12:22:25 --> Severity: Warning --> Attempt to read property "total_unfinished_todos" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 169
ERROR - 2024-08-12 12:22:25 --> Severity: Warning --> Attempt to read property "total_unfinished_todos" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 170
ERROR - 2024-08-12 12:22:25 --> Severity: Warning --> Attempt to read property "firstname" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 298
ERROR - 2024-08-12 12:22:25 --> Severity: Warning --> Attempt to read property "lastname" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 298
ERROR - 2024-08-12 12:22:25 --> Severity: Warning --> Attempt to read property "staffid" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 179
ERROR - 2024-08-12 12:22:25 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 247
ERROR - 2024-08-12 12:22:25 --> Severity: Warning --> Attempt to read property "profile_image" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 274
ERROR - 2024-08-12 12:22:25 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 194
ERROR - 2024-08-12 12:22:25 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:22:25 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:22:25 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:22:25 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:22:25 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:22:25 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:22:25 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:22:25 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:22:25 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:22:25 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:22:25 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:22:25 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:22:25 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:22:25 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:22:25 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:22:25 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:22:25 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:22:25 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:22:25 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:22:25 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:22:25 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:22:25 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:22:25 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:22:25 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:22:25 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:22:25 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:22:25 --> Severity: error --> Exception: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND `end_time` IS NULL' at line 3 C:\xampp\htdocs\perfex_crm\system\database\drivers\mysqli\mysqli_driver.php 307
ERROR - 2024-08-12 12:23:02 --> Could not find the language line "billings"
ERROR - 2024-08-12 12:24:02 --> Could not find the language line "billings"
ERROR - 2024-08-12 12:24:21 --> Could not find the language line "billings"
ERROR - 2024-08-12 12:24:37 --> Could not find the language line "billings"
ERROR - 2024-08-12 12:24:38 --> Could not find the language line "billings"
ERROR - 2024-08-12 12:24:45 --> Could not find the language line "Meet Industry's Most Advanced Real Estate Lead Marketplace"
ERROR - 2024-08-12 12:24:45 --> Could not find the language line "Buy Lead"
ERROR - 2024-08-12 12:24:45 --> Could not find the language line "Learn More"
ERROR - 2024-08-12 12:24:45 --> Could not find the language line "Zip Codes"
ERROR - 2024-08-12 12:24:45 --> Could not find the language line "acquisition_channel"
ERROR - 2024-08-12 12:24:45 --> Could not find the language line "Price Range start"
ERROR - 2024-08-12 12:24:45 --> Could not find the language line "Price Range end"
ERROR - 2024-08-12 12:24:45 --> Could not find the language line "From"
ERROR - 2024-08-12 12:24:45 --> Could not find the language line "To"
ERROR - 2024-08-12 12:24:45 --> Could not find the language line "deal"
ERROR - 2024-08-12 12:24:45 --> Could not find the language line "quality"
ERROR - 2024-08-12 12:24:45 --> Could not find the language line "Metadata"
ERROR - 2024-08-12 12:24:45 --> Could not find the language line "Lead"
ERROR - 2024-08-12 12:24:45 --> Could not find the language line "Contact"
ERROR - 2024-08-12 12:24:45 --> Could not find the language line "Lead Type"
ERROR - 2024-08-12 12:24:45 --> Could not find the language line "Actions"
ERROR - 2024-08-12 12:24:45 --> Could not find the language line "Prospect ID"
ERROR - 2024-08-12 12:24:45 --> Could not find the language line "Generated date"
ERROR - 2024-08-12 12:24:45 --> Could not find the language line "Industry"
ERROR - 2024-08-12 12:24:45 --> Could not find the language line "Zip code"
ERROR - 2024-08-12 12:24:45 --> Could not find the language line "Source"
ERROR - 2024-08-12 12:24:45 --> Could not find the language line "Deal"
ERROR - 2024-08-12 12:24:45 --> Could not find the language line "Quality"
ERROR - 2024-08-12 12:24:45 --> Could not find the language line "Quality"
ERROR - 2024-08-12 12:24:45 --> Could not find the language line "Name"
ERROR - 2024-08-12 12:24:45 --> Could not find the language line "Status Id"
ERROR - 2024-08-12 12:24:45 --> Could not find the language line "Type Id"
ERROR - 2024-08-12 12:24:45 --> Could not find the language line "Category Id"
ERROR - 2024-08-12 12:24:45 --> Could not find the language line "Acquisition Channels Id"
ERROR - 2024-08-12 12:24:45 --> Could not find the language line "Industry Id"
ERROR - 2024-08-12 12:24:45 --> Could not find the language line "Status"
ERROR - 2024-08-12 12:24:45 --> Could not find the language line "Actions"
ERROR - 2024-08-12 12:25:06 --> Could not find the language line "billings"
ERROR - 2024-08-12 12:25:14 --> Could not find the language line "No prospects found."
ERROR - 2024-08-12 12:25:27 --> Could not find the language line "billings"
ERROR - 2024-08-12 12:33:54 --> init client assets
ERROR - 2024-08-12 12:33:59 --> init client assets
ERROR - 2024-08-12 12:34:04 --> Severity: Warning --> Attempt to read property "permissions" on array C:\xampp\htdocs\perfex_crm\application\helpers\admin_helper.php 130
ERROR - 2024-08-12 12:34:04 --> Severity: Warning --> Attempt to read property "permissions" on array C:\xampp\htdocs\perfex_crm\application\helpers\admin_helper.php 130
ERROR - 2024-08-12 12:34:05 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 326
ERROR - 2024-08-12 12:34:05 --> Severity: Warning --> Attempt to read property "is_not_staff" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 381
ERROR - 2024-08-12 12:34:05 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 326
ERROR - 2024-08-12 12:34:05 --> Severity: Warning --> Attempt to read property "is_not_staff" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 381
ERROR - 2024-08-12 12:34:05 --> Severity: Warning --> Attempt to read property "permissions" on array C:\xampp\htdocs\perfex_crm\application\helpers\admin_helper.php 130
ERROR - 2024-08-12 12:34:05 --> Severity: Warning --> Attempt to read property "total_unread_notifications" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\head.php 18
ERROR - 2024-08-12 12:34:06 --> Severity: Warning --> Attempt to read property "is_not_staff" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 381
ERROR - 2024-08-12 12:34:06 --> Severity: Warning --> Attempt to read property "is_not_staff" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 381
ERROR - 2024-08-12 12:34:06 --> Severity: Warning --> Attempt to read property "total_unfinished_todos" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 169
ERROR - 2024-08-12 12:34:06 --> Severity: Warning --> Attempt to read property "total_unfinished_todos" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 170
ERROR - 2024-08-12 12:34:06 --> Severity: Warning --> Attempt to read property "firstname" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 298
ERROR - 2024-08-12 12:34:06 --> Severity: Warning --> Attempt to read property "lastname" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 298
ERROR - 2024-08-12 12:34:06 --> Severity: Warning --> Attempt to read property "staffid" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 179
ERROR - 2024-08-12 12:34:06 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 247
ERROR - 2024-08-12 12:34:06 --> Severity: Warning --> Attempt to read property "profile_image" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 274
ERROR - 2024-08-12 12:34:06 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 194
ERROR - 2024-08-12 12:34:06 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:34:06 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:34:06 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:34:06 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:34:06 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:34:06 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:34:06 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:34:06 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:34:06 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:34:06 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:34:06 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:34:06 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:34:06 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:34:06 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:34:06 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:34:06 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:34:06 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:34:06 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:34:06 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:34:06 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:34:06 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:34:06 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:34:06 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:34:06 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:34:06 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:34:06 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:34:07 --> Severity: error --> Exception: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND `end_time` IS NULL' at line 3 C:\xampp\htdocs\perfex_crm\system\database\drivers\mysqli\mysqli_driver.php 307
ERROR - 2024-08-12 12:36:08 --> init client assets
ERROR - 2024-08-12 12:36:13 --> init client assets
ERROR - 2024-08-12 12:36:18 --> Could not find the language line "New Prospect"
ERROR - 2024-08-12 12:36:18 --> Could not find the language line "Search Prospects"
ERROR - 2024-08-12 12:36:18 --> Could not find the language line "Filter By"
ERROR - 2024-08-12 12:36:18 --> Could not find the language line "Active Prospects"
ERROR - 2024-08-12 12:36:19 --> Could not find the language line "Inactive Prospects"
ERROR - 2024-08-12 12:36:19 --> Could not find the language line "No prospects found."
ERROR - 2024-08-12 09:36:49 --> 404 Page Not Found: Prospects/reported
ERROR - 2024-08-12 12:37:04 --> init client assets
ERROR - 2024-08-12 12:37:09 --> init client assets
ERROR - 2024-08-12 12:37:15 --> Could not find the language line "total_campaigns"
ERROR - 2024-08-12 12:37:15 --> Could not find the language line "total_prospects"
ERROR - 2024-08-12 12:37:15 --> Could not find the language line "prospects_average_cost"
ERROR - 2024-08-12 12:37:15 --> Could not find the language line "reported_prospects"
ERROR - 2024-08-12 09:38:41 --> 404 Page Not Found: Prospects/reported
ERROR - 2024-08-12 12:39:35 --> init client assets
ERROR - 2024-08-12 12:39:40 --> init client assets
ERROR - 2024-08-12 12:39:45 --> Severity: Warning --> Attempt to read property "permissions" on array C:\xampp\htdocs\perfex_crm\application\helpers\admin_helper.php 130
ERROR - 2024-08-12 12:39:45 --> Severity: Warning --> Attempt to read property "permissions" on array C:\xampp\htdocs\perfex_crm\application\helpers\admin_helper.php 130
ERROR - 2024-08-12 12:39:46 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 326
ERROR - 2024-08-12 12:39:46 --> Severity: Warning --> Attempt to read property "is_not_staff" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 381
ERROR - 2024-08-12 12:39:46 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 326
ERROR - 2024-08-12 12:39:46 --> Severity: Warning --> Attempt to read property "is_not_staff" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 381
ERROR - 2024-08-12 12:39:46 --> Severity: Warning --> Attempt to read property "permissions" on array C:\xampp\htdocs\perfex_crm\application\helpers\admin_helper.php 130
ERROR - 2024-08-12 12:39:46 --> Severity: Warning --> Attempt to read property "total_unread_notifications" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\head.php 18
ERROR - 2024-08-12 12:39:46 --> Severity: Warning --> Attempt to read property "is_not_staff" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 381
ERROR - 2024-08-12 12:39:46 --> Severity: Warning --> Attempt to read property "is_not_staff" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 381
ERROR - 2024-08-12 12:39:46 --> Severity: Warning --> Attempt to read property "total_unfinished_todos" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 169
ERROR - 2024-08-12 12:39:46 --> Severity: Warning --> Attempt to read property "total_unfinished_todos" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 170
ERROR - 2024-08-12 12:39:46 --> Severity: Warning --> Attempt to read property "firstname" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 298
ERROR - 2024-08-12 12:39:46 --> Severity: Warning --> Attempt to read property "lastname" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 298
ERROR - 2024-08-12 12:39:46 --> Severity: Warning --> Attempt to read property "staffid" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 179
ERROR - 2024-08-12 12:39:46 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 247
ERROR - 2024-08-12 12:39:46 --> Severity: Warning --> Attempt to read property "profile_image" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 274
ERROR - 2024-08-12 12:39:47 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 194
ERROR - 2024-08-12 12:39:47 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:39:47 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:39:47 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:39:47 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:39:47 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:39:47 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:39:47 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:39:47 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:39:47 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:39:47 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:39:47 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:39:47 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:39:47 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:39:47 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:39:47 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:39:47 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:39:47 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:39:47 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:39:47 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:39:47 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:39:47 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:39:47 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:39:47 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:39:47 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:39:47 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:39:47 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:39:47 --> Severity: error --> Exception: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND `end_time` IS NULL' at line 3 C:\xampp\htdocs\perfex_crm\system\database\drivers\mysqli\mysqli_driver.php 307
ERROR - 2024-08-12 12:40:23 --> init client assets
ERROR - 2024-08-12 12:40:27 --> init client assets
ERROR - 2024-08-12 12:40:33 --> Severity: Warning --> Attempt to read property "permissions" on array C:\xampp\htdocs\perfex_crm\application\helpers\admin_helper.php 130
ERROR - 2024-08-12 12:40:33 --> Severity: Warning --> Attempt to read property "permissions" on array C:\xampp\htdocs\perfex_crm\application\helpers\admin_helper.php 130
ERROR - 2024-08-12 12:40:34 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 326
ERROR - 2024-08-12 12:40:34 --> Severity: Warning --> Attempt to read property "is_not_staff" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 381
ERROR - 2024-08-12 12:40:34 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 326
ERROR - 2024-08-12 12:40:34 --> Severity: Warning --> Attempt to read property "is_not_staff" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 381
ERROR - 2024-08-12 12:40:34 --> Severity: Warning --> Attempt to read property "permissions" on array C:\xampp\htdocs\perfex_crm\application\helpers\admin_helper.php 130
ERROR - 2024-08-12 12:40:34 --> Severity: Warning --> Attempt to read property "total_unread_notifications" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\head.php 18
ERROR - 2024-08-12 12:40:34 --> Severity: Warning --> Attempt to read property "is_not_staff" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 381
ERROR - 2024-08-12 12:40:34 --> Severity: Warning --> Attempt to read property "is_not_staff" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 381
ERROR - 2024-08-12 12:40:34 --> Severity: Warning --> Attempt to read property "total_unfinished_todos" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 169
ERROR - 2024-08-12 12:40:34 --> Severity: Warning --> Attempt to read property "total_unfinished_todos" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 170
ERROR - 2024-08-12 12:40:34 --> Severity: Warning --> Attempt to read property "firstname" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 298
ERROR - 2024-08-12 12:40:34 --> Severity: Warning --> Attempt to read property "lastname" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 298
ERROR - 2024-08-12 12:40:34 --> Severity: Warning --> Attempt to read property "staffid" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 179
ERROR - 2024-08-12 12:40:34 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 247
ERROR - 2024-08-12 12:40:34 --> Severity: Warning --> Attempt to read property "profile_image" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 274
ERROR - 2024-08-12 12:40:34 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 194
ERROR - 2024-08-12 12:40:34 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:40:34 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:40:34 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:40:34 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:40:34 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:40:34 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:40:34 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:40:34 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:40:34 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:40:34 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:40:34 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:40:34 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:40:34 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:40:34 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:40:34 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:40:34 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:40:34 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:40:34 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:40:34 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:40:34 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:40:34 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:40:34 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:40:34 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:40:34 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:40:34 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:40:34 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:40:35 --> Severity: error --> Exception: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND `end_time` IS NULL' at line 3 C:\xampp\htdocs\perfex_crm\system\database\drivers\mysqli\mysqli_driver.php 307
ERROR - 2024-08-12 12:48:52 --> Could not find the language line "billings"
ERROR - 2024-08-12 12:49:17 --> Could not find the language line "billings"
ERROR - 2024-08-12 12:49:33 --> Could not find the language line "billings"
ERROR - 2024-08-12 12:50:22 --> Could not find the language line "billings"
ERROR - 2024-08-12 12:50:29 --> Could not find the language line "Name"
ERROR - 2024-08-12 12:50:29 --> Could not find the language line "Description"
ERROR - 2024-08-12 12:50:29 --> Could not find the language line "Start Date"
ERROR - 2024-08-12 12:50:29 --> Could not find the language line "End Date"
ERROR - 2024-08-12 12:50:29 --> Could not find the language line "Active"
ERROR - 2024-08-12 12:50:29 --> Could not find the language line "Actions"
ERROR - 2024-08-12 12:51:54 --> init client assets
ERROR - 2024-08-12 12:51:59 --> init client assets
ERROR - 2024-08-12 12:52:05 --> Severity: Warning --> Attempt to read property "permissions" on array C:\xampp\htdocs\perfex_crm\application\helpers\admin_helper.php 130
ERROR - 2024-08-12 12:52:05 --> Severity: Warning --> Attempt to read property "permissions" on array C:\xampp\htdocs\perfex_crm\application\helpers\admin_helper.php 130
ERROR - 2024-08-12 12:52:05 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 326
ERROR - 2024-08-12 12:52:05 --> Severity: Warning --> Attempt to read property "is_not_staff" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 381
ERROR - 2024-08-12 12:52:05 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 326
ERROR - 2024-08-12 12:52:05 --> Severity: Warning --> Attempt to read property "is_not_staff" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 381
ERROR - 2024-08-12 12:52:05 --> Severity: Warning --> Attempt to read property "permissions" on array C:\xampp\htdocs\perfex_crm\application\helpers\admin_helper.php 130
ERROR - 2024-08-12 12:52:05 --> Severity: Warning --> Attempt to read property "total_unread_notifications" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\head.php 18
ERROR - 2024-08-12 12:52:06 --> Severity: Warning --> Attempt to read property "is_not_staff" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 381
ERROR - 2024-08-12 12:52:06 --> Severity: Warning --> Attempt to read property "is_not_staff" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 381
ERROR - 2024-08-12 12:52:06 --> Severity: Warning --> Attempt to read property "total_unfinished_todos" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 169
ERROR - 2024-08-12 12:52:06 --> Severity: Warning --> Attempt to read property "total_unfinished_todos" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 170
ERROR - 2024-08-12 12:52:06 --> Severity: Warning --> Attempt to read property "firstname" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 298
ERROR - 2024-08-12 12:52:06 --> Severity: Warning --> Attempt to read property "lastname" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 298
ERROR - 2024-08-12 12:52:06 --> Severity: Warning --> Attempt to read property "staffid" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 179
ERROR - 2024-08-12 12:52:06 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 247
ERROR - 2024-08-12 12:52:06 --> Severity: Warning --> Attempt to read property "profile_image" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 274
ERROR - 2024-08-12 12:52:06 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 194
ERROR - 2024-08-12 12:52:06 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:52:06 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:52:06 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:52:06 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:52:06 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:52:06 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:52:06 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:52:06 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:52:06 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:52:06 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:52:06 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:52:06 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:52:06 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:52:06 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:52:06 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:52:06 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:52:06 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:52:06 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:52:06 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:52:06 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:52:06 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:52:06 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:52:06 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:52:06 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:52:06 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:52:06 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:52:06 --> Severity: error --> Exception: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND `end_time` IS NULL' at line 3 C:\xampp\htdocs\perfex_crm\system\database\drivers\mysqli\mysqli_driver.php 307
ERROR - 2024-08-12 12:55:45 --> init client assets
ERROR - 2024-08-12 12:55:50 --> init client assets
ERROR - 2024-08-12 12:55:56 --> Severity: Warning --> Attempt to read property "permissions" on array C:\xampp\htdocs\perfex_crm\application\helpers\admin_helper.php 130
ERROR - 2024-08-12 12:55:56 --> Severity: Warning --> Attempt to read property "permissions" on array C:\xampp\htdocs\perfex_crm\application\helpers\admin_helper.php 130
ERROR - 2024-08-12 12:55:56 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 326
ERROR - 2024-08-12 12:55:56 --> Severity: Warning --> Attempt to read property "is_not_staff" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 381
ERROR - 2024-08-12 12:55:56 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 326
ERROR - 2024-08-12 12:55:57 --> Severity: Warning --> Attempt to read property "is_not_staff" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 381
ERROR - 2024-08-12 12:55:57 --> Severity: Warning --> Attempt to read property "permissions" on array C:\xampp\htdocs\perfex_crm\application\helpers\admin_helper.php 130
ERROR - 2024-08-12 12:55:57 --> Severity: Warning --> Attempt to read property "total_unread_notifications" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\head.php 18
ERROR - 2024-08-12 12:55:57 --> Severity: Warning --> Attempt to read property "is_not_staff" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 381
ERROR - 2024-08-12 12:55:57 --> Severity: Warning --> Attempt to read property "is_not_staff" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 381
ERROR - 2024-08-12 12:55:57 --> Severity: Warning --> Attempt to read property "total_unfinished_todos" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 169
ERROR - 2024-08-12 12:55:57 --> Severity: Warning --> Attempt to read property "total_unfinished_todos" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 170
ERROR - 2024-08-12 12:55:57 --> Severity: Warning --> Attempt to read property "firstname" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 298
ERROR - 2024-08-12 12:55:57 --> Severity: Warning --> Attempt to read property "lastname" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 298
ERROR - 2024-08-12 12:55:57 --> Severity: Warning --> Attempt to read property "staffid" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 179
ERROR - 2024-08-12 12:55:57 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 247
ERROR - 2024-08-12 12:55:57 --> Severity: Warning --> Attempt to read property "profile_image" on array C:\xampp\htdocs\perfex_crm\application\helpers\staff_helper.php 274
ERROR - 2024-08-12 12:55:57 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 194
ERROR - 2024-08-12 12:55:57 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:55:57 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:55:57 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:55:57 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:55:57 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:55:57 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:55:57 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:55:57 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:55:57 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:55:57 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:55:57 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:55:57 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:55:57 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:55:57 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:55:57 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:55:57 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:55:57 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:55:57 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:55:57 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:55:57 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:55:57 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:55:57 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:55:57 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:55:57 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:55:57 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:55:57 --> Severity: Warning --> Attempt to read property "default_language" on array C:\xampp\htdocs\perfex_crm\application\views\admin\includes\header.php 201
ERROR - 2024-08-12 12:55:58 --> Severity: error --> Exception: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND `end_time` IS NULL' at line 3 C:\xampp\htdocs\perfex_crm\system\database\drivers\mysqli\mysqli_driver.php 307
