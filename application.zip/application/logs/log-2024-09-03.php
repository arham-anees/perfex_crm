<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-09-03 16:50:24 --> Could not find the language line "Status"
ERROR - 2024-09-03 16:50:24 --> client
ERROR - 2024-09-03 16:50:24 --> 12
ERROR - 2024-09-03 16:50:24 --> client
ERROR - 2024-09-03 16:50:27 --> client
ERROR - 2024-09-03 16:50:27 --> 12
ERROR - 2024-09-03 16:50:27 --> client
ERROR - 2024-09-03 16:50:33 --> Could not find the language line "Status"
ERROR - 2024-09-03 16:50:33 --> client
ERROR - 2024-09-03 16:50:33 --> 12
ERROR - 2024-09-03 16:50:33 --> client
ERROR - 2024-09-03 16:50:38 --> Could not find the language line "clients_list_value"
ERROR - 2024-09-03 16:50:38 --> Could not find the language line "clients_list_tags"
ERROR - 2024-09-03 16:50:38 --> Could not find the language line "clients_list_status"
ERROR - 2024-09-03 16:50:38 --> Could not find the language line "clients_list_source"
ERROR - 2024-09-03 16:50:38 --> Could not find the language line "campaign_id"
ERROR - 2024-09-03 16:50:38 --> Could not find the language line "Stars"
ERROR - 2024-09-03 16:50:38 --> Could not find the language line "Reasons"
ERROR - 2024-09-03 16:50:38 --> Could not find the language line "Select Reason"
ERROR - 2024-09-03 16:50:38 --> Could not find the language line "Select Reason"
ERROR - 2024-09-03 16:50:38 --> Could not find the language line "Details"
ERROR - 2024-09-03 16:50:38 --> Could not find the language line "Name"
ERROR - 2024-09-03 16:50:38 --> Could not find the language line "Status"
ERROR - 2024-09-03 16:50:38 --> Could not find the language line "Type"
ERROR - 2024-09-03 16:50:38 --> Could not find the language line "Category"
ERROR - 2024-09-03 16:50:38 --> Could not find the language line "Acquisition Channels"
ERROR - 2024-09-03 16:50:38 --> Could not find the language line "Desired Amount"
ERROR - 2024-09-03 16:50:38 --> Could not find the language line "Industry"
ERROR - 2024-09-03 16:50:38 --> Could not find the language line "Upload Evidence (MP3)"
ERROR - 2024-09-03 16:50:38 --> Could not find the language line "Target CRM"
ERROR - 2024-09-03 16:50:38 --> Could not find the language line "Target CRM"
ERROR - 2024-09-03 16:50:38 --> client
ERROR - 2024-09-03 16:50:38 --> 12
ERROR - 2024-09-03 16:50:38 --> client
ERROR - 2024-09-03 16:53:08 --> client
ERROR - 2024-09-03 16:53:08 --> 12
ERROR - 2024-09-03 16:53:08 --> client
ERROR - 2024-09-03 16:53:24 --> client
ERROR - 2024-09-03 16:53:24 --> 12
ERROR - 2024-09-03 16:53:24 --> client
ERROR - 2024-09-03 16:53:28 --> client
ERROR - 2024-09-03 16:53:28 --> 12
ERROR - 2024-09-03 16:53:28 --> client
ERROR - 2024-09-03 17:02:53 --> Could not find the language line "clients_list_value"
ERROR - 2024-09-03 17:02:53 --> Could not find the language line "clients_list_tags"
ERROR - 2024-09-03 17:02:53 --> Could not find the language line "clients_list_status"
ERROR - 2024-09-03 17:02:53 --> Could not find the language line "clients_list_source"
ERROR - 2024-09-03 17:02:53 --> Could not find the language line "campaign_id"
ERROR - 2024-09-03 17:02:53 --> Could not find the language line "Stars"
ERROR - 2024-09-03 17:02:53 --> Could not find the language line "Reasons"
ERROR - 2024-09-03 17:02:53 --> Could not find the language line "Select Reason"
ERROR - 2024-09-03 17:02:53 --> Could not find the language line "Select Reason"
ERROR - 2024-09-03 17:02:53 --> Could not find the language line "Details"
ERROR - 2024-09-03 17:02:53 --> Could not find the language line "Name"
ERROR - 2024-09-03 17:02:53 --> Could not find the language line "Status"
ERROR - 2024-09-03 17:02:53 --> Could not find the language line "Type"
ERROR - 2024-09-03 17:02:53 --> Could not find the language line "Category"
ERROR - 2024-09-03 17:02:53 --> Could not find the language line "Acquisition Channels"
ERROR - 2024-09-03 17:02:53 --> Could not find the language line "Desired Amount"
ERROR - 2024-09-03 17:02:53 --> Could not find the language line "Industry"
ERROR - 2024-09-03 17:02:53 --> Could not find the language line "Upload Evidence (MP3)"
ERROR - 2024-09-03 17:02:53 --> Could not find the language line "Target CRM"
ERROR - 2024-09-03 17:02:53 --> Could not find the language line "Target CRM"
ERROR - 2024-09-03 17:02:53 --> client
ERROR - 2024-09-03 17:02:53 --> 12
ERROR - 2024-09-03 17:02:53 --> client
ERROR - 2024-09-03 17:04:04 --> Could not find the language line "Status"
ERROR - 2024-09-03 17:04:04 --> client
ERROR - 2024-09-03 17:04:04 --> 12
ERROR - 2024-09-03 17:04:04 --> client
ERROR - 2024-09-03 17:04:09 --> Could not find the language line "Status"
ERROR - 2024-09-03 17:04:09 --> client
ERROR - 2024-09-03 17:04:09 --> 12
ERROR - 2024-09-03 17:04:09 --> client
ERROR - 2024-09-03 17:05:17 --> Could not find the language line "Status"
ERROR - 2024-09-03 17:05:17 --> client
ERROR - 2024-09-03 17:05:17 --> 12
ERROR - 2024-09-03 17:05:17 --> client
ERROR - 2024-09-03 17:05:24 --> client
ERROR - 2024-09-03 17:05:24 --> 12
ERROR - 2024-09-03 17:05:24 --> client
ERROR - 2024-09-03 17:07:28 --> Could not find the language line "Status"
ERROR - 2024-09-03 17:07:28 --> client
ERROR - 2024-09-03 17:07:28 --> 12
ERROR - 2024-09-03 17:07:28 --> client
ERROR - 2024-09-03 17:07:31 --> Could not find the language line "Status"
ERROR - 2024-09-03 17:07:31 --> client
ERROR - 2024-09-03 17:07:31 --> 12
ERROR - 2024-09-03 17:07:31 --> client
ERROR - 2024-09-03 17:08:19 --> Could not find the language line "Status"
ERROR - 2024-09-03 17:08:19 --> client
ERROR - 2024-09-03 17:08:19 --> 12
ERROR - 2024-09-03 17:08:19 --> client
ERROR - 2024-09-03 17:08:30 --> client
ERROR - 2024-09-03 17:08:30 --> 12
ERROR - 2024-09-03 17:08:30 --> client
ERROR - 2024-09-03 17:08:59 --> Could not find the language line "Status"
ERROR - 2024-09-03 17:08:59 --> client
ERROR - 2024-09-03 17:08:59 --> 12
ERROR - 2024-09-03 17:08:59 --> client
ERROR - 2024-09-03 17:09:57 --> Could not find the language line "clients_list_value"
ERROR - 2024-09-03 17:09:57 --> Could not find the language line "clients_list_tags"
ERROR - 2024-09-03 17:09:57 --> Could not find the language line "clients_list_status"
ERROR - 2024-09-03 17:09:57 --> Could not find the language line "clients_list_source"
ERROR - 2024-09-03 17:09:57 --> Could not find the language line "campaign_id"
ERROR - 2024-09-03 17:09:57 --> Could not find the language line "Stars"
ERROR - 2024-09-03 17:09:57 --> Could not find the language line "Reasons"
ERROR - 2024-09-03 17:09:57 --> Could not find the language line "Select Reason"
ERROR - 2024-09-03 17:09:57 --> Could not find the language line "Select Reason"
ERROR - 2024-09-03 17:09:57 --> Could not find the language line "Details"
ERROR - 2024-09-03 17:09:57 --> Could not find the language line "Name"
ERROR - 2024-09-03 17:09:57 --> Could not find the language line "Status"
ERROR - 2024-09-03 17:09:57 --> Could not find the language line "Type"
ERROR - 2024-09-03 17:09:57 --> Could not find the language line "Category"
ERROR - 2024-09-03 17:09:57 --> Could not find the language line "Acquisition Channels"
ERROR - 2024-09-03 17:09:57 --> Could not find the language line "Desired Amount"
ERROR - 2024-09-03 17:09:57 --> Could not find the language line "Industry"
ERROR - 2024-09-03 17:09:57 --> Could not find the language line "Upload Evidence (MP3)"
ERROR - 2024-09-03 17:09:57 --> Could not find the language line "Target CRM"
ERROR - 2024-09-03 17:09:57 --> Could not find the language line "Target CRM"
ERROR - 2024-09-03 17:09:57 --> client
ERROR - 2024-09-03 17:09:57 --> 12
ERROR - 2024-09-03 17:09:57 --> client
ERROR - 2024-09-03 17:15:21 --> Could not find the language line "Status"
ERROR - 2024-09-03 17:15:21 --> client
ERROR - 2024-09-03 17:15:21 --> 12
ERROR - 2024-09-03 17:15:21 --> client
ERROR - 2024-09-03 17:15:26 --> client
ERROR - 2024-09-03 17:15:26 --> 12
ERROR - 2024-09-03 17:15:26 --> client
ERROR - 2024-09-03 17:15:40 --> Could not find the language line "Status"
ERROR - 2024-09-03 17:15:40 --> client
ERROR - 2024-09-03 17:15:40 --> 12
ERROR - 2024-09-03 17:15:40 --> client
ERROR - 2024-09-03 17:15:43 --> Could not find the language line "Status"
ERROR - 2024-09-03 17:15:43 --> client
ERROR - 2024-09-03 17:15:43 --> 12
ERROR - 2024-09-03 17:15:43 --> client
ERROR - 2024-09-03 17:15:53 --> Could not find the language line "Status"
ERROR - 2024-09-03 17:15:53 --> client
ERROR - 2024-09-03 17:15:53 --> 12
ERROR - 2024-09-03 17:15:53 --> client
ERROR - 2024-09-03 17:15:59 --> Could not find the language line "clients_list_value"
ERROR - 2024-09-03 17:15:59 --> Could not find the language line "clients_list_tags"
ERROR - 2024-09-03 17:15:59 --> Could not find the language line "clients_list_status"
ERROR - 2024-09-03 17:15:59 --> Could not find the language line "clients_list_source"
ERROR - 2024-09-03 17:15:59 --> Could not find the language line "campaign_id"
ERROR - 2024-09-03 17:15:59 --> Could not find the language line "Stars"
ERROR - 2024-09-03 17:15:59 --> Could not find the language line "Reasons"
ERROR - 2024-09-03 17:15:59 --> Could not find the language line "Select Reason"
ERROR - 2024-09-03 17:15:59 --> Could not find the language line "Select Reason"
ERROR - 2024-09-03 17:15:59 --> Could not find the language line "Details"
ERROR - 2024-09-03 17:15:59 --> Could not find the language line "Name"
ERROR - 2024-09-03 17:15:59 --> Could not find the language line "Status"
ERROR - 2024-09-03 17:15:59 --> Could not find the language line "Type"
ERROR - 2024-09-03 17:15:59 --> Could not find the language line "Category"
ERROR - 2024-09-03 17:15:59 --> Could not find the language line "Acquisition Channels"
ERROR - 2024-09-03 17:15:59 --> Could not find the language line "Desired Amount"
ERROR - 2024-09-03 17:15:59 --> Could not find the language line "Industry"
ERROR - 2024-09-03 17:15:59 --> Could not find the language line "Upload Evidence (MP3)"
ERROR - 2024-09-03 17:15:59 --> Could not find the language line "Target CRM"
ERROR - 2024-09-03 17:15:59 --> Could not find the language line "Target CRM"
ERROR - 2024-09-03 17:15:59 --> client
ERROR - 2024-09-03 17:15:59 --> 12
ERROR - 2024-09-03 17:15:59 --> client
ERROR - 2024-09-03 17:17:05 --> Could not find the language line "Status"
ERROR - 2024-09-03 17:17:05 --> client
ERROR - 2024-09-03 17:17:05 --> 12
ERROR - 2024-09-03 17:17:05 --> client
ERROR - 2024-09-03 17:17:10 --> client
ERROR - 2024-09-03 17:17:10 --> 12
ERROR - 2024-09-03 17:17:10 --> client
ERROR - 2024-09-03 17:17:24 --> Could not find the language line "Status"
ERROR - 2024-09-03 17:17:24 --> client
ERROR - 2024-09-03 17:17:24 --> 12
ERROR - 2024-09-03 17:17:24 --> client
ERROR - 2024-09-03 17:17:31 --> Could not find the language line "clients_list_value"
ERROR - 2024-09-03 17:17:31 --> Could not find the language line "clients_list_tags"
ERROR - 2024-09-03 17:17:31 --> Could not find the language line "clients_list_status"
ERROR - 2024-09-03 17:17:31 --> Could not find the language line "clients_list_source"
ERROR - 2024-09-03 17:17:31 --> Could not find the language line "campaign_id"
ERROR - 2024-09-03 17:17:31 --> Could not find the language line "Stars"
ERROR - 2024-09-03 17:17:31 --> Could not find the language line "Reasons"
ERROR - 2024-09-03 17:17:31 --> Could not find the language line "Select Reason"
ERROR - 2024-09-03 17:17:31 --> Could not find the language line "Select Reason"
ERROR - 2024-09-03 17:17:31 --> Could not find the language line "Details"
ERROR - 2024-09-03 17:17:31 --> Could not find the language line "Name"
ERROR - 2024-09-03 17:17:31 --> Could not find the language line "Status"
ERROR - 2024-09-03 17:17:31 --> Could not find the language line "Type"
ERROR - 2024-09-03 17:17:31 --> Could not find the language line "Category"
ERROR - 2024-09-03 17:17:31 --> Could not find the language line "Acquisition Channels"
ERROR - 2024-09-03 17:17:31 --> Could not find the language line "Desired Amount"
ERROR - 2024-09-03 17:17:31 --> Could not find the language line "Industry"
ERROR - 2024-09-03 17:17:31 --> Could not find the language line "Upload Evidence (MP3)"
ERROR - 2024-09-03 17:17:31 --> Could not find the language line "Target CRM"
ERROR - 2024-09-03 17:17:31 --> Could not find the language line "Target CRM"
ERROR - 2024-09-03 17:17:31 --> client
ERROR - 2024-09-03 17:17:31 --> 12
ERROR - 2024-09-03 17:17:31 --> client
ERROR - 2024-09-03 17:19:30 --> client
ERROR - 2024-09-03 17:19:30 --> 12
ERROR - 2024-09-03 17:19:30 --> client
ERROR - 2024-09-03 17:19:35 --> Could not find the language line "Status"
ERROR - 2024-09-03 17:19:35 --> client
ERROR - 2024-09-03 17:19:35 --> 12
ERROR - 2024-09-03 17:19:35 --> client
ERROR - 2024-09-03 17:20:18 --> Could not find the language line "clients_list_value"
ERROR - 2024-09-03 17:20:18 --> Could not find the language line "clients_list_tags"
ERROR - 2024-09-03 17:20:18 --> Could not find the language line "clients_list_status"
ERROR - 2024-09-03 17:20:18 --> Could not find the language line "clients_list_source"
ERROR - 2024-09-03 17:20:18 --> Could not find the language line "campaign_id"
ERROR - 2024-09-03 17:20:18 --> Could not find the language line "Stars"
ERROR - 2024-09-03 17:20:18 --> Could not find the language line "Reasons"
ERROR - 2024-09-03 17:20:18 --> Could not find the language line "Select Reason"
ERROR - 2024-09-03 17:20:18 --> Could not find the language line "Select Reason"
ERROR - 2024-09-03 17:20:18 --> Could not find the language line "Details"
ERROR - 2024-09-03 17:20:18 --> Could not find the language line "Name"
ERROR - 2024-09-03 17:20:18 --> Could not find the language line "Status"
ERROR - 2024-09-03 17:20:18 --> Could not find the language line "Type"
ERROR - 2024-09-03 17:20:18 --> Could not find the language line "Category"
ERROR - 2024-09-03 17:20:18 --> Could not find the language line "Acquisition Channels"
ERROR - 2024-09-03 17:20:18 --> Could not find the language line "Desired Amount"
ERROR - 2024-09-03 17:20:18 --> Could not find the language line "Industry"
ERROR - 2024-09-03 17:20:18 --> Could not find the language line "Upload Evidence (MP3)"
ERROR - 2024-09-03 17:20:18 --> Could not find the language line "Target CRM"
ERROR - 2024-09-03 17:20:18 --> Could not find the language line "Target CRM"
ERROR - 2024-09-03 17:20:18 --> client
ERROR - 2024-09-03 17:20:18 --> 12
ERROR - 2024-09-03 17:20:18 --> client
ERROR - 2024-09-03 17:20:56 --> Could not find the language line "Status"
ERROR - 2024-09-03 17:20:56 --> client
ERROR - 2024-09-03 17:20:56 --> 12
ERROR - 2024-09-03 17:20:56 --> client
ERROR - 2024-09-03 17:21:02 --> client
ERROR - 2024-09-03 17:21:02 --> 12
ERROR - 2024-09-03 17:21:02 --> client
ERROR - 2024-09-03 17:21:10 --> Could not find the language line "Status"
ERROR - 2024-09-03 17:21:10 --> client
ERROR - 2024-09-03 17:21:10 --> 12
ERROR - 2024-09-03 17:21:10 --> client
ERROR - 2024-09-03 17:21:18 --> Could not find the language line "clients_list_value"
ERROR - 2024-09-03 17:21:18 --> Could not find the language line "clients_list_tags"
ERROR - 2024-09-03 17:21:18 --> Could not find the language line "clients_list_status"
ERROR - 2024-09-03 17:21:18 --> Could not find the language line "clients_list_source"
ERROR - 2024-09-03 17:21:18 --> Could not find the language line "campaign_id"
ERROR - 2024-09-03 17:21:18 --> Could not find the language line "Stars"
ERROR - 2024-09-03 17:21:18 --> Could not find the language line "Reasons"
ERROR - 2024-09-03 17:21:18 --> Could not find the language line "Select Reason"
ERROR - 2024-09-03 17:21:18 --> Could not find the language line "Select Reason"
ERROR - 2024-09-03 17:21:18 --> Could not find the language line "Details"
ERROR - 2024-09-03 17:21:18 --> Could not find the language line "Name"
ERROR - 2024-09-03 17:21:18 --> Could not find the language line "Status"
ERROR - 2024-09-03 17:21:18 --> Could not find the language line "Type"
ERROR - 2024-09-03 17:21:18 --> Could not find the language line "Category"
ERROR - 2024-09-03 17:21:18 --> Could not find the language line "Acquisition Channels"
ERROR - 2024-09-03 17:21:18 --> Could not find the language line "Desired Amount"
ERROR - 2024-09-03 17:21:18 --> Could not find the language line "Industry"
ERROR - 2024-09-03 17:21:18 --> Could not find the language line "Upload Evidence (MP3)"
ERROR - 2024-09-03 17:21:18 --> Could not find the language line "Target CRM"
ERROR - 2024-09-03 17:21:18 --> Could not find the language line "Target CRM"
ERROR - 2024-09-03 17:21:18 --> client
ERROR - 2024-09-03 17:21:18 --> 12
ERROR - 2024-09-03 17:21:18 --> client
ERROR - 2024-09-03 17:21:37 --> client
ERROR - 2024-09-03 17:21:37 --> 12
ERROR - 2024-09-03 17:21:37 --> client
ERROR - 2024-09-03 17:24:39 --> client
ERROR - 2024-09-03 17:24:39 --> 12
ERROR - 2024-09-03 17:24:39 --> client
ERROR - 2024-09-03 17:24:57 --> client
ERROR - 2024-09-03 17:24:57 --> 12
ERROR - 2024-09-03 17:24:57 --> client
ERROR - 2024-09-03 17:27:17 --> client
ERROR - 2024-09-03 17:27:17 --> 12
ERROR - 2024-09-03 17:27:17 --> client
ERROR - 2024-09-03 17:27:19 --> Could not find the language line "Status"
ERROR - 2024-09-03 17:27:19 --> client
ERROR - 2024-09-03 17:27:19 --> 12
ERROR - 2024-09-03 17:27:19 --> client
ERROR - 2024-09-03 17:29:46 --> client
ERROR - 2024-09-03 17:29:46 --> 12
ERROR - 2024-09-03 17:29:46 --> client
ERROR - 2024-09-03 17:29:48 --> client
ERROR - 2024-09-03 17:29:48 --> 12
ERROR - 2024-09-03 17:29:48 --> client
ERROR - 2024-09-03 17:29:54 --> Could not find the language line "create_crm_link"
ERROR - 2024-09-03 17:29:54 --> Could not find the language line "description"
ERROR - 2024-09-03 17:29:54 --> Could not find the language line "link"
ERROR - 2024-09-03 17:29:54 --> client
ERROR - 2024-09-03 17:29:54 --> 12
ERROR - 2024-09-03 17:29:54 --> client
ERROR - 2024-09-03 17:30:32 --> client
ERROR - 2024-09-03 17:30:32 --> 12
ERROR - 2024-09-03 17:30:32 --> client
ERROR - 2024-09-03 17:30:36 --> Could not find the language line "crm_link_details"
ERROR - 2024-09-03 17:30:36 --> Could not find the language line "description"
ERROR - 2024-09-03 17:30:36 --> Could not find the language line "link"
ERROR - 2024-09-03 17:30:36 --> client
ERROR - 2024-09-03 17:30:36 --> 12
ERROR - 2024-09-03 17:30:36 --> client
ERROR - 2024-09-03 17:30:38 --> client
ERROR - 2024-09-03 17:30:38 --> 12
ERROR - 2024-09-03 17:30:38 --> client
ERROR - 2024-09-03 17:30:40 --> Could not find the language line "edit_crm_link"
ERROR - 2024-09-03 17:30:40 --> Could not find the language line "description"
ERROR - 2024-09-03 17:30:40 --> Could not find the language line "link"
ERROR - 2024-09-03 17:30:40 --> Could not find the language line "save_changes"
ERROR - 2024-09-03 17:30:40 --> client
ERROR - 2024-09-03 17:30:40 --> 12
ERROR - 2024-09-03 17:30:40 --> client
ERROR - 2024-09-03 17:30:44 --> client
ERROR - 2024-09-03 17:30:44 --> 12
ERROR - 2024-09-03 17:30:44 --> client
ERROR - 2024-09-03 17:36:23 --> Could not find the language line "clients_list_value"
ERROR - 2024-09-03 17:36:23 --> Could not find the language line "clients_list_tags"
ERROR - 2024-09-03 17:36:23 --> Could not find the language line "clients_list_status"
ERROR - 2024-09-03 17:36:23 --> Could not find the language line "clients_list_source"
ERROR - 2024-09-03 17:36:23 --> Could not find the language line "campaign_id"
ERROR - 2024-09-03 17:36:23 --> Could not find the language line "Stars"
ERROR - 2024-09-03 17:36:23 --> Could not find the language line "Reasons"
ERROR - 2024-09-03 17:36:23 --> Could not find the language line "Select Reason"
ERROR - 2024-09-03 17:36:23 --> Could not find the language line "Select Reason"
ERROR - 2024-09-03 17:36:23 --> Could not find the language line "Details"
ERROR - 2024-09-03 17:36:23 --> Could not find the language line "Name"
ERROR - 2024-09-03 17:36:23 --> Could not find the language line "Status"
ERROR - 2024-09-03 17:36:23 --> Could not find the language line "Type"
ERROR - 2024-09-03 17:36:23 --> Could not find the language line "Category"
ERROR - 2024-09-03 17:36:23 --> Could not find the language line "Acquisition Channels"
ERROR - 2024-09-03 17:36:23 --> Could not find the language line "Desired Amount"
ERROR - 2024-09-03 17:36:23 --> Could not find the language line "Industry"
ERROR - 2024-09-03 17:36:23 --> Could not find the language line "Upload Evidence (MP3)"
ERROR - 2024-09-03 17:36:23 --> Could not find the language line "Target CRM"
ERROR - 2024-09-03 17:36:23 --> Could not find the language line "Target CRM"
ERROR - 2024-09-03 17:36:23 --> client
ERROR - 2024-09-03 17:36:23 --> 12
ERROR - 2024-09-03 17:36:23 --> client
ERROR - 2024-09-03 17:41:34 --> Could not find the language line "clients_list_value"
ERROR - 2024-09-03 17:41:34 --> Could not find the language line "clients_list_tags"
ERROR - 2024-09-03 17:41:34 --> Could not find the language line "clients_list_status"
ERROR - 2024-09-03 17:41:34 --> Could not find the language line "clients_list_source"
ERROR - 2024-09-03 17:41:34 --> Could not find the language line "campaign_id"
ERROR - 2024-09-03 17:41:34 --> Could not find the language line "Stars"
ERROR - 2024-09-03 17:41:34 --> Could not find the language line "Reasons"
ERROR - 2024-09-03 17:41:34 --> Could not find the language line "Select Reason"
ERROR - 2024-09-03 17:41:34 --> Could not find the language line "Select Reason"
ERROR - 2024-09-03 17:41:34 --> Could not find the language line "Details"
ERROR - 2024-09-03 17:41:34 --> Could not find the language line "Name"
ERROR - 2024-09-03 17:41:34 --> Could not find the language line "Status"
ERROR - 2024-09-03 17:41:34 --> Could not find the language line "Type"
ERROR - 2024-09-03 17:41:34 --> Could not find the language line "Category"
ERROR - 2024-09-03 17:41:34 --> Could not find the language line "Acquisition Channels"
ERROR - 2024-09-03 17:41:34 --> Could not find the language line "Desired Amount"
ERROR - 2024-09-03 17:41:34 --> Could not find the language line "Industry"
ERROR - 2024-09-03 17:41:34 --> Could not find the language line "Upload Evidence (MP3)"
ERROR - 2024-09-03 17:41:34 --> Could not find the language line "leadevo_generate_api_description"
ERROR - 2024-09-03 17:41:34 --> Could not find the language line "leadevo_generate_api_button"
ERROR - 2024-09-03 17:41:34 --> client
ERROR - 2024-09-03 17:41:34 --> 12
ERROR - 2024-09-03 17:41:34 --> client
ERROR - 2024-09-03 14:41:36 --> 404 Page Not Found: /index
ERROR - 2024-09-03 17:41:44 --> Could not find the language line "clients_list_value"
ERROR - 2024-09-03 17:41:44 --> Could not find the language line "clients_list_tags"
ERROR - 2024-09-03 17:41:44 --> Could not find the language line "clients_list_status"
ERROR - 2024-09-03 17:41:44 --> Could not find the language line "clients_list_source"
ERROR - 2024-09-03 17:41:44 --> Could not find the language line "campaign_id"
ERROR - 2024-09-03 17:41:44 --> Could not find the language line "Stars"
ERROR - 2024-09-03 17:41:44 --> Could not find the language line "Reasons"
ERROR - 2024-09-03 17:41:44 --> Could not find the language line "Select Reason"
ERROR - 2024-09-03 17:41:44 --> Could not find the language line "Select Reason"
ERROR - 2024-09-03 17:41:44 --> Could not find the language line "Details"
ERROR - 2024-09-03 17:41:44 --> Could not find the language line "Name"
ERROR - 2024-09-03 17:41:44 --> Could not find the language line "Status"
ERROR - 2024-09-03 17:41:44 --> Could not find the language line "Type"
ERROR - 2024-09-03 17:41:44 --> Could not find the language line "Category"
ERROR - 2024-09-03 17:41:44 --> Could not find the language line "Acquisition Channels"
ERROR - 2024-09-03 17:41:44 --> Could not find the language line "Desired Amount"
ERROR - 2024-09-03 17:41:44 --> Could not find the language line "Industry"
ERROR - 2024-09-03 17:41:44 --> Could not find the language line "Upload Evidence (MP3)"
ERROR - 2024-09-03 17:41:44 --> Could not find the language line "leadevo_generate_api_description"
ERROR - 2024-09-03 17:41:44 --> Could not find the language line "leadevo_generate_api_button"
ERROR - 2024-09-03 17:41:44 --> client
ERROR - 2024-09-03 17:41:44 --> 12
ERROR - 2024-09-03 17:41:44 --> client
ERROR - 2024-09-03 14:41:51 --> 404 Page Not Found: /index
ERROR - 2024-09-03 17:51:03 --> Could not find the language line "clients_list_value"
ERROR - 2024-09-03 17:51:03 --> Could not find the language line "clients_list_tags"
ERROR - 2024-09-03 17:51:03 --> Could not find the language line "clients_list_status"
ERROR - 2024-09-03 17:51:03 --> Could not find the language line "clients_list_source"
ERROR - 2024-09-03 17:51:03 --> Could not find the language line "campaign_id"
ERROR - 2024-09-03 17:51:03 --> Could not find the language line "Stars"
ERROR - 2024-09-03 17:51:03 --> Could not find the language line "Reasons"
ERROR - 2024-09-03 17:51:03 --> Could not find the language line "Select Reason"
ERROR - 2024-09-03 17:51:03 --> Could not find the language line "Select Reason"
ERROR - 2024-09-03 17:51:03 --> Could not find the language line "Details"
ERROR - 2024-09-03 17:51:03 --> Could not find the language line "Name"
ERROR - 2024-09-03 17:51:03 --> Could not find the language line "Status"
ERROR - 2024-09-03 17:51:03 --> Could not find the language line "Type"
ERROR - 2024-09-03 17:51:03 --> Could not find the language line "Category"
ERROR - 2024-09-03 17:51:03 --> Could not find the language line "Acquisition Channels"
ERROR - 2024-09-03 17:51:03 --> Could not find the language line "Desired Amount"
ERROR - 2024-09-03 17:51:03 --> Could not find the language line "Industry"
ERROR - 2024-09-03 17:51:03 --> Could not find the language line "Upload Evidence (MP3)"
ERROR - 2024-09-03 17:51:03 --> Could not find the language line "Target CRM"
ERROR - 2024-09-03 17:51:03 --> Could not find the language line "Target CRM"
ERROR - 2024-09-03 17:51:03 --> client
ERROR - 2024-09-03 17:51:03 --> 12
ERROR - 2024-09-03 17:51:03 --> client
ERROR - 2024-09-03 18:00:36 --> Could not find the language line "clients_list_value"
ERROR - 2024-09-03 18:00:36 --> Could not find the language line "clients_list_tags"
ERROR - 2024-09-03 18:00:36 --> Could not find the language line "clients_list_status"
ERROR - 2024-09-03 18:00:36 --> Could not find the language line "clients_list_source"
ERROR - 2024-09-03 18:00:36 --> Could not find the language line "campaign_id"
ERROR - 2024-09-03 18:00:36 --> Could not find the language line "Stars"
ERROR - 2024-09-03 18:00:36 --> Could not find the language line "Reasons"
ERROR - 2024-09-03 18:00:36 --> Could not find the language line "Select Reason"
ERROR - 2024-09-03 18:00:36 --> Could not find the language line "Select Reason"
ERROR - 2024-09-03 18:00:36 --> Could not find the language line "Details"
ERROR - 2024-09-03 18:00:36 --> Could not find the language line "Name"
ERROR - 2024-09-03 18:00:36 --> Could not find the language line "Status"
ERROR - 2024-09-03 18:00:36 --> Could not find the language line "Type"
ERROR - 2024-09-03 18:00:36 --> Could not find the language line "Category"
ERROR - 2024-09-03 18:00:36 --> Could not find the language line "Acquisition Channels"
ERROR - 2024-09-03 18:00:36 --> Could not find the language line "Desired Amount"
ERROR - 2024-09-03 18:00:36 --> Could not find the language line "Industry"
ERROR - 2024-09-03 18:00:36 --> Could not find the language line "Upload Evidence (MP3)"
ERROR - 2024-09-03 18:00:36 --> Could not find the language line "Target CRM"
ERROR - 2024-09-03 18:00:36 --> Could not find the language line "Target CRM"
ERROR - 2024-09-03 18:00:36 --> client
ERROR - 2024-09-03 18:00:36 --> 12
ERROR - 2024-09-03 18:00:36 --> client
ERROR - 2024-09-03 18:01:02 --> client
ERROR - 2024-09-03 18:01:02 --> 12
ERROR - 2024-09-03 18:01:02 --> client
ERROR - 2024-09-03 18:01:07 --> Could not find the language line "edit_crm_link"
ERROR - 2024-09-03 18:01:07 --> Could not find the language line "description"
ERROR - 2024-09-03 18:01:07 --> Could not find the language line "link"
ERROR - 2024-09-03 18:01:07 --> Could not find the language line "save_changes"
ERROR - 2024-09-03 18:01:07 --> client
ERROR - 2024-09-03 18:01:07 --> 12
ERROR - 2024-09-03 18:01:07 --> client
ERROR - 2024-09-03 18:01:30 --> client
ERROR - 2024-09-03 18:01:30 --> 12
ERROR - 2024-09-03 18:01:30 --> client
ERROR - 2024-09-03 18:01:41 --> Could not find the language line "clients_list_value"
ERROR - 2024-09-03 18:01:41 --> Could not find the language line "clients_list_tags"
ERROR - 2024-09-03 18:01:41 --> Could not find the language line "clients_list_status"
ERROR - 2024-09-03 18:01:41 --> Could not find the language line "clients_list_source"
ERROR - 2024-09-03 18:01:41 --> Could not find the language line "campaign_id"
ERROR - 2024-09-03 18:01:41 --> Could not find the language line "Stars"
ERROR - 2024-09-03 18:01:41 --> Could not find the language line "Reasons"
ERROR - 2024-09-03 18:01:41 --> Could not find the language line "Select Reason"
ERROR - 2024-09-03 18:01:41 --> Could not find the language line "Select Reason"
ERROR - 2024-09-03 18:01:41 --> Could not find the language line "Details"
ERROR - 2024-09-03 18:01:41 --> Could not find the language line "Name"
ERROR - 2024-09-03 18:01:41 --> Could not find the language line "Status"
ERROR - 2024-09-03 18:01:41 --> Could not find the language line "Type"
ERROR - 2024-09-03 18:01:41 --> Could not find the language line "Category"
ERROR - 2024-09-03 18:01:41 --> Could not find the language line "Acquisition Channels"
ERROR - 2024-09-03 18:01:41 --> Could not find the language line "Desired Amount"
ERROR - 2024-09-03 18:01:41 --> Could not find the language line "Industry"
ERROR - 2024-09-03 18:01:41 --> Could not find the language line "Upload Evidence (MP3)"
ERROR - 2024-09-03 18:01:41 --> Could not find the language line "Target CRM"
ERROR - 2024-09-03 18:01:41 --> Could not find the language line "Target CRM"
ERROR - 2024-09-03 18:01:41 --> client
ERROR - 2024-09-03 18:01:41 --> 12
ERROR - 2024-09-03 18:01:41 --> client
ERROR - 2024-09-03 18:02:01 --> client
ERROR - 2024-09-03 18:02:01 --> 12
ERROR - 2024-09-03 18:02:01 --> client
ERROR - 2024-09-03 18:02:04 --> Could not find the language line "edit_crm_link"
ERROR - 2024-09-03 18:02:04 --> Could not find the language line "description"
ERROR - 2024-09-03 18:02:04 --> Could not find the language line "link"
ERROR - 2024-09-03 18:02:04 --> Could not find the language line "save_changes"
ERROR - 2024-09-03 18:02:04 --> client
ERROR - 2024-09-03 18:02:04 --> 12
ERROR - 2024-09-03 18:02:04 --> client
ERROR - 2024-09-03 18:02:30 --> client
ERROR - 2024-09-03 18:02:30 --> 12
ERROR - 2024-09-03 18:02:30 --> client
ERROR - 2024-09-03 18:02:38 --> Could not find the language line "clients_list_value"
ERROR - 2024-09-03 18:02:38 --> Could not find the language line "clients_list_tags"
ERROR - 2024-09-03 18:02:38 --> Could not find the language line "clients_list_status"
ERROR - 2024-09-03 18:02:38 --> Could not find the language line "clients_list_source"
ERROR - 2024-09-03 18:02:38 --> Could not find the language line "campaign_id"
ERROR - 2024-09-03 18:02:38 --> Could not find the language line "Stars"
ERROR - 2024-09-03 18:02:38 --> Could not find the language line "Reasons"
ERROR - 2024-09-03 18:02:38 --> Could not find the language line "Select Reason"
ERROR - 2024-09-03 18:02:38 --> Could not find the language line "Select Reason"
ERROR - 2024-09-03 18:02:38 --> Could not find the language line "Details"
ERROR - 2024-09-03 18:02:38 --> Could not find the language line "Name"
ERROR - 2024-09-03 18:02:38 --> Could not find the language line "Status"
ERROR - 2024-09-03 18:02:38 --> Could not find the language line "Type"
ERROR - 2024-09-03 18:02:38 --> Could not find the language line "Category"
ERROR - 2024-09-03 18:02:38 --> Could not find the language line "Acquisition Channels"
ERROR - 2024-09-03 18:02:38 --> Could not find the language line "Desired Amount"
ERROR - 2024-09-03 18:02:38 --> Could not find the language line "Industry"
ERROR - 2024-09-03 18:02:38 --> Could not find the language line "Upload Evidence (MP3)"
ERROR - 2024-09-03 18:02:38 --> Could not find the language line "Target CRM"
ERROR - 2024-09-03 18:02:38 --> Could not find the language line "Target CRM"
ERROR - 2024-09-03 18:02:38 --> client
ERROR - 2024-09-03 18:02:38 --> 12
ERROR - 2024-09-03 18:02:38 --> client
ERROR - 2024-09-03 18:03:50 --> Could not find the language line "Status"
ERROR - 2024-09-03 18:03:50 --> client
ERROR - 2024-09-03 18:03:50 --> 12
ERROR - 2024-09-03 18:03:50 --> client
ERROR - 2024-09-03 18:03:54 --> client
ERROR - 2024-09-03 18:03:54 --> 12
ERROR - 2024-09-03 18:03:54 --> client
ERROR - 2024-09-03 18:03:57 --> Could not find the language line "edit_crm_link"
ERROR - 2024-09-03 18:03:57 --> Could not find the language line "description"
ERROR - 2024-09-03 18:03:57 --> Could not find the language line "link"
ERROR - 2024-09-03 18:03:57 --> Could not find the language line "save_changes"
ERROR - 2024-09-03 18:03:57 --> client
ERROR - 2024-09-03 18:03:57 --> 12
ERROR - 2024-09-03 18:03:57 --> client
ERROR - 2024-09-03 18:04:04 --> client
ERROR - 2024-09-03 18:04:04 --> 12
ERROR - 2024-09-03 18:04:04 --> client
ERROR - 2024-09-03 18:04:08 --> Could not find the language line "clients_list_value"
ERROR - 2024-09-03 18:04:08 --> Could not find the language line "clients_list_tags"
ERROR - 2024-09-03 18:04:08 --> Could not find the language line "clients_list_status"
ERROR - 2024-09-03 18:04:08 --> Could not find the language line "clients_list_source"
ERROR - 2024-09-03 18:04:08 --> Could not find the language line "campaign_id"
ERROR - 2024-09-03 18:04:08 --> Could not find the language line "Stars"
ERROR - 2024-09-03 18:04:08 --> Could not find the language line "Reasons"
ERROR - 2024-09-03 18:04:08 --> Could not find the language line "Select Reason"
ERROR - 2024-09-03 18:04:08 --> Could not find the language line "Select Reason"
ERROR - 2024-09-03 18:04:08 --> Could not find the language line "Details"
ERROR - 2024-09-03 18:04:08 --> Could not find the language line "Name"
ERROR - 2024-09-03 18:04:08 --> Could not find the language line "Status"
ERROR - 2024-09-03 18:04:08 --> Could not find the language line "Type"
ERROR - 2024-09-03 18:04:08 --> Could not find the language line "Category"
ERROR - 2024-09-03 18:04:08 --> Could not find the language line "Acquisition Channels"
ERROR - 2024-09-03 18:04:08 --> Could not find the language line "Desired Amount"
ERROR - 2024-09-03 18:04:08 --> Could not find the language line "Industry"
ERROR - 2024-09-03 18:04:08 --> Could not find the language line "Upload Evidence (MP3)"
ERROR - 2024-09-03 18:04:08 --> Could not find the language line "Target CRM"
ERROR - 2024-09-03 18:04:08 --> Could not find the language line "Target CRM"
ERROR - 2024-09-03 18:04:08 --> client
ERROR - 2024-09-03 18:04:08 --> 12
ERROR - 2024-09-03 18:04:08 --> client
