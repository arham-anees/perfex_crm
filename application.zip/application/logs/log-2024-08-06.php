<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-08-06 16:10:50 --> init client assets
ERROR - 2024-08-06 16:10:50 --> init client assets
ERROR - 2024-08-06 16:10:50 --> init client assets
ERROR - 2024-08-06 16:10:50 --> init client assets
ERROR - 2024-08-06 16:10:54 --> init client assets
ERROR - 2024-08-06 16:10:54 --> init client assets
ERROR - 2024-08-06 16:10:54 --> init client assets
ERROR - 2024-08-06 16:10:54 --> init client assets
ERROR - 2024-08-06 16:11:11 --> init client assets
ERROR - 2024-08-06 16:11:11 --> init client assets
ERROR - 2024-08-06 16:11:11 --> init client assets
ERROR - 2024-08-06 16:11:11 --> init client assets
ERROR - 2024-08-06 16:11:11 --> Could not find the language line "New Campaign"
ERROR - 2024-08-06 16:11:23 --> init client assets
ERROR - 2024-08-06 16:11:23 --> init client assets
ERROR - 2024-08-06 16:11:23 --> Could not find the language line "New Campaign"
ERROR - 2024-08-06 16:11:23 --> Could not find the language line "Name"
ERROR - 2024-08-06 16:11:23 --> Could not find the language line "Description"
ERROR - 2024-08-06 16:11:23 --> Could not find the language line "Active"
ERROR - 2024-08-06 16:11:23 --> Could not find the language line "Actions"
ERROR - 2024-08-06 16:11:23 --> Severity: error --> Exception: Cannot use object of type stdClass as array /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/views/themes/perfex/views/clients/campaigns/campaign.php 30
ERROR - 2024-08-06 16:11:28 --> init client assets
ERROR - 2024-08-06 16:11:28 --> init client assets
ERROR - 2024-08-06 16:11:28 --> Could not find the language line "New Campaign"
ERROR - 2024-08-06 16:11:31 --> init client assets
ERROR - 2024-08-06 16:11:31 --> init client assets
ERROR - 2024-08-06 16:11:31 --> Could not find the language line "Onboarding"
ERROR - 2024-08-06 16:11:31 --> Could not find the language line "Onboarding"
ERROR - 2024-08-06 16:11:31 --> Could not find the language line "Invite Friend"
ERROR - 2024-08-06 16:11:31 --> Could not find the language line "Join our private Facebook group"
ERROR - 2024-08-06 16:11:31 --> Could not find the language line "group dedicated specifically for ambassadors. In the group, you'll get access to other successful ambassadors, learn the latest marketing strategies, get help from our support team, and stay informed on all the latest product updates."
ERROR - 2024-08-06 16:11:31 --> Could not find the language line "Sign Up for Alerts"
ERROR - 2024-08-06 16:11:31 --> Could not find the language line "Sign up for our email alerts to stay informed about the latest updates, opportunities, and important information."
ERROR - 2024-08-06 16:11:31 --> Could not find the language line "Video Coming Soon..."
ERROR - 2024-08-06 16:11:31 --> Could not find the language line "Complete and Continue"
ERROR - 2024-08-06 16:11:31 --> Could not find the language line "Continue"
ERROR - 2024-08-06 16:11:31 --> Could not find the language line "Onboarding Progress"
ERROR - 2024-08-06 16:11:31 --> Could not find the language line "Watch welcome message"
ERROR - 2024-08-06 16:11:31 --> Could not find the language line "Join Facebook group"
ERROR - 2024-08-06 16:11:31 --> Could not find the language line "Sign up for email alerts"
ERROR - 2024-08-06 16:11:31 --> Could not find the language line "Watch portal walkthrough"
ERROR - 2024-08-06 16:11:31 --> Could not find the language line "Understand the opportunity"
ERROR - 2024-08-06 16:11:31 --> Could not find the language line "Review available products"
ERROR - 2024-08-06 16:11:31 --> Could not find the language line "Sign Up for Alerts"
ERROR - 2024-08-06 16:11:31 --> Could not find the language line "<i class="fa fa-exclamation-circle tw-mr-1"></i> We'll never send marketing emails through these alerts. These email alerts are strictly to inform you about Ambassador Program latest updates."
ERROR - 2024-08-06 16:11:31 --> Could not find the language line "Sign Up and Continue"
ERROR - 2024-08-06 16:11:34 --> init client assets
ERROR - 2024-08-06 16:11:34 --> init client assets
ERROR - 2024-08-06 16:11:34 --> Could not find the language line "Meet Industry's Most Advanced Real Estate Lead Marketplace"
ERROR - 2024-08-06 16:11:34 --> Could not find the language line "Buy Lead"
ERROR - 2024-08-06 16:11:34 --> Could not find the language line "Learn More"
ERROR - 2024-08-06 16:11:34 --> Could not find the language line "Industry"
ERROR - 2024-08-06 16:11:34 --> Could not find the language line "Price Range"
ERROR - 2024-08-06 16:11:34 --> Could not find the language line "Location"
ERROR - 2024-08-06 16:11:34 --> Could not find the language line "Learn More"
ERROR - 2024-08-06 16:11:43 --> init client assets
ERROR - 2024-08-06 16:11:43 --> init client assets
ERROR - 2024-08-06 16:11:43 --> init client assets
ERROR - 2024-08-06 16:11:43 --> init client assets
ERROR - 2024-08-06 16:12:00 --> Could not find the language line "appointment_appointments"
ERROR - 2024-08-06 16:12:00 --> Could not find the language line "appointment_you_have_new_appointment"
ERROR - 2024-08-06 16:12:00 --> Could not find the language line "appointment_you_have_new_appointment"
ERROR - 2024-08-06 16:12:00 --> Could not find the language line "appointment_you_have_new_appointment"
ERROR - 2024-08-06 13:12:00 --> 404 Page Not Found: /index
ERROR - 2024-08-06 16:12:01 --> Could not find the language line "appointment_appointments"
ERROR - 2024-08-06 16:12:02 --> Could not find the language line "appointment_appointments"
ERROR - 2024-08-06 16:19:48 --> init client assets
ERROR - 2024-08-06 16:19:48 --> init client assets
ERROR - 2024-08-06 16:19:48 --> Could not find the language line "New Campaign"
ERROR - 2024-08-06 16:19:48 --> Could not find the language line "Name"
ERROR - 2024-08-06 16:19:48 --> Could not find the language line "Description"
ERROR - 2024-08-06 16:19:48 --> Could not find the language line "Active"
ERROR - 2024-08-06 16:19:48 --> Could not find the language line "Actions"
ERROR - 2024-08-06 16:19:48 --> Severity: error --> Exception: Cannot use object of type stdClass as array /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/views/themes/perfex/views/clients/campaigns/campaign.php 30
ERROR - 2024-08-06 16:19:51 --> init client assets
ERROR - 2024-08-06 16:19:51 --> init client assets
ERROR - 2024-08-06 16:19:51 --> Could not find the language line "New Campaign"
ERROR - 2024-08-06 16:19:51 --> Could not find the language line "Name"
ERROR - 2024-08-06 16:19:51 --> Could not find the language line "Description"
ERROR - 2024-08-06 16:19:51 --> Could not find the language line "Active"
ERROR - 2024-08-06 16:19:51 --> Could not find the language line "Actions"
ERROR - 2024-08-06 16:19:51 --> Severity: error --> Exception: Cannot use object of type stdClass as array /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/views/themes/perfex/views/clients/campaigns/campaign.php 30
ERROR - 2024-08-06 16:20:32 --> init client assets
ERROR - 2024-08-06 16:20:32 --> init client assets
ERROR - 2024-08-06 16:20:32 --> Could not find the language line "New Campaign"
ERROR - 2024-08-06 16:20:32 --> Could not find the language line "Name"
ERROR - 2024-08-06 16:20:32 --> Could not find the language line "Description"
ERROR - 2024-08-06 16:20:32 --> Could not find the language line "Active"
ERROR - 2024-08-06 16:20:32 --> Could not find the language line "Actions"
ERROR - 2024-08-06 16:20:32 --> Severity: error --> Exception: Cannot use object of type stdClass as array /Applications/XAMPP/xamppfiles/htdocs/perfex_crm/application/views/themes/perfex/views/clients/campaigns/campaign.php 34
ERROR - 2024-08-06 16:20:50 --> init client assets
ERROR - 2024-08-06 16:20:50 --> init client assets
ERROR - 2024-08-06 16:20:50 --> Could not find the language line "New Campaign"
ERROR - 2024-08-06 16:20:50 --> Could not find the language line "Name"
ERROR - 2024-08-06 16:20:50 --> Could not find the language line "Description"
ERROR - 2024-08-06 16:20:50 --> Could not find the language line "Active"
ERROR - 2024-08-06 16:20:50 --> Could not find the language line "Actions"
