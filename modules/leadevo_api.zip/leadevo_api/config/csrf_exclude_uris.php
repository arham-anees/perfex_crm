<?php defined('BASEPATH') or exit('No direct script access allowed');

return ['leadevo_api/receive'];